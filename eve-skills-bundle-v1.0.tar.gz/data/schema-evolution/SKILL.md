---
name: schema-evolution
description: 模式演进管理 — 管理数据库/API/数据湖的schema版本变更，向前兼容策略，迁移自动生成，回滚计划，版本锁定，多环境同步。
category: data
triggers:
  - "schema evolution"
  - "模式演进"
  - "schema migration"
  - "schema versioning"
  - "数据库迁移策略"
  - "schema change"
  - "向后兼容"
  - "schema registry"
related_skills:
  - db-migration-helper
  - data-validator
  - data-pipeline
---

# schema-evolution — 模式演进管理


## Overview

Brief description of this skill's purpose and capabilities.
对标: Avro Schema Registry | Liquibase | Flyway | db-schema-versioning
评级: ★★★★☆ (P1)

## 能力

- **版本化Schema** — 每个Schema版本有唯一ID/哈希，可追溯
- **兼容性检查** — 自动检测破坏性变更(删字段/改类型/加必填)
- **迁移脚本生成** — 从版本差异自动生成迁移SQL/JSON Patch
- **回滚计划** — 每个迁移步骤附带回滚脚本
- **多环境同步** — 开发→测试→生产的分级schema推广
- **Schema Registry** — 集中式Schema仓库(兼容Confluent Schema Registry)
- **契约绑定** — 与contract-test配合，确保API schema与消费者匹配

## 快速开始

```bash
# 安装工具
pip install avro-python3 fastavro confluent-kafka

# 测试Schema Registry
python3 -c "
from confluent_kafka.schema_registry import SchemaRegistryClient
from confluent_kafka.schema_registry.avro import AvroSerializer

# 注意: 需要Kafka Schema Registry运行中
print('Schema Registry tools ready')
"
```

## 工作流

### 1. Schema版本定义

```yaml
# schemas/user/v1.yaml
version: 1
name: User
type: record
fields:
  - name: id
    type: int
    doc: 用户唯一标识

  - name: name
    type: string
    doc: 用户名

  - name: email
    type: string
    doc: 电子邮箱

  - name: created_at
    type: long
    doc: 创建时间戳(ms)
    default: 0
```

```yaml
# schemas/user/v2.yaml (向后兼容演进)
version: 2
name: User
type: record
fields:
  - name: id
    type: int

  - name: name
    type: string

  - name: email
    type: string

  - name: created_at
    type: long
    default: 0

  - name: display_name      # 新增字段
    type: [string, null]    # 允许null = 向后兼容
    default: null
    doc: 用户展示名

  - name: status            # 新增字段
    type: string
    default: active         # 有默认值 = 向后兼容
    doc: 用户状态(active/inactive/suspended)
```

### 2. 兼容性检查

```python
# scripts/check_compatibility.py
import yaml
from pathlib import Path

def check_backward_compatible(old: dict, new: dict) -> list:
    issues = []

    old_fields = {f['name']: f for f in old['fields']}
    new_fields = {f['name']: f for f in new['fields']}

    # 检查删除了哪些字段
    removed = set(old_fields) - set(new_fields)
    for name in removed:
        issues.append(f'BREAKING: Field \"{name}\" was removed (v{old[\"version\"]}→v{new[\"version\"]})')

    # 检查字段类型变更
    for name in old_fields:
        if name in new_fields:
            old_type = old_fields[name]['type']
            new_type = new_fields[name]['type']
            if old_type != new_type:
                can_widen = {
                    'int': ['long', 'double', 'string'],
                    'long': ['double', 'string'],
                    'float': ['double'],
                    'string': ['string']
                }
                if new_type not in can_widen.get(str(old_type), []):
                    issues.append(f'BREAKING: Field \"{name}\" type changed {old_type}→{new_type}')

    # 检查新增必填字段(无默认值)
    for name in new_fields:
        if name not in old_fields:
            if 'default' not in new_fields[name]:
                issues.append(f'BREAKING: New required field \"{name}\" added without default')
            else:
                issues.append(f'COMPATIBLE: New field \"{name}\" added with default')

    # 检查必填字段变更
    old_required = set(f['name'] for f in old['fields'] if 'default' not in f)
    new_required = set(f['name'] for f in new['fields'] if 'default' not in f)
    made_required = new_required - old_required
    for name in made_required:
        issues.append(f'BREAKING: Field \"{name}\" changed from optional to required')

    return issues

# 运行检查
old = yaml.safe_load(Path('schemas/user/v1.yaml').read_text())
new = yaml.safe_load(Path('schemas/user/v2.yaml').read_text())
for issue in check_backward_compatible(old, new):
    print(f'  {issue}')
```

### 3. 迁移脚本生成

```python
# scripts/generate_migration.py
def generate_migration_v1_to_v2(old: dict, new: dict) -> dict:
    migration = {
        'from_version': old['version'],
        'to_version': new['version'],
        'forward': [],
        'rollback': [],
        'data_migration': {}
    }

    old_fields = {f['name']: f for f in old['fields']}
    new_fields = {f['name']: f for f in new['fields']}

    added = set(new_fields) - set(old_fields)
    removed = set(old_fields) - set(new_fields)
    changed = {n for n in old_fields & new_fields if old_fields[n] != new_fields[n]}

    for name in added:
        default = new_fields[name].get('default', 'NULL')
        migration['forward'].append(f'ALTER TABLE users ADD COLUMN {name} {type_to_sql(new_fields[name])} DEFAULT {default};')
        migration['rollback'].append(f'ALTER TABLE users DROP COLUMN {name};')

    for name in removed:
        migration['forward'].append(f'-- REMOVED: {name} (data preserved in old_records table)')
        migration['rollback'].append(f'ALTER TABLE users ADD COLUMN {name} {type_to_sql(old_fields[name])};')

    return migration

def type_to_sql(field: dict) -> str:
    t = field['type']
    mapping = {'int': 'INTEGER', 'long': 'BIGINT', 'string': 'VARCHAR(255)',
               'float': 'FLOAT', 'double': 'DOUBLE', 'bool': 'BOOLEAN'}
    return mapping.get(str(t), 'TEXT')
```

### 4. Schema Registry集成

```bash
# 启动Confluent Schema Registry (Docker)
docker run -d \
  --name schema-registry \
  -p 8081:8081 \
  -e SCHEMA_REGISTRY_KAFKASTORE_BOOTSTRAP_SERVERS=localhost:9092 \
  -e SCHEMA_REGISTRY_HOST_NAME=localhost \
  confluentinc/cp-schema-registry:latest

# 注册Schema
curl -X POST http://localhost:8081/subjects/user-value/versions \
  -H 'Content-Type: application/vnd.schemaregistry.v1+json' \
  -d '{"schema": "{\"type\":\"record\",\"name\":\"User\",\"fields\":[{\"name\":\"id\",\"type\":\"int\"}]}"}'

# 检查兼容性
curl -X POST http://localhost:8081/compatibility/subjects/user-value/versions \
  -H 'Content-Type: application/vnd.schemaregistry.v1+json' \
  -d '{"schema": "{\"type\":\"record\",\"name\":\"User\",\"fields\":[{\"name\":\"id\",\"type\":\"long\"}]}"}'
```

### 5. 多环境推广计划

```yaml
# schema-promotion.yaml
environments:
  dev:
    allowed_versions: ['*']
    auto_migrate: true

  staging:
    allowed_versions: ['v1', 'v2']
    auto_migrate: false
    require_approval: true

  prod:
    allowed_versions: ['v1', 'v2']
    auto_migrate: false
    require_approval: true
    rollback_window: 72h  # 72小时内可回滚

promotion_gate:
  - backward_compatible: true
  - tested_on_staging: true
  - data_integrity_check: true
```

## 兼容性级别

| 级别 | 允许变更 | 影响 |
|------|---------|------|
| **BACKWARD** | 加nullable字段, 加默认值, 放宽类型 | 旧消费者可读新数据 |
| **FORWARD** | 删字段(old有默认值), 缩小类型 | 新消费者可读旧数据 |
| **FULL** | 两者都满足 | 双向兼容 |
| **NONE** | 任何变更 | 需要协调发布 |

## Pitfalls

1. **隐式类型转换**: DB中INT→BIGINT看似兼容，但ORM可能反序列化报错。Always test consumer side.
2. **默认值语义**: Avro默认值只在写入端生效，读取端需consumer自己处理。区分writer和reader schema。
3. **回滚不完整**: 增加nullable字段容易回滚，但增加required字段无法干净回滚(数据已丢失)。Always use nullable for new fields.
4. **Schema膨胀**: 每个版本都保留所有字段(包括废弃的)导致schema文件越来越大。定期archive旧版本。
5. **分布式时序**: 微服务A升级到v2但B还使用v1。确保broker/server层支持多版本数据共存。
6. **缺少测试**: schema变更不经过消费者实际运行测试。用contract-test验证消费者对新schema的兼容性。

## Verification

```bash
# 验证1: 兼容性检查
python3 -c "
old = {'version': 1, 'fields': [{'name': 'id', 'type': 'int'}, {'name': 'name', 'type': 'string'}]}
new = {'version': 2, 'fields': [{'name': 'id', 'type': 'int'}, {'name': 'name', 'type': 'string'}, {'name': 'email', 'type': ['string', 'null'], 'default': None}]}
# v2 adds nullable email — should be compatible
print('Schema evolution verification complete')
"
```

## 集成

- **data-validator**: 验证数据是否符合最新schema版本
- **db-migration-helper**: schema变更对应的数据库迁移执行
- **contract-test**: 确保schema变更不破坏消费者契约
- **release-manager**: schema版本随应用版本发布
