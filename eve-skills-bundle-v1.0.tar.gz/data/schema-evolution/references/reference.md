# schema-evolution — Reference

## Overview
模式演进管理 — 管理数据库/API/数据湖的schema版本变更，向前兼容策略，迁移自动生成，回滚计划，版本锁定，多环境同步。

## Integration Points
- Hermes Agent skill ecosystem
- evolution_engine.py scoring system
- self-audit verification

## Key Resources
- SKILL.md: main skill definition
- scripts/: executable code (if present)
