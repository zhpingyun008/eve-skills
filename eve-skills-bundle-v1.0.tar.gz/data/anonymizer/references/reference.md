# anonymizer — Reference

## Overview
数据脱敏 — 自动检测并脱敏PII/敏感数据，支持静态脱敏(数据库/文件)和动态脱敏(API层)。多策略：遮蔽/泛化/替换/扰动/k-匿名/l-多样性。

## Integration Points
- Hermes Agent skill ecosystem
- evolution_engine.py scoring system
- self-audit verification

## Key Resources
- SKILL.md: main skill definition
- scripts/: executable code (if present)
