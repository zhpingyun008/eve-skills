---
name: anonymizer
description: 数据脱敏 — 自动检测并脱敏PII/敏感数据，支持静态脱敏(数据库/文件)和动态脱敏(API层)。多策略：遮蔽/泛化/替换/扰动/k-匿名/l-多样性。
category: data
triggers:
  - "anonymize"
  - "数据脱敏"
  - "data masking"
  - "PII detection"
  - "脱敏"
  - "data obfuscation"
  - "数据匿名化"
  - "differential privacy"
  - "k-anonymity"
related_skills:
  - data-validator
  - secret-scanner
  - compliance-checker
---

# anonymizer — 数据脱敏框架


## Overview

Brief description of this skill's purpose and capabilities.
对标: Presidio | ARX Data Anonymization Tool | Faker | Oracle Data Masking
评级: ★★★★☆ (P1)

## 能力

- **自动PII检测** — 基于正则+NER模型自动识别姓名/身份证/手机/邮箱/地址/信用卡等
- **多策略脱敏** — 遮蔽、替换、泛化、扰动、k-匿名、差分隐私
- **多格式输入** — CSV/JSON/SQL/Parquet/API响应
- **静态+动态脱敏** — 批量文件脱敏 + API代理实时脱敏
- **审计日志** — 记录每次脱敏操作、策略、受影响字段
- **可逆脱敏** — 支持可逆加密脱敏(需密钥，用于测试环境)

## 快速开始

```bash
# 安装
pip install presidio-analyzer presidio-anonymizer faker

# 下载NER模型
python3 -m spacy download en_core_web_lg

# 基本PII检测
python3 -c "
from presidio_analyzer import AnalyzerEngine
analyzer = AnalyzerEngine()
text = 'My name is Alice and my email is alice@example.com, phone: +1-555-123-4567'
results = analyzer.analyze(text=text, language='en')
for r in results:
    print(f'  {r.entity_type}: {text[r.start:r.end]} (score={r.score:.2f})')
"
```

## 工作流

### 1. PII自动检测

```python
# scripts/detect_pii.py
import json
import re
from pathlib import Path

class PIDetector:
    PATTERNS = {
        'email': r'[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+',
        'phone': r'\+?[\d\-\(\) ]{7,20}',
        'ssn': r'\d{3}-\d{2}-\d{4}',
        'credit_card': r'\b(?:\d[ -]*?){13,16}\b',
        'ip_address': r'\b(?:\d{1,3}\.){3}\d{1,3}\b',
        'chinese_id': r'\b[1-9]\d{5}(?:19|20)\d{2}(?:0[1-9]|1[0-2])(?:0[1-9]|[12]\d|3[01])\d{3}[\dXx]\b',
        'chinese_phone': r'1[3-9]\d{9}',
    }

    def detect(self, text: str) -> list:
        found = []
        for entity_type, pattern in self.PATTERNS.items():
            for match in re.finditer(pattern, text):
                found.append({
                    'entity_type': entity_type,
                    'value': match.group(),
                    'start': match.start(),
                    'end': match.end()
                })
        return found

    def detect_in_json(self, data: dict, path: str = '') -> list:
        results = []
        if isinstance(data, str):
            for item in self.detect(data):
                item['path'] = path
                results.append(item)
        elif isinstance(data, dict):
            for key, value in data.items():
                results.extend(self.detect_in_json(value, f'{path}.{key}'))
        elif isinstance(data, list):
            for i, item in enumerate(data):
                results.extend(self.detect_in_json(item, f'{path}[{i}]'))
        return results
```

### 2. 脱敏策略

```python
# scripts/anonymize.py
import json
import hashlib
import random
from faker import Faker

fake = Faker()

class Anonymizer:
    STRATEGIES = {
        'mask': lambda v, cfg: v[:cfg.get('visible_chars', 2)] + '*' * (len(v) - cfg.get('visible_chars', 2)),
        'replace': lambda v, cfg: str(cfg.get('replacement', '[REDACTED]')),
        'hash': lambda v, cfg: hashlib.sha256(v.encode()).hexdigest()[:16],
        'faker': lambda v, cfg: getattr(fake, cfg.get('faker_method', 'name'))(),
        'shift': lambda v, cfg: str(int(v) + random.randint(-cfg['range'], cfg['range'])) if v.isdigit() else v,
        'generalize': lambda v, cfg: generalize_value(v, cfg),
        'encrypt': lambda v, cfg: encrypt_value(v, cfg.get('key')),  # 可逆加密
    }

    def __init__(self, config_path: str):
        with open(config_path) as f:
            self.config = json.load(f)

    def anonymize_record(self, record: dict) -> dict:
        result = record.copy()
        for field_config in self.config['fields']:
            path_parts = field_config['field'].split('.')
            value = self._get_nested(result, path_parts)
            if value and field_config['strategy'] in self.STRATEGIES:
                new_value = self.STRATEGIES[field_config['strategy']](str(value), field_config)
                self._set_nested(result, path_parts, new_value)
        return result

    def _get_nested(self, data, keys):
        current = data
        for key in keys:
            if isinstance(current, dict):
                current = current.get(key)
            else:
                return None
        return current

    def _set_nested(self, data, keys, value):
        current = data
        for key in keys[:-1]:
            if isinstance(current, dict):
                current = current.setdefault(key, {})
        current[keys[-1]] = value
```

### 3. 脱敏配置

```yaml
# config/anonymize_rules.yaml
fields:
  # 完全遮蔽
  - field: user.ssn
    strategy: mask
    visible_chars: 4
    # 123-45-6789 → *******6789

  # 替换为固定值
  - field: user.password
    strategy: replace
    replacement: "[REDACTED]"

  # 用Faker替换
  - field: user.name
    strategy: faker
    faker_method: name

  - field: user.email
    strategy: faker
    faker_method: email

  - field: user.address
    strategy: faker
    faker_method: address

  # 哈希(单向)
  - field: user.id_number
    strategy: hash

  # 数值扰动(±1-5)
  - field: salary
    strategy: shift
    range: 5

  # 年龄泛化
  - field: age
    strategy: generalize
    bucket: 10
    # 27 → 20-30

  # 可逆加密
  - field: phone
    strategy: encrypt
    key: "${ANON_KEY}"

  # 全部替换(text字段全局替换)
  - entity_type: credit_card
    strategy: replace
    replacement: "****-****-****-%04d"
```

### 4. 批量处理

```bash
# 批量脱敏CSV
python3 -c "
import pandas as pd
from anonymizer import Anonymizer

anon = Anonymizer('config/anonymize_rules.yaml')
df = pd.read_csv('users.csv')

pii_fields = ['name', 'email', 'phone', 'ssn']
for field in pii_fields:
    if field in df.columns:
        df[field] = df[field].apply(lambda v: anon.anonymize_record({field: v})[field])

df.to_csv('users_anonymized.csv', index=False)
print(f'Anonymized {len(df)} records')
"

# 批量脱敏JSON Lines
python3 anonymize.py --input data/users.jsonl --output data/users_anonymized.jsonl --config config/anonymize_rules.yaml
```

### 5. 动态脱敏API代理

```python
# FastAPI中间件实现动态脱敏
from fastapi import FastAPI, Request
from anonymizer import Anonymizer
import json

app = FastAPI()
anonymizer = Anonymizer('config/anonymize_rules.yaml')

@app.middleware('http')
async def anonymize_response(request: Request, call_next):
    response = await call_next(request)

    if response.status_code == 200 and '/api/users' in request.url.path:
        body = json.loads(response.body)
        if isinstance(body, list):
            body = [anonymizer.anonymize_record(u) for u in body]
        elif isinstance(body, dict):
            body = anonymizer.anonymize_record(body)
        # 需要重写response
    return response
```

### 6. k-匿名实现

```python
# scripts/k_anonymity.py
import pandas as pd
import numpy as np

def apply_k_anonymity(df: pd.DataFrame, quasi_identifiers: list, k: int = 5) -> pd.DataFrame:
    """
    对准标识符列应用泛化，确保每个组合至少出现k次
    """
    result = df.copy()

    for col in quasi_identifiers:
        if df[col].dtype in ['int64', 'float64']:
            # 数值型: 桶泛化
            bins = min(10, df[col].nunique())
            result[col] = pd.cut(df[col], bins=bins, labels=[f'{i*10}-{(i+1)*10}' for i in range(bins)])
        else:
            # 分类型: 高频保留，低频合并
            freq = df[col].value_counts()
            threshold = len(df) * 0.05  # 5% threshold
            rare = freq[freq < threshold].index
            result[col] = result[col].apply(lambda v: 'OTHER' if v in rare else v)

    # 验证k-匿名性
    group_counts = result.groupby(quasi_identifiers).size()
    min_k = group_counts.min()
    print(f'k-anonymity: k={min_k} (target: k={k})')

    if min_k < k:
        warnings.warn(f'k-anonymity not met (k={min_k} < {k}). Apply more aggressive generalization.')

    return result

# 使用示例
df = pd.read_csv('users.csv)
qi_cols = ['age', 'zipcode', 'gender']
df_anon = apply_k_anonymity(df, qi_cols, k=5)
df_anon.to_csv('users_k5_anonymous.csv', index=False)
```

## 脱敏策略对比

| 策略 | 保护强度 | 可用性 | 可逆 | 适用 |
|------|---------|--------|------|------|
| **遮蔽** | ★★★★★ | ★★ | ❌ | SSN/密码 |
| **替换** | ★★★★★ | ★ | ❌ | 测试数据 |
| **Faker** | ★★★★ | ★★★★★ | ❌ | 开发/测试 |
| **哈希** | ★★★★ | ★★★ | ❌ | ID关联 |
| **扰动** | ★★★ | ★★★★ | ❌ | 数值分析 |
| **泛化** | ★★ | ★★★★ | ❌ | 统计分析 |
| **k-匿名** | ★★★★ | ★★★ | ❌ | 发布数据 |
| **加密** | ★★★★★ | ★★★★★ | ✅ | 受控环境 |

## Pitfalls

1. **PII遗漏**: 正则漏掉非标准格式。结合NER+正则两层检测，人工抽查10%样本。
2. **过度脱敏**: 把所有字段全部遮蔽导致数据不可用。保持分析所需字段的语义可用性。
3. **重识别攻击**: 单纯遮蔽/替换不能防止链接攻击。对发布数据使用k-匿名/差分隐私。
4. **差分隐私噪音**: 太多噪声使聚合结果不可靠。根据所需精度调整epsilon参数。
5. **时间戳/ID保留**: 脱敏了name但保留了timestamp+zipcode+gender仍可重识别。用准标识符检测工具。
6. **JSON嵌套**: 深层嵌套JSON无法遍历所有字段。用递归遍历+路径白名单。
7. **性能开销**: 实时脱敏API增加10-50ms延迟。使用缓存+异步处理。

## Verification

```bash
# 验证1: PII检测能力
python3 -c "
from anonymizer import PIDetector
detector = PIDetector()

test_text = '''
Alice Johnson, alice@corp.com, +1-555-123-4567
Credit Card: 4111-1111-1111-1111
SSN: 123-45-6789
IP: 192.168.1.1
'''

results = detector.detect(test_text)
print(f'Detected {len(results)} PII items:')
for r in results:
    print(f'  [{r[\"entity_type\"]}] {r[\"value\"]}')
assert len(results) >= 4, f'Expected 4+ PII items, got {len(results)}'
print('PII detection verification: PASSED')
"

# 验证2: 脱敏后PII残留检查(重复检测)
python3 -c "
anonymized_text = '[REDACTED] [REDACTED] [REDACTED]'
from anonymizer import PIDetector
detector = PIDetector()
assert len(detector.detect(anonymized_text)) == 0
print('Anonymization verification: PASSED (no PII leaked)')
"
echo 'Anonymizer verification complete'
```

## 集成

- **compliance-checker**: 脱敏合规(GDPR/HIPAA/PCI-DSS)
- **secret-scanner**: 代码仓库中的硬编码敏感数据处理
- **data-validator**: 脱敏后数据质量验证
- **data-pipeline**: ETL流水线中嵌入脱敏步骤
