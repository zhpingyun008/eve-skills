---
name: data-validator
description: 数据验证框架 + 数据集质量验证 — 声明式数据验证规则引擎(JSON Schema/YAML/CSV)，数据集质量检查(缺失值/异常值/标签错误/数据泄露/分布偏移/偏见)，批量验证与报告生成。
category: data
triggers:
  - "data validate"
  - "数据验证"
  - "schema validation"
  - "validate schema"
  - "json schema validate"
  - "数据校验"
  - "data integrity check"
  - "csv validate"
  - "dataset validate"
  - "data quality check"
  - "clean data"
  - "数据质量检查"
  - "偏见识別"
  - "data drift"
  - "dataset bias"
  - "data leakage check"
related_skills:
  - schema-evolution
  - db-migration-helper
  - experiment-tracker
  - ml-pipeline
---

# data-validator — 数据验证框架


## Overview

Brief description of this skill's purpose and capabilities.
对标: Great Expectations | JSON Schema | Apache Griffin | Soda Core
评级: ★★★★★ (P1)

## 能力

- **声明式规则** — YAML/JSON定义验证规则，无需写代码
- **多格式支持** — JSON/YAML/CSV/Parquet/Avro/Protobuf
- **链式验证** — 串联多个验证规则，短路或全量模式
- **批量处理** — 对10万+记录的数据集并行验证
- **报告生成** — HTML/JSON/Markdown格式验证报告
- **阈值设置** — 允许配置通过/警告/失败阈值百分比
- **计划集成** — 作为数据管道pre-check/ETL验证步骤

## 快速开始

```bash
# 安装依赖
pip install jsonschema pyyaml cerberus pandera

# 基本JSON Schema验证
python3 -c "
import json, jsonschema

schema = {
    'type': 'object',
    'properties': {
        'name': {'type': 'string', 'minLength': 1},
        'email': {'type': 'string', 'pattern': '^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\\\\.[a-zA-Z0-9-.]+$'},
        'age': {'type': 'integer', 'minimum': 0, 'maximum': 150}
    },
    'required': ['name', 'email']
}

data = {'name': 'Alice', 'email': 'alice@example.com', 'age': 30}
jsonschema.validate(instance=data, schema=schema)
print('Validation passed!')
"
```

## 工作流

### 1. 定义验证规则

```yaml
# rules/user_data.yaml
rules:
  - name: required_fields
    type: required
    fields: [name, email, age, role]

  - name: email_format
    type: pattern
    field: email
    pattern: '^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$'
    severity: error

  - name: age_range
    type: range
    field: age
    min: 0
    max: 150
    severity: error

  - name: role_enum
    type: enum
    field: role
    values: [admin, user, moderator, viewer]
    severity: warning

  - name: name_length
    type: length
    field: name
    min: 1
    max: 100
    severity: error

  - name: phone_optional_format
    type: pattern
    field: phone
    pattern: '^\+?[0-9\-\(\) ]{7,20}$'
    severity: warning
    nullable: true
```

### 2. 运行验证

```python
# scripts/validate_data.py
import json
import yaml
import sys
from pathlib import Path

def validate_with_rules(data_path: str, rules_path: str) -> dict:
    with open(rules_path) as f:
        config = yaml.safe_load(f)

    with open(data_path) as f:
        data = json.load(f) if data_path.endswith('.json') else yaml.safe_load(f)

    results = {'total': len(data), 'passed': 0, 'failed': 0, 'errors': []}

    for record in data:
        record_errors = []
        for rule in config['rules']:
            error = apply_rule(rule, record)
            if error:
                record_errors.append(error)

        if record_errors:
            results['failed'] += 1
            results['errors'].append({'record': record.get('id', '?'), 'issues': record_errors})
        else:
            results['passed'] += 1

    return results

def apply_rule(rule: dict, record: dict):
    field = rule.get('field')
    value = record.get(field)
    severity = rule.get('severity', 'error')

    # nullable check
    if value is None and rule.get('nullable'):
        return None

    if rule['type'] == 'required' and field not in record:
        return {'rule': rule['name'], 'message': f'Missing required field: {field}', 'severity': severity}

    if value is None:
        return None

    if rule['type'] == 'pattern':
        import re
        if not re.match(rule['pattern'], str(value)):
            return {'rule': rule['name'], 'message': f'{field} does not match pattern', 'severity': severity}

    if rule['type'] == 'range':
        if value < rule['min'] or value > rule['max']:
            return {'rule': rule['name'], 'message': f'{field}={value} outside range [{rule["min"]}, {rule["max"]}]', 'severity': severity}

    if rule['type'] == 'enum':
        if value not in rule['values']:
            return {'rule': rule['name'], 'message': f'{field}={value} not in allowed values', 'severity': severity}

    if rule['type'] == 'length':
        if len(str(value)) < rule['min'] or len(str(value)) > rule['max']:
            return {'rule': rule['name'], 'message': f'{field} length={len(str(value))} outside [{rule["min"]}, {rule["max"]}]', 'severity': severity}

    return None

if __name__ == '__main__':
    results = validate_with_rules(sys.argv[1], sys.argv[2])
    print(f'Total: {results["total"]}, Passed: {results["passed"]}, Failed: {results["failed"]}')
    for err in results['errors'][:5]:
        print(f'  [{err["record"]}] {err["issues"]}')

    # Generate report
    report = f'''# Data Validation Report
- **Total Records**: {results["total"]}
- **Passed**: {results["passed"]} ({results["passed"]/results["total"]*100:.1f}%)
- **Failed**: {results["failed"]} ({results["failed"]/results["total"]*100:.1f}%)
'''
    Path('validation_report.md').write_text(report)
    print(f'Report written to validation_report.md')
```

### 3. 数据管道集成

```python
# Apache Airflow / Prefect 集成
from prefect import task, Flow

@task
def validate_source_data(data_path: str, rules_path: str):
    results = validate_with_rules(data_path, rules_path)
    threshold = 0.95  # 95% pass threshold
    if results['failed'] / results['total'] > (1 - threshold):
        raise ValueError(f'Data quality threshold not met: {results["failed"]}/{results["total"]} failed')
    return True

@task
def transform_data():
    # ETL transformation
    pass

with Flow('etl-pipeline') as flow:
    validated = validate_source_data('/data/input/users.json', '/rules/user_data.yaml')
    transform_data(upstream_tasks=[validated])
```

## 规则引擎对比

| 工具 | 最佳场景 | 声明式 | 性能 | 复杂度 |
|------|---------|--------|------|--------|
| **JSON Schema** | API请求/响应验证 | ✅ 全声明式 | ⚡ 快速 | 低 |
| **Cerberus** | Python dict/JSON验证 | ✅ YAML/代码 | ⚡ 快速 | 低 |
| **Pandera** | DataFrame/CSV验证 | ✅ 装饰器/代码 | 🔄 中等 | 中 |
| **Great Expectations** | 数据管道质量门禁 | ✅ YAML | 🐢 较重 | 高 |
| **Soda Core** | DB/数据湖验证 | ✅ YAML | 🔄 中等 | 中 |

## Pitfalls

1. **性能瓶颈**: 对100万+记录应用10+条规则可能很慢。使用抽样或分批验证。
2. **规则冲突**: 两条规则对同一字段有矛盾约束。验证前做规则冲突检测。
3. **类型推断问题**: CSV加载时年龄`"050"`可能解析为数字`50`或字符串`"050"`。预定义数据类型。
4. **null vs 空字符串**: `""`不等于`null`。在规则中明确区分可空和空字符串。
5. **假阳性警告**: 枚举值验证对新业务场景过于严格。保持枚举可扩展或使用预警模式。
6. **阈值选择**: 通过率设100%会导致每次数据更新都失败。根据数据质量基线设置合理阈值。

## Verification

```bash
# 验证1: 用JSON Schema验证一个有效和一个无效记录
python3 -c "
import json, jsonschema

schema = {'type': 'object', 'properties': {'id': {'type': 'integer'}}, 'required': ['id']}
valid = {'id': 1}
invalid = {'name': 'test'}

jsonschema.validate(valid, schema)  # passes
try:
    jsonschema.validate(invalid, schema)
    print('ERROR: Should have raised')
except jsonschema.ValidationError as e:
    print(f'Correctly rejected: {e.message}')
"
echo 'Data validator verification complete'
```

## 集成

- **schema-evolution**: 验证数据是否匹配最新schema版本
- **db-migration-helper**: 迁移前后数据完整性验证
- **ml-pipeline**: 训练/推理数据门禁
- **experiment-tracker**: 记录数据集hash与质量指标
- **model-evaluator**: 数据质量与模型性能关联分析

---

## 数据集质量验证 (来自 dataset-validator)

合并自 engineering/dataset-validator (已归档)。专注ML数据集质量检查。

### 1. 数据集快速Profile

```bash
python3 -c "
import pandas as pd
df = pd.read_csv('dataset.csv')
print(f'Shape: {df.shape}')
print(f'Columns: {list(df.columns)}')
print(f'Dtypes:\n{df.dtypes}')
print(f'\nMissing:\n{df.isnull().sum()}')
print(f'\nStats:\n{df.describe()}')
"
```

### 2. 质量检查清单

```python
import pandas as pd, numpy as np
df = pd.read_csv('dataset.csv')
issues = []

# Missing values
for col in df.columns:
    null_pct = df[col].isnull().mean()
    if null_pct > 0.1:
        issues.append(f'HIGH: {col} has {null_pct:.1%} missing values')
    elif null_pct > 0.01:
        issues.append(f'LOW: {col} has {null_pct:.1%} missing values')

# Duplicate rows
dupes = df.duplicated().sum()
if dupes:
    issues.append(f'HIGH: {dupes} duplicate rows ({dupes/len(df):.1%})')

# Outliers (numeric)
for col in df.select_dtypes(include=[np.number]).columns:
    q1, q3 = df[col].quantile([0.25, 0.75])
    iqr = q3 - q1
    outliers = ((df[col] < q1 - 1.5*iqr) | (df[col] > q3 + 1.5*iqr)).sum()
    if outliers > len(df) * 0.01:
        issues.append(f'MEDIUM: {col} has {outliers} outliers ({outliers/len(df):.1%})')

# Class imbalance
if 'label' in df.columns or 'target' in df.columns:
    target = 'label' if 'label' in df.columns else 'target'
    dist = df[target].value_counts(normalize=True)
    min_class, max_class = dist.min(), dist.max()
    if max_class / min_class > 10:
        issues.append(f'HIGH: Severe class imbalance (ratio {max_class/min_class:.1f}:1)')

for issue in issues:
    print(f'  [{issue.split(\":\")[0]}] {issue.split(\":\",1)[1].strip()}')
```

### 3. 数据泄露检测

```bash
# Temporal leakage check
python3 -c "
import pandas as pd
df = pd.read_csv('dataset.csv')
if 'timestamp' in df.columns or 'date' in df.columns:
    time_col = 'timestamp' if 'timestamp' in df.columns else 'date'
    df[time_col] = pd.to_datetime(df[time_col])
    train_end = df[df['split']=='train'][time_col].max() if 'split' in df.columns else df[time_col].quantile(0.8)
    test_start = df[df['split']=='test'][time_col].min() if 'split' in df.columns else df[time_col].quantile(0.8)
    if 'split' in df.columns and test_start < train_end:
        print('HIGH: Temporal leakage detected!')
    elif 'split' in df.columns:
        print(f'OK: Temporal gap = {(test_start - train_end).days} days')

# Feature-target correlation leakage
python3 -c "
import pandas as pd, numpy as np
df = pd.read_csv('dataset.csv')
target = 'label' if 'label' in df.columns else (df.columns[-1] if 'target' not in df.columns else 'target')
feats = [c for c in df.columns if c != target and df[c].dtype in ['int64','float64']]
for f in feats:
    corr = df[f].corr(df[target]) if df[target].dtype in ['int64','float64'] else 0
    if abs(corr) > 0.95:
        print(f'HIGH: {f} near-perfect correlation ({corr:.3f}) with target — possible leakage')
"
```

### 4. 偏见/公平性审计

```bash
python3 -c "
import pandas as pd
df = pd.read_csv('dataset.csv')
sensitive_attrs = ['gender', 'race', 'age', 'ethnicity', 'income']
found = [c for c in df.columns if any(s in c.lower() for s in sensitive_attrs)]
if found:
    for attr in found:
        dist = df[attr].value_counts(normalize=True)
        print(f'Distribution for {attr}:')
        for val, pct in dist.items():
            print(f'  {val}: {pct:.1%}')
        if dist.min() < 0.05:
            print(f'  ⚠️  Underrepresentation: \"{dist.idxmin()}\" only {dist.min():.1%}')
else:
    print('No obvious sensitive attributes found. Manual review recommended.')
"
```

### 5. 分布偏移检测

```bash
python3 -c "
import pandas as pd, numpy as np
from scipy.stats import ks_2samp
train = pd.read_csv('train.csv')
test = pd.read_csv('test.csv')
for col in train.select_dtypes(include=[np.number]).columns[:10]:
    if col in test.columns:
        stat, p = ks_2samp(train[col].dropna(), test[col].dropna())
        if p < 0.05:
            print(f'MEDIUM: {col} shows significant distribution shift (p={p:.4f})')
        elif p > 0.05:
            print(f'OK: {col} distribution stable (p={p:.4f})')
"
```

### 数据集验证注意事项

1. **Null表示**: 缺失值可能编码为999、-1、'N/A'或空字符串 — 需配置显式null值列表
2. **类别不平衡≠偏见**: 不平衡可能是合理的(如欺诈检测)，区分数据不平衡和有害偏见
3. **ID列泄露**: user_id/transaction_id可泄露信息 — 分析前始终删除唯一标识符
4. **大数据集性能**: 100M+行时使用抽样(`df.sample(100000)`)以提升性能
5. **图像/文本限制**: pandas不能直接验证图像或文本质量 — 补充领域特定工具
6. **隐私问题**: 错误报告可能暴露PII — 敏感数据使用脱敏输出模式

### 脚本

- `scripts/check.py`: 环境检查与基本验证测试
- `scripts/check.py`: 环境检查与数据集质量验证

### 集成

- **experiment-tracker**: 记录数据集hash与质量指标到MLflow
- **ml-pipeline**: 数据验证作为pipeline的第一阶段
- **schema-evolution**: 验证数据是否匹配最新schema版本
