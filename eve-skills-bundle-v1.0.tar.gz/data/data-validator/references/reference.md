# dataset-validator — Reference

## Overview
数据集质量验证 — 检测缺失值、异常值、标签错误、数据泄露、分布偏移、偏见/公平性问题。支持CSV/JSON/Parquet/Image/Text多格式。触发词："dataset validate"/"数据验证"/"data quality"/"clean data"/"数据质量检查"/"偏见识別"。

## Integration
- Hermes Agent ecosystem (engineering/dataset-validator)
- evolution_engine.py / self_audit.py scoring
