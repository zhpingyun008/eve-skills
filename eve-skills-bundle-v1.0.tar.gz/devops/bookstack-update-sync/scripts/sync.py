#!/usr/bin/env python3
"""
BookStack update log sync script — robust version.

Reads token from ~/.hermes/config.yaml to avoid fragile inline pasting.
Usage:
    python3 scripts/sync.py "<summary>" "<type>" "[detail_url]"

Example:
    python3 scripts/sync.py "外包结算系统 v2.0 - 批次删除" "技能" "/books/39/page/outsourcing-settlement-check-system"

Types & badges:
    技能 -> kb-badge kb-badge-purple
    基础设施 -> kb-badge kb-badge-blue
    运维 -> kb-badge
    进化 -> kb-badge kb-badge-green
    服务 -> kb-badge
    知识库 -> kb-badge kb-badge-blue
"""

import json
import os
import re
import sys
import urllib.request
from datetime import datetime
from pathlib import Path


def get_token():
    """Read BookStack API token from Hermes config.yaml"""
    config_path = Path.home() / ".hermes" / "config.yaml"
    if not config_path.exists():
        # Fallback: try environment variable
        token = os.environ.get("BOOKSTACK_API_TOKEN") or os.environ.get("BOOKSTACK_TOKEN")
        if token:
            return token
        print("ERROR: No BookStack token found. Set BOOKSTACK_API_TOKEN or BOOKSTACK_TOKEN env var", file=sys.stderr)
        sys.exit(1)

    try:
        import yaml
        with open(config_path) as f:
            config = yaml.safe_load(f)
        # Try common locations
        for path in ["bookstack.token", "bookstack.api_token", "integrations.bookstack.token"]:
            parts = path.split(".")
            val = config
            for p in parts:
                val = val.get(p) if isinstance(val, dict) else None
                if val is None:
                    break
            if val:
                return val
    except ImportError:
        pass

    # Fallback: grep yaml manually
    with open(config_path) as f:
        for line in f:
            m = re.search(r"token\s*[:=]\s*['\"]?([a-f0-9]+:[a-zA-Z0-9_-]+)['\"]?", line)
            if m:
                return m.group(1)

    # Fallback: try environment variable (when config.yaml has no token entry)
    token = os.environ.get("BOOKSTACK_API_TOKEN") or os.environ.get("BOOKSTACK_TOKEN")
    if token:
        return token

    print("ERROR: Could not extract BookStack token from config.yaml. Set BOOKSTACK_TOKEN env var", file=sys.stderr)
    sys.exit(1)


API_BASE = "http://localhost:8080/api"
PAGE_ID = 285


def api(token, method, path, data=None):
    auth = "Token " + token
    body = json.dumps(data).encode() if data else None
    req = urllib.request.Request(API_BASE + path, data=body,
        headers={"Authorization": auth, "Content-Type": "application/json"},
        method=method)
    resp = urllib.request.urlopen(req, timeout=15)
    return json.loads(resp.read().decode())


def badge_for_type(update_type):
    m = {
        "技能": "kb-badge kb-badge-purple",
        "基础设施": "kb-badge kb-badge-blue",
        "运维": "kb-badge",
        "进化": "kb-badge kb-badge-green",
        "服务": "kb-badge",
        "知识库": "kb-badge kb-badge-blue",
    }
    return m.get(update_type, "kb-badge")


def main():
    if len(sys.argv) < 2:
        print("Usage: sync.py <summary> [type] [detail_url]", file=sys.stderr)
        sys.exit(1)

    summary = sys.argv[1]
    update_type = sys.argv[2] if len(sys.argv) > 2 else "技能"
    detail_url = sys.argv[3] if len(sys.argv) > 3 else ""

    token = get_token()
    badge = badge_for_type(update_type)
    date_str = datetime.now().strftime("%Y-%m-%d")
    detail_cell = f'<a href="{detail_url}">详情</a>' if detail_url else "-"

    new_row = f"""<tr>
  <td>{date_str}</td>
  <td><span class="{badge}">{update_type}</span></td>
  <td><b>{summary}</b></td>
  <td>{detail_cell}</td>
</tr>"""

    page = api(token, "GET", f"/pages/{PAGE_ID}")
    html = page.get("html", "")

    month_str = datetime.now().strftime("%Y年%m月")
    section_marker = f'<h2 class="kb-section-title"><span class="kb-icon">📅</span>{month_str}</h2>'

    if section_marker in html:
        idx = html.index(section_marker)
        section = html[idx:]
        first_end = section.index("</tr>") + 5
        new_html = html[:idx] + section[:first_end] + "\n" + new_row + section[first_end:]
    else:
        first_month = html.find('<h2 class="kb-section-title"><span class="kb-icon">📅</span>')
        new_month = (f'<h2 class="kb-section-title"><span class="kb-icon">📅</span>{month_str}</h2>\n'
                     f'<table class="kb-table kb-table-anime">\n'
                     f'<tr><th>日期</th><th>类型</th><th>摘要</th><th>详情</th></tr>\n'
                     f'{new_row}\n'
                     f'</table>\n'
                     f'<div class="kb-cartoon-divider">✦ ✦ ✦ ✦ ✦</div>\n')
        new_html = html[:first_month] + new_month + html[first_month:]

    result = api(token, "PUT", f"/pages/{PAGE_ID}", {"html": new_html})
    print(f"✅ Synced: {result['updated_at']}")


if __name__ == "__main__":
    main()
