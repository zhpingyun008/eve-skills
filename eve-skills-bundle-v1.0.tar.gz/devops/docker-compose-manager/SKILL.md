---
name: docker-compose-manager
description: Docker Compose全生命周期管理 — 多环境配置、服务编排、健康检查、日志聚合、卷管理、网络配置、生产就绪化改造。触发词："docker compose"/"docker-compose"/"compose管理"/"多容器编排"/"docker service"。
depends_on: []
related_skills:
  - k8s-deployer
  - k8s-resource-manager
  - secrets-vault-manager
category: devops
triggers:
  - "docker compose"
  - "docker-compose"
  - "compose管理"
  - "多容器编排"
  - "docker service"
  - "compose file"
  - "compose部署"
---

# Docker Compose Manager — Docker Compose全生命周期管理


## Overview

Brief description of this skill's purpose and capabilities.
Docker Compose多容器应用编排：开发→测试→生产部署。

## Trigger Conditions

Load this skill when:
- User asks to write/review a docker-compose.yml
- Multi-container application setup
- Development-to-production compose migration
- Service health checking
- Volume/data persistence management

## Workflow

### 1. Compose File Structure

```yaml
# docker-compose.yml
version: "3.9"

services:
  app:
    build:
      context: .
      dockerfile: Dockerfile
      args:
        NODE_ENV: ${NODE_ENV:-development}
    ports:
      - "${APP_PORT:-3000}:3000"
    environment:
      - DB_HOST=db
      - REDIS_HOST=redis
    volumes:
      - .:/app  # Development mount
      - /app/node_modules  # Anonymous volume (don't overwrite)
    depends_on:
      db:
        condition: service_healthy
      redis:
        condition: service_started
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:3000/health"]
      interval: 30s
      timeout: 10s
      retries: 3
    restart: unless-stopped
    networks:
      - frontend
      - backend

  db:
    image: postgres:16-alpine
    volumes:
      - pgdata:/var/lib/postgresql/data
      - ./init.sql:/docker-entrypoint-initdb.d/init.sql
    environment:
      POSTGRES_DB: myapp
      POSTGRES_PASSWORD_FILE: /run/secrets/db_password
    secrets:
      - db_password
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U myapp"]
      interval: 10s
    networks:
      - backend

  redis:
    image: redis:7-alpine
    volumes:
      - redisdata:/data
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
    networks:
      - backend

volumes:
  pgdata:
  redisdata:

secrets:
  db_password:
    file: ./secrets/db_password.txt

networks:
  frontend:
  backend:
    internal: true  # Backend not accessible from outside
```

### 2. Multi-Environment Compose

```yaml
# docker-compose.override.yml (auto-merged in development)
# docker-compose.prod.yml (explicit: -f docker-compose.yml -f docker-compose.prod.yml)

services:
  app:
    # Production overrides
    build:
      args:
        NODE_ENV: production
    ports:
      - "80:3000"
    volumes: []  # No code mount in production
    deploy:
      replicas: 3
      resources:
        limits:
          cpus: '0.5'
          memory: '512M'

  # Production-only services
  nginx:
    image: nginx:alpine
    ports:
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf
    depends_on:
      - app
```

### 3. Common Operations

```bash
# Build images
docker compose build --parallel

# Start services
docker compose up -d

# View logs
docker compose logs -f --tail=100

# Follow specific service
docker compose logs -f app

# Execute in container
docker compose exec app npm run migrate

# Check status
docker compose ps

# Resource usage
docker compose top
docker stats $(docker compose ps -q)

# Restart service
docker compose restart app

# Rebuild and recreate single service
docker compose up -d --build --no-deps app
```

### 4. Health Check Monitor

```bash
# Check all services health
docker compose ps --format "table {{.Name}}\t{{.Status}}"

# Service dependency graph
docker compose config --services | while read svc; do
    deps=$(docker compose config 2>/dev/null | grep -A100 "^  $svc:" | grep "depends_on" -A10 | tail -n +2 | tr -d ' ')
    [ -n "$deps" ] && echo "$svc → $deps"
done
```

### 5. Cleanup & Maintenance

```bash
# Stop and remove containers
docker compose down

# Remove volumes too (destructive!)
docker compose down -v

# Remove unused resources
docker compose down --remove-orphans
docker system prune -f --volumes

# Clean dangling images
docker image prune -f
```

### 6. Production Hardening

```yaml
# Security hardening checklist
services:
  app:
    security_opt:
      - no-new-privileges:true
    cap_drop:
      - ALL
    cap_add:
      - NET_BIND_SERVICE  # Only if binding to ports <1024
    read_only: true       # Read-only root filesystem
    tmpfs:
      - /tmp              # Writable temp directory
    user: "1000:1000"     # Non-root user
```

## Pitfalls

1. **Volume permission issues**: Docker mounts preserve host UID/GID. Container may not have write access. Use `user` directive or entrypoint to fix.
2. **depends_on false guarantee**: `depends_on` only waits for container start, not service readiness. Always use `condition: service_healthy` with healthchecks.
3. **Port conflicts**: Multiple projects on same host may conflict on port 80/443. Use environment variables for port mapping: `${PORT:-3000}:3000`.
4. **.env file loading**: Docker Compose auto-loads `.env` but ONLY for variable substitution in compose file, NOT for container environment. Use `env_file` for container env.
5. **Build cache invalidation**: Changing `ARG` values invalidates all subsequent layers. Order ARGs with low-change values first.
6. **Compose v1 deprecation**: `docker-compose` (hyphen, v1) is deprecated. Use `docker compose` (space, v2) integrated in Docker CLI.

## Verification

```bash
# Validate compose file
docker compose config 2>/dev/null | head -10 && echo "✓ Compose file valid" || echo "✗ Compose file has errors"

# Quick test: start, verify, stop
cd /path/to/project
docker compose up -d --wait 2>/dev/null && \
  docker compose ps --format "table {{.Name}}\t{{.Status}}" | grep -q "Up" && \
  echo "✓ Services started" || echo "✗ Service start failed"
docker compose down 2>/dev/null
```

## Integration

- **container-security-scanner**: Scan images used in compose file
- **k8s-resource-manager**: Convert compose to K8s manifests (kompose)
- **health-dashboard**: Monitor compose services health
- **log-analyzer**: Aggregate compose service logs
