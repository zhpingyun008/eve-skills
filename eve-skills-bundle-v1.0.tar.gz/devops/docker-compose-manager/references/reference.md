# docker-compose-manager — Reference

## Overview
Docker Compose全生命周期管理 — 多环境配置、服务编排、健康检查、日志聚合、卷管理、网络配置、生产就绪化改造。触发词："docker compose"/"docker-compose"/"compose管理"/"多容器编排"/"docker service"。

## Integration Points
- Hermes Agent skill ecosystem
- evolution_engine.py scoring system
- self-audit verification

## Key Resources
- SKILL.md: main skill definition
- scripts/: executable code (if present)
