---
name: public-access-deploy
description: Public HTTP access deployment for local services via tunneling (cloudflared/frp/ngrok/SSH). Covers service detection → backend restart → tunnel setup → public URL verification → documentation update. Works around WSL network limitations and China GFW.
category: devops
triggers:
  - "公网部署"
  - "public access"
  - "公网恢复"
  - "隧道"
  - "tunnel"
  - "cloudflared"
  - "cloudflare tunnel"
  - "内网穿透"
  - "上线服务"
  - "把服务暴露到公网"
  - "公网地址验证"
  - "deployed products"
  - "产品上线"
  - "service deployment"
---

# public-access-deploy — 公网服务部署与隧道管理

## Overview

Makes local backend services (FastAPI/Flask/uvicorn) accessible from the public internet. The full cycle: detect which deployed products are down → restart backend services → establish tunnel → verify public accessibility → update documentation.

## Core Flow

### Phase 1: Service Detection & Port-Conflict Diagnosis

Scan for which deployed services are running vs down:

```bash
# Check ports from deployed-products.md
for port in 9090 8770 8771 8000 8080; do
  code=$(curl -s -o /dev/null -w "%{http_code}" --connect-timeout 3 http://localhost:$port/)
  echo ":$port → $code"
done
# 000 = down, 200/301/302/307 = up, other = possibly up but unexpected
```

**Critical check**: HTTP 200 does NOT guarantee the right service. The process on a port may be from a different project if it was started from the wrong CWD. Example: port 8000 returned 200 with 海航HTML when Skills Market was expected.

```bash
# Diagnose: find PID and check CWD
PID=$(ss -tlnp | grep ":PORT " | grep -oP 'pid=\K[0-9]+')
readlink -f /proc/$PID/cwd
# → /home/yestin/projects/haihang-ticketing/  ← WRONG! Should be skills-market/backend/

# Verify via response body:
curl -s http://localhost:PORT/health
# Skills Market: {"status":"healthy"}
# But if you get HTML with "海航AI购票助手", wrong process is on the port
```

**Root cause**: Two projects both have `backend/main.py`. A process started in Project A's directory with `uvicorn backend.main:app` loads Project A's code because the CWD determines which module is loaded.

**Fix**: Kill misbound process, restart with correct CWD on intended port.

**Port Map Reference**:

| Service | Port | Notes |
|---------|:----:|-------|
| Skills Market | 8770 | FastAPI, Dockerfile port |
| LLM Gateway | 9090 | Unified API gateway |
| Env Vault | 8771 | Python FastAPI |
| 海航购票助手 | 8000 | Vite proxy target, haihang-ticketing backend |
| Prompt Optimizer | 8085 | Flask |
| PromptHub | 3871 | Flask |

### Phase 2: Backend Service Restart

Use `terminal(background=true)` — never use nohup/setsid/disown in foreground:

```python
# DO: Hermes-managed background
terminal(background=True, command="cd ~/projects/my-service && python3 -m uvicorn app.main:app --port 9090 --host 0.0.0.0")

# DON'T: nohup in foreground (blocked by Hermes)
```

**Verification** (after 3s wait):
```bash
curl -s -o /dev/null -w "%{http_code}" --connect-timeout 3 http://localhost:PORT/
```

### Phase 3: Tunnel Setup (cloudflared)

#### WSL/China Network Quirks

1. **Always use `--protocol http2`** — QUIC (default) is unreliable on WSL due to UDP stack limitations:

```bash
cloudflared tunnel --url http://localhost:PORT --protocol http2
```

2. **GFW blocking is intermittent** (as of 2026-07-22). Previously port 7844 was blocked, but cloudflared now works from WSL — all 3 tunnels connected successfully via `--protocol http2` (Los Angeles edge, ~6s connect). Try cloudflared first before falling back to frp/SSH. If it fails, see `references/cloudflared-gfw-wsl-quirks.md` for diagnostics.

3. **ICMP proxy warning** is benign:
   ```
   WRN ICMP proxy feature is disabled error="cannot create ICMPv4 proxy: socket: permission denied"
   ```
   This is a WSL permission limitation, not a tunnel failure.

4. **Precheck `hard_fail=true` is not fatal**: cloudflared's connectivity precheck may report "Environment has critical failures" (QUIC fails on port 7844, HTTP/2 to region2 times out) but the tunnel **still connects** to region1 via HTTP/2 after ~20-30s of retries. The `hard_fail` flag is overly conservative on GFW-filtered networks. Always wait for `Registered tunnel connection` in logs before declaring failure.

5. **Successful connection log pattern**:
   ```
   INF Registered tunnel connection connIndex=0 connection=<UUID> event=0 ip=198.41.x.x location=lax01 protocol=http2
   ```
   Wait ~6s after starting, then extract the URL from logs to get the public address.

#### Setup Steps

```bash
# Start tunnel with HTTP/2 protocol + capture logs
cloudflared tunnel --url http://localhost:PORT --protocol http2

# Wait ~6s for connection, then get URL from logs:
cat /tmp/cloudflared-PORT.log | grep -oP 'https://[a-z-]+\.trycloudflare\.com'
```

#### Alternative Tunneling Methods (when --protocol http2 fails)

| Method | Command | China-Friendly |
|--------|---------|---------------|
| cloudflared | `cloudflared tunnel --url URL --protocol http2` | ⚠️ (intermittent GFW block, try first) |
| frp | `frpc -c frpc.ini` (requires VPS with frps) | ✅ |
| SSH -R | `ssh -R 80:localhost:PORT user@vps` | ✅ (if VPS is outside GFW) |
| ngrok | `ngrok http PORT` | ⚠️ (partially blocked) |

### Phase 4: Verification

Always verify in this order:

1. **Local port**: `curl http://localhost:PORT/` → should return 200
2. **Tunnel URL**: `curl https://RANDOM.trycloudflare.com/` → may timeout if GFW blocks
3. **From external browser** (user-side): if the tunnel is established, this should work even when curling from inside WSL times out

### Phase 5: Documentation Update

Update `~/deployed-products.md` with current service status. Include:
- Port assignments
- Local accessibility status
- Public URL (if tunnel is functional)
- Known limitations

See `references/deployed-products-status.md` for the canonical format.

## Service Startup Reference

### Standard Backend Starters

```python
# LLM Gateway
terminal(background=True, command="cd ~/projects/llm-gateway && python3 -m uvicorn app.main:app --port 9090 --host 0.0.0.0")

# Skills Market (port 8770 — see Port Map Reference, NOT 8000)
terminal(background=True, command="cd ~/projects/skills-market/backend && python3 -m uvicorn main:app --port 8770 --host 0.0.0.0")

# Env Vault
terminal(background=True, command="cd ~/projects/env-vault/backend && PYTHONPATH=\"$PWD/app\" python3 -m uvicorn app.main:app --port 8771 --host 0.0.0.0")
```

## Pitfalls

### 1. cloudflared creates URLs before connection is established

When cloudflared starts, it registers a DNS entry on trycloudflare.com before the tunnel connection is actually established. You'll see `https://xxx.trycloudflare.com` in logs even when the tunnel is failing to connect. Always check for `Connected` or `connection established` in logs, not just URL existence.

### 2. `--protocol http2` required on WSL

Without this flag, cloudflared uses QUIC (UDP-based) which frequently fails on WSL due to network stack limitations. Always include this flag when running cloudflared from WSL.

### 3. Background process verification

When using `terminal(background=true)`, the bash wrapper exits before the Python daemon starts. `exit code 0/1` from the bg process is the wrapper, NOT the service. Verify actual service with `ps aux | grep <service>` or `ss -tlnp | grep :PORT`.

### 4. Port verification using curl

`curl -s -o /dev/null -w "%{http_code}"` is the most reliable way to verify. Some services return 307 (redirect) instead of 200 — this is normal for certain frameworks.

### 5. Multiple tunnel processes

Starting multiple cloudflared instances can cause port/process conflicts. Use `pkill -f "cloudflared tunnel"` to clean up before restarting (if pkill is not blocked by Hermes, use `process(action='kill')` for Hermes-tracked instances).

**Multiple concurrent tunnels work**: Running 3+ cloudflared instances simultaneously (e.g., Skills Market:8770, LLM Gateway:9090, Env Vault:8771) is verified to work. Each gets its own trycloudflare URL. However, starting too many at once may trigger GFW rate limiting (region2 HTTP/2 blocked). Stagger starts by ~2s if connection fails.

### 6. Port conflict — wrong service on port (CWD mismatch)

When `curl http://localhost:PORT/health` returns wrong content, the process on that port was started from the wrong CWD. Two projects sharing the same module name (e.g., both have `backend/main.py` with `uvicorn backend.main:app`) causes this.

**Diagnosis**:
```bash
PID=$(ss -tlnp | grep ":PORT " | grep -oP 'pid=\K[0-9]+')
readlink -f /proc/$PID/cwd
# Compare expected vs actual project directory
```

**Fix**: Kill and restart from correct CWD.
