# cloudflared + GFW + WSL Quirks

## Background

2026-07-05 session: cloudflared tunnels failed to connect from WSL (GFW blocked port 7844).

**2026-07-22 update**: cloudflared now works from WSL! All 3 tunnels (Skills Market :8000, LLM Gateway :9090, Env Vault :8771) connected successfully via `--protocol http2`. GFW blocking appears to be intermittent rather than permanent.

## Connection Diagnostics

### Successful Connection (works as of 2026-07-22)

Log pattern for a working tunnel:
```
INF Requesting new quick Tunnel on trycloudflare.com...
INF |  https://RANDOM-NAME.trycloudflare.com                       |
INF Generated Connector ID: UUID
INF Initial protocol http2
INF Registered tunnel connection connIndex=0 connection=UUID event=0 ip=198.41.x.x location=lax01 protocol=http2
```

URL is reachable within ~1.3s with HTTP 200.

### What Still Works When Blocked
- `api.cloudflare.com:443` — reachable (standard HTTPS)
- DNS resolution for `region1.v2.argotunnel.com` and `region2.v2.argotunnel.com` — succeeds
- Cloudflare API reachable — `precheck component="Cloudflare API" status=pass`

### What Fails When Blocked
- **TCP port 7844** — `DialContext error: dial tcp 198.41.192.37:7844: i/o timeout`
- **QUIC (UDP)** — `UDP Connectivity: QUIC connection failed`
- **HTTP/2 over port 7844** — `HTTP/2 connection is blocked or unreachable`

### Log Patterns When Blocked

```
precheck component="TCP Connectivity" details="HTTP/2 connection is blocked or unreachable" status=fail
precheck component="UDP Connectivity" details="QUIC connection failed" status=fail
Tunnel connection curve preferences: [X25519MLKEM768 CurveID(65074) CurveP256]
Failed to dial a quic connection: timeout: handshake did not complete in time
Unable to establish connection with Cloudflare edge: TLS handshake timeout
```

### Misleading Signal

cloudflared registers a trycloudflare.com URL BEFORE the tunnel connects. You'll see:
```
https://xxx.trycloudflare.com
```
in logs even though the tunnel is repeatedly failing. The URL exists in Cloudflare's DNS but no data can flow through it. **Check for `Registered tunnel connection` in logs**, not just URL existence.

## Strategy

1. **Try cloudflared first** (it works now as of 2026-07-22)
2. If `Registered tunnel connection` never appears after 15s, GFW is blocking again → fall back to alternatives below

## Workarounds (when cloudflared is blocked)

### Option 1: VPS Relay (Recommended)
Use a VPS outside GFW as relay. Two methods:
- **frp**: Deploy frps on VPS, frpc on WSL. Most stable for China.
- **SSH -R tunnel**: `ssh -R 9090:localhost:9090 user@vps` (requires VPS)

### Option 2: Windows Host cloudflared
Run cloudflared from Windows (not WSL). Windows has a different network stack and may not be subject to the same QUIC/UDP limitations.

### Option 3: SOCKS5 Proxy
If you have a working SOCKS5 proxy, tunnel cloudflared traffic through it:
```bash
ALL_PROXY=socks5://proxy:1080 cloudflared tunnel --url http://localhost:9090 --protocol http2
```

## Verification Commands

```bash
# Check if edge is reachable
timeout 3 bash -c 'echo > /dev/tcp/198.41.192.37/7844' 2>&1 && echo "REACHABLE" || echo "BLOCKED"

# Check general internet connectivity
curl -s -o /dev/null -w "%{http_code} %{time_total}s\n" --connect-timeout 5 https://www.baidu.com/
curl -s -o /dev/null -w "%{http_code} %{time_total}s\n" --connect-timeout 5 https://api.cloudflare.com/
```
