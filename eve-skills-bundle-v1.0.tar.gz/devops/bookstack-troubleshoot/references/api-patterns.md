# BookStack API Usage Patterns & Pitfalls

Collected from real-world usage of the BookStack REST API (http://localhost:8080/api/).

## URL Routing: Shelves use Slug, not Numeric ID

BookStack shelves are accessed in the web UI by **slug** (URL-friendly name), not numeric ID.
The API always returns both `id` and `slug`.

```bash
# CORRECT web URL — uses slug:
curl http://localhost:8080/shelves/appv10

# WRONG — returns "Shelf not found":
curl http://localhost:8080/shelves/1317
```

**To find the slug**: query the API:
```bash
curl -s http://localhost:8080/api/shelves/1317 -H "Authorization: Token $TOKEN" \
  | python3 -c "import json,sys; print(json.load(sys.stdin)['slug'])"
```

## Book Pagination: /books/{id} only returns first page

The `GET /api/books/{id}` endpoint returns books with a `pages.data` field that only contains the **first page** of pages (pagination default ~20). If a book has 50 pages, only the first 20 appear.

**Do NOT rely on `pages.data` for checking if a page exists** — it's incomplete.

**Workaround**: Check page existence by direct `GET /api/pages/{id}`, or search by name via `GET /api/pages?filter[name]=exact_name`.

## PUT /api/shelves/{id} OVERWRITES Book List

When updating a shelf to add books, the `books` array in the PUT body **replaces** the entire existing book list:

```python
# BAD — overwrites all existing books, only keeps [2438,2439,2440]:
requests.put(f"{API}/shelves/1317", json={"name": "Shelf Name", "books": [2438, 2439, 2440]})
```

**Fix**: Always include ALL existing books in the array. First read the current list, append new IDs, then PUT.

```python
# GOOD — preserves existing books:
existing = requests.get(f"{API}/shelves/1317").json()
old_ids = [b["id"] for b in existing.get("books", {}).get("data", [])]
all_ids = old_ids + [2438, 2439, 2440]  # append new ones
requests.put(f"{API}/shelves/1317", json={"name": "...", "books": all_ids})
```

**Note**: `POST /api/books` with `shelf_id=N` **does not** actually associate the book with the shelf. The shelf association must be made via `PUT /api/shelves/{id}`.

## Authentication

All API calls require `Authorization: Token <token>` header.

```bash
curl -H "Authorization: Token kbsync-2026:kb-sync-secret-2026" \
  http://localhost:8080/api/shelves
```

## Cartoon HTML for BookStack Pages

BookStack pages accept full HTML. To display raw markdown content (e.g., SKILL.md format), wrap it in a `<pre>` tag:

```python
escaped = content.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;")
html = f'<pre style="font-family:monospace;font-size:13px;line-height:1.5;background:#f8f9fc;padding:16px;border-radius:8px;overflow-x:auto;white-space:pre-wrap;word-break:break-word;">{escaped}</pre>'
```

For full cartoon style, embed CSS in the HTML and use the hero-card + tables pattern from existing `.cartoon.html` files.

## Page Deletion

```python
# Returns 204 No Content on success
requests.delete(f"{API}/pages/{page_id}", headers={"Authorization": f"Token {TOKEN}"})
```

## Book Creation with Shelf Association

```python
# Step 1: Create the book
r = requests.post(f"{API}/books", json={"name": "Book Name", "description": "..."})
book_id = r.json()["id"]

# Step 2: Associate with shelf (GET current books first to avoid overwrite)
shelf = requests.get(f"{API}/shelves/{shelf_id}").json()
existing_ids = [b["id"] for b in shelf.get("books", {}).get("data", [])]
requests.put(f"{API}/shelves/{shelf_id}", json={
    "name": shelf["name"],
    "books": existing_ids + [book_id]
})
```

## Common Error Responses

| HTTP Status | Meaning | Likely Cause |
|-------------|---------|-------------|
| 204 | Success (no content) | DELETE operation |
| 404 | Not found | Wrong ID or wrong URL format |
| 422 | Validation error | Missing required field or invalid JSON |
| 429 | Too Many Attempts | Rate limit — slow down between requests |
