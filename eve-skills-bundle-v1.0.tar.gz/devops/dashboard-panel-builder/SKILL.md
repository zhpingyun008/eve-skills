---
name: dashboard-panel-builder
description: "Extend the Hermes Flask+HTMX Dashboard (localhost:5000) with new backend data providers and frontend panels. Covers the full CRUD cycle: backend module, API route, HTML+JS panel, /api/all integration, service restart."
category: devops
triggers:
  - "add X to Dashboard / create Dashboard panel / Dashboard面板"
  - "make Y visible on Dashboard / Dashboard显示Z"
  - "新增仪表板面板 / new dashboard card / dashboard section"
  - "Flask dashboard route / HTMX dashboard / backend module"
  - "pipeline visualization / skills inventory / dashboard数据源"
  - "dashboard扩展 / dashboard集成 / extend dashboard"
  - "api/all combined endpoint / 合并端点"
  - "30s poll / HTMX auto-refresh / dashboard轮询"
  - "cost optimization panel / 成本优化面板 / provider cost comparison"
  - "snapshot export / JSON download / 快照导出 / health snapshot"
  - "dashboard startup verification / smoke test"
---

# dashboard-panel-builder — Hermes Dashboard Panel Extension

## Overview

Add a new data panel to the Hermes Dashboard (Flask + Bootstrap 5 + HTMX at `~/projects/hermes-dashboard/`). This skill covers the full pattern used to add Pipeline status, Skills Inventory, and similar panels.

**Architecture:**

```text
backend/pipeline.py -> frontend/routes.py -> index.html (HTML + JS)
         |                      |
    agent_bridge.db        /api/pipeline -> updateDashboard() -> DOM update
                                              |
                                       /api/all (combined) — HTMX 30s poll
                                              |
                                       /api/<name> — standalone fetch (on-demand)
```

**Two data flow patterns:**

1. **Combined polling** (`/api/all`) — all data in one 30s HTMX poll. Best for data that changes slowly (skills inventory, cron schedule, evolution score). Use `get_<name>_summary()` lightweight variants.

2. **Standalone fetch** (`/api/<name>`) — separate `fetch()` call on page load or on-demand. Best for system-level data that changes rapidly (gateway process count, port status, WebUI alive check) where you don't want to bloat the 30s poll payload. Example: Gateway process monitoring that needs fresh data every page load but not every 30 seconds.

## Workflow

### Step 1: Create backend module

Location: `~/projects/hermes-dashboard/backend/<name>.py`

Structure:
```python
"""
Hermes Dashboard -- <Name> Data Provider
"""

import os, sqlite3, json, glob, re
from datetime import datetime, timezone

def get_<name>():
    """Return dict with structured data for the dashboard."""
    # Read from DB, filesystem, or API
    # Always return a complete dict (handle missing data gracefully)
    return {
        "key": "value",
        "updated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
    }

def get_<name>_summary():
    """Lightweight version for /api/all combined endpoint."""
    return {"total": N, "categories": [...]}
```

**Key conventions:**
- Always have a `get_<name>()` (full) and `get_<name>_summary()` (lightweight) variant
- For drill-down details, add `get_<name>_detail(id)` returning tasks, artifacts, feedback per entity
- Return complete dicts even when data is missing (use empty lists, not errors)
- Timestamp with UTC ISO format
- All error states are safe to render (dashboard JS handles missing fields)

### Step 2: Register routes in frontend/routes.py

```python
from backend import <name>  # Add import

@bp.route("/api/<name>")
def api_<name>():
    """JSON: <description>."""
    return jsonify(<name>.get_<name>())

@bp.route("/api/<name>/summary")
def api_<name>_summary():
    """JSON: lightweight summary."""
    return jsonify(<name>.get_<name>_summary())
```

### Step 3: Add to combined /api/all endpoint

```python
return jsonify({
    # ...existing keys...
    "<name>": <name>.get_<name>_summary(),  # + this line
})
```

### Step 4: Add HTML section to index.html

Choose placement:
- **Metric card** (top row, col-6 col-md-3) -- for a single number/status
- **Subsystem card** (col-md-6 col-lg-3 grid) -- for data with stats
- **Full-width card** (col-12, card with header+body) -- for complex panels with agent cards / progress bars / tables

Example subsystem card:
```html
<div class="col-md-6 col-lg-3">
  <div class="card subsystem-card h-100">
    <div class="card-body">
      <div class="subsystem-title">Panel Name</div>
      <div class="subsystem-value" id="panel-value">--</div>
      <div style="margin-top: 10px;">
        <div class="subsystem-stat">
          <span class="stat-label">Label</span>
          <span class="stat-value" id="panel-stat1">--</span>
        </div>
      </div>
    </div>
  </div>
</div>
```

### Step 5: Add DOM references in JS

In the `const els = { ... }` section of `index.html`:

```javascript
panelValue:  $('panel-value'),
panelStat1:  $('panel-stat1'),
```

### Step 6: Add update logic in updateDashboard()

```javascript
/* -- Panel Name -- */
const pnl = data.<name> || {};
if (pnl.total != null) {
  els.panelValue.textContent = pnl.total;
}
```

For complex panels (agent cards, progress bars, blocker alerts) that use innerHTML rendering, create a separate `updatePanelName()` function and call it from `updateDashboard()`.

### Type G: Service/Process Monitoring Backend (Gateway, WebUI, System Processes)

For monitoring system-level services (gateway process count, port status, WebUI alive check). Unlike database-backed panels, this reads from `ps aux`, `ss`, and `curl`.

**Backend module pattern (backend/services.py):**
```python
"""Backend: services monitoring — gateway processes, WebUI, system ports."""

import subprocess, os
from datetime import datetime, timezone

HOME = os.path.expanduser("~")

def get_gateway_status():
    """Check all gateway-related processes and ports."""
    result = {
        "gateway_count": 0,
        "main_gateway_alive": False,
        "agent_gateways": {},
        "total_agent_count": 0,
    }
    # Count gateway processes
    try:
        r = subprocess.run(
            "ps aux | grep 'gateway run' | grep -v grep | wc -l",
            shell=True, capture_output=True, text=True, timeout=5
        )
        result["gateway_count"] = int(r.stdout.strip() or 0)
    except:
        result["gateway_count"] = -1
    
    # Check main gateway health
    try:
        r = subprocess.run(
            "curl -s -o /dev/null -w '%%{http_code}' http://127.0.0.1:8642/health",
            shell=True, capture_output=True, text=True, timeout=3
        )
        result["main_gateway_alive"] = r.stdout.strip() == "200"
    except:
        result["main_gateway_alive"] = False
    
    # Check agent gateway ports
    agent_names = {8643: "arch", 8644: "cm", 8645: "sec", 8646: "dev",
                   8647: "pm", 8648: "qa", 8649: "req", 8650: "doc",
                   8651: "spi", 8652: "test", 8653: "yestin"}
    for port, name in agent_names.items():
        try:
            r = subprocess.run(
                f"ss -tlnp 2>/dev/null | grep -q ':{port} ' && echo 'LISTEN' || echo 'DOWN'",
                shell=True, capture_output=True, text=True, timeout=3
            )
            alive = r.stdout.strip() == "LISTEN"
            result["agent_gateways"][name] = {"port": port, "alive": alive, "status": "✅" if alive else "❌"}
            if alive: result["total_agent_count"] += 1
        except:
            result["agent_gateways"][name] = {"port": port, "alive": False, "status": "❌"}
    return result

def get_services_summary():
    """Combined lightweight summary for dashboard display."""
    gw = get_gateway_status()
    webui = get_webui_status()  # check ss for port 8648/8688
    return {
        "gateway": {"count": gw["gateway_count"], "main_alive": gw["main_gateway_alive"]},
        "webui": webui,
        "timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
    }
```

**Route (frontend/routes.py):**
```python
from backend import services  # add import

@bp.route("/api/services")
def api_services():
    """JSON: Gateway + WebUI + system processes monitoring."""
    return jsonify(services.get_services_summary())
```

**Key differences from DB-backed panels:**
- Uses `subprocess.run` with shell commands (ps, ss, curl)
- No database dependency — pure runtime state
- Data changes every second, not every minute
- Best fetched via standalone `fetch()` on page load, not via 30s HTMX poll

### Type H: Command Center Badge (Lightweight Service Indicator)

For adding a small badge/indicator to the Command Center row instead of a full card. Used for services that need a quick health check without a dedicated panel.

**HTML (add to the Command Center row in the header):**
```html
<span id="svc-gw" class="severity-badge healthy" style="display:none">GW</span>
<span id="svc-wui" class="severity-badge healthy" style="display:none">WUI</span>
```

Start hidden (`display:none`) and reveal via JS after data loads.

**JS (in updateDashboard() or standalone fetch):**
```javascript
// Separate fetch for system services (not via /api/all)
fetch('/api/services').then(r=>r.json()).then(svcData => {
    const gw = svcData.gateway || {};
    const wui = svcData.webui || {};
    
    const gwEl = document.getElementById('svc-gw');
    if (gwEl) {
        gwEl.style.display = '';
        gwEl.textContent = 'GW:' + gw.count;
        gwEl.className = 'severity-badge ' + (gw.main_alive ? 'healthy' : 'critical');
    }
    
    const wuiEl = document.getElementById('svc-wui');
    if (wuiEl) {
        wuiEl.style.display = '';
        wuiEl.textContent = 'WUI' + (wui.alive ? '✅' : '❌');
        wuiEl.className = 'severity-badge ' + (wui.alive ? 'healthy' : 'critical');
    }
}).catch(() => {});
```

**Key patterns:**
- Start badges hidden and reveal on data load (avoids flashing empty badges)
- Use `gw.count` to show running gateway process count
- Use `severity-badge healthy/critical` class to color the badge
- Fetch separately — don't bloat the 30s /api/all poll with rapidly-changing process data
- Always `.catch(() => {})` to prevent unhandled promise rejection errors

### Type I: Frontend-Only Panel (No Backend Changes)

**When to use**: You spot data fields in `/api/all` that aren't displayed on the dashboard. This is the fastest 80% case — data already flows on every 30s poll, just not rendered.

```text
1. curl -s :5000/api/all | python3 -c "import sys,json;d=json.load(sys.stdin);print(list(d.keys()))"
   → spot unused keys like "health_history", "gbrain.status"
2. curl -s :5000/api/all > /tmp/api.json && python3 -c "
import json
with open('/tmp/api.json') as f:
    d = json.load(f)
for k in d:
    if isinstance(d[k], dict):
        print(f'  {k}: {list(d[k].keys())}')
    elif isinstance(d[k], list):
        print(f'  {k}: list({len(d[k])} items)')
"
   → examine the structure of unused data
3. Add HTML card (Step 4 — subsystem card or metric card)
4. Add DOM refs in `const els = { ... }` (Step 5)
5. Add update logic in `updateDashboard()` (Step 6 — consume from existing data consts)
6. Restart Flask (Step 8)
   → No backend/*.py, no route, no /api/all integration needed
```

**Key difference**: Instead of `const pnl = data.<name> || {}`, consume from existing destructured data like `const hh = data.health_history || []` or enrich an existing section like `if (gbrain.status && els.gbrainStatus) { els.gbrainStatus.textContent = gbrain.status; }`.

**Replacing old cards**: When upgrading an existing card (e.g., enriching GBrain with more fields), you must **remove the old HTML** to avoid duplicate DOM IDs. Use `patch` with old_string covering the entire old card div. Verify with `grep -c` the new IDs to confirm no duplicates.

### Step 7: Harden dashboard config

Add `TEMPLATES_AUTO_RELOAD = True` to `app.py` so template changes take effect without full restart — critical during iterative development:

```python
# In app.py, after app creation:
app.config['TEMPLATES_AUTO_RELOAD'] = True
```

Add a `window.onerror` global handler as a safety net to make JS errors visible on the page (instead of silently breaking all panels). Insert at the top of the main `<script>` block:

```javascript
/* Global JS error catch — prevents silent failure */
window.onerror = function(msg, url, line, col, err) {
  var banner = document.getElementById('error-banner') || (function(){
    var b = document.createElement('div');
    b.id = 'error-banner';
    b.style.cssText = 'position:fixed;top:0;left:0;right:0;background:#dc3545;color:#fff;padding:8px 16px;z-index:99999;font-size:13px;text-align:center';
    document.body.prepend(b);
    return b;
  })();
  banner.textContent = '⚠ JS Error: ' + msg + ' (line ' + line + ')';
  console.error('Dashboard JS error:', msg, url, line, col, err);
};
```

### Step 8: Restart dashboard

```bash
kill $(lsof -t -i:8050) 2>/dev/null; sleep 1
cd ~/projects/hermes-dashboard && python3 app.py
```

### Step 9 (Optional): Add interactive card click handlers

For panels where clicking a card should show details (e.g., agent execution history):

1. Add a `onclick` to the card div: `onclick="openAgentDetail('ID')"`
2. Add `cursor:pointer` to the card style
3. Add a modal HTML block before the bootstrap script tag (see Type D above)
4. Add async modal functions `openAgentDetail()` + `closeAgentModal()` in a separate `<script>` block BEFORE the main dashboard IIFE, or as standalone functions in the same script block before the IIFE
5. Add a backend API endpoint for per-item detail data

**Critical JS structure rule:** The Bootstrap JS `<script src="...">` tag MUST have `crossorigin="anonymous" defer></script>` — without the closing `></script>` on the same line as src, any content between the tag and its closing `</script>` is silently ignored by the browser. Always close the bootstrap script tag properly before adding any custom JS:

## Panel Types Reference

### Type A: Progress Bar Panel (e.g., Pipeline)

```text
[Header -- Phase Label]              [% Badge]
[████████████████████████] 100%
[N/N tasks completed]         [No blockers]
[PM✅] [REQ✅] [ARCH✅] ... [SPI✅]
```

Key elements: progress bar div, agent card grid (generated via JS .map()), blocker alert section (conditional display).

Cards should be **clickable** — add `cursor:pointer` style and `onclick="openAgentDetail('ID')"` handler to each card div:

```javascript
return '<div style="cursor:pointer" onclick="openAgentDetail(\'' + a.id + '\')">...';
```

### Type B: Inventory Card (e.g., Skills)

```text
[ Skills ]
[ 147    ]
[ Categories  21 cats     ]
[ Top Cat     CMMI5 (45)  ]
[ Last Sync   2026-05-10  ]
```

Key elements: large count number, stat rows with label+value.

### Type C: Data Table Panel (e.g., Incidents, Cron Jobs)

```text
[ Title ]                    [badge]
[ Col1    Col2    Col3    Status ]
[ data    data    data    badge  ]
```

Key elements: `table-dark-custom` table, `severity-badge` status spans, empty state fallback.

### Type E: Cost Optimization Panel (Provider Comparison + Recommendations)

For showing provider cost analysis with bar charts and recommendations. Added in 2026-05-13 deep-dive.

```text
[ 💰 Cost Optimization ]
[ cheapeast provider: DeepSeek V4 ($0.15/M tokens) ]
[ Recommendations: 3 items ]
[ Provider comparison bar chart (Canvas rendered) ]
```

**HTML template:**
```html
<div class="col-12">
  <div class="card">
    <div class="card-header"><h6>💰 Cost Optimization</h6></div>
    <div class="card-body">
      <div id="cost-opt-trend-canvas-container" style="position:relative">
        <canvas id="cost-opt-trend-canvas" width="700" height="250"></canvas>
      </div>
      <div id="cost-opt-recs"></div>
      <div id="cost-opt-table"></div>
    </div>
  </div>
</div>
```

**Backend module pattern (backend/costs.py):**
```python
def get_provider_cost_analysis():
    \"\"\"Compare 5 LLM providers and return cost analysis.\"\"\"
    # Providers to compare
    providers = {
        "OpenAI GPT-4o": {"input": 2.50, "output": 10.00},
        "Anthropic Claude 3.5": {"input": 3.00, "output": 15.00},
        "DeepSeek V4": {"input": 0.15, "output": 0.60},
        "Google Gemini 1.5": {"input": 0.10, "output": 0.40},
        "Open Source (Local)": {"input": 0.0, "output": 0.0},
    }
    # Read actual task data from DB if available
    total_input_tokens = tasks_summary.get("total_input_tokens", 500000)
    total_output_tokens = tasks_summary.get("total_output_tokens", 100000)
    
    for name, pricing in providers.items():
        cost = (total_input_tokens * pricing["input"] / 1_000_000 +
                total_output_tokens * pricing["output"] / 1_000_000)
    
    # Sort and build recommendations
    cheapest = min(providers, key=lambda p: providers[p]["cost"])
    dearest = max(providers, key=lambda p: providers[p]["cost"])
    
    return {
        "providers": provider_list,
        "recommendations": [
            f"🚀 Use {cheapest} for daily cron tasks (save ~${save_amount}/month)",
            f"💰 Use premium models only for complex reasoning tasks",
            f"📊 Monitor token usage to prevent cost spikes",
        ],
        "cheapest": cheapest,
        "dearest": dearest,
    }
```

**Key features:**
- Bar chart comparing per-provider costs (Canvas rendered with HiDPI support)
- Recommendation list with actionable savings suggestions
- Provider detail table (cheap/medium/premium/blended cost tiers)
- Integrated into `/api/all` for 30s HTMX polling

### Type F: Snapshot Export Button (One-click JSON Download)

For exporting all dashboard data as a downloadable JSON file. Added in 2026-05-13 deep-dive.

For exporting all dashboard data as a downloadable JSON file. Added in 2026-05-13 deep-dive.

**HTML template (Header area):**
```html
<a id="snapshot-btn" class="snapshot-btn" href="#" onclick="event.preventDefault();downloadSnapshot()">
  📥 Snapshot
</a>
```

**Backend endpoint (routes.py):**
```python
@bp.route("/api/health-snapshot")
def api_health_snapshot():
    \"\"\"Return complete system state as JSON for export.\"\"\"
    data = {
        "snapshot_time": datetime.now(timezone.utc).isoformat(),
        "health": health.get_health_data(),
        "pipeline": pipeline.get_pipeline_status(),
        "cron": cron.get_cron_summary(),
        "costs": costs.get_cost_summary(),
        "skills": skills.get_skills_summary(),
        # ...collect all data providers
    }
    return jsonify(data)
```

**JS download function:**
```javascript
async function downloadSnapshot() {
  const btn = document.getElementById('snapshot-btn');
  btn.textContent = '⏳';
  try {
    const resp = await fetch('/api/health-snapshot');
    const data = await resp.json();
    const blob = new Blob([JSON.stringify(data, null, 2)], {type: 'application/json'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'hermes-health-snapshot-' + new Date().toISOString().slice(0,10) + '.json';
    a.click();
    URL.revokeObjectURL(url);
  } catch(e) {
    console.error('Snapshot failed:', e);
    btn.textContent = '❌';
    setTimeout(() => btn.textContent = '📥 Snapshot', 2000);
  }
  btn.textContent = '📥 Snapshot';
}
```

**CSS:**
```css
.snapshot-btn {
  display: inline-flex; align-items: center; gap: 4px;
  padding: 6px 14px; border-radius: 20px;
  background: var(--card-bg); border: 1px solid var(--border-color);
  color: var(--text-primary); text-decoration: none;
  font-size: 0.8rem; cursor: pointer;
  transition: all 0.2s;
}
.snapshot-btn:hover { background: var(--accent); color: #fff; }
```

### Type D: Agent Detail Modal (e.g., Agent Execution History)

```html
<!-- Modal backdrop + container in HTML body, hidden by default -->
<div id="agent-modal" style="display:none;position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.5);z-index:9999;align-items:center;justify-content:center">
  <div style="background:var(--card-bg);border-radius:16px;max-width:720px;width:90%;max-height:85vh;overflow-y:auto;padding:24px;position:relative">
    <button onclick="closeAgentModal()" style="position:absolute;top:12px;right:16px;background:none;border:none;font-size:1.5rem;cursor:pointer;color:var(--text-secondary)">✕</button>
    <div id="agent-modal-content"></div>
  </div>
</div>
```

Key elements: fixed backdrop, centered card, close button, scrollable content div, close on backdrop click.

Async modal data loading:
```javascript
async function openAgentDetail(agentId) {
  const modal = document.getElementById('agent-modal');
  const content = document.getElementById('agent-modal-content');
  modal.style.display = 'flex';
  content.innerHTML = '<div style="text-align:center;padding:40px;color:var(--text-secondary)">⏳ Loading...</div>';
  try {
    const resp = await fetch('/api/pipeline/agent/' + agentId);
    const data = await resp.json();
    // Build HTML with tables for tasks, artifacts, feedback
    content.innerHTML = html;
  } catch (err) {
    content.innerHTML = '<div style="text-align:center;padding:40px;color:var(--red)">❌ Error: ' + err.message + '</div>';
  }
}
function closeAgentModal() { document.getElementById('agent-modal').style.display = 'none'; }
// Close on backdrop click:
document.addEventListener('click', function(e) {
  if (e.target.id === 'agent-modal') closeAgentModal();
});
```

This pattern requires: (1) a backend API endpoint returning per-item detail data, (2) a route like `/api/pipeline/agent/<id>`, (3) a modal template in the HTML, (4) async JS to fetch and render.

## Dashboard Architecture Reference

| Component | Location | Role |
|-----------|----------|------|
| app.py | ~/projects/hermes-dashboard/app.py | Flask entry (port 8050) |
| Blueprint | frontend/routes.py | All routes, imports backend modules |
| Templates | frontend/templates/index.html | Main dashboard (2000+ lines, HTML+JS) |
| Backend | backend/*.py | Data providers |
| Combined API | /api/all | All data in one endpoint for 30s HTMX polling |
| Standalone API | /api/<name> | On-demand data for system monitoring |
| Services API | /api/services | Gateway process count, WebUI status, system processes |
| CSS | static/css/dashboard.css | Dark dashboard theme |

### Port note

The Dashboard runs on port **8050** (not 5000). The old port 5000 is deprecated. All health checks, API URLs, and kill commands should use 8050.

### Type J: Server-Side Rendering Fallback (Fix for Silent JS Failure)

**When to use**: The Dashboard renders (title, HTML visible) but all panels show "—" or "0" despite `/api/all` returning valid data. Root cause is a JS runtime error (ReferenceError/SyntaxError) in the poll cycle that silently kills `updateDashboard()` before it reaches the render code.

[existing content...]

#### Comparison: Server-Side vs Client-Side Rendering

[existing content...]

**Reference canvas chart functions**: `references/canvas-chart-engine.md` — zero-dependency Canvas pie/bar/line chart functions usable in any panel.
*  </td>
</tr>
```
 
### Type K: OS Status Panel (Service Mesh)

For building a Hermes OS service mesh panel that reads from the Service Registry (registry.json) and displays all system services with real-time health status.

**Architecture:**
```text
~/.hermes/os/registry.json  →  backend/hermes_os.py  →  /api/os  →  os.html (JS render)
```

**Backend module (backend/hermes_os.py):**
```python
import json, os, subprocess, sys
REGISTRY = os.path.expanduser("~/.hermes/os/registry.json")

def get_os_status():
    """完整服务网格"""
    reg = _read_registry()
    services = reg.get("services", {})
    online = sum(1 for s in services.values() if s.get("status") == "online")
    return {"total": len(services), "online": online, "services": services}

def get_os_summary():
    """轻量摘要（Dashboard卡片用）"""
    status = get_os_status()
    return {"total": status["total"], "online": status["online"],
            "offline": status["offline"], "health": "healthy" if status["offline"] == 0 else "degraded",
            "services": [{"name": s["name"], "type": s["type"], "port": s["port"], "status": s["status"]}
                         for s in sorted(status["services"].values(), key=lambda x: x["name"])]}

def get_system_resources():
    """系统资源 (CPU/Memory/Disk via psutil)"""
    import psutil; cpu = psutil.cpu_percent(interval=0.3)
    mem = psutil.virtual_memory(); disk = psutil.disk_usage("/")
    return {"cpu_percent": cpu, "memory_gb": round(mem.used/1e9,1), "disk_gb": round(disk.used/1e9,1), ...}
```

**Route (routes.py):**
```python
from backend import hermes_os
@bp.route("/api/os")
def api_os():
    return jsonify({"status": hermes_os.get_os_status(), "summary": hermes_os.get_os_summary(), "resources": hermes_os.get_system_resources()})
@bp.route("/os")
def os_page():
    return render_template("os.html")
```

**HTML template (os.html) key elements:**
```html
<!-- Stats row: Services Online / CPU / Memory / Disk -->
<div class="stats-row">
  <div class="stat-card"><div class="label">Services Online</div><div class="value" id="total-online">—</div></div>
  <div class="stat-card"><div class="label">CPU</div><div class="value" id="cpu-value">—</div>
    <div class="resource-bar"><div class="fill" id="cpu-bar" style="width:0%"></div></div></div>
  <!-- memory, disk → same pattern -->
</div>

<!-- Service Mesh: auto-generated cards -->
<div class="section-title"><i class="bi-diagram-3"></i> Service Mesh</div>
<div class="service-grid" id="service-grid">Loading...</div>
```

**JS refresh logic:**
```javascript
async function refresh() {
    const r = await fetch('/api/os');
    const d = await r.json();
    const s = d.summary;
    // Update stats
    document.getElementById('total-online').textContent = `${s.online}/${s.total}`;
    // Update resource gauges
    document.getElementById('cpu-value').textContent = `${res.cpu_percent.toFixed(1)}%`;
    document.getElementById('cpu-bar').style.width = `${cpu}%`;
    // Build service cards
    const grid = document.getElementById('service-grid');
    grid.innerHTML = '';
    for (const svc of s.services) {
        const card = document.createElement('div'); card.className = 'service-card';
        card.innerHTML = `
            <div class="status-dot ${svc.status}"></div>
            <div class="service-icon ${svc.type}"><i class="bi ${typeIcons[svc.type] || 'bi-box'}"></i></div>
            <div class="service-info">
                <div class="name">${svc.name}</div>
                <div class="type">${svc.type}</div>
                <div class="port">:${svc.port}</div>
            </div>`;
        grid.appendChild(card);
    }
}
refresh(); setInterval(refresh, 10000);
```

**Key conventions:**
- Service type icons: gateway→bi-hdd-stack, api-server→bi-cloud-arrow-up, dashboard→bi-speedometer2, web-ui→bi-window, wiki→bi-book, mcp→bi-plug
- Status dots: online=green glow, offline=red glow (CSS box-shadow)
- Resource bars: <50% green, 50-80% yellow, >80% red
- Nav links to Dashboard (:8050), WebUI(:8000), WebUI(:8648)
- Auto-refresh every 10 seconds

**Known pitfalls:**
- `registry.json` uses file-based storage — concurrent writes may drop data. Acceptable for 2-minute heartbeat interval
- Service status shows "stale" for 60s after restart until next heartbeat
- psutil not available? `get_system_resources()` returns error dict, system gracefully shows "—"

### Type L: Live Log Stream Panel

For embedding a real-time log viewer in the Dashboard that tails and displays logs from multiple Hermes OS services.

**Architecture:**
```text
~/.hermes/os/log_aggregator.py  →  backend/log_aggregator.py  →  /api/os/logs  →  OS page (JS render)
```

**Aggregator (log_aggregator.py):**
```python
SOURCES = {
    "gateway": "~/.hermes/logs/agent.log",
    "dashboard": "~/.hermes/state/dashboard.log",
    "heartbeat": "~/.hermes/logs/cron/heartbeat.log",
    "errors": "~/.hermes/logs/errors.log",
    "cron": "~/.hermes/logs/cron/cron.log",
}
def tail_file(path, max_lines=50):
    if not os.path.exists(path): return []
    with open(path, "r", errors="replace") as f:
        return [l.rstrip() for l in f.readlines()[-max_lines:] if l.strip()]
def detect_level(line):
    upper = line.upper()
    if "ERROR" in upper or "TRACEBACK" in upper: return "ERROR"
    if "WARN" in upper: return "WARN"
    return "INFO"
```
Output format: JSONL with {source, timestamp, message, level}

**Backend module (backend/log_aggregator.py):**
```python
def get_logs(limit=100, level=None, source=None):
    """读取聚合JSONL, 可选按级别/源过滤"""
    with open(AGGREGATOR_OUTPUT) as f:
        return [json.loads(line) for line in f if line.strip()][:limit]
def get_log_summary():
    """按源统计ERROR/WARN/INFO分布"""
```

**Route:**
```python
@bp.route("/api/os/logs")
def api_os_logs():
    limit = request.args.get("limit", 50, type=int)
    level = request.args.get("level")
    source = request.args.get("source")
    return jsonify({"logs": log_aggregator.get_logs(limit, level, source),
                     "summary": log_aggregator.get_log_summary()})
```

**HTML (os.html):**
```html
<div class="section-title"><i class="bi-journal-text"></i> Live Log Stream</div>
<div id="log-container" style="background:#0d1117;border-radius:10px;padding:16px;
     font-family:monospace;font-size:0.75rem;max-height:400px;overflow-y:auto"></div>
```

**JS:**
```javascript
async function refreshLogs() {
    const r = await fetch('/api/os/logs?limit=50');
    const d = await r.json();
    const container = document.getElementById('log-container');
    container.innerHTML = '';
    for (const log of d.logs) {
        const icon = log.level === 'ERROR' ? '🔴' : log.level === 'WARN' ? '🟡' : '⚪';
        const color = log.level === 'ERROR' ? '#ef4444' : log.level === 'WARN' ? '#eab308' : '#94a3b8';
        const div = document.createElement('div');
        div.innerHTML = `<span>${icon}</span><span style="width:80px">${log.source}</span><span style="color:${color}">${log.message}</span>`;
        container.appendChild(div);
    }
}
refreshLogs(); setInterval(refreshLogs, 15000);
```

**Color scheme:** ERROR=red(#ef4444), WARN=yellow(#eab308), INFO=muted(#94a3b8), source label=text-muted

**Log filter by source (future enhancement):** Append `?source=gateway&level=ERROR` to API URL for targeted log viewing. Can be used for a "Show errors only" toggle.

**Known pitfalls:**
- Log source files may not exist (fresh install). The aggregator returns empty list, not error
- Lines >500 chars are truncated in the aggregator
- The aggregator reads tail 30 lines from each source, not full files. For deep log analysis, use the source file directly

**Pattern**: Instead of fixing the JS race condition, server-render the data at page-load time so the initial state is correct regardless of JS poll failures. Two techniques:

#### Technique 1: Flask Route → Jinja2 Template Injection

Inject data directly into the template so the initial HTML is correct:

```python
# frontend/routes.py
@bp.route("/")
def index():
    """Render the main dashboard page with server-side data for resilience."""
    cron_jobs = cron.get_cron_jobs()  # or any data source
    return render_template("index.html",
        cron_jobs=cron_jobs,           # pass parsed Python list, not JSON string
        cron_total=len(cron_jobs),
        cron_active=len([j for j in cron_jobs if j.get("enabled") != False])
    )
```

```html
<!-- index.html — server-rendered badge count (no JS dependency) -->
<span class="badge" id="job-count-badge">{{ cron_total }}</span>

<!-- index.html — server-rendered table rows (no JS dependency) -->
<tbody id="jobs-body">
  {% if cron_jobs %}
  {% for j in cron_jobs[:15] if j.get('enabled') != False %}
  <tr>
    <td>{{ j.name | truncate(24) }}</td>
    <td>{{ j.schedule_display or j.schedule or '—' | truncate(14) }}</td>
    <td>{{ j.next_run or '—' }}</td>
    <td><span class="severity-badge {{ 'healthy' if j.last_status == 'ok' else 'warning' }}">{{ (j.last_status or 'unknown') | capitalize | truncate(10) }}</span></td>
  </tr>
  {% endfor %}
  {% else %}
  <tr><td colspan="4"><div class="empty-state"><div class="empty-icon">📭</div>No data</div></td></tr>
  {% endif %}
</tbody>
```

**Key choice**: Use `tojson | safe` in a `<script>` tag to pass data from server to JS as a JSON array, NOT `json.dumps()` in Python (causes double-encoding issues):

```html
<script>
/* ── Server-side initial data ────────────────────────── */
const INITIAL_CRON = {{ cron_jobs | tojson | safe }};
</script>
```

#### Technique 2: JS Initial Data Hydration

Create a function that builds a minimal data object from server-provided data and calls `updateDashboard()` early, before the AJAX poll completes:

```html
<script>
/* ── Server-side initial data ────────────────────────── */
let initializeFromServerData = function() {
  const cron = { jobs: INITIAL_CRON, total: INITIAL_CRON.length };
  const data = {
    cron: cron,
    health: {}, healer: {}, evolution: {}, gbrain: {},
    promptchain: {}, pipeline: {}, skills: {},
    costs: {}, chat: {}, bailongma: {}, bailongma_social: {}
  };
  updateDashboard(data);
};
</script>
```

Call it at init time, BEFORE `fetchAndUpdate()`:

```javascript
/* ── Init ────────────────────────────────────────────── */
initializeFromServerData();   // <-- immediate render with server data
fetchAndUpdate();             // <-- then let AJAX overwrite with fresh data
startCountdown();
setInterval(fetchAndUpdate, POLL_INTERVAL_MS);
```

**Why it works**: The JS poll error is contained in `fetchAndUpdate()`. The server-data hydration call is a synchronous function call with data already in memory — no await, no fetch, no race condition. Even if every subsequent poll fails, the Dashboard shows correct data from page load.

#### Comparison: Server-Side vs Client-Side Rendering

| Dimension | Client-Side (JS poll) | Server-Side (Flask inj.) |
|-----------|----------------------|-------------------------|
| Initial load speed | Slow (wait for AJAX) | Instant (inline HTML) |
| Resilience to JS errors | Zero (silently blank) | Full (HTML already correct) |
| Data freshness | Poll every 30s | Initial only + AJAX refresh |
| Template complexity | Low | Medium (Jinja2 + JS) |
| When to use | Primary data flow | Fallback + initial render |

#### Best Practice: Hybrid Approach

Combine both: server-render the initial data (so the page is never blank), then let the JS poll overwrite with fresh data on each cycle. The user always sees real data, even if JS is broken.

**For the common cron jobs panel pattern**, allocate `<script>` data + server-render for the top 15 rows. The AJAX poll refreshes all 39+ jobs on the next cycle.

## Troubleshooting: Dashboard Loads But Shows No Data

When the Dashboard renders (title, HTML structure visible) but all dynamic values show "—" or "0":

### Diagnosis Workflow

```text
Step 1: Service running?        ps aux | grep app.py
Step 2: API responds?           curl -s -o /dev/null -w '%{http_code}' :5000/api/all
Step 3: API has data?           curl -s :5000/api/all | head -c 200
Step 4: Browser snapshot?       browser_navigate -> check snapshot
Step 5: JS console errors?      browser_console -> look for JS exceptions
Step 6: JS syntax OK?           Extract<script> content, test with new Function()
Step 7: Duplicate const/let?    grep -n "const \|let "  to find same-name declarations
Step 8: Fixed? Restart Flask    kill + restart required for template cache
```

### Common Root Causes

| Symptom | Root Cause | Fix |
|---------|-----------|-----|
| Page loads, no dynamic data | JS silent exception (SyntaxError/ReferenceError) | Check browser_console, fix JS |
| "Identifier has already been declared" | Duplicate `const`/`let` in same function scope | `grep -n "const "` find dupes, remove extras |
| Template changes not reflected | Flask caches templates in `debug=False` mode | Restart Flask server |
| Multiple Flask processes | Previous background processes not killed | `kill $(lsof -t -i:5000)` before restart |
| New panel still shows placeholder | DOM ref missing from `els` object | Add `panelId: $('panel-id')` to `const els` |
| API returns 200 but browser shows nothing | `const` declared inside `if`/`for` block used outside | Move declaration to function scope |
| `new Function()` passes but browser fails | Function declarations inside other functions create separate scopes in browser but not in `new Function()` wrapper | Test with IIFE wrapper: `new Function('(function(){"use strict";' + js + '})()')` |
| API returns 200, panel still shows "0" or "—" | **Data source field name mismatch** — backend `get_*()` reads wrong field names (e.g., `j.get("status")` when source has `last_status`, `j.get("next_run")` when source has `next_run_at`) | `curl -s :5000/api/<endpoint> | python3 -m json.tool` to check actual field names in API output → check raw data source schema → fix `j.get()` calls in backend module to match actual field names |

### Key Tools

- `browser_navigate(url)` — Load page and get accessibility snapshot showing rendered content
- `browser_console()` — Check for JS exceptions and console.log output
- `browser_snapshot()` — Full rendered DOM tree
- `new Function(js)` — Test JS syntax in Node
- Template cache: Flask stores compiled templates. In production mode (`debug=False`), changes to `index.html` require server restart. Always restart after editing templates.

## Pitfalls

1. **HTMX polling conflicts**: /api/all is polled every 30s. Keep its payload under ~100KB. Use get_*_summary() variants for combined endpoint.
2. **Blocked pipe to Python**: curl ... | python3 -c may be blocked by sandbox. Use curl > /tmp/file.json && python3 pattern instead.
3. **Port binding**: Port 5000 may already be in use. Always kill before restarting.
4. **Template caching**: Flask loads templates from disk on every request in debug mode. In production mode (`debug=False`), template changes require a server restart OR set `TEMPLATES_AUTO_RELOAD = True` in app.py. Always restart after editing templates in production mode.
5. **Empty state**: Always have a fallback HTML for when data is empty.
6. **Missing DOM refs**: If getElementById returns null, accessing .textContent throws. Always guard with if (el).
7. **Background restart**: Use terminal(background=true) for long-lived Flask process, then terminal() for tests in separate calls.
8. **Duplicate const declarations**: When adding multiple JS sections that reference the same data (e.g., `const pc = data.promptchain || {}`), the second `const pc` in the same function scope causes `SyntaxError: Identifier 'pc' has already been declared`. Always reuse existing consts or rename to avoid duplication. Check with `grep -n "const "` on the template file.
9. **Browser vs Node.js execution**: `new Function()` tests put all code in a single scope, masking nested function scope differences. A `const` in a nested `function(){}` is valid in the browser but `new Function()` may report it as a duplicate if the same name exists in the outer scope. Always test in the actual browser with `browser_navigate` + `browser_console`.
10. **Silent JS errors**: Without `window.onerror`, a SyntaxError in any panel's JS code silently kills the entire `updateDashboard()` IIFE — all panels appear blank with no visible error. Always add the `window.onerror` handler as a safety net during development.
11. **Duplicate DOM IDs from card replacement**: When enriching an existing card (e.g., adding fields to GBrain), you must **delete the old HTML card** before adding the new one. If you add a new card with the same ID while the old card still exists, the browser only returns the first `getElementById()` match — the old card's DOM references win and the new one appears blank. Always search `grep -n 'id=\\"gbrain-'` (or whatever prefix) to verify no duplicates before deploying. In rare cases where the old card is in a different `.row`, it's safer to `patch` it in-place rather than adding a duplicate.

13. **Flask Blueprint trailing slash mismatch**: When using Flask Blueprints with route `@bp.route("/portal")` (no trailing slash) and a login API redirects to `/portal/` (with trailing slash), the browser 404s. Flask treats `/portal` and `/portal/` as **different routes**. Fix: make the redirect URL match the actual route exactly. Use `redirect: "/portal"` not `redirect: "/portal/"` when the route is `@bp.route("/portal")`.

## Verification

### Quick smoke test

```bash
# Verify API endpoint
curl -s http://localhost:5000/api/<name>

# Verify /api/all includes it
curl -s http://localhost:5000/api/all | python3 -c "import sys,json; d=json.load(sys.stdin); print(list(d.keys()))"

# Verify HTML rendering
curl -s http://localhost:5000/ | grep -c "Section ID or unique HTML text"

# Verify dashboard restart
kill $(lsof -t -i:5000) 2>/dev/null
cd ~/projects/hermes-dashboard && python3 app.py &
sleep 2 && curl -s -o /dev/null -w '%{http_code}' http://localhost:5000/
```

### Post-deployment E2E verify script

For production deployments, create an automated `verify_dashboard.py` script that validates all layers:

```python
#!/usr/bin/env python3
"""verify_dashboard.py — 15-point E2E health check for Hermes Dashboard"""
import urllib.request, json, sys, os
errors = []

def check(desc, ok):
    tag = "PASS" if ok else "FAIL"
    print(f"  [{tag}] {desc}")
    if not ok: errors.append(desc)

# 1. Service alive
base = "http://localhost:5000"
try:
    r = urllib.request.urlopen(base, timeout=5)
    check(f"Dashboard alive (HTTP {r.status})", r.status == 200)
except Exception as e: check(f"Dashboard alive", False)

# 2. /api/all responds
try:
    r = urllib.request.urlopen(f"{base}/api/all", timeout=5)
    all_data = json.loads(r.read())
    check("/api/all returns 200 + valid JSON", True)
except Exception as e: check("/api/all valid JSON", False)

# 3–15. Individual data checks...
#  (health data, pipeline status, cron counts, skills data, etc.)

print(f"\n{'='*50}")
print(f"Result: {len(errors)} failures / {15 - len(errors)} passed")
if errors:
    print(f"Failures: {', '.join(errors)}")
    sys.exit(1)
```

**Check categories to cover:**
- Service alive (HTTP 200)
- /api/all returns valid JSON with expected keys
- Pipeline panel: agent count, progress percentage data
- Skills panel: total count, categories
- HTML rendering: critical element IDs exist in served HTML
- JS syntax: extract `<script>` blocks, validate with `new Function()` in Node
- Error banner: `window.onerror` handler is registered

## Feedback Engine Patches
*自动生成于 2026-07-16 02:02:04*

## Tool Recommendations (from trajectory feedback)

### patch
Trajectory analysis shows **patch** strongly correlates with high session scores.
- Use `patch` for targeted find-and-replace edits instead of sed/awk.
- Supports fuzzy matching with 9 strategies for robust edits.
- Auto-runs syntax checks after modification.
- Preferred for surgical code changes over full file rewrites.

### Guardrails
- Ensure `old_string` is unique in the file unless `replace_all=True`.
- Include enough surrounding context to guarantee uniqueness.
- Use `mode='patch'` for V4A multi-file patches.

### Efficiency Tips
- Combine multiple edits into a single V4A patch when possible.
- Use `replace_all=True` for bulk replacements of the same pattern.
- Preview changes with `--dry-run` mode before applying.

---
## Feedback Engine Patches
*自动生成于 2026-07-17 02:02:37*

## Tool Recommendations (from trajectory feedback)

### patch
Trajectory analysis shows **patch** strongly correlates with high session scores.
- Use `patch` for targeted find-and-replace edits instead of sed/awk.
- Supports fuzzy matching with 9 strategies for robust edits.
- Auto-runs syntax checks after modification.
- Preferred for surgical code changes over full file rewrites.

### Guardrails
- Ensure `old_string` is unique in the file unless `replace_all=True`.
- Include enough surrounding context to guarantee uniqueness.
- Use `mode='patch'` for V4A multi-file patches.

### Efficiency Tips
- Combine multiple edits into a single V4A patch when possible.
- Use `replace_all=True` for bulk replacements of the same pattern.
- Preview changes with `--dry-run` mode before applying.

---
## Feedback Engine Patches
*自动生成于 2026-07-22 12:19:48*

## Tool Recommendations (from trajectory feedback)

### patch
Trajectory analysis shows **patch** strongly correlates with high session scores.
- Use `patch` for targeted find-and-replace edits instead of sed/awk.
- Supports fuzzy matching with 9 strategies for robust edits.
- Auto-runs syntax checks after modification.
- Preferred for surgical code changes over full file rewrites.

### Guardrails
- Ensure `old_string` is unique in the file unless `replace_all=True`.
- Include enough surrounding context to guarantee uniqueness.
- Use `mode='patch'` for V4A multi-file patches.

### Efficiency Tips
- Combine multiple edits into a single V4A patch when possible.
- Use `replace_all=True` for bulk replacements of the same pattern.
- Preview changes with `--dry-run` mode before applying.
