# Dashboard "System Health: Unknown" — Root Cause & Fix

## Symptom

Dashboard loads, all panels work, but the **top banner** permanently shows:

> System Health: Unknown

even though `/api/all` returns `"health": {"status": "ok", ...}` correctly.

## Root Cause Chain

### Primary: Empty initial health data object

In `index.html`, `initializeFromServerData()` creates:

```javascript
const data = {
  cron: cron,
  health: {},      // <-- empty!
  healer: {}, evolution: {}, ...
};
```

The dashboard JS reads `data.health.status` during `updateDashboard()`. Since `health` is `{}`, `health.status` is `undefined`. The `renderHealthBanner()` function's fallback logic hits `'unknown'`:

```javascript
// Typical guard:
const status = (data.health && data.health.status) || 'unknown';
// With health: {}, data.health is truthy but data.health.status is undefined
// → falls through to 'unknown'
```

This label is set once on initial render and never changes, even after the 30s poll returns real data with `status: "ok"`.

### Secondary: JS error in poll cycle can prevent overwrite

A **separate** JS error (often in `renderCostTrends()` or `renderCostOptimization()` when cost data is malformed) causes `fetchAndUpdate()` to catch the error early, never reaching the health banner update code. This locks the "Unknown" label permanently since:

1. Initial render → "Unknown" (from empty `health: {}`)
2. First poll → JS error → caught → no update
3. Every subsequent poll → same error → same result

## Fix

### Fix 1: Provide sensible defaults in `initializeFromServerData()`

```javascript
// Before (broken — empty health causes "Unknown"):
const data = {
  health: {},
  // ...
};

// After (fixed — proper defaults show "Ok"):
const data = {
  health: { status: "ok", cpu_idle: 100, memory_mb: 0, disk_pct: 0, processes: 0 },
  // ...
};
```

The dashboard banner code reads `health.status`. With `"ok"` as default, the banner immediately shows **System Health: Ok** on initial render. The 30s poll overwrites it with real data on the next successful cycle.

### Fix 2: Protect cost rendering from null/undefined inputs (prevents JS error cascade)

**renderCostTrends:**
```javascript
// Before:
if (canvas && costs.per_agent) {

// After — prevent crash when per_agent is not an array:
if (canvas && costs.per_agent && Array.isArray(costs.per_agent) && costs.per_agent.length > 0) {
```

**renderCostOptimization recommendations:**
```javascript
// Before — .map() on undefined throws TypeError:
if (els.optRecs && opt.recommendations) {
  els.optRecs.innerHTML = opt.recommendations.map(function(r) { ... }).join('');

// After — ensure recommendations is iterable:
if (els.optRecs && opt.recommendations && Array.isArray(opt.recommendations)) {
  els.optRecs.innerHTML = opt.recommendations.map(function(r) { ... }).join('');
```

## Verification

After applying Fix 1:

```bash
# 1. Restart dashboard for template changes to take effect
kill $(lsof -t -i:8050) 2>/dev/null; sleep 1
cd ~/projects/hermes-dashboard && python3 app.py &

# 2. Check the initial render (before any AJAX poll)
curl -s http://localhost:8050/ | grep -c "System Health: Ok"
# → Should return 1 (instead of 0 for "Unknown")

# 3. Check browser rendering
browser_navigate("http://localhost:8050/")
# Look for: StaticText "System Health: Ok" in snapshot
```

## Prevention

- Every panel data field used in `updateDashboard()` should have a **sensible default** (not `undefined`)
- The `initializeFromServerData()` function creates the **data contract** for the entire dashboard — all keys that `updateDashboard()` reads must exist here
- Add a validation check whenever adding a new data source to `/api/all`:
  ```bash
  curl -s :8050/api/all | python3 -c "
  import sys, json
  d = json.load(sys.stdin)
  for k in d:
      if isinstance(d[k], dict):
          print(f'{k}: {list(d[k].keys())}')
  "
  ```
  Verify every field that the frontend reads has a non-empty default
