# Canvas Chart Engine — Zero-Dependency Chart Rendering

General-purpose Canvas-based chart functions (pie, bar, line) for any web project.
No libraries — pure `CanvasRenderingContext2D`. Dark-theme optimized.

## Functions

### `drawPie(canvasId, data, labels, legendId)`

Parameters: `canvasId` (string), `data` (number[]), `labels` (string[]), `legendId` (string|optional)

Draws a donut/pie chart. Auto-generates legend below the canvas. Slices < 0.3 radians skip percentage labels (too small to read). Colors cycle through a 12-color palette.

```javascript
const CHART_COLORS = ['#3b82f6','#10b981','#f59e0b','#ef4444','#8b5cf6','#ec4899','#06b6d4','#84cc16','#f97316','#6366f1','#14b8a6','#e11d48'];

function drawPie(canvasId, data, labels, legendId) {
  const c = document.getElementById(canvasId);
  if (!c) return;
  const ctx = c.getContext('2d');
  const W = c.width, H = c.height, cx = W/2, cy = H/2, R = Math.min(W,H)/2 - 10;
  ctx.clearRect(0,0,W,H);
  const total = data.reduce((a,b)=>a+b,0);
  if (total === 0) { ctx.fillStyle='#334155'; ctx.font='14px sans-serif'; ctx.textAlign='center'; ctx.fillText('无数据',cx,cy); return; }
  let start = -Math.PI/2;
  data.forEach((v,i) => {
    const angle = (v/total) * Math.PI * 2;
    ctx.beginPath(); ctx.moveTo(cx,cy); ctx.arc(cx,cy,R,start,start+angle);
    ctx.closePath(); ctx.fillStyle = CHART_COLORS[i % CHART_COLORS.length]; ctx.fill();
    ctx.strokeStyle = '#0f172a'; ctx.lineWidth = 2; ctx.stroke();
    if (angle > 0.3) {
      const mx = cx + Math.cos(start + angle/2) * R*0.6;
      const my = cy + Math.sin(start + angle/2) * R*0.6;
      ctx.fillStyle = '#fff'; ctx.font = 'bold 11px sans-serif'; ctx.textAlign = 'center';
      ctx.fillText(Math.round(v/total*100)+'%', mx, my+4);
    }
    start += angle;
  });
  if (legendId) {
    const el = document.getElementById(legendId);
    if (el) el.innerHTML = labels.map((l,i) =>
      `<span class="chart-legend-item" style="display:inline-flex;align-items:center;gap:4px;margin:2px 6px;cursor:pointer;font-size:11px">
        <span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:${CHART_COLORS[i%CHART_COLORS.length]}"></span>
        ${l} (${data[i]})
      </span>`
    ).join('');
  }
}
```

### `drawBar(canvasId, data, labels, color)`

Parameters: `canvasId` (string), `data` (number[]), `labels` (string[]), `color` (string|string[]|optional, default '#3b82f6')

Vertical bar chart with gradient fill, value labels above bars, truncated x-axis labels. Accepts a single color or an array for per-bar coloring.

```javascript
function drawBar(canvasId, data, labels, color='#3b82f6') {
  const c = document.getElementById(canvasId);
  if (!c) return;
  const ctx = c.getContext('2d');
  const W = c.width, H = c.height;
  ctx.clearRect(0,0,W,H);
  if (!data.length) { ctx.fillStyle='#334155'; ctx.font='14px sans-serif'; ctx.textAlign='center'; ctx.fillText('无数据',W/2,H/2); return; }
  const max = Math.max(...data, 1);
  const pad = {t:10,b:20,l:30,r:10};
  const bw = (W - pad.l - pad.r) / data.length;
  data.forEach((v,i) => {
    const bh = (v/max) * (H - pad.t - pad.b);
    const x = pad.l + i * bw + bw*0.1;
    const y = H - pad.b - bh;
    const w = bw * 0.8;
    const grad = ctx.createLinearGradient(x,y,x,H-pad.b);
    const col = Array.isArray(color) ? color[i%color.length] : color;
    grad.addColorStop(0, col || CHART_COLORS[i%CHART_COLORS.length]);
    grad.addColorStop(1, (col||CHART_COLORS[i%CHART_COLORS.length])+'66');
    ctx.fillStyle = grad;
    ctx.beginPath(); ctx.roundRect(x,y,w,bh, [3,3,0,0]); ctx.fill();
    ctx.fillStyle = '#94a3b8'; ctx.font = '9px sans-serif'; ctx.textAlign = 'center';
    ctx.fillText(v, x+w/2, y-4);
    ctx.fillStyle = '#64748b'; ctx.font = '8px sans-serif';
    const label = labels[i].length > 6 ? labels[i].slice(0,5)+'..' : labels[i];
    ctx.fillText(label, x+w/2, H-4);
  });
}
```

### `drawLine(canvasId, data, labels)`

Parameters: `canvasId` (string), `data` (number[]), `labels` (string[])

Line chart with gradient area fill, dashed grid lines, data point dots with value labels, truncated x-axis labels. Best for time-series/trend data.

```javascript
function drawLine(canvasId, data, labels) {
  const c = document.getElementById(canvasId);
  if (!c) return;
  const ctx = c.getContext('2d');
  const W = c.width, H = c.height;
  ctx.clearRect(0,0,W,H);
  if (!data.length || data.every(v=>v===0)) { /* empty state */ return; }
  const max = Math.max(...data, 1);
  const pad = {t:10,b:20,l:30,r:10};
  const xStep = (W - pad.l - pad.r) / Math.max(data.length-1, 1);
  const points = data.map((v,i) => ({
    x: pad.l + i * xStep,
    y: H - pad.b - (v/max) * (H - pad.t - pad.b)
  }));
  // Grid lines (dashed)
  ctx.strokeStyle = '#1e293b'; ctx.lineWidth=1; ctx.setLineDash([3,3]);
  for (let g=1; g<=4; g++) {
    const gy = pad.t + (H-pad.t-pad.b)/4*(g-1);
    ctx.beginPath(); ctx.moveTo(pad.l,gy); ctx.lineTo(W-pad.r,gy); ctx.stroke();
  }
  ctx.setLineDash([]);
  // Area fill (gradient)
  ctx.beginPath(); ctx.moveTo(points[0].x, H-pad.b);
  points.forEach(p => ctx.lineTo(p.x, p.y));
  ctx.lineTo(points[points.length-1].x, H-pad.b); ctx.closePath();
  const grad = ctx.createLinearGradient(0,0,0,H);
  grad.addColorStop(0, 'rgba(59,130,246,0.3)'); grad.addColorStop(1, 'rgba(59,130,246,0.02)');
  ctx.fillStyle = grad; ctx.fill();
  // Line
  ctx.beginPath(); ctx.moveTo(points[0].x, points[0].y);
  points.forEach(p => ctx.lineTo(p.x, p.y));
  ctx.strokeStyle = '#3b82f6'; ctx.lineWidth=2.5; ctx.lineJoin='round'; ctx.stroke();
  // Dots + values
  points.forEach((p,i) => {
    ctx.beginPath(); ctx.arc(p.x, p.y, 4, 0, Math.PI*2);
    ctx.fillStyle = '#3b82f6'; ctx.fill();
    ctx.strokeStyle = '#0f172a'; ctx.lineWidth=2; ctx.stroke();
    ctx.fillStyle = '#94a3b8'; ctx.font = '9px sans-serif'; ctx.textAlign = 'center';
    ctx.fillText(data[i], p.x, p.y-9);
  });
  // X labels
  points.forEach((p,i) => {
    ctx.fillStyle = '#64748b'; ctx.font = '8px sans-serif'; ctx.textAlign = 'center';
    ctx.fillText(labels[i].length > 7 ? labels[i].slice(2) : labels[i], p.x, H-4);
  });
}
```

## Required CSS (for legend items)

```css
.chart-legend-item:hover { background: rgba(255,255,255,0.05); }
.chart-canvas-wrap { position: relative; width: 100%; display: flex; justify-content: center; }
.chart-canvas-wrap canvas { max-width: 100%; }
```

## Known Limitations

- Canvas `ctx.roundRect()` is supported in all modern browsers (Chrome 99+, Firefox 112+, Safari 15.4+). For older browser support, replace with manual `arcTo()` path.
- Line chart uses `ctx.setLineDash` which is supported everywhere.
- Labels are truncated at 6 chars for bar charts, 7 chars for line charts — adjust slice length for your data.
- The chart functions assume a dark background (stroke colors like `#0f172a` for slice separators). Adjust for light themes.
