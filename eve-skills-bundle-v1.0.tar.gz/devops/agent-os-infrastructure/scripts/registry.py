#!/usr/bin/env python3
"""
Hermes OS Service Registry — 服务注册中心
用于agent-os-infrastructure技能的轻量服务发现

用法:
  python3 registry.py register <name> <type> <port> [host]
  python3 registry.py heartbeat <name>
  python3 registry.py check
  python3 registry.py list
"""
import json, os, time
from datetime import datetime

REGISTRY_FILE = os.path.expanduser("~/.hermes/os/registry.json")
os.makedirs(os.path.dirname(REGISTRY_FILE), exist_ok=True)

def load():
    if os.path.exists(REGISTRY_FILE):
        with open(REGISTRY_FILE) as f:
            return json.load(f)
    return {"services": {}, "updated_at": None}

def save(reg):
    reg["updated_at"] = datetime.now().isoformat()
    with open(REGISTRY_FILE, "w") as f:
        json.dump(reg, f, indent=2, ensure_ascii=False)

def register(name, stype, port, host="0.0.0.0", meta=None):
    reg = load()
    reg["services"][name] = {
        "name": name, "type": stype, "host": host, "port": port,
        "url": f"http://{host}:{port}",
        "meta": meta or {},
        "status": "online",
        "last_heartbeat": time.time(),
        "registered_at": reg["services"].get(name, {}).get("registered_at", datetime.now().isoformat())
    }
    save(reg)
    print(f"[Registry] Registered: {name} ({stype}) on :{port}")

def heartbeat(name):
    reg = load()
    if name in reg["services"]:
        reg["services"][name]["last_heartbeat"] = time.time()
        reg["services"][name]["status"] = "online"
        save(reg)

def check_stale(timeout=60):
    reg = load()
    now = time.time()
    changed = False
    for name, svc in reg["services"].items():
        if now - svc["last_heartbeat"] > timeout and svc["status"] == "online":
            svc["status"] = "offline"
            changed = True
            print(f"[Registry] Stale: {name}")
    if changed:
        save(reg)

def list_services():
    reg = load()
    return reg["services"]

if __name__ == "__main__":
    import sys
    cmd = sys.argv[1] if len(sys.argv) > 1 else "list"
    if cmd == "register" and len(sys.argv) >= 5:
        register(sys.argv[2], sys.argv[3], int(sys.argv[4]), sys.argv[5] if len(sys.argv) > 5 else "0.0.0.0")
    elif cmd == "heartbeat" and len(sys.argv) >= 3:
        heartbeat(sys.argv[2])
    elif cmd == "check":
        check_stale()
        for name, svc in load()["services"].items():
            icon = "✅" if svc["status"] == "online" else "❌"
            print(f"{icon} {name:30s} {svc['type']:20s} :{svc['port']:<5}")
    elif cmd == "list":
        print(json.dumps(load(), indent=2, ensure_ascii=False))
    else:
        print("Usage: registry.py [register|heartbeat|check|list]")
