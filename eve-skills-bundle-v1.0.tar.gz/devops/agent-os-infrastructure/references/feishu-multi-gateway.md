# Feishu Multi-Gateway Troubleshooting

## Symptom

飞书群聊不响应、不回复、无协作。Gateway日志显示WebSocket keepalive ping timeout，每~10分钟断开重连。

## Diagnosis

```bash
# 1. Count gateway processes
ps aux | grep "hermes.*gateway" | grep -v grep | wc -l
# Expected: 1 (main) + maybe 2 (yestin/tester profiles with --replace)
# Problem: 12+ (main + 10 agent profiles + yestin/tester)

# 2. Check Feishu lock files
ls ~/.local/state/hermes/gateway-locks/feishu-*.lock | wc -l
# Expected: 1-3
# Problem: 10+

# 3. Check gateway logs for keepalive timeouts
journalctl --user -u hermes-gateway.service --no-pager | grep "keepalive ping timeout"
# Shows: "sent 1011 (internal error) keepalive ping timeout; no close frame received"
```

## Root Cause

**12 Gateway processes × 1 Feishu WebSocket each = 12 concurrent connections**

Each Agent Profile runs its own `hermes gateway run --profile <name>` which independently connects to Feishu WebSocket. The Feishu server cannot maintain 12 concurrent keepalive streams:
- Keepalive ping timeout every ~10 minutes
- Connection drops → message loss during reconnection window
- Multiple app_ids registered in gateway-locks (each profile has its own feishu app_id)

## Fix

### 1. Disable Feishu in all Agent Profile configs

Each profile's config.yaml at `~/.hermes/profiles/<name>/config.yaml` has:

```yaml
feishu:
    enabled: true           # ← Change to false
    extra:
      app_id: cli_xxx
      app_secret: ${FEISHU_APP_SECRET}
```

Change `enabled: true` to `enabled: false` for all profiles.

### 2. Kill and restart agent gateways

```bash
# Kill all profile gateways
ps aux | grep "hermes.*gateway.*--profile" | grep -v grep | awk '{print $2}' | xargs -r kill -9
```

Note: Some processes may auto-restart via cron/systemd. The CMMI5 PM Scheduler (runs every 5min) may restart them. Check and disable if needed.

### 3. Clean stale lock files

```bash
rm -f ~/.local/state/hermes/gateway-locks/feishu-app-id-*.lock
```

## Verification

```bash
# Should show only 1-3 gateway processes
ps aux | grep "hermes.*gateway" | grep -v grep

# Expected:
# main gateway (systemd, --replace)
# yestin profile (--replace, API-only)
# tester profile (--replace, API-only)

# Check gateway logs for Feishu errors
journalctl --user -u hermes-gateway.service --no-pager --since "5 minutes ago" | grep -ci "feishu\|lark\|timeout\|disconnect"
# Should be 0
```

## Profile Config Locations

| Profile | Config Path |
|---------|------------|
| pm | `~/.hermes/profiles/pm/config.yaml` |
| req | `~/.hermes/profiles/req/config.yaml` |
| arch | `~/.hermes/profiles/arch/config.yaml` |
| dev | `~/.hermes/profiles/dev/config.yaml` |
| sec | `~/.hermes/profiles/sec/config.yaml` |
| tester | `~/.hermes/profiles/tester/config.yaml` |
| qa | `~/.hermes/profiles/qa/config.yaml` |
| cm | `~/.hermes/profiles/cm/config.yaml` |
| doc | `~/.hermes/profiles/doc/config.yaml` |
| spi | `~/.hermes/profiles/spi/config.yaml` |
| yestin | `~/.hermes/profiles/yestin/config.yaml` |
