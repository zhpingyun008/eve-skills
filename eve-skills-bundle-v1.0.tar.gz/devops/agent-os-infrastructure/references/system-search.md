# System Search Implementation

## Backend (`~/.hermes/os/system_search.py`)

Cross-source search engine that indexes Skills/Sessions/Logs/Config.

### Architecture

```
user query (GET /portal/api/search?q=xxx)
    │
    ├── _search_skills(q)
    │     glob ~/.hermes/skills/**/SKILL.md
    │     → parse frontmatter for name
    │     → case-insensitive content match
    │     → return type="skill", icon="📦"
    │
    ├── _search_profiles(q)
    │     listdir ~/.hermes/profiles/*/sessions/
    │     → take last 10 JSON files per profile
    │     → json.dumps() + lower() match
    │     → return type="session", icon="💬"
    │
    ├── _search_logs(q)
    │     listdir ~/.hermes/logs/ (last 5 files)
    │     → line-by-line lower() match
    │     → return type="log", icon="📋", line number
    │
    └── _search_config(q)
          read config.yaml line by line
          → return type="config", icon="⚙️"
```

### Key Functions

```python
def search(query, limit=20)  # Main entry: queries 4 sources, returns sorted results
def _search_skills(q, limit)  # Parse SKILL.md frontmatter, content match
def _search_profiles(q, limit)  # Latest sessions JSON content match
def _search_logs(q, limit)  # Recent log file line match
def _search_config(q, limit)  # Config file line match
def _extract_snippet(text, query, window=60)  # Context window around match
```

### Result Format

```json
{
  "type": "skill|session|log|config",
  "title": "Display title",
  "path": "Relative or absolute file path",
  "match": "Context snippet around match (~150 chars)",
  "icon": "📦|💬|📋|⚙️"
}
```

### Pitfalls

- `glob("**/SKILL.md", recursive=True)` on 250+ skills takes ~1-2 seconds
- Session search opens each JSON file fully into memory — large session files (>5MB) will cause latency
- Log search reads entire files line by line — avoid on files >50MB
- Case-insensitive via `content.lower()` — will not find camelCase or mixed-case matches accurately
- No ranking — results are ordered by source priority (skills first), not relevance
- Portal search page at `/portal/search?q=xxx` is a standalone HTML page, not part of the sidebar layout
- Search input in sidebar uses `onkeydown` event, not form submit — works but loses focus on redirect
