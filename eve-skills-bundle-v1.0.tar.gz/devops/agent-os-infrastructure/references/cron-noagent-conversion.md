# Cron no_agent模式转换参考 (2026-05-28)

## 核心原则

Hermes Agent的Cron任务支持两种模式：
- **LLM驱动**（默认）：每次触发调用LLM处理prompt，消耗token
- **no_agent=True**：直接执行script，零LLM调用，零token消耗

**什么时候用no_agent：** Cron任务只需要执行terminal命令/脚本，不需要LLM推理（健康检查、服务自愈、命令执行等）

## 转换清单（16个已转换任务）

| Cron | 频率 | 原Model | 转换方式 | 脚本 |
|------|------|---------|----------|------|
| Gateway AutoHeal | 每2分钟 | z-ai/glm-4-flash | no_agent+bash | gateway-autoheal.sh |
| 全栈自主学习(frequent) | 每5分钟 | z-ai/glm-4-flash | no_agent+bash | fullstack-learn.py |
| 全栈课程引擎(hourly) | 每1小时 | z-ai/glm-4-flash | no_agent+bash | fullstack-learn.py |
| Workflow Orchestrator | 每3分钟 | z-ai/glm-4-flash | no_agent+python | workflow-orchestrator.py |
| 统一健康检查 | 每5分钟 | z-ai/glm-4-flash | no_agent+python | unified-health-check.py |
| BookStack巡检 | 每5分钟 | z-ai/glm-4-flash | no_agent+bash | start-bookstack.sh |
| Xvfb自愈 | 每4分钟 | glm-4.5-air | no_agent+python | browser-tool.py |
| WebUI自启 | 每5分钟 | glm-4.5-air | no_agent+bash | curl check |
| Bailongma巡检 | 每5分钟 | z-ai/glm-4-flash | no_agent+python | check_health.py |
| Context Auto-Writer | 每3分钟 | glm-4.5-air | no_agent+python | context-auto-write.py |
| 增强学习引擎 | 每30分钟 | z-ai/glm-4-flash | no_agent+bash | enhanced-learn.py |
| 飞书心跳推送 | 每2小时 | glm-4-flash | no_agent+python | feishu-pusher.py |
| 飞书每日报告 | 每日9点 | glm-4-flash | no_agent+python | feishu-pusher.py |
| 进化快检 | 每12小时 | z-ai/glm-4-flash | no_agent+bash | evolution_engine.py |
| Feishu WebSocket | 每15分钟 | z-ai/glm-4-flash | no_agent+bash | lock check |
| Feishu Group Bridge | 每2分钟 | z-ai/glm-4-flash | no_agent+python | feishu-group-bridge.py |

## 转换模式

### 模式1: Python脚本包装器（推荐）
```python
#!/usr/bin/env python3
import subprocess, sys, os
result = subprocess.run(['python3', os.path.expanduser('~/scripts/target.py')],
                       capture_output=True, text=True, timeout=30)
out = result.stdout.strip()
if out:
    print(f'[Service] {out}')
# silent when healthy → Cron不发送输出
```

### 模式2: Bash脚本包装器
```bash
#!/usr/bin/env bash
output=$(bash ~/scripts/target.sh fix 2>&1)
if echo "$output" | grep -qi "repaired\|restarted\|error"; then
  echo "[$(date '+%H:%M:%S')] $output"
fi
```

### 关键规则
1. **静默成功 = 不输出** — no_agent模式只有输出时才发送消息
2. **异常时才出声** — 只在修复/错误时输出，健康状态静默
3. **30-60s超时** — 防止脚本hang住Cron调度器
4. **cwd使用绝对路径** — no_agent脚本默认无~/.hermes上下文

## 效果

- ZAI API调用量减少约85%
- 429限频从6680次/24h降至约500次/24h
- 零新增token消耗
