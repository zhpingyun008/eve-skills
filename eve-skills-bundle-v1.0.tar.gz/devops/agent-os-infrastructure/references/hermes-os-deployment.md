# Hermes OS 部署参考 (2026-05-28)

## 端口规划

| 端口 | 服务 | 说明 |
|------|------|------|
| 8000 | Hermes WebUI | Node.js chat interface |
| 8050 | Hermes Dashboard | Flask+HTMX监控+Dashboard |
| 8082 | PromptChain | Prompt toolchain service |
| 8642 | Hermes OS API | 统一API Server (systemd) |
| 8648 | Hermes WebUI | Vue Hermes client |
| 8655 | Hermes Gateway | 主Gateway+16平台 |

## 服务清单

| 名称 | Type | 状态 | 管理方式 |
|------|------|------|----------|
| hermes-os-api | api-server | systemd | `systemctl --user [start/stop/restart/status]` |
| hermes-gateway | gateway | systemd | `systemctl --user` |
| hermes-dashboard | dashboard | systemd | `systemctl --user` |
| hermes-promptchain | service | systemd | `systemctl --user` |
| hermes-wiki | wiki | systemd | `systemctl --user` |
| WebUI-8000 | web-ui | managed by webui Cron | auto-heal |
| WebUI-8648 | web-ui | managed by webui Cron | auto-heal |
| computer-use-mcp | mcp | spawned by Gateway | auto |

## 系统d服务列表

```
hermes-dashboard.service       active  Dashboard + Portal
hermes-gateway.service         active  Gateway (Feishu/Discord/Telegram)
hermes-os-api.service          active  OS API Server
hermes-promptchain.service     active  Prompt Toolchain
hermes-wiki.service            active  Documentation Wiki
```

## Portal路由结构

```
:8050/
├── / (Dashboard首页)
├── /portal (Portal首页 — Quick Launch + 系统概览 + Activity Feed)
├── /portal/terminal (Web Terminal — xterm.js)
├── /portal/cmmi5 (CMMI5 Agent集群面板)
├── /portal/store (Skill Store — 250技能搜索)
├── /os (OS Service Mesh)
├── /api/os (OS状态API)
├── /api/os/logs (日志聚合API)
├── /portal/api/profiles (CMMI5 Profiles API)
├── /portal/api/profiles/<name>/sessions (Agent会话API)
├── /portal/api/store (技能商店API)
├── /portal/api/store/search (技能搜索API)
├── /portal/api/events (事件总线API)
├── /portal/api/webui-status (WebUI在线检测)
└── /portal/api/exec (终端命令执行API)
```

## Cron Job统计

- 总计: 70个（原64 + OS Heartbeat + Log Aggregator + Event Bus + 原有）
- no_agent: 17个（脚本直接执行，零LLM调用）
- LLM驱动: 53个（需要推理的智能任务）

### OS专属Cron

| Cron | 频率 | 用途 | 模式 |
|------|------|------|------|
| OS Service Heartbeat | 每2分钟 | 服务注册心跳+超时检测 | no_agent |
| OS Log Aggregator | 每5分钟 | 6源日志统一采集 | no_agent |
| OS Event Bus Publisher | 每5分钟 | 事件心跳自动发布 | no_agent |

## Agent Profiles (12个)

| Profile | Model | Provider | 角色 |
|---------|-------|----------|------|
| pm | deepseek-v4-pro | deepseek | 项目管理 |
| req | deepseek-v4-pro | deepseek | 需求分析 |
| arch | deepseek-v4-pro | deepseek | 架构设计 |
| dev | deepseek-v4-pro | deepseek | 开发实现 |
| sec | deepseek-v4-pro | deepseek | 安全合规 |
| tester | deepseek-v4-flash | deepseek | 测试 |
| qa | deepseek-v4-flash | deepseek | 质量保证 |
| cm | deepseek-v4-flash | deepseek | 配置管理 |
| doc | deepseek-v4-flash | deepseek | 文档 |
| spi | deepseek-v4-flash | deepseek | 供应商管理 |
| yestin | deepseek-v4-flash | deepseek | 主Agent |

## Hermes OS Phase依赖

| Phase | 内容 | 状态 |
|-------|------|------|
| Phase 1 | API Server独立:8642 + Service Registry + Log Aggregator | ✅ 完成 |
| Phase 2 | 统一Portal + Web Terminal + CMMI5面板 | ✅ 完成 |
| Phase 3 | Skill Store 250索引 + Event Bus + 全链路集成 | ✅ 完成 |
| Next | Desktop客户端 · 在线Skill商店 · GPU监控 | ⏳ 待定 |
