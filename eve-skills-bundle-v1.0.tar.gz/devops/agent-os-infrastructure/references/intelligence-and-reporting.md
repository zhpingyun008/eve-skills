# Intelligence Engine + Feishu Daily Report

## Intelligence Engine (`~/.hermes/os/intel_engine.py`)

统一智能层，聚合5个数据源到单一Portal面板。

### 数据源
| 源 | 方法 | 说明 |
|----|------|------|
| Evolution Engine | `meta-evolution/data/latest.json` (fallback:MEMORY.md) | 评分+维度 |
| Learning System | `knowledge/learned/*.json` + `research/*.md` | 笔记统计+最新主题 |
| System Summary | `systemctl` + `uptime` + `os.walk(skills)` + `state.db cron_jobs` | 运行状态聚合 |
| Event Bus | `event_bus.jsonl` | 最近20条事件 |
| Health Engine | `health_engine.py` (通过self-report) | 评分数据 |

### Portal页面 (`/portal/intel`)
- **顶部**: 5统计卡片(服务/Cron/Skills/笔记/运行时间)
- **左列**: 进化评分环+维度分解
- **右列**: 学习活动摘要+近期主题
- **底部**: 事件流Activity Feed(15条)
- **报表面板**: 飞书日报预览(一键刷新)

### API端点
- `GET /portal/api/intel` — 完整智能数据
- `GET /portal/api/intel/report` — 日报Markdown文本

## Feishu Daily Report

### Cron Job
- **名称**: `Hermes OS Daily Report to Feishu`
- **频率**: 每日9点
- **模式**: no_agent, deliver=feishu:oc_45221585195958ed91e3edb673cfafd8
- **脚本**: 调用`intel_engine.generate_daily_report()`输出Markdown

### 日报结构
```
🤖 Hermes OS Daily Report
📅 2026-05-28 11:12:10

📊 System Status
• Services: 5 systemd
• Cron Jobs: 70
• Skills: 250 installed
• Uptime: up 2 hours

🧬 Evolution
• (进化引擎数据)

📚 Learning Activity
• Total notes: 0
• Recent: topic1, topic2, topic3

📌 Recent Activity
• [HH:MM:SS] Event message
```

### 扩展指南
- 新增数据源: 在`get_all_intel()`中添加新key, 在`generate_daily_report()`中添加对应section
- 推送时间: 调整cron schedule `0 HH * * *`
- 推送目标: 修改cron deliver参数
