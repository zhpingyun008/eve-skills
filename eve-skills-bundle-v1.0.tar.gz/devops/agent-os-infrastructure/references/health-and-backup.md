# Health + Backup 参考 (2026-05-28, Phase 5)

## System Health Scoring

5维度评分系统，综合评分0-100，附带等级(A+/A/B/C/D/F)。

### 评分维度

| 维度 | 权重 | 数据源 | 公式 |
|------|:----:|--------|------|
| CPU | 20% | `top -bn1` 空闲率 | idle值直接作为分数 |
| 内存 | 20% | `free -m` MemAvailable | (available/total)*100 |
| 磁盘 | 20% | `df -h /` Use% | max(0, 100 - pct*0.8) |
| 服务 | 25% | systemd hermes*服务活跃率 | (active/total)*100 |
| 错误率 | 15% | errors.log 最后1000行中ERROR计数 | max(10, 100 - min(cnt*10, 90)) |

### 等级

| 分数 | 等级 | 含义 |
|:----:|:----:|------|
| ≥90 | A+ | 完美 |
| ≥80 | A | 优秀 |
| ≥70 | B | 良好 |
| ≥60 | C | 及格 |
| ≥40 | D | 需关注 |
| <40 | F | 危险 |

### 趋势检测

基于最后10个评分点判断：
- recent[-1] > recent[0] + 5 → improving
- recent[-1] < recent[0] - 5 → degrading
- 否则 → stable

### 优化建议引擎

基于各维度分数自动生成建议：

| 条件 | 建议 |
|------|------|
| disk < 60 | 💾 磁盘空间不足，运行清理 |
| memory < 60 | 🧠 内存压力，检查泄漏 |
| errors < 70 | 🔴 错误率偏高，检查error日志 |
| services < 80 | ⚙️ 部分服务离线 |
| cpu < 60 | 🔥 CPU负载高，检查进程 |
| 全部正常 | ✅ 系统状态良好 |

### 数据存储

- 实时评分: `~/.hermes/os/health_scores.jsonl` (追加写)
- 历史上限: 1440条(24h @ 1min间隔，实际每5分钟采样)
- Portal展示: Chart.js趋势图(最近24h，采样至最多100点)

### Cron

```
Hermes OS Health Score  */5 * * * *  采集评分数据
```

### API端点

| 端点 | 说明 |
|------|------|
| `/portal/health` | 健康仪表盘页面 |
| `/portal/api/health/score` | 当前评分JSON |
| `/portal/api/health/trend?hours=24` | 趋势数据(含points/current/trend/count) |
| `/portal/api/health/tips` | 优化建议列表 |

---

## Backup Engine

### 备份内容 (8项)

| 文件 | 说明 | 大小 |
|------|------|:----:|
| config.yaml | Agent配置 | ~2K |
| registry.json | 服务注册表(OS) | ~1K |
| event_bus.jsonl | 事件总线(OS) | ~10K |
| health_scores.jsonl | 健康评分历史(OS) | ~50K |
| skill_store.json | 技能索引(OS) | ~30K |
| backlog.json | Backlog数据 | ~5K |
| sprint_history.jsonl | Sprint历史 | ~10K |
| services_snapshot.txt | systemd服务快照 | ~2K |

### 操作

```bash
# 创建备份
python3 ~/.hermes/os/backup_engine.py create "label"
→ Backup created: hermes-os_20260528_105147_label (8 files)

# 列出备份
python3 ~/.hermes/os/backup_engine.py list
→ Backups (1): ✅ hermes-os_20260528_105147_label

# 恢复备份
python3 ~/.hermes/os/backup_engine.py restore "hermes-os_20260528_105147"
→ Restored 8 files
```

### 存储位置

`~/.hermes/backups/hermes-os_YYYYMMDD_HHMMSS_label/`

每个备份目录包含：
- manifest.json — 备份清单
- config.yaml — 配置快照
- registry.json — 注册表快照
- event_bus.jsonl — 事件总线
- health_scores.jsonl — 评分历史
- skill_store.json — 技能索引
- backlog.json — Backlog
- sprint_history.jsonl — Sprint历史
- services_snapshot.txt — systemd快照

### API端点

| 端点 | 说明 |
|------|------|
| `/portal/api/backup/list` | 备份列表 |
| `/portal/api/backup/create?label=xxx` | 创建备份 |
| `/portal/api/backup/restore/<name>` | 恢复备份 |
