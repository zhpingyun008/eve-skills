# Report Engine + Brand Landing Page — Reference

## Report Engine (`~/.hermes/os/report_engine.py`)

### Architecture

```python
generate_report(format="md")  # Main entry: Returns full system report in requested format
collect_all()                 # Aggregate system/services/health/resources data
_to_markdown(data)            # Format as Markdown
_to_html(data)                # Format as standalone HTML page
_to_md_to_html(md)            # Minimal MD-to-HTML converter for embedding
```

### Supported Formats

| Format | Endpoint | Content Type | Use Case |
|--------|----------|--------------|----------|
| Markdown | `GET /portal/api/report/md` | Plain text | Feishu/Discord push, file export |
| JSON | `GET /portal/api/report/json` | JSON | Programmatic consumption |
| HTML | `GET /portal/api/report/html` | HTML | Browser preview, email |

### Data Collected

| Section | Source | Method |
|---------|--------|--------|
| System | `uptime -p`, `uname -a` | subprocess |
| Services | `systemctl --user list-units` | subprocess, filter "hermes" |
| Health | `health_engine.py score` | script invocation |
| Resources | `free -h`, `df -h /`, `state.db size` | subprocess + os.path.getsize |

### Portal Page

`/portal/report` — Three format buttons (MD/JSON/HTML), live preview panel, char count + timestamp metadata.

### Pitfalls

- Report is a point-in-time snapshot — no historical comparison
- `subprocess.run(timeout=5)` may fail under system load — add retry for production
- HTML format uses a custom minimal MD→HTML converter, NOT a full markdown library
- Report content length varies: MD ~700 chars, JSON ~3KB, HTML ~2KB depending on system size

## Brand Landing Page (`/portal/about`)

### Design

- Full-screen centered layout (not sidebar-based)
- Hero section: logo + tagline + tech badges (CMMI5/Self-Healing/Auto-Learning)
- Live stats: service count, cron jobs, skills, health score (fetched from API)
- Navigation grid: 10 portal pages as linked cards with icon + name + description
- Footer: version info, model/provider, system summary

### Implementation

- Standalone HTML template (portal_about.html) — NOT shared sidebar
- Stats populated via client-side JS fetching 3 parallel API calls on load
- Root route `/` redirects to `/portal/about` via `@app.route("/")` redirect

### Pitfalls

- Landing page has NO sidebar — ensure direct URL access to other pages is available
- Stats JS runs on page load — initial render shows "—" placeholders before API responds
- Redirect from `/` means the legacy Dashboard at `/` is no longer the root page
