# Pipeline + Admin Console 参考 (2026-05-28, Phase 4)

## CMMI5 Pipeline DAG

### 管道顺序

```
PM(9) → REQ(5) → ARCH(4) → DEV(14) → TEST(9) → QA(8) → CM(5) → SPI(7)
                            ↓
                           SEC(6) → QA
                                       ↓
                                      DOC(7) → SPI
```

括号内为已完成任务数。SEC和DOC为并行分支。

### 数据来源

SQLite: `~/projects/hermes-infra/agent-bridge/agent_bridge.db`

| 表 | 行数 | 用途 |
|----|------|------|
| agent_tasks | 74 | 任务记录(agent_id, status, task_name, started_at) |
| agent_artifacts | 341 | 产物(artifact_type, artifact_path, hash) |
| agent_feedback | 103 | Agent间反馈(source → target, feedback_type) |
| agent_context | 638 | Agent间上下文传递 |
| agent_skill_invocations | 2425 | 技能调用历史 |

### 状态统计 (2026-05-28)

| Agent | 任务数 | 产物数 | 状态 |
|-------|--------|--------|------|
| PM | 9 | 24 | completed |
| REQ | 5 | 11 | completed |
| ARCH | 4 | 20 | completed |
| DEV | 14 | 81 | completed |
| SEC | 6 | 31 | completed |
| TEST | 9 | 49 | completed |
| QA | 8 | 28 | completed |
| CM | 5 | 16 | completed |
| DOC | 7 | 58 | completed |
| SPI | 7 | 23 | completed |
| **总计** | **74** | **341** | **all completed** |

### 反馈流拓扑

```
PM → DEV (3x info)
REQ → PM (3x info), REQ → ARCH (3x info)
ARCH → DEV (4x info), ARCH → PM (4x suggestion)
DEV → TEST (6x info)
SEC → DEV (1x warning)
TEST → DEV (1x warning)
QA → DEV (1x blocker)
CM → CM (71x blocker — 自阻断, CM内部审计)
DOC → SPI (5x info)
```

### 前端实现

纯CSS DAG，无外部依赖：
- 按order分组为stage列
- 并行agent放在同一个stage-parallel容器
- 箭头用pipe-arrow div(CSS line实现)
- 状态动画：completed=静态绿, running=脉冲蓝, idle=灰

---

## System Admin Console

### 服务控制

| 服务ID | 显示名 | 描述 |
|--------|--------|------|
| hermes-gateway | Gateway | 消息网关(16平台) |
| hermes-dashboard | Dashboard | 系统监控面板 |
| hermes-os-api | OS API | 统一API服务:8642 |
| hermes-promptchain | PromptChain | 提示词工具链 |
| hermes-wiki | Wiki | 知识库 |

### API端点

```bash
# 列出服务状态
GET /portal/api/admin/services
→ {"services": [{"id":"hermes-gateway","active":true,"pid":"10834",...}]}

# 执行操作
GET /portal/api/admin/service/hermes-gateway/restart
→ {"service":"hermes-gateway","action":"restart","success":true,
   "services":[...]}  # 操作后自动刷新全量状态

# 进程列表
GET /portal/api/admin/processes
→ {"processes": [{"pid":"356","cpu":"0.5","mem":"1.2","cmd":"python -m hermes..."}]}

# 系统信息
GET /portal/api/admin/system
→ {"uptime":"up 1 hour", "memory":"Mem: 1.6G/8.2G"}
```

### 安全设计

- **白名单**: 仅限5个已注册的systemd服务，不接受任意service_id
- **操作确认**: 前端confirm()弹窗，仅restart和stop需要确认
- **超时保护**: systemctl操作30秒超时
- **只读模式**: start操作不会覆盖已存在的active服务(前端disabled)

### 进程监控

从`ps aux --sort=-%mem`中过滤包含`hermes`/`python3`/`node`的进程(排除grep自身)。显示前20条。

---

## 新增API端点总表 (Phase 4)

| 端点 | 方法 | 说明 |
|------|------|------|
| `/portal/pipeline` | GET | Pipeline可视化页面 |
| `/portal/api/pipeline` | GET | 管道状态JSON(agents+DAG+summary) |
| `/portal/api/pipeline/activity?limit=20` | GET | 最近管道活动 |
| `/portal/admin` | GET | 系统管理控制台页面 |
| `/portal/api/admin/services` | GET | 服务状态列表 |
| `/portal/api/admin/service/<id>/<action>` | GET | 服务操作(不能POST，Flask blueprint限制) |
| `/portal/api/admin/processes` | GET | 进程列表 |
| `/portal/api/admin/system` | GET | 系统信息 |

## 数据规模 (2026-05-28)

| 指标 | 值 |
|------|-----|
| Pipeline Agents | 10 |
| Pipeline Tasks | 74 (全部completed) |
| Pipeline Artifacts | 341 |
| Admin Services | 5 (4 active) |
| Portal Pages | 7 (均HTTP 200) |
| systemd Services | 5 (hermes-os-api新增) |
