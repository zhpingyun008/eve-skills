# Skill Store + Event Bus 参考 (2026-05-28)

## Skill Store 架构

### 数据流
```
os.walk(~/.hermes/skills/) → 每个SKILL.md:
  1. 解析YAML frontmatter (name, description, triggers, tags, related_skills)
  2. 统计脚本数量 (.py, .sh, .js, .ts)
  3. 计算文件大小
  4. 提取分类 (目录层级的第一级)

→ skill_store.json (完整索引)
→ Portal web UI (分类tab + 搜索框)
```

### 核心文件路径
- `~/.hermes/os/skill_store.py` — 扫描+解析+索引引擎
- `~/.hermes/os/skill_store.json` — 索引缓存
- `~/projects/hermes-dashboard/backend/skill_store.py` — Dashboard后端
- `~/projects/hermes-dashboard/frontend/templates/portal_store.html` — 前端UI

### API端点
- `GET /portal/api/store` — 完整商店数据
- `GET /portal/api/store/search?q=&category=` — 搜索
- `GET /portal/api/store/categories` — 分类列表

### 数据规模 (2026-05-28)
- 250个SKILL.md索引
- 41个分类
- 296个参考.md文件
- 340个脚本
- 索引时间: ~5-10秒

---

## Event Bus 架构

### 事件模型
```json
{
  "id": "1745814577000_hermes-os",
  "type": "system.startup | system.service | cron.optimized | cron.tick | health.alert | sprint.status",
  "source": "hermes-os | hermes-dashboard | hermes-gateway | ...",
  "message": "Phase 2 completed — Portal, Terminal, CMMI5 panels online",
  "data": {},
  "timestamp": 1745814577.0,
  "time_str": "10:29:37"
}
```

### 核心文件路径
- `~/.hermes/os/event_bus.py` — 发布/订阅引擎
- `~/.hermes/os/event_bus.jsonl` — 事件存储
- `~/projects/hermes-dashboard/backend/event_bus.py` — Dashboard后端
- `~/projects/hermes-dashboard/frontend/templates/portal.html` — Activity Feed UI

### 操作命令
```bash
# 发布事件
python3 ~/.hermes/os/event_bus.py publish "system.startup" "my-service" "Service started"

# 查看摘要
python3 ~/.hermes/os/event_bus.py summary

# 查看最近事件
python3 ~/.hermes/os/event_bus.py
```

### Portal集成
Portal首页底部Activity Feed每20秒刷新，显示：
- 时间戳 + 类型图标 + 来源 + 消息
- 类型图标映射：系统启动🚀, 服务⚙️, 升级⬆️, 优化⚡, 健康🟢/🔴

### 裁剪策略
- 最大500条事件，超出自动从头部裁剪
- 保留最近事件
- JSONL格式便于grep/awk分析
