# Cloudflare Tunnel 快速公网部署

> 2026-06-17 | 适用场景：WSL 环境下将 localhost 服务暴露到公网

## 安装 cloudflared

```bash
# 方法 1: apt 安装
sudo apt-get install -y cloudflared

# 方法 2: 直接下载二进制 (WSL 推荐)
wget -q https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 -O /tmp/cloudflared
sudo mv /tmp/cloudflared /usr/local/bin/
sudo chmod +x /usr/local/bin/cloudflared
cloudflared --version
```

## 快速启动临时隧道 (无 Cloudflare 账号)

```bash
cloudflared tunnel --url http://localhost:PORT
```

cloudflared 会自动生成一个 `https://RANDOM-WORDS.trycloudflare.com` 公网 URL。

## 持久化运行 (后台)

```bash
cloudflared tunnel --url http://localhost:PORT > /tmp/cloudflared_url.log 2>&1 &
```

URL 会出现在日志中，格式:
```
Your quick Tunnel has been created! Visit it at:
https://random-words-here.trycloudflare.com
```

## 验证隧道健康

```bash
# 查看连接状态
cat /tmp/cloudflared_url.log | grep -i "created\|PASS\|FAIL"

# 测试公网可达性
curl -s -o /dev/null -w "HTTP %{http_code} (%{time_total}s)" --max-time 15 https://RANDOM-URL.trycloudflare.com/

# 测试 API 端点
curl -s -X POST https://RANDOM-URL.trycloudflare.com/api/endpoint \
  -H "Content-Type: application/json" \
  -d '{"key":"value"}'
```

## 故障排查

### 症状: "failed to parse quick Tunnel ID: invalid UUID length: 0"
- **原因**: cloudflared 无法解析 trycloudflare.com 的 DNS
- **检查**: `curl -s -o /dev/null -w '%{http_code}' --max-time 10 https://trycloudflare.com/`
- **修复**: 这个问题通常是瞬时的，重试即可。如果持续，检查 WSL DNS (`cat /etc/resolv.conf`)

### 症状: 连接测试全部 PASS 但 curl 返回 HTTP 502
- **原因**: 本地服务未运行或端口不对
- **检查**: `curl -s http://localhost:PORT/`
- **修复**: 先启动本地服务，再启动 tunnel

### 症状: UDP Connectivity FAIL (QUIC)
- **原因**: WSL 网络限制 UDP 出站
- **修复**: cloudflared 会自动降级到 HTTP/2 (TCP)，隧道仍可用

## 已知限制

1. **临时隧道无 SLA**: trycloudflare.com 的即用隧道无可用性保证，适合演示和测试，生产环境应使用命名隧道
2. **WSL DNS 间歇性不可达**: WSL 的 DNS 代理 `10.255.255.254` 对某些域名间歇性失败，重试通常可解决
3. **cloudflared 需保持前台运行**: 隧道进程退出后 URL 立即失效

## 替代方案

| 工具 | 安装 | 可靠性 | 适用场景 |
|:----|:----|:------:|:--------|
| Cloudflare Tunnel | binary | ⭐⭐⭐⭐⭐ | 公网部署首选 |
| Serveo (SSH) | 内置 | ⭐⭐⭐ | WSL 友好但偶尔超时 |
| localtunnel (npm) | `npm i -g localtunnel` | ⭐⭐⭐ | 简单场景 |
| ngrok | binary | ⭐⭐⭐⭐ | 需注册账号 |

## Windows 端 (WSL 宿主)

如果 WSL 内网络受限，可在 Windows 上运行 cloudflared：

```batch
REM deploy_windows.bat
cloudflared tunnel --url http://localhost:PORT
```

WSL2 会自动将 localhost 端口转发到 Windows，所以 Windows 上 cloudflared 可以连接 WSL 内的服务。
