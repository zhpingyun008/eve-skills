# User-Level systemd — Deploy Services Without Root

## Problem

Agent services (eve-discuss-api, watchdog, CMMI5 bridges, etc.) need systemd supervision for auto-restart, health checks, and lifecycle management. But in WSL environments or CI runners, `sudo` for system-level `systemctl` is unavailable or impractical.

## Solution

User-level systemd (`systemctl --user`) runs a per-user systemd instance that requires no root privileges. One-time `loginctl enable-linger` ensures user services start at boot; after that, all management is permissionless.

## Quick Setup

```bash
# Step 1: Enable lingering (one-time sudo, registers user session on boot)
sudo loginctl enable-linger $USER

# Step 2: Verify it's active
systemctl --user status    # Should show user systemd running
loginctl show-user $USER   # Check Linger=yes

# Step 3: Place service file
mkdir -p ~/.config/systemd/user/
cp my-service.service ~/.config/systemd/user/

# Step 4: Manage entirely as user — no sudo ever
systemctl --user daemon-reload
systemctl --user enable my-service.service
systemctl --user start my-service.service
systemctl --user status my-service.service
```

## Service File Template

```ini
[Unit]
Description=Eve Discuss API
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=/home/yestin/.venv/bin/python /home/yestin/company/scripts/discuss-api.py
Restart=always
RestartSec=30
WatchdogSec=15
Environment=PYTHONUNBUFFERED=1

[Install]
WantedBy=default.target
```

Note: `WantedBy=default.target` (NOT `multi-user.target`) — user-level services use `default.target`.

## Common Commands

| Command | Effect |
|---------|--------|
| `systemctl --user list-units --type=service` | List user services |
| `systemctl --user enable <name>.service` | Enable on boot |
| `systemctl --user start <name>.service` | Start now |
| `systemctl --user status <name>.service` | Check status + journal |
| `loginctl enable-linger $USER` | Enable user session persistence |
| `journalctl --user -u <name>.service -n 50` | View logs (user scope) |

## Existing User Services (Reference)

On this host, the following user-level services are already running:

| Service | Function |
|---------|----------|
| bookstack.service | BookStack Wiki (MariaDB + PHP) |
| eve-contact-api.service | Eve Contact Form — Lead Submission |
| hermes-os-api.service | Hermes OS API Server (port 8642) |
| hermes-gateway.service | Hermes Gateway (Feishu/Discord/Telegram) |
| hermes-dashboard.service | Hermes Dashboard + Portal (port 8050) |

## Pitfalls

1. **`WantedBy=multi-user.target` is wrong for user services.** Always use `default.target`. Using `multi-user.target` will cause `enable` to fail silently or create broken symlinks.

2. **One-time `loginctl enable-linger` is required.** Without it, user services stop when the user logs out (WSL session ends). After `enable-linger`, services survive session disconnects and restart at boot.

3. **`After=network-online.target` still works** in user mode — the user systemd waits for network just like the system one.

4. **`WorkingDirectory` paths must be absolute** — user systemd's `~` expansion is inconsistent across versions. Always use full paths (`/home/yestin/...`) in ExecStart.

5. **WSL-specific:** If WSL doesn't emit `systemd-logind`, `loginctl` may fail. Workaround: run `sudo loginctl enable-linger $USER` from the WSL command line once. After that the linger flag persists across reboots.

6. **Environment variables from `~/.bashrc` are NOT loaded** by systemd services (user or system). Use `Environment=` directives in the service file or an `EnvironmentFile=` to set required env vars.

7. **Quick check for availability:** `systemctl --user status` should return a status message, not "Failed to connect to bus". If the bus is missing, check `XDG_RUNTIME_DIR` is set and `dbus.service` is running.

## Verification Checklist

- [ ] `loginctl show-user $USER` shows `Linger=yes`
- [ ] `systemctl --user is-enabled <name>.service` returns `enabled`
- [ ] `systemctl --user is-active <name>.service` returns `active`
- [ ] Service restarts automatically after process kill (`pkill -f <name>` followed by `systemctl --user status`)
- [ ] After `sudo reboot` or WSL restart, service comes up automatically
