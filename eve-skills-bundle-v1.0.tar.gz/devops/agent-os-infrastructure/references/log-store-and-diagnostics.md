# Log Store & Diagnostics — Reference

## Log Store Architecture

```
~/.hermes/os/log_store.py    →  Python SQLite engine
~/projects/hermes-dashboard/backend/log_store.py  →  Dashboard backend
/portal/logs                 →  Portal log browser page
/portal/api/logs             →  JSON query API
/portal/diag                 →  Diagnostics page
/portal/api/diag             →  JSON diagnostics API
```

## Data Sources

| Source | Path | Lines Ingested |
|--------|------|:--------------:|
| agent | ~/.hermes/logs/agent.log | 500 |
| gateway | ~/.hermes/logs/gateway.log | 500 |
| errors | ~/.hermes/logs/errors.log | 500 |
| dashboard | ~/.hermes/logs/dashboard.log | 500 |

## Query Parameters

`GET /portal/api/logs?source=agent&level=ERROR&q=timeout&limit=100&hours=24`

| Param | Default | Options |
|-------|---------|---------|
| source | all | all, agent, gateway, errors, dashboard |
| level | all | all, ERROR, WARN, INFO, DEBUG |
| q | — | free-text search in message |
| limit | 100 | max rows returned |
| hours | 24 | time window |
| offset | 0 | pagination |

## Level Detection Logic (log_store.py)

```python
upper = line.upper()
if "ERROR" in upper or "TRACEBACK" in upper or "FATAL" in upper: return "ERROR"
if "WARN" in upper: return "WARN"
if "INFO" in upper: return "INFO"
if "DEBUG" in upper or "TRACE" in upper: return "DEBUG"
return "INFO"
```

## Diagnostics Output

`GET /portal/api/diag` returns:
- `sections.services` — systemd service summary + details
- `sections.disk` — `df -h` output
- `sections.memory` — `free -h` output
- `sections.state_db` — state.db size in MB
- `sections.system` — system metadata (services/cron/skills/uptime)

## Cron

| Cron | Schedule | Action |
|------|----------|--------|
| Hermes OS Log Store Ingestion | `*/5 * * * *` | `python3 log_store.py ingest` |

## Pitfalls

- First ingest auto-creates `~/.hermes/os/log_store.db` with CREATE TABLE
- Only last 500 lines per source — not a full log archive
- 30-day auto-cleanup runs on every ingest: `DELETE FROM logs WHERE timestamp < now-30d`
- Level detection is keyword-based, not structured parsing — may miscategorize
- Diagnostics runs subprocess commands per request — ~2s latency
