---
name: agent-os-infrastructure
description: AI Agent操作系统层建设 — Service Registry / API Gateway / Unified Portal / Web Terminal / Agent Cluster Monitor。在Agent CLI之上构建OS级基础设施。
category: devops
triggers:
  - "hermes os"
  - "agent os"
  - "service registry"
  - "service mesh"
  - "统一门户"
  - "unified portal"
  - "web terminal"
  - "agent monitor"
  - "api gateway agent"
  - "agent infrastructure"
  - "os layer"
  - "service registration"
  - "agent cluster"
  - "多agent管理面板"
---

# Agent OS Infrastructure

在AI Agent CLI之上构建OS级基础设施层的模式与方法。

## 架构层次

```
┌─────────────────────────────────────────────────────┐
│                 UI Layer                             │
│  CLI (Agent)  │  Web Portal  │  Desktop (Electron)  │
├─────────────────────────────────────────────────────┤
│               API Gateway Layer                      │
│  OpenAI兼容API  │  Service Registry  │  Health Endpt │
├─────────────────────────────────────────────────────┤
│           Agent Engine Layer                         │
│  Chat/Gateway/Cron/Skills/Profiles/MCP/Memory        │
└─────────────────────────────────────────────────────┘
```

## 核心组件

### 1. 独立API Server

将Agent的API能力从Gateway解耦为独立服务。

| 配置项 | 值 |
|--------|-----|
| 端口 | 8642 |
| 绑定 | 0.0.0.0 |
| CORS | * |
| 认证 | API Key (SHA256) |
| 后端 | Python http.server (轻量) 或 FastAPI |

关键端点：
- `GET /health` — 健康检查
- `GET /v1/models` — OpenAI兼容模型列表
- `POST /v1/chat/completions` — 对话代理
- `GET/POST /os/*` — OS管理端点

### 2. Service Registry (服务注册中心)

基于JSON文件的轻量服务发现。

```python
# 核心操作
register(name, type, port, host)    # 注册服务
heartbeat(name)                      # 发送心跳
check_stale(timeout=60)              # 标记超时服务为offline
list_services()                      # 列出所有服务
```

数据存储：`~/.hermes/os/registry.json`

### 3. 统一Web Portal

基于Flask+HTML的轻量门户，左导航+右内容区布局。

导航结构：
```
Core:     Home | Service Mesh | Terminal
AI:       CMMI5 Agents | Web Chat | Hermes Client
System:   Health Dashboard | Wiki
```

### 4. Web Terminal (xterm.js)

嵌入式终端，通过REST API执行命令（非WebSocket）。

安全沙箱策略：
- **白名单**: 40+允许的命令前缀（ls, cd, cat, ps, df, git, curl, python3等）
- **黑名单**: rm -rf /, mkfs, dd if= 等破坏性操作
- **超时**: 30-60s自动终止
- **cwd追踪**: 支持cd切换目录

### 5. CMMI5 Agent Cluster Monitor

多Agent Profile可视化管理面板。

数据来源：
- `~/.hermes/profiles/<name>/profile.yaml` — 配置
- `~/.hermes/profiles/<name>/sessions/` — 会话历史

### 6. Skill Store (技能商店)

250个SKILL.md技能的索引、分类、搜索系统。

核心功能：
- **全量索引**: 扫描~/.hermes/skills所有子目录，解析YAML frontmatter提取name/description/triggers/tags
- **分类浏览**: 41个分类，带图标和计数
- **全文搜索**: 按名称和描述搜索，支持大小写不敏感
- **元数据**: 脚本数量、文件大小、触发词、相关技能

数据流：
```
walk skills/ → parse SKILL.md frontmatter → count scripts → save ~/.hermes/os/skill_store.json
                                                                          ↓
                                                              Portal web UI (分类tab + 搜索框)
```

端点：
- `GET /portal/api/store` — 完整商店数据
- `GET /portal/api/store/search?q=&category=` — 搜索
- `GET /portal/api/store/categories` — 分类列表

### 8. CMMI5 Pipeline Visualization (管道流程图)

基于CMMI5 AgentBridge数据构建的管道DAG可视化。显示PM→REQ→ARCH→[DEV,SEC]→TEST→QA→[CM,DOC]→SPI的完整流水线。

**数据来源**: `~/projects/hermes-infra/agent-bridge/agent_bridge.db`
- `agent_tasks`: 74条任务记录含agent_id/status/task_name/started_at
- `agent_artifacts`: 341条产物记录(设计文档/代码/测试报告等)
- `agent_feedback`: 103条反馈记录(阻断/info/warning/suggestion)

**前端实现**: 纯CSS DAG流程图，按order分组每列stage：
```
Stage 1 → Stage 2 → Stage 3 → Stage 4 → Stage 5 → Stage 6 → Stage 7 → Stage 8
 PM        REQ       ARCH       DEV        TEST      QA         CM         SPI
                                SEC(并行)            DOC(并行)
```

**状态颜色**: completed(绿), running(蓝+脉冲), idle(灰)

端点：
- `GET /portal/api/pipeline` — 完整管道状态(agents+summary)
- `GET /portal/api/pipeline/activity?limit=N` — 最近N条活动

### 9. System Admin Console (系统管理控制台)

服务启停、进程查看、系统信息的一站式管理界面。

**功能**:
- **服务控制**: 5个systemd服务的一键start/stop/restart
- **进程监控**: Hermes相关进程列表(PID/CPU/MEM/Command)
- **系统信息**: 运行时间、内存状态

**安全设计**: REST API接口，操作需确认弹窗(restart/stop)

端点：
- `GET /portal/api/admin/services` — 服务状态列表
- `GET /portal/api/admin/service/<id>/<action>` — 执行操作(start/stop/restart)
- `GET /portal/api/admin/processes` — 进程列表
- `GET /portal/api/admin/system` — 系统信息

### 11. System Health & Evolution (系统健康评分)

5维度实时评分+趋势分析+优化建议系统。

#### 评分维度

| 维度 | 权重 | 数据源 |
|------|:----:|--------|
| CPU | 20% | top空闲率 |
| 内存 | 20% | free可用率 |
| 磁盘 | 20% | df使用率 |
| 服务 | 25% | systemd活跃率 |
| 错误率 | 15% | errors.log ERROR计数 |

综合评分0-100，对应等级A+(≥90)/A(≥80)/B(≥70)/C(≥60)/D(≥40)/F(<40)。

#### 趋势引擎

自动判断improving/degrading/stable趋势，Chart.js折线图展示24h变化。

#### 优化建议

基于低分维度自动生成可操作建议（磁盘清理/内存检查/服务恢复等）。

#### 存储

`~/.hermes/os/health_scores.jsonl` — JSONL追加写，自动裁剪至1440条。

#### 数据采集Cron

每5分钟采集一次评分，Portal每30秒刷新。

#### 端点
- `/portal/health` — 健康仪表盘页面
- `/portal/api/health/score` — 当前评分
- `/portal/api/health/trend?hours=24` — 趋势数据
- `/portal/api/health/tips` — 优化建议

### 12. 系统快照/备份

一键备份关键配置，支持列表查看和恢复。

#### 备份内容 (8项)
config.yaml / registry.json / event_bus.jsonl / health_scores.jsonl / skill_store.json / backlog.json / sprint_history.jsonl / services_snapshot.txt

#### 存储
`~/.hermes/backups/hermes-os_YYYYMMDD_HHMMSS_label/`

#### 操作
- Portal Health页面点击"Create Snapshot" / API触发
- 支持从备份列表恢复

#### 端点
- `/portal/api/backup/list` — 备份列表
- `/portal/api/backup/create?label=xxx` — 创建备份
- `/portal/api/backup/restore/<name>` — 恢复备份

### 13. Portal Home 升级


### 14. Intelligence Engine (智能层面板)

统一智能层，聚合Evolution/Learning/System/Events 4个数据源到单个Portal面板。

**后端**: `~/.hermes/os/intel_engine.py`
- `get_all_intel()` — 聚合所有数据源为单一JSON
- `generate_daily_report()` — 生成飞书日报Markdown文本

**数据流**:
```
Evolution Engine → metadata → Intel Engine → /portal/api/intel → portal_intel.html
Learning System → research/             → Intel Engine → /portal/api/intel/report → 飞书推送
System Stats  → subprocess/os.walk     → (每日9点Cron)
Event Bus     → event_bus.jsonl
```

**Portal页面**: `/portal/intel`
- 5统计卡片(服务数/Cron数/Skills/学习笔记/运行时间)
- 进化评分环+维度分解
- 学习活动摘要+近期主题
- 活动流(15条事件)
- 日报预览面板(可手动刷新)

### 15. Feishu Daily Report (飞书自动日报)

每日9点通过Cron自动生成系统状态报告并推送到飞书群聊。

| 配置项 | 值 |
|--------|-----|
| Cron Job | Hermes OS Daily Report to Feishu |
| 频率 | 每日9点 (0 9 * * *) |
| 模式 | no_agent=true |
| 目标 | feishu群聊 |
| 脚本 | intel_engine.generate_daily_report() |

报告格式参考 `references/intelligence-and-reporting.md`。

### 16. System Search (统一系统搜索)

跨Skills/Sessions/Logs/Config的全文搜索。搜索框在Portal侧边栏顶部。

**搜索源**:
| 源 | 方法 | 限制 |
|----|------|------|
| Skills | 解析SKILL.md frontmatter name | 全量扫描 |
| Sessions | profiles/&lt;name&gt;/sessions/*.json JSON内容匹配 | 每个profile最近10个 |
| Logs | ~/.hermes/logs/* 行级匹配 | 最近5个文件 |
| Config | config.yaml 行级匹配 | — |

**API**: `GET /portal/api/search?q=&lt;query&gt;&amp;limit=20`
**Portal页面**: `/portal/search?q=&lt;query&gt;` — 搜索结果页

**Pitfalls**:
- 搜索Skill时从SKILL.md提取`name:`字段作为标题，缺省会fallback到目录名
- Session搜索在profiles目录中仅取最近10个JSON文件以控制延迟
- 日志搜索在最近5个文件中逐行匹配，大日志文件(&gt;100MB)会超时
- 搜索最小长度2字符，避免单字符高频查询
- 侧边栏搜索框通过URL redirect跳转到搜索页，Enter触发

### 17. 全局侧边栏设计模式

所有Portal页面复用相同侧边栏布局。

**结构**:
```
┌────────────────────┐
│  Brand: Hermes OS  │
├────────────────────┤
│  🔍 Search input   │  ← 统一搜索入口
├────────────────────┤
│  Core              │
│  🏠 Home           │
│  📊 Service Mesh   │
│  💻 Terminal       │
├────────────────────┤
│  AI Agents         │
│  🤖 CMMI5 Agents   │
│  🔀 Pipeline       │
│  📦 Skill Store    │
│  🧠 Intelligence   │
│  💬 Web Chat       │
│  🧠 Hermes Client  │
├────────────────────┤
│  System            │
│  📈 Health         │
│  ⚙️ Admin          │
│  📚 Wiki           │
├────────────────────┤
│  Footer: status    │  ← ● 8/8 services ♥ 69.8
└────────────────────┘
```

**模式实现**:
- 每个独立页面都嵌入自己的sidebar HTML（非模板继承），避免Flask模板冲突
- .active在server端通过nav-item类设定
- Footer通过JS实时刷新服务数量和健康评分
- 搜索框Enter触发`window.location.href='/portal/search?q='+encodeURIComponent(val)`


Portal首页不再只是静态展示，包含：
- **Quick Launch卡片组**: 6个WebUI服务的一键直达(带在线状态指示灯)
- **Activity Feed**: Event Bus事件流实时刷新(每20秒)
- **系统概览**: 服务数/CPU/内存/磁盘卡片
- **侧边栏导航**: 7个导航项，响应式适配

### 7. Event Bus (事件总线)

轻量级发布/订阅事件系统，JSONL文件持久化。

事件结构：
```json
{
  "id": "timestamp_source",
  "type": "system.startup|system.service|cron.optimized|health.alert|...",
  "source": "hermes-os|hermes-dashboard|...",
  "message": "Human-readable description",
  "data": {},
  "timestamp": 1234567890.0,
  "time_str": "10:29:37"
}
```

关键特性：
- **JSONL存储**: 追加写，自动裁剪至500条上限
- **类型过滤**: 按event_type或source订阅
- **Cron集成**: 5分钟心跳事件自动发布
- **Portal集成**: Portal首页Activity Feed实时刷新

端点：
- `GET /portal/api/events?limit=50&type=` — 获取事件流
- 日志级别检测使用简单关键词匹配(ERROR/WARN/INFO/DEBUG)，非结构化解析

### 20. Report Engine (系统报告导出)

一键导出全系统状态报告，支持Markdown/JSON/HTML三种格式。详情见`references/report-and-branding.md`。

- `GET /portal/api/report/<fmt>` — 生成报告(fmt=md|json|html)
- `/portal/report` — Portal页面，三格式按钮+实时预览

### 21. Brand Landing Page (品牌启动页)

Hermes OS品牌着陆页，根路由`/`重定向至此。详情见`references/report-and-branding.md`。

- `/portal/about` — 品牌页(hero+统计+导航网格)
---详见`references/evolution-phases-summary.md`。

## Cron集成

```
hermes-os-api.service — API Server
hermes-gateway.service — 消息网关
hermes-dashboard.service — Dashboard+Portal
```

## Cron集成

| Cron | 频率 | 用途 |
|------|------|------|
| OS Service Heartbeat | 每2分钟 | 服务注册心跳+超时检测 |
| OS Log Aggregator | 每5分钟 | 6源日志统一采集 |
| OS Event Bus Publisher | 每5分钟 | 事件心跳自动发布 |
| OS Health Score | 每5分钟 | 健康评分采集 |
| OS Daily Report | 每日9点 | 飞书自动日报推送 |

### no_agent模式优化

16个高频脚本型Cron任务已从LLM驱动转为no_agent=True模式。核心原则：
- 纯terminal/API操作的Cron（健康检查、Gateway自愈、日志采集等）无需LLM调用
- 显著降低Provider API调用量和429限频风险
- 提升执行效率（直接脚本执行，无LLM延迟）
- 详情见`references/cron-noagent-conversion.md`

## Pitfalls

- API Server应作为独立systemd服务运行，不依赖Gateway
- Service Registry 60s超时配合2min心跳 = 1次心跳丢失仍在线，2次丢失标记offline
- Portal侧边栏布局使用position:fixed + margin-left，响应式需适配mobile
- 终端沙箱白名单需定期审查，避免遗漏必要的命令
- CMMI5 Agent面板的session count仅统计JSON文件数，不含未持久化的内存会话
- Log Aggregator使用tail方式（仅最后N行），不追踪增量 — 适合快速概览不适合审计
- Skill Store索引使用os.walk全量扫描，首次索引耗时约5-10秒（250个SKILL.md需解析frontmatter）
- Event Bus JSONL文件追加写入但无自动归档，500条上限在密集事件下约2小时写满
- **User-level systemd部署**: 首次sudo执行`loginctl enable-linger $USER`后可完全绕过root依赖。`WantedBy=default.target`而非`multi-user.target`是所有用户级systemd服务的正确写法。详见`references/user-level-systemd.md`
- Phase 1-3的7个API端点分散在两个blueprint（routes.py + portal_routes.py），新增端点需重启Dashboard
- **Pipeline数据源**: `agent_bridge.db`的`agent_tasks`表使用`agent_id`字段(大写)，字段名大小写敏感
- **Admin控制台安全**: 服务stop/restart操作有确认弹窗但无二次鉴权，建议生产环境加API Key验证
- **Portal响应式**: 768px断点下侧边栏缩为56px宽，此时nav-item的文字label隐藏，仅显示图标
- **Event Bus类型约定**: 自定义事件类型建议用`<domain>.<action>`格式(system.startup, cron.tick, health.alert)，保持一致性便于过滤
- **健康评分CPU**: 使用`top -bn1`的空闲率而非`ps`的进程CPU加总，避免高估负载。空闲率直接作为分数(99% idle = 99分)
- **健康评分内存**: 使用`MemAvailable`(第7列)而非`MemUsed`(第3列)，因为Linux会将缓存算入used但实际可回收
- **健康评分错误率**: `errors.log`可能包含大量WARNING行，正则使用`\bERROR\b|\bTraceback\b`精确匹配避免误计
- **备份恢复路径映射**: `backup_engine.py`内使用BACKUP_ITEMS列表建立文件名↔原始路径的映射关系，新增备份项需要双向注册
### Chart.js趋势图

近24小时的数据点采样至最多100点渲染，否则浏览器性能下降。使用`data[::max(1,len//100)]`采样策略。

### 18. Log Store (日志持久化引擎)

将4个日志源(agent/gateway/errors/dashboard)持久化到SQLite，支持全文搜索和级别/源过滤。

**引擎**: `~/.hermes/os/log_store.py`
- `ingest()` — 采集所有日志源的最后500行到SQLite
- `query(source, level, search, limit, hours)` — 可过滤查询
- 自动清理30天前的日志
- Cron: 每5分钟采集一次

**Portal页面**: `/portal/logs`
- 按源/级别/关键词过滤
- 级别分布统计卡片
- 200条实时显示，自动刷新

**API**: `GET /portal/api/logs?source=&level=&q=&limit=&hours=`

### 19. Diagnostics (系统诊断工具)

一键系统快照工具，收集服务/磁盘/内存/state.db/系统信息。

**Portal页面**: `/portal/diag`
- 点击"Run Diagnostics"触发
- 显示服务状态、磁盘使用、内存状态、state.db大小

**API**: `GET /portal/api/diag`

**Pitfalls**:
- Log Store SQLite文件(~/.hermes/os/log_store.db)在首次ingest时自动创建
- Ingest采集最近500行而非全量文件，适合快速概览不适合审计
- 30天自动清理策略通过`DELETE FROM logs WHERE timestamp < now-30d`实现，每次ingest后执行
- 日志级别检测使用简单关键词匹配(ERROR/WARN/INFO/DEBUG)，非结构化解析

### 22. Report Engine (系统报告导出)

一键导出全系统状态报告，支持MD/JSON/HTML三种格式。

**引擎**: `~/.hermes/os/report_engine.py`
- `generate_report("md")` — Markdown格式，687字符标准报告
- `generate_report("json")` — 完整JSON格式
- `generate_report("html")` — HTML格式(含CSS样式)
- `collect_all()` — 聚合服务/健康/资源/state.db数据

**Portal**: `/portal/report` — 三格式按钮+实时预览
**API**: `GET /portal/api/report/<md|json|html>`

### 23. Brand Landing Page (品牌启动页)

Hermes OS品牌着陆页，根路由`/`重定向至此。

- `/portal/about` — Hero+统计卡片+10导航网格+技术徽章
- 根路由`/` → `/portal/about` (通过app.py redirect实现)
- 实时数据：服务数/Cron数/Skills数/健康评分

### 24. System Topology (系统拓扑可视化)

服务依赖关系图，展示从User→Portal→API→Engine→Data的五层架构。

**Portal**: `/portal/topo`
- 五层拓扑图 (User/Portal/API/Engine/Data)
- 实时服务网格表 (5 service/port/status/PID)
- 6个统计卡片 (Services/Ports/Cron/Pages/Health/Uptime)
- 每30秒自动刷新

### 25. Command Palette (全局命令面板)

Ctrl+K / ⌘K 全局快捷键命令面板，20条内置命令，模糊搜索。在所有Portal页面可用。

**按键**: Ctrl+K打开, Escape关闭, ↑↓导航, Enter执行, 输入文字模糊搜索

**命令类型** (20条):
- 导航(14条): 跳转到任一Portal页面
- 操作(3条): Restart Dashboard / Create Backup / Run Diagnostics
- 外部(3条): Wiki / Chat / Hermes Client

**实现**: 纯前端JS，嵌入portal.html的`<script>`标签。COMMANDS数组硬编码。
**Pitfall**: 重启Dashboard命令会立即刷新页面，需等待2秒后reload。命令数组是静态的，新增页面需手动添加。

### 26. System Topology (系统拓扑可视化)

User→Portal→API→Engine→Data 五层服务依赖关系图。`/portal/topo`
- 五层拓扑图 + 实时服务网格表 + 6统计卡片
- 30秒自动刷新

### 27. Feishu Multi-Gateway Troubleshooting

**现象**: 飞书群聊不响应、不回复、无协作。Gateway日志显示WebSocket频繁keepalive超时断开。

**根因**: 多个Gateway进程同时连接飞书WebSocket。
- 主Gateway (systemd) + 每个Agent Profile独立Gateway = 最多12个并发WS连接
- 飞书服务端无法维持12个并发keepalive → 每~10分钟超时断开 → 消息丢失

**诊断命令**:
```bash
# 检查gateway进程数
ps aux | grep "hermes.*gateway" | grep -v grep

# 检查飞书lock文件
ls ~/.local/state/hermes/gateway-locks/feishu-*.lock

# 检查keepalive超时
journalctl --user -u hermes-gateway.service --no-pager | grep "keepalive ping timeout"
```

**修复**: 在Agent Profile的config.yaml中禁用飞书
```yaml
# ~/.hermes/profiles/<name>/config.yaml
feishu:
    enabled: false  # 只有main gateway处理飞书
```

然后重启所有agent gateway进程。

**验证**: 确认只剩1个主Gateway处理飞书
```bash
ps aux | grep "hermes.*gateway" | grep -v grep
# 应只显示1个main gateway + 几个API-only profile gateway
```

**Pitfalls**:
- Agent Profile的`feishu.enabled: true`在默认配置中可能开启，需逐个profile检查
- 即使禁用飞书，agent gateway仍可提供API服务(用于@mention bridge)
- lock文件可能需要手动清理：`rm -f ~/.local/state/hermes/gateway-locks/feishu-*.lock`
- Gateway auto-restart机制(如CMMI5 PM Scheduler)可能在stop后重新拉起，需检查cron

### 28. CMMI5 Agent Online Status Detection

CMMI5 Agent面板(`/portal/cmmi5`)需要显式添加在线状态检测。`backend/portal_cmmi5.py`中的`get_profiles()`函数应包含:

```python
info["online"] = bool(info["exists"] and info["has_config"] and info["session_count"] > 0)
```

**数据源**: 从`profiles/<name>/sessions/`目录的JSON文件数量判定。无实时进程检测——只要有历史会话记录即判定为`online`。

**Pitfall**: Session文件名是UUID格式(如`session_feac048f-3046-4685-bd49-861692888f52.json`)，无法从中提取时间戳作为`last_active`。如需精确最后活动时间，需从session JSON内部解析`started_at`字段。

**前端显示**: 卡片名称旁显示`● online`(绿色)或`○ offline`(红色)。TEST profile需要手动创建目录和init session文件。

### 28. 10-Phase Evolution 演进总览

Hermes OS从CLI工具到16页面管理平台的完整构建过程(约3小时)。

| Phase | 内容 | 耗时 | 产出 |
|-------|------|:----:|------|
| 1 | API独立+注册中心+日志聚合 | 40min | 3核心组件 |
| 2 | 统一Portal+Terminal+CMMI5 | 20min | 3 Portal页面 |
| 3 | Skill Store+Event Bus | 15min | 2系统模块 |
| 4 | Pipeline+系统管理控制台 | 20min | 2管理面板 |
| 5 | 健康评分+进化+备份 | 15min | 3运维工具 |
| 6 | 智能层+飞书日报 | 10min | 1智能面板+1Cron |
| 7 | 系统搜索+Portal升级 | 10min | 搜索+首页升级 |
| 8 | 日志持久化+浏览器+诊断 | 8min | 3日志工具 |
| 9 | 报告导出+品牌启动页 | 8min | 3品牌页面 |
| 10 | 拓扑+Cron健康+经验沉淀 | 5min | 拓扑图+技能沉淀 |
| 11 | Command Palette+飞书修复 | 5min | 全局快捷键+WS竞争修复 |

---详见`references/evolution-phases-summary.md`。

## Cron集成
- `references/report-and-branding.md` — 报告导出 + 品牌启动页
