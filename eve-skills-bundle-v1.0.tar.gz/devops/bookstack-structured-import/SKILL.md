---
category: devops
description: Import structured project data (workload tables, WBS, requirement lists,
  budget breakdowns, credential vaults) from user-provided text into BookStack as
  hierarchical project documentation pages with computed summary statistics. Also
  covers direct MySQL fallback when BookStack API is unavailable.
name: bookstack-structured-import
triggers:
- 导入工作量清单 / 导入需求表 / 导入WBS / 导入任务分解
- create BookStack project page from table data / structured data to BookStack
- 项目工作量导入BookStack / 需求清单入库
- workload list / WBS / requirement inventory / budget breakdown to BookStack
- 创建项目文档到BookStack / 工作量汇总
workflow:
  load_order: late
---

# BookStack Structured Data Import

Import structured project data tables into BookStack as properly formatted documentation pages with calculated summaries.

## Workflow

### Step 1: Parse user-provided data
The user typically provides a markdown table or text with rows of work items. Extract:
- **Module/grouping column**: First column text, used for grouping
- **Sub-category column**: Second column (work type, sub-module)
- **Workload column**: Numeric values (人天/hours/days)
- **Text columns**: Description, notes, status fields

```python
# Pattern: parse workload numbers
import re
rows = []
for line in raw_text.strip().split('\n'):
    parts = line.rsplit(' ', 1)
    if len(parts) == 2 and parts[1].isdigit():
        rows.append((module_name, sub_category, int(parts[1])))
```

### Step 2: Compute summary statistics
- Module-level totals and percentages
- Category-level (work type) totals
- Grand total across all items
- Top-N largest modules for summary emphasis

### Step 3: Create BookStack hierarchy
```python
TOKEN = "your-bookstack-api-token"
BASE = "http://localhost:8080/api"

# 3a: Create Shelf (if not exists) — always check for duplicates first!
# GET /api/shelves → find if shelf with same name exists
existing = GET /api/shelves?count=100
shelf_id = existing['data'][0]['id'] if any(s['name']=='项目名称' for s in existing['data']) else POST /api/shelves ...

shelf = POST /api/shelves
  {"name": "项目名称", "description": "...", "tags": [{"name":"project","value":"..."}]}

# 3b: Create Book
book = POST /api/books
  {"name": "文档名称", "description": "..."}

# 3b-fix: ⚠️ CRITICAL — bookshelf_id in POST /api/books does NOT work!
#          Book is created but NOT linked to shelf. Must use PUT shelf later.
#          Any bookshelf_id parameter in the POST body is silently ignored.
# Fix: Link book to shelf explicitly AFTER creating book:
curl -s -X PUT "http://localhost:8080/api/shelves/{shelf_id}" \
  -H "Authorization: Token $TOKEN" \
  -d "{\"name\":\"项目名称\",\"books\":[{book.id}]}"

# Alternatively, the PUT must include the shelf's name (does not work without it):
# PUT /api/shelves/{shelf_id} requires: {"name": "...", "books": [book_id]}
# If you omit "name", BookStack returns 422 with validation error.

# 3c: Create Chapter
chapter = POST /api/chapters
  {"name": "📋 汇总章节", "book_id": book["id"]}

# 3d: Create summary Page — MUST include template formatting from the start!
page = POST /api/pages
  {"name": "文档标题", "chapter_id": chapter["id"],
   "html": templated_html_content,  # Use Step 5 template format, not bare HTML
   "tags": [{"name":"project","value":"..."},{"name":"type","value":"workload"}]}
```

### Step 4: Format HTML summary page
Build a clean HTML page with:
- Header: title, grand total, module count, item count
- Module summary table: module name | workload | %
- **Detailed breakdown by module** (not just totals — include sub-function and description columns)
- Category breakdown (optional): work type | workload | %
- Notes section for caveats

**For tables < 100 rows**: Single detailed table with all columns (序号/模块/子功能/描述/工作量)
For tables ≥ 100 rows: Per-module section tables with full detail, plus a summary section on top.

**Decision: how many modules to expand fully?**

| Table size | Strategy |
|-----------|----------|
| < 100 rows | Expand ALL modules with full detail (子功能+需求功能描述 columns) |
| 100-300 rows | Expand ALL modules with full detail (may need script-based approach) |
| > 300 rows | Expand first 2-3 modules fully, summarize remaining modules with scope ranges |

**⚠️ User preference override**: If the user specifically asks to "把其他模块也拆开" (expand all modules), or the table has < 300 rows, always expand ALL modules with per-row detail. The user considers partial expansion as incomplete.

```python
# Build per-module sections for large tables
for module_name, rows_in_module in grouped_data.items():
    html += f"<h3>{module_name}</h3>"
    html += "<table><thead><tr><th>序号</th><th>子功能</th><th>需求功能概述</th><th>工作量</th></tr></thead><tbody>"
    for seq, (sub, desc, wl) in enumerate(rows_in_module, 1):
        html += f"<tr><td>{seq}</td><td>{sub}</td><td>{desc}</td><td>{wl}</td></tr>"
    html += "</tbody></table>"
```

```python
html = f"""
<h2>{doc_name}</h2>
<p><strong>总工作量：{grand_total} 人天</strong> | 模块数：{n_modules} | 条目数：{n_items}</p>
<h3>模块汇总</h3>
<table><thead><tr><th>模块</th><th>工作量</th><th>占比</th></tr></thead>
<tbody>
  {''.join(f'<tr><td>{m}</td><td>{t}</td><td>{p:.1f}%</td></tr>' for m,t,p in module_summaries)}
  <tr style="font-weight:bold;background:#e8f4fd"><td>合计</td><td>{grand_total}</td><td>100%</td></tr>
</tbody></table>
<h3>按类型统计</h3>
<table>...</table>
"""
```

### ⚠️ CRITICAL: 大型需求清单审查→补充→拆分→同步全流程

当用户交付一份大型需求清单（数百条、数千人天）时，执行以下5步流程：

### 第1步：审查完整性
- 检查所有模块是否有编号跳跃（如149→200），记录缺失编号区间
- 按行业标准检查缺失模块（PMO/架构设计/性能测试/上线护航等）

### 第2步：补充缺失
- 对每个编号跳跃区间补充子模块条目，确保编号连续性
- 补充条目必须用 `★` 前缀标记，表格中以橘色行高亮

### 第3步：合并原清单与补充
- 将补充条目按编号插入原清单对应位置，生成完整文档

### 第4步：≤15人天拆分（用户强制规则）
每一项子功能的人天数不得超过15。参见 `references/需求清单管理与拆分模式.md`。

### 第5步：参照模板格式同步BookStack
- 找到对应模板页面（如「XX项目需求工作量清单模板」）
- 使用模板的14列表格结构，补充行用`background:#fff3e0`高亮

## ⚠️ IRON RULE: Always use kb-template format from the VERY FIRST write

**Do NOT create a bare HTML table page first, then try to "upgrade" to kb-template later.**
The data import page MUST use kb-template format (kb-card, kb-badge, kb-table, emoji section titles, cartridge dividers) on the FIRST write.
If you write bare HTML first, the user will say "没有按默认模版要求" and you'll have to rebuild.

**From the very first POST/PUT, the page must include:**
- `<div class="kb-card">` for header cards
- `<span class="kb-badge kb-badge-*-lg">` for stats (工作量/模块数/条目数)
- `<div class="kb-section-title">📌 ...</div>` for section headings
- `<table class="kb-table"><thead>...` for data tables
- `<div class="kb-cartoon-divider">✦ ✦ ✦ ✦ ✦</div>` for separators (optional)
- Emoji markers: 📋 title, 📊 stats, 📌 sections, ⚠️ warnings

See Step 5 template for exact HTML structure.

**⚠️ CRITICAL: Always format the page with the BookStack template style from the start.** If you create a page with bare HTML tables and no template styling, the user will say "没有按默认模版要求" and you'll need to rebuild.

The BookStack default template uses:
- `kb-card` or `kb-card-comic` div wrappers for cover/header sections
- `kb-badge` spans for status/tag badges (color variants: kb-badge-green/blue/purple/yellow/red, size: kb-badge-lg)
- `kb-section-title` class or inline-styled section headers with emoji
- `kb-table` class for data tables (purple #6c5ce7 headers, alternating row colors)
- `kb-cartoon-divider` `✦ ✦ ✦ ✦ ✦` for section separators
- Emoji markers: 📌 for sections, 📋 for title, 📊 for stats, 🎯 for goals, ⚠️ for warnings

```python
# Template-compliant HTML structure for workload pages:
html = '''<div class="kb-card">
<h2>📋 项目名称</h2>
<p><span class="kb-badge kb-badge-green kb-badge-lg">📊 总工作量：N 人天</span>
<span class="kb-badge kb-badge-blue kb-badge-lg">📦 模块数：N</span></p>
</div>

<div class="kb-section-title">📌 一、模块工作量汇总</div>
<table class="kb-table"><thead><tr>...</tr></thead><tbody>...</tbody></table>

<div class="kb-section-title">📌 二、模块1：XXX</div>
<div class="kb-card"><p><span class="kb-badge">📊 小计：N 人天</span> <span class="kb-badge kb-badge-green">需求方案</span></p></div>
<table class="kb-table"><thead><tr><th>序号</th><th>子功能</th><th>需求功能概述</th><th>工作量</th></tr></thead><tbody>...</tbody></table>

<div class="kb-card kb-card-comic">
<p><span class="kb-badge kb-badge-lg">📌 说明</span></p>
<p>完整N条需求清单含9个字段，可按需导出。</p>
</div>'''
```

### Step 5.2: Script-based approach for large datasets (500+ rows)

For tables with 500+ rows across many modules, inline Python `execute_code` is impractical. Use a build-script approach:

1. Write the full Python build script to a file using `write_file()`
2. Execute the script with `python3 /tmp/build-script.py`
3. Verify the page with API GET

```python
# Template structure for a 500+ row build script:

import json, urllib.request, datetime

API = "http://localhost:8080/api/pages"
AUTH = "Token YOUR_TOKEN_ID:YOUR_SECRET"
PAGE_ID = 1904

# Data structure: module -> [(sub_function, description, workload)]
DATA = {
    "模块1名称": [
        ("子功能1", "需求功能概述1", 15),
        ("子功能2", "需求功能概述2", 8),
        # ... all rows
    ],
    # ... all 21 modules
}

# Build HTML with per-module sections
def build_page_html(data):
    html = '<div class="kb-card">\n<h2>📋 文档标题</h2>\n'
    grand_total = sum(sum(w for _,_,w in rows) for rows in data.values())
    html += f'<p><span class="kb-badge kb-badge-green kb-badge-lg">📊 总工作量：{grand_total} 人天</span>'
    html += f'<span class="kb-badge kb-badge-blue kb-badge-lg">📦 模块数：{len(data)}</span></p>\n</div>\n\n'
    
    # Module summary table
    html += '<div class="kb-section-title">📌 一、模块工作量汇总</div>\n'
    html += '<table class="kb-table"><thead><tr><th>模块</th><th>工作量</th><th>占比</th></tr></thead><tbody>\n'
    for mod, rows in data.items():
        total = sum(w for _,_,w in rows)
        pct = total / grand_total * 100
        html += f'<tr><td>{mod}</td><td style="text-align:right">{total}</td><td style="text-align:right">{pct:.1f}%</td></tr>\n'
    html += f'<tr style="font-weight:bold;background:#e8f4fd"><td>合计</td><td style="text-align:right">{grand_total}</td><td style="text-align:right">100%</td></tr>\n'
    html += '</tbody></table>\n\n'
    
    # Per-module detail tables
    for i, (mod, rows) in enumerate(data.items(), 1):
        module_total = sum(w for _,_,w in rows)
        html += f'<div class="kb-section-title">📌 {"二" if i<=1 else "继续编号"}、模块{i}：{mod}</div>\n'
        html += f'<div class="kb-card"><p><span class="kb-badge">📊 小计：{module_total} 人天</span></p></div>\n'
        html += '<table class="kb-table"><thead><tr><th>序号</th><th>子功能</th><th>需求功能概述</th><th>工作量</th></tr></thead><tbody>\n'
        for seq, (sub, desc, wl) in enumerate(rows, 1):
            html += f'<tr><td>{seq}</td><td>{sub}</td><td>{desc}</td><td style="text-align:right">{wl}</td></tr>\n'
        html += '</tbody></table>\n\n'
    
    return html

# Execute: PUT to update page
html = build_page_html(DATA)
data = json.dumps({"name": "文档标题", "html": html}, ensure_ascii=False).encode()
req = urllib.request.Request(f"http://localhost:8080/api/pages/{PAGE_ID}", data=data,
    headers={"Authorization": AUTH, "Content-Type": "application/json"}, method="PUT")
resp = json.loads(urllib.request.urlopen(req).read())
print(f"✅ Page {PAGE_ID} updated: {resp.get('id')}")
```

**Key benefits of script approach:**
- No inline Python size limits (execute_code has output/log size limits)
- Easier debugging: write → execute → fix → re-execute
- Full control over HTML generation with helper functions
- Data stays in a clean dict structure, easy to modify

```python
# Pattern: detailed for first modules
for module_name, rows_in_module in first_modules:
    html += f'<div class="kb-section-title">📌 模块：{module_name}</div>'
    html += '<div class="kb-card"><p><span class="kb-badge">📊 小计：N 人天</span></p></div>'
    html += '<table class="kb-table"><thead><tr><th>序号</th><th>子功能</th><th>需求功能概述</th><th>工作量</th></tr></thead><tbody>'
    for seq, (sub, desc, wl) in enumerate(rows_in_module, start):
        html += f'<tr><td>{seq}</td><td>{sub}</td><td>{desc}</td><td style="text-align:right">{wl}</td></tr>'
    html += '</tbody></table>'

# Pattern: summary for remaining modules
html += '<div class="kb-section-title">📌 其余模块汇总</div>'
html += '<table class="kb-table"><thead><tr><th>模块</th><th>子功能范围</th><th>工作量</th></tr></thead><tbody>'
for mod, scope, wl in remaining:
    html += f'<tr><td>{mod}</td><td>{scope}</td><td style="text-align:right">{wl}</td></tr>'
html += '</tbody></table>'
```

## Multi-document parallel generation (via delegate_task)

For complex projects requiring multiple interdependent documents (gap analysis + workload list + report), use `delegate_task` for parallel generation:

**Phase 1 — Research + Analysis (parallel):**
```python
result = delegate_task(tasks=[
    {"goal": "Generate gap/competitor analysis report", "context": "...", "toolsets": ["terminal","file","web"]},
    {"goal": "Generate workload list with requirements", "context": "...", "toolsets": ["terminal","file"]}
])
```

**Phase 2 — Consolidate → Build report:** Use outputs from both parallel tasks to construct the unified report.

**Phase 3 — BookStack batch upload:**
- Create book: `POST /api/books`
- Each document as separate page under same book: `POST /api/pages` with `book_id`
- 28人AI team estimation: ¥800/人天, 9,000-10,000 人天/36mo, Phase1~40%/Phase2~35%/Phase3~25%

### Step 6: Verify
- Open `http://localhost:8080/books/{book_slug}` to verify rendering
- Check tags are applied correctly
- Verify computed totals match user's expected values (spot-check 2-3 modules)
- **CRITICAL**: Open the page URL to verify it renders with proper template formatting (kb-card, emoji, table styles) — if the user says "没有按默认模版要求", rebuild with Step 5 format immediately

## Pitfalls
- ⚠️ BookStack API token format: `Authorization: Token {token}` (not Bearer)
- ⚠️ Shelf must be created before Book, Book before Chapter, Chapter before Page
- ⚠️ **CRITICAL: POST /api/books with bookshelf_id does NOT link Book to Shelf!** Must use PUT /api/shelves/{id} with "books":[book_id] after creation
- ⚠️ **PUT /api/shelves/{id} overwrites ALL fields**: Must include ALL existing values. Omitted fields will be lost (name, description, tags, books). The `books` array is the COMPLETE list — pass existing + new book IDs together, not just new ones.
- ⚠️ **BookStack Web URLs use slugs, not numeric IDs**: `/shelves/{slug}` not `/shelves/{id}`. Slug is auto-generated from shelf name. Fetch slug via API: `curl /api/shelves/{id}` → response `{ "slug": "..." }`.
- ⚠️ **API GET /books/{id} pages field may appear empty**: BookStack API paginates the `pages` sub-field. Zero pages shown does NOT mean the book is empty.
- ⚠️ **API GET /books/{id} contents truncates at 60+ pages**: Always use Python urllib (not curl) to read book contents.
- ⚠️ Check for duplicate shelf names before creating — use GET /api/shelves first
- ⚠️ Skip header rows, blank rows, separator rows — ignore non-numeric workload values
- ⚠️ Keep HTML simple — BookStack WYSIWYG editor strips complex CSS. Use inline styles only.
- ⚠️ Page name slug is auto-generated from Chinese chars — no manual slug needed
- ⚠️ **Project文档必须归位于项目专属书架**。Book下按类别建立子Book。
- ⚠️ **文档默认风格**：项目文档使用卡通动漫风格，从第一次写入就使用模板格式。
- ⚠️ **≤15人天强制规则**: 每项子功能不超过15人天。按工作阶段/产品族/时间周期拆分。
- ⚠️ **角色工作量必须按关键词分配**，不可留空或写"待定"。
- ⚠️ **补充条目必须按编号插入原位置**，不可在文档末尾追加。
- ⚠️ **描述智能补全**: 空描述用关键词匹配规则生成，不命中的留空（约5-10%）。
- ⚠️ **SDLC排序**: 每个模块内按需→设→开→测→部→日排列。
- ⚠️ **复杂度校准**: 日常维护类上限"中等"。
- ⚠️ **多模块新增**: 当补充3个以上新模块时，需要同时调整汇总表和总统计。
- ⚠️ **不要在BookStack API搜索中使用中文URL参数**：中文需用 `urllib.parse.quote()` 编码，否则报 `UnicodeEncodeError`。
### ⚠️ CRITICAL: 项目立项报告生成 — 必须按海航版模板12章节结构

当生成项目立项报告（Initiation Report/项目立项报告）时，必须执行以下流程：

**第1步：获取模板**
- BookStack模板库 Page [1440]「XX项目立项报告模板（海航版）」（Shelf [1416] → Book [1417]）
- 用API GET /api/pages/1440读取完整HTML，理解12章节结构
- 模板的12章节固定为：
  1. 项目建设背景（(一)项目现状 / (二)问题 / (三)工艺方法，每小节含编写指引card）
  2. 项目概况（(一)名称 / (二)单位 / (三)负责人 / (四)总图 / (五)设计原则 / (六)建设内容含目标+模块表 / (七)总投资 / (八)建设期）
  3. 可行性与依据
  4. 组织机构及人员配置
  5. 项目实施方案
  6. 环境保护（不涉及则填"不涉及"）
  7. 建设计划工期（(一)里程碑表 / (二)阶段性目标表）
  8. 投资估算（(一)编制原则 / (二)依据 / (三)投资估算明细表）
  9. 经济效益分析
  10. 风险因素及控制措施（风险表含7列）
  11. 结论
  12. 附考察报告

**第2步：收集实际项目数据**
- 找到对应的需求工作量清单页（Shelf[1901] Book[1902]中的需求清单合并版）
- 提取模块汇总表、阶段性目标、投资估算明细
- 所有数据必须来自实际项目文档，不可自行编造

**第3步：按模板结构填充内容**
- 每个章节使用与模板完全一致的h2/h3标题层级
- 保留模板中的编写指引card，替换示例内容
- 数据表格使用模板中的列结构（里程碑表6列、风险表7列、投资表5列）
- 页头使用模板的badge组合：kb-badge-purple/kb-badge-green/kb-badge-blue
- 分隔线使用 `<div class="kb-cartoon-divider">✦ ✦ ✦ ✦ ✦</div>`

**第4步：引用需求清单**
- 在建设内容章节中明确说明"具体建设内容详见《大客户销售系统V2.0 完整需求清单（合并版）》"
- 模块汇总表必须包含原工作量、补充工作量、总工作量三列
- 投资估算表需与需求清单中的人天数据一致

## Pitfalls (additional)
- ⚠️ **HTML构建方式选择**：对于包含大量中文和CSS样式的HTML（>1000行），**严禁使用execute_code内联字符串构建**。Python的Unicode转义在处理中文HTML时极易出错导致内容截断。必须使用file-based方式：write_file写Python脚本→terminal执行→API更新BookStack。
- ⚠️ **Python 3.11+ f-string反斜杠限制**：Python 3.11不支持在f-string表达式`{}`内使用反斜杠。`print(f"Count: {html.count('\\"mermaid\\"')}")` 会抛出 `SyntaxError: f-string expression part cannot include a backslash`。**修复方案**：将表达式提取为变量再使用：
  ```python
  mermaid_count = html.count('<pre class="mermaid"')
  print(f"Mermaid count: {mermaid_count}")  # 正确
  ```
  适用于所有含引号或反斜杠的字符串方法调用。
- ⚠️ **BookStack页面创建API端点**：创建页面应使用 `POST /api/pages`（请求体含 `book_id`），而非 `POST /api/books/{id}/pages`（后者返回405 Method Not Allowed）。正确格式：
  ```python
  result = api("POST", "/pages", {
      "book_id": book_id,
      "name": "页面名称",
      "html": "<p>内容</p>",
      "tags": [{"name": "project", "value": "项目名称"}]
  })
  ```
- ⚠️ **构建脚本与上传脚本分离时的full_html提取**：当构建脚本(build-*.py)和上传脚本(upload-*.py)分开时，使用`exec()`从构建脚本中提取`full_html`变量：
  ```python
  exec_globals = {}
  exec(compile(open('build-script.py').read(), 'build-script.py', 'exec'), exec_globals)
  full_html = exec_globals.get('full_html', '')
  ```
  确保构建脚本最后有 `full_html = "".join(parts)` 赋值。
- ⚠️ **模板必须参考现有模板页面**：不要凭记忆构建模板结构。每次先GET模板页面的完整HTML，再按实际结构填充。
- ⚠️ **需求清单数据必须真实引用**：立项报告中的数据必须与项目实际需求清单文档完全一致。用户会交叉验证两者的一致性。
- ⚠️ **编写指引card不可删除**：海航版模板的每个章节都包含"✏️ 编写指引"card，填充真实数据时应保留这些指引card。

## Related
- bookstack-kb-architecture: Broader KB design (styling, Mermaid, content quality)
- agent-bookstack-archive: Auto-archiving CMMI5 agent outputs
- bookstack-template-manager: Managing reusable templates including the workload checklist template
- `references/skill-md-sync-pattern.md`: Historical reference for SKILL.md → BookStack sync patterns.  
  **⚠️ NOTE**: The authoritative skill sync cron job lives in `devops/skill-bookstack-sync`,  
  with the current Book ID mapping at `skill-bookstack-sync/references/book-mapping.md`.  
  This reference file (`skill-md-sync-pattern.md`) is historical and its mapping section  
  may be stale — always check `skill-bookstack-sync/references/book-mapping.md` first.
- `references/direct-mysql-operations.md`: Fallback technique when BookStack API is unavailable.
- `references/需求清单管理与拆分模式.md`: 大型需求清单的完整性审查、≤15人天拆分策略、角色工作量智能分配算法。
- `references/project-charter-generation.md`: 项目立项报告生成模式 — 从需求工作量清单到12章海航版立项报告的全流程：模板获取（Page 1440）、Mermaid UML图嵌入（activity/sequence）、全文润色规范（术语统一/痛点数据化/ROI三表）、WPS金山文档同步限制与解决方案。
- `references/haihang-project-initiation-report.md`: 海航版立项报告模板的12章节结构速查（包含每章节的子章节名称、表格列定义、示例数据格式）。
- `references/role-based-supplement-pattern.md`: 多角色补充格式模式 — 海航版模板中按角色分层（项目经理/产品/架构师/开发/测试）组织补充内容的HTML格式规范。

## Feedback Engine Patches
*自动生成于 2026-07-16 02:02:04*

## Tool Recommendations (from trajectory feedback)

### patch
Trajectory analysis shows **patch** strongly correlates with high session scores.
- Use `patch` for targeted find-and-replace edits instead of sed/awk.
- Supports fuzzy matching with 9 strategies for robust edits.
- Auto-runs syntax checks after modification.
- Preferred for surgical code changes over full file rewrites.

### Guardrails
- Ensure `old_string` is unique in the file unless `replace_all=True`.
- Include enough surrounding context to guarantee uniqueness.
- Use `mode='patch'` for V4A multi-file patches.

### Efficiency Tips
- Combine multiple edits into a single V4A patch when possible.
- Use `replace_all=True` for bulk replacements of the same pattern.
- Preview changes with `--dry-run` mode before applying.

---
## Feedback Engine Patches
*自动生成于 2026-07-17 02:02:37*

## Tool Recommendations (from trajectory feedback)

### patch
Trajectory analysis shows **patch** strongly correlates with high session scores.
- Use `patch` for targeted find-and-replace edits instead of sed/awk.
- Supports fuzzy matching with 9 strategies for robust edits.
- Auto-runs syntax checks after modification.
- Preferred for surgical code changes over full file rewrites.

### Guardrails
- Ensure `old_string` is unique in the file unless `replace_all=True`.
- Include enough surrounding context to guarantee uniqueness.
- Use `mode='patch'` for V4A multi-file patches.

### Efficiency Tips
- Combine multiple edits into a single V4A patch when possible.
- Use `replace_all=True` for bulk replacements of the same pattern.
- Preview changes with `--dry-run` mode before applying.

---
## Feedback Engine Patches
*自动生成于 2026-07-21 08:58:12*

## Tool Recommendations (from trajectory feedback)

### write_file
Trajectory analysis shows **write_file** strongly correlates with high session scores.
- Use `write_file` to create new files or overwrite existing ones.
- Preferred over terminal heredoc for structured file creation.
- Automatically creates parent directories.

### Guardrails
- Always use absolute paths to avoid ambiguity.
- Creates parent directories — verify the intended path before writing.
- Overwrites entire file content — if you need targeted edits, use `patch` instead.

### Efficiency Tips
- Batch content creation: write whole files at once instead of appending line-by-line.
- For large files, consider splitting into multiple smaller files.
- Use `patch` for incremental updates to avoid full rewrites.

---
## Feedback Engine Patches
*自动生成于 2026-07-22 12:19:48*

## Tool Recommendations (from trajectory feedback)

### patch
Trajectory analysis shows **patch** strongly correlates with high session scores.
- Use `patch` for targeted find-and-replace edits instead of sed/awk.
- Supports fuzzy matching with 9 strategies for robust edits.
- Auto-runs syntax checks after modification.
- Preferred for surgical code changes over full file rewrites.

### Guardrails
- Ensure `old_string` is unique in the file unless `replace_all=True`.
- Include enough surrounding context to guarantee uniqueness.
- Use `mode='patch'` for V4A multi-file patches.

### Efficiency Tips
- Combine multiple edits into a single V4A patch when possible.
- Use `replace_all=True` for bulk replacements of the same pattern.
- Preview changes with `--dry-run` mode before applying.
