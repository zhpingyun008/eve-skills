# Project Document Organization in BookStack

## Shelf Structure Pattern

Each project should have a dedicated BookStack shelf with the following sub-book layout:

```
Shelf: {项目名称} (e.g., "海南APP对标携程项目V1.0", slug auto-generated)
├── 📚 00-项目立项与章程
│   ├── 项目章程
│   ├── WBS工作分解结构
│   ├── 里程碑计划
│   ├── 风险登记册
│   └── 项目立项报告
├── 📚 01-竞品分析
│   ├── 携程APP深度对标分析报告
│   └── 模板可行性评估报告
├── 📚 02-架构设计
│   └── 系统架构全景图
```

## Workflow

1. **Create shelf** via `POST /api/shelves` with name and description
2. **Create books** via `POST /api/books` — Note: `shelf_id` parameter does NOT work!
3. **Link books to shelf** via `PUT /api/shelves/{id}` with the COMPLETE list of book IDs:
   ```json
   {"name": "Shelf Name", "description": "...", "books": [book_id_1, book_id_2, ...]}
   ```
4. **Create pages** via `POST /api/pages` with `book_id` parameter
5. **Find shelf URL**: Navigate via `/shelves/{slug}` — slug is auto-generated from name, get it from `GET /api/shelves/{id}` response

## Document Style

- Use cartoon/动漫 style (`.cartoon.html`) with `kb-card`, `kb-badge`, `kb-table` CSS classes
- Markdown source in `docs/` directory, cartoon HTML in `docs/*.cartoon.html`
- `sync_bookstack.py` handles conversion from .md/.cartoon.html to BookStack API

## Migration (when moving from wrong shelf)

1. Create new books under the correct shelf
2. Read old page content via `GET /api/pages/{old_id}` → extract `html` field
3. Create new pages in new books via `POST /api/pages` with same content
4. Delete old pages via `DELETE /api/pages/{old_id}`
5. Update `sync_bookstack.py` mappings

## 🔴 IRON RULE: Multi-Project Independence

**Different projects MUST NOT share any files, books, or shelves in BookStack.**

When two projects live in the same code repository (e.g., same git repo but different phases/projects):

| Entity | Rule |
|--------|------|
| **Shelf** | Each project gets its OWN shelf — never add books to another project's shelf |
| **Book** | Each project's books belong ONLY to that project's shelf |
| **md/html files** | Each file belongs to ONE project only. **No shared files.** |
| **sync_bookstack.py** | Section-divide by project with clear `# ===== Project Name =====` comments |

### Concrete Example

```
❌ WRONG — architecture_overview.md shared across two projects:
  Book 406 (海航AI购票助手) → architecture_overview.md
  Book 2440 (海南对标携程)  → architecture_overview.md ← SAME FILE

✅ CORRECT — each file belongs to one project:
  Book 406 (海航AI购票助手) → (no sync, or separate file)
  Book 2440 (海南对标携程)  → architecture_overview.md ← only here
```

### Enforcement in sync_bookstack.py

```python
# ===== 海南APP对标携程项目V1.0 (Shelf 1317) =====
sync_book(2438, [("项目章程", "docs/project_charter.md"), ...])
sync_book(2439, [("竞品分析", ...)])
sync_book(2440, [("架构全景图", "docs/architecture_overview.md")])

# ===== 海航AI购票助手 (Shelf 400) =====
sync_book(403, [("项目概览", "README.md"), ...])
sync_book(1632, [("需求分析", ...)])
# Book 406 deliberately omitted if it had shared file
```

### Cleanup Procedure

When discovering a file/Book that was mistakenly shared:

1. **Remove** the shared file from the incorrect project's Book (update `sync_bookstack.py`)
2. **Delete** the old BookStack page (API `DELETE /api/pages/{old_id}`)
3. If the file contains content from both projects: **split it** into two files
4. **Verify** via BookStack web UI that each shelf shows only its own books
