# BookStack Direct MySQL Operations

When the BookStack REST API is unavailable (token lost/expired, 401 errors, or no API token exists), shelves/books/pages can be created directly via MySQL. This is a **fallback** approach — prefer the API when possible.

## Database Connection

```
Host: 127.0.0.1:3307
User: bookstack
Pass: bookstack_pass (from ~/projects/BookStack/.env)
DB:   bookstack
Socket: /tmp/mariadb.sock
```

## Tables Required for a Visible Shelf

To create a fully functional, visible shelf with restricted permissions, you must populate **5+ tables**:

### 1. `entities` — Main entity record
```sql
INSERT INTO entities (type, name, slug, created_at, updated_at, created_by, updated_by, owned_by)
VALUES ('bookshelf', '书架名称', 'shelf-slug', NOW(), NOW(), 1, 1, 1);
```
- `type`: 'bookshelf' | 'book' | 'chapter' | 'page'
- `slug`: URL-safe identifier (ASCII only, e.g. `personal-private-1234567890`)
- `created_by/updated_by/owned_by`: User ID (1 = admin)
- For **book**: book_id=NULL (book-level entity, not page)
- For **page**: book_id=[book_id], chapter_id=NULL, priority=0

### 2. `entity_container_data` — Description/content for shelves & books
```sql
INSERT INTO entity_container_data (entity_id, entity_type, description, description_html)
VALUES (2669, 'bookshelf', '<p>描述文本</p>', '<p>描述文本</p>');
```

For **pages**, content goes in `entity_page_data` instead:
```sql
INSERT INTO entity_page_data (page_id, draft, template, revision_count, editor, html, text, markdown)
VALUES (page_id, 0, 0, 1, 'wysiwyg', '<h2>Title</h2><p>Content</p>', 'Plain text', NULL);
```

### 3. `bookshelves_books` — Shelf-to-book linkage
```sql
INSERT INTO bookshelves_books (bookshelf_id, book_id, `order`)
VALUES (shelf_entity_id, book_entity_id, 1);
```

### 4. `joint_permissions` — Visibility control (CRITICAL)
Without this, content returns "Not Found" for all users.
```sql
-- Admin (role_id=1): full access (status=3)
-- Other roles (2=Editor, 3=Public, 4=Viewer): no access (status=0)
INSERT IGNORE INTO joint_permissions (role_id, entity_type, entity_id, status, owner_id) VALUES
(1, 'bookshelf', shelf_id, 3, 1),
(2, 'bookshelf', shelf_id, 0, 1),
(3, 'bookshelf', shelf_id, 0, 1),
(4, 'bookshelf', shelf_id, 0, 1),
(1, 'book', book_id, 3, 1),
(2, 'book', book_id, 0, 1),
(3, 'book', book_id, 0, 1),
(4, 'book', book_id, 0, 1);
```
- status=3: Explicit allow
- status=1: Inherit from parent
- status=0: Explicit deny

### 5. `slug_history` — URL routing
```sql
INSERT INTO slug_history (sluggable_type, sluggable_id, slug, created_at, updated_at)
VALUES ('bookshelf', shelf_id, 'shelf-slug', NOW(), NOW());
```

### 6. `entity_permissions` — (Optional) For explicit role-based restrictions
```sql
INSERT INTO entity_permissions (entity_id, entity_type, role_id, action, has_permission)
VALUES
(shelf_id, 'bookshelf', 1, 'view', 1),
(shelf_id, 'bookshelf', 1, 'update', 1),
(shelf_id, 'bookshelf', 1, 'delete', 1),
(shelf_id, 'bookshelf', 2, 'view', 0),
(shelf_id, 'bookshelf', 3, 'view', 0);
```

### 7. `page_revisions` — Required for page version history
```sql
INSERT INTO page_revisions (page_id, name, slug, html, text, created_by, created_at, type)
VALUES (page_id, '页面标题', 'page-slug', '<h2>HTML</h2>', 'Plain text', 1, NOW(), 'version');
```

## Complete Example: Creating a Private Shelf with Credential Pages

```bash
# 1. Create shelf entity
mysql -u bookstack -pbookstack_pass -h 127.0.0.1 -P 3307 bookstack \
  -e "INSERT INTO entities (type,name,slug,created_at,updated_at,created_by,updated_by,owned_by) VALUES ('bookshelf','个人私密','private-shelf',NOW(),NOW(),1,1,1);"

# Get the shelf ID from LAST_INSERT_ID — or query it
SHELF_ID=$(mysql -u bookstack -pbookstack_pass -h 127.0.0.1 -P 3307 bookstack \
  -N -e "SELECT id FROM entities WHERE type='bookshelf' ORDER BY id DESC LIMIT 1;")

# 2. Add shelf description
mysql -u bookstack -pbookstack_pass -h 127.0.0.1 -P 3307 bookstack \
  -e "INSERT INTO entity_container_data (entity_id,entity_type,description,description_html) VALUES ($SHELF_ID,'bookshelf','<p>Description</p>','<p>Description</p>');"

# 3. Create book
mysql -u bookstack -pbookstack_pass -h 127.0.0.1 -P 3307 bookstack \
  -e "INSERT INTO entities (type,name,slug,created_at,updated_at,created_by,updated_by,owned_by) VALUES ('book','账号与密码','book-slug',NOW(),NOW(),1,1,1);"
BOOK_ID=$(mysql -u bookstack -pbookstack_pass -h 127.0.0.1 -P 3307 bookstack \
  -N -e "SELECT id FROM entities WHERE type='book' ORDER BY id DESC LIMIT 1;")

# 4. Link shelf to book
mysql -u bookstack -pbookstack_pass -h 127.0.0.1 -P 3307 bookstack \
  -e "INSERT INTO bookshelves_books (bookshelf_id,book_id,\`order\`) VALUES ($SHELF_ID,$BOOK_ID,1);"

# 5. Set permissions
mysql -u bookstack -pbookstack_pass -h 127.0.0.1 -P 3307 bookstack \
  -e "INSERT IGNORE INTO joint_permissions (role_id,entity_type,entity_id,status,owner_id) VALUES (1,'bookshelf',$SHELF_ID,3,1),(2,'bookshelf',$SHELF_ID,0,1),(1,'book',$BOOK_ID,3,1),(2,'book',$BOOK_ID,0,1);"

# 6. Add slug history
mysql -u bookstack -pbookstack_pass -h 127.0.0.1 -P 3307 bookstack \
  -e "INSERT INTO slug_history (sluggable_type,sluggable_id,slug,created_at,updated_at) VALUES ('bookshelf',$SHELF_ID,'private-shelf',NOW(),NOW());"
```

## Limitations
- Chinese characters in slugs are not supported — use ASCII slugs with timestamps (e.g., `private-1779966543`)
- The `updated_at` timestamp must be set correctly for "Recent" sorting
- Page content is HTML-only (markdown column can be NULL)
- No search indexing — pages won't appear in BookStack search until a reindex is triggered via the CLI
