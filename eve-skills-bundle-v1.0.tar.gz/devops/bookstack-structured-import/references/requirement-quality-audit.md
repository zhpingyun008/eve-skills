# 大型需求清单质量审计工作流

> 适用场景：用户交付数百条需求清单后，进行系统性质量检查、完整性评估和优化调整。

## 一、三重质量检查

### 检查1：重复项检测

```python
# 模块内精确重复
for mn, mt, items in MODULES_DATA:
    seen = set()
    for sf, ov, pv, sp in items:
        if sf in seen: print(f"重复: [{mn[:30]}] {sf}")
        seen.add(sf)

# 跨模块可疑重复（同名出现在3+模块）
cross_dup = defaultdict(list)
for mn, mt, items in MODULES_DATA:
    for sf, ov, pv, sp in items:
        cross_dup[sf].append(mn[:30])
suspicious = [(sf, mods) for sf, mods in cross_dup.items() if len(mods) >= 3]
```

### 检查2：工时合理性

| 指标 | 阈值 | 处理 |
|------|------|------|
| 模块声明PD vs 条目PD总和 | 差异 > 2人天 | 缩放重算 |
| 单条目PD | > 15人天 | 拆分子项 |
| 模块均值 | > 12人天/条 | 拆分或补充条目 |
| PM占比 | > 30% | 检查是否过度管理 |
| 测试占比 | < 10% (模块>50人天) | 建议补充测试条目 |
| 0人天条目 | 任何 | 删除或补PD |

**PD缩放算法** — 当恢复缺失条目后，条目PD总和超出模块声明值时：
```python
factor = orig_module_pd / sum(items_pd)
new_items = [(sf, ov, max(1, round(pv * factor)), sp) for sf, ov, pv, sp in items]
```

### 检查3：描述完整性

```python
# 自动描述补全 — 四层匹配
def fill_desc(sf, ov, sp):
    if ov.strip() not in ('','补充条目','★补充条目','补充工作项'): return ov
    
    # Level 1: 精确匹配 DESC_MAP
    if clean in DESC_MAP: return DESC_MAP[clean]
    
    # Level 2: 前缀匹配 DESC_EXTRA
    for prefix, desc in DESC_EXTRA.items():
        if clean.startswith(prefix):
            return f'{desc}-{suffix}'
    
    # Level 3: 关键词匹配（通用模式）
    for kw, desc in KEYWORD_DESC:
        if kw in clean: return desc
    
    # Level 4: fallback
    return '功能开发实施'
```

## 二、SDLC闭环完整性评分

| 阶段 | 检查关键词 | 权重 |
|------|-----------|:----:|
| 需求分析 | 需求分析/需求收集/需求文档/梳理 | 1 |
| 详细设计 | 详细设计/需求详细/需求细化/方案设计/原型/UI设计 | 1 |
| 接口/功能开发 | 接口/功能开发/逻辑处理/代码/开发 | 1 |
| 测试 | 测试/SIT/UAT/验收/用例/联调 | 1 |
| 部署 | 部署上线/生产部署/变更脚本/上线 | 1 |

评分 = 5个阶段中已覆盖数量 / 5。运维/管理/支持类模块可接受低分（≤3），核心功能模块需满分。

## 三、补充条目完整性

| 补充类型 | 触发条件 | 人天参考 |
|---------|---------|:--------:|
| SDLC补缺 | 核心模块某阶段缺失 | +15 |
| 数据备份/灾备 | 全系统缺失 | +10 |
| 用户培训/操作手册 | 全系统缺失 | +15 |
| 浏览器兼容性测试 | 有前端模块 | +8 |
| 灾备演练 | 合规需求 | +10 |
| 数据安全/合规治理 | 涉及PII数据 | +15 |
| 消息通知中心 | 无统一通知通道 | +18 |
| 自动化测试体系 | 手工测试效率低 | +15 |

## 四、缺失条目恢复

当用户指出原数据被遗漏时：
1. 对比原始文档（编号项 vs 无编号项）
2. 按模块检查丢失数量
3. 重建条目时注意：**保持模块PD不变**，条目PD按比例缩放

```python
# 模块PD保持原始声明值，条目PD缩放
orig_pd = ORIG_PD.get(module_id, current_mt)
calc_pd = sum(item_pd for items in module)
if abs(calc_pd - orig_pd) > 2:
    factor = orig_pd / calc_pd
    items = [(sf, ov, max(1, round(pv * factor)), sp) for ...]
```

## 五、最终验证脚本

```python
# 生成审计报告
print(f"模块数: {len(modules)}")
print(f"总条目: {sum(len(items) for ...)}")  
print(f"总人天: {sum(mt for ...)}")
print(f"重复条目: {dup_count}")
print(f"超PD条目(>15): {over_count}")
print(f"空描述: {empty_count}")
print(f"平均SDLC评分: {avg_sdlc:.1f}/5")
```
