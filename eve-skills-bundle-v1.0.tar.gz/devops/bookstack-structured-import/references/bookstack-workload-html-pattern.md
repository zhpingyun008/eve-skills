# BookStack 批量需求表 HTML 渲染模式

## 问题场景
将 400+ 条需求工作量清单同步到 BookStack，需卡通风格 + 13列角色分解表 + 智能优化。

## HTML生成模式

### 模板结构
```
[英雄卡] — kb-card-comic + emoji + badges
[填写说明] — kb-section-title + ol
[工作量清单总表] — kb-table + 13列thead + tbody（逐行）
[工作量汇总] — kb-table + 各模块统计 + 合计行
[页脚] — 编制信息
```

### 13列定义
序号 | 功能/模块 | 子功能 | 需求功能概述 | 合计 | PM | 需求 | 研发 | 架构 | 测试 | 备注 | 类型 | 说明

### 样式常量（内联）
```python
S = {
    'th': 'border:1px solid #dfe6e9;padding:5px 6px;text-align:center;background:#6c5ce7;color:#fff;font-weight:bold;font-size:11px;',
    'td': 'border:1px solid #dfe6e9;padding:4px 6px;font-size:11px;',
    'cc': 'border:1px solid #dfe6e9;padding:4px 6px;font-size:11px;text-align:center;',
    'sm': 'border:1px solid #dfe6e9;padding:4px 6px;text-align:center;font-weight:bold;background:#f8f9fa;font-size:11px;',
}
```

### 行渲染
- 模块首行: 显示模块名称（`font-weight:bold`），后续行留空
- 补充行: `style="background:#fff3e0;"`（橘色高亮）
- 合计行: `style="font-weight:bold;background:#f8f9fa;"`

### 数据管道
```
原数据(modules_data.py) 
  → split_item() 拆分>15人天 
  → gen_desc() 补充描述 
  → sdlc_sort_key() 排序 
  → calc_complexity() 复杂度 
  → dist() 角色分解 
  → HTML渲染 
  → PUT /api/pages/{id}
```

### 避坑
- BookStack API PUT 需要完整HTML（非增量）
- 所有样式必须内联，禁止`<style>`标签
- `box-shadow`会被BookStack剥离
- 中文URL参数需urlencode
