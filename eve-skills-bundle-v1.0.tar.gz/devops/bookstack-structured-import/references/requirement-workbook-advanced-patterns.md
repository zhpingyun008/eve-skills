# 需求工作量清单高级模式

> 适用场景：500+条/3000+人天的大型航空/IT项目需求清单
> 数据驱动：modules_data.py 结构 (module_name, total_pd, [(subfunc, overview, pd, is_supplement)...])

## 一、数据持久化策略

### 核心数据文件: modules_data.py

```python
MODULES_DATA = [
    ("1. 模块名称", 139, [
        ("子功能名称", "功能描述", 5, 0),  # (子功能, 概述, 人天, 是否补充)
        ("★补充子功能", "补充描述", 8, 1),  # sp=1 表示补充条目
    ]),
]
```

**⚠️ 重要**: 新增模块（如M26-M28）必须写入该文件，否则每次重新生成时丢失。

### 多模块数据源管理

当原始数据（MODULES_DATA）和补充数据（NEW_MODULES, ADDITIONS）分散在多个位置时：
1. NEW_MODULES 必须跟随主数据一起提交到 BookStack
2. 每次重新生成HTML时，必须包含 ALL 数据源（原始+补充+新增模块）
3. **常见失误**: 只处理了 MODULES_DATA，忘记包含 NEW_MODULES，导致模块26-28反复丢失

```python
# 正确的做法 - 所有数据源一次装配
all_mods = []
for mn, mt, items in MODULES_DATA:    # 原始21模块
    all_mods.append(process(mn, mt, items))
for mn, mt, items in NEW_MODULES:      # 补充模块22-28 
    all_mods.append(process(mn, mt, items))
# ADDITIONS 在 module data 装配时注入
```

## 二、子功能拆分策略 (≤15人天)

当某子功能人天超过15时，需智能拆分：

### 按工作阶段拆分（全流程类）

```python
def split_by_phase(sf, ov, pd, sp):
    """85人天全流程 → 需求分析15/详细设计14/接口开发Ⅰ14/接口开发Ⅱ14/前端开发14/测试部署14"""
    phases = ['需求分析','详细设计','接口开发Ⅰ','接口开发Ⅱ','前端开发','测试部署','联调支持','验收测试']
    n = (pd + 14) // 15  # 计算需要拆成几份
    base = pd // n
    rem = pd % n
    for i in range(n):
        cp = base + (1 if i < rem else 0)
        ph = phases[i] if i < len(phases) else f'子功能{labels[i]}'
        yield (f'{base_name}-{ph}', f'{ph}阶段', cp, sp)
```

### 按时间周期拆分（日常保障类）

```python
def split_by_period(sf, ov, pd, sp):
    """233人天日常 → 1-2月15/3-4月15/.../12月14"""
    periods = ['1-2月','3-4月','5-6月','7-8月','9-10月','11-12月','1月','2月','3月','4月','5月','6月']
    for i in range(n):
        yield (f'{sf}-{periods[i]}', f'{periods[i]}日常保障', cp, sp)
```

### 按产品族拆分（配置类）

```python
def split_by_family(sf, ov, pd, sp):
    """35人天各产品配置 → S0/S1/S2配置 / S3/F0/F1配置 / ..."""
    groups = ['S0/S1/S2','S3/F0/F1','F2/F3/F4','F5/F6/C0','C1/C2/C3','C4/C5/C6']
    for i in range(n):
        yield (f'{subfunc[:18]}[{groups[i]}]', f'{groups[i]}配置', cp, sp)
```

## 三、角色工作量分配算法 (dist函数)

智能按关键词匹配分配人天到5个角色：

```python
def distribute_effort(total, keywords_text):
    """根据子功能名+描述中的关键词，智能分配PM/需求/研发/架构/测试占比"""
    pm=req=dev=arch=test=0.0
    
    if any(w in kw for w in ['需求分析','文档梳理']): 
        req=total*0.6; pm=total*0.4
    elif any(w in kw for w in ['原型','UI设计','方案设计']): 
        req=total*0.5; arch=total*0.3; pm=total*0.2
    elif any(w in kw for w in ['实施方案','上线计划','项目管理']): 
        pm=total*0.6; req=total*0.2; arch=total*0.2
    elif any(w in kw for w in ['接口','开发','代码','CMS','配置']): 
        dev=total*0.7; arch=total*0.2; req=total*0.1
    elif any(w in kw for w in ['测试','SIT','UAT','验收','联调','验证','压测']): 
        test=total*0.6; dev=total*0.4
    elif any(w in kw for w in ['部署','上线','变更']): 
        dev=total*0.5; test=total*0.3; pm=total*0.2
    elif any(w in kw for w in ['日常','保障','问题排查']): 
        dev=total*0.5; test=total*0.3; req=total*0.2
    elif any(w in kw for w in ['培训','手册','文档']): 
        req=total*0.5; test=total*0.3; pm=total*0.2
    elif any(w in kw for w in ['备份','灾备']): 
        dev=total*0.4; test=total*0.3; arch=total*0.3
    # ... 20+种工作类型匹配
    
    # 归一化确保总和=total
    s=pm+req+dev+arch+test
    if abs(s-total)>0.5 and s>0: 
        f=total/s; pm*=f; req*=f; dev*=f; arch*=f; test*=f
    return round(pm,1),round(req,1),round(dev,1),round(arch,1),round(test,1)
```

**匹配优先级**: 顺序敏感——越具体的匹配放前面。
**回退策略**: 无关键词匹配时返回 dev=50%/test=25%/req=15%/arch=10%/pm=10%。

### 工作类型关键词库（28+类）

| 类别 | 关键词 | 主要角色 | 占比 |
|------|--------|---------|:----:|
| 需求分析 | 需求分析/文档/梳理 | 需求60%+PM40% | 100% |
| UI设计 | 原型/UI/方案设计 | 需求50%+架构30%+PM20% | 100% |
| 项目管理 | 实施计划/上线计划 | PM60%+需求20%+架构20% | 100% |
| 接口开发 | 接口/开发/代码/CMS | 研发70%+架构20%+需求10% | 100% |
| 测试验证 | 测试/SIT/UAT/验收 | 测试60%+研发40% | 100% |
| 部署上线 | 部署/上线/变更 | 研发50%+测试30%+PM20% | 100% |
| 日常支持 | 日常/保障/问题排查 | 研发50%+测试30%+需求20% | 100% |
| 培训文档 | 培训/手册/文档 | 需求50%+测试30%+PM20% | 100% |
| 安全加密 | 安全/漏洞/加密/合规 | 研发50%+架构20%+测试30% | 100% |
| 同步推送 | 同步/推送 | 研发60%+架构20%+测试20% | 100% |
| 监控告警 | 监控/告警/巡检 | 研发50%+测试30%+架构20% | 100% |
| 审计日志 | 审计/日志 | 研发50%+测试30%+架构20% | 100% |
| 备份灾备 | 备份/灾备 | 研发40%+测试30%+架构30% | 100% |
| 风控防刷 | 风控/防刷 | 研发60%+架构30%+测试10% | 100% |
| 支付退款 | 支付/退款/对账 | 研发50%+架构20%+测试20%+需求10% | 100% |
| 兼容性 | 兼容性 | 测试60%+研发40% | 100% |

## 四、智能描述生成 (fill_desc函数)

### 主数据条目（非补充）
使用通用规则：
```python
DESC_MAP = {
    '需求分析/文档/梳理': '梳理业务需求，输出需求文档',
    '需求详细设计/细化': '细化功能点、规则定义及评审',
    '实施方案/技术方案/业务流程': '制定技术实施方案及业务流程',
    '原型/UI设计/页面设计': '页面原型及交互设计',
    '接口/下单/生单/退订': '接口功能开发',
    '测试用例/测试方案': '测试用例编写及评审',
    'SIT/系统集成': '系统集成测试',
    'UAT/用户验收': '用户验收测试',
    '部署上线/生产部署': '生产环境部署上线',
    '变更脚本/变更': '数据库变更脚本编写及审核',
}
```

### 补充条目（sp=1）
需要更具体的描述，不能使用通用描述：
```python
SUPP_DESC = {
    'PC官网辅助功能-需求分析及文档梳理': '梳理PC官网辅助功能需求，输出需求规格说明书',
    '代金券公共能力-发放引擎开发': '代金券批量发放引擎开发，支持多渠道发券',
    '同步失败重试与死信队列机制': '数据同步失败自动重试及死信队列异常处理机制',
    '安全漏洞全量复测及验收': '安全漏洞修复后全量复测及验收确认',
    # ... 每个补充条目一条具体描述
}
```

### 占位检查机制
每次更新后必须检查是否有"补充工作项"或"★补充条目"占位残留在HTML中：
```python
remaining = html.count('补充工作项')
remaining2 = html.count('★补充条目')
if remaining > 0 or remaining2 > 0:
    # 需要补充具体描述后重新更新
```

## 五、SDLC闭环完整性检查

评估每个模块是否覆盖了完整的软件开发生命周期：

```python
SDLC_CHECKS = {
    '需求分析': ['需求分析','需求收集','需求文档','梳理'],
    '详细设计': ['详细设计','需求详细','需求细化'],
    '原型UI': ['原型','UI设计','页面设计','交互'],
    '接口开发': ['接口','功能开发','逻辑处理','代码'],
    '测试用例': ['测试用例','测试方案'],
    'SIT测试': ['SIT','系统集成'],
    'UAT测试': ['UAT','用户验收'],
    '验收测试': ['验收测试','生产验收','回归测试'],
    '部署上线': ['部署上线','生产部署'],
    '变更脚本': ['变更脚本','变更'],
}

def assess_sdlc(module_items):
    """返回(score/10, missing_phases)"""
    subs = [sf for sf,_,_,_ in module_items]
    score = 0
    missing = []
    for phase, keywords in SDLC_CHECKS.items():
        found = any(k in s for s in subs for k in keywords)
        if found: score += 1
        else: missing.append(phase)
    return score, missing
```

**行业标准**: 开发类模块≥8/10，接口对接类≥5/10，运维支持类≥3/10。

## 六、工作量合理性校验

### 检查项
| 检查 | 阈值 | 意义 |
|------|:----:|------|
| 模块均值 | ≤15人天 | 粒度控制 |
| 研发占比 | 30%-70% | 开发合理区间 |
| 测试占比 | 10%-35% | 测试覆盖合理区间 |
| PM占比 | 0%-30% | 管理成本合理区间 |
| 条目数 | ≥3条/模块 | 分解充分性 |
| 每项上限 | ≤15人天 | 用户强制规则 |

## 七、多轮优化工作流

当用户要求"继续检查/优化/完善"时，执行以下多轮工作流：

```
Round 1: 基础构建
  └─ 解析原始数据 → 拆分(≤15PD) → 生成HTML → BookStack同步

Round 2: 完整性审查
  └─ SDLC检查 → 模块依赖检查 → 非功能需求检查
  └─ 补充缺失项 → 生成HTML → BookStack同步

Round 3: 工时合理性优化
  └─ 角色占比分析 → 发现异常模块
  └─ 补充缺项(P0-P4优先级) → 重平衡 → 生成HTML → BookStack同步

Round 4: 描述补全
  └─ 扫描HTML中的占位描述(★补充条目/补充工作项)
  └─ 逐个匹配具体描述 → 替换 → BookStack同步

Round 5: 最终验证
  └─ 数量/人天/模块数 三次一致
  └─ 全部描述非空
  └─ 所有≤15人天
  └─ 卡通风格+模板格式+BK正确
```

**关键原则**: 每轮都要重新生成完整的HTML（不是增量补丁），因为BookStack API的PUT会覆盖整个页面。

## 八、常见陷阱

1. **NEW_MODULES漂移**: 新增模块（M26-M28）未并入主数据文件，每次重新生成时消失
2. **占位描述残留**: "★补充条目"/"补充工作项"在更新HTML后未被替换
3. **角色合计偏差**: dist函数求和后需要归一化，否则角色合计≠总人天
4. **HTML搜索错误**: 在HTML中搜索"★补充"时使用`<span>`而不是`</td>`会导致误判为0
5. **多轮数据分裂**: modules_data.py与BookStack页面数据不同步（前者只有原始+第1轮补充，后者有全部5轮优化）
