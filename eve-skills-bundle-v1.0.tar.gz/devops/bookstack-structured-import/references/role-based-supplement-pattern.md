# 多角色补充格式模式 (海航版模板)

在按海航版模板生成立项报告时，每个章节需要按角色分层补充内容。此模式称为"角色补充格式"。

## 格式规范

每个角色补充使用独立card包裹：

```html
<div class="kb-card" style="border-left:4px solid #a29bfe;padding:10px;margin:8px 0;">
  <p style="margin:0;color:#2d3436;">
    <strong>【角色名称补充】</strong>补充内容...
  </p>
</div>
```

## 角色优先级顺序

在每个章节内，按以下顺序排列角色补充：

1. **项目经理** — 统筹全局（管理/资源/制度/结论）
2. **产品经理** — 业务视角（需求/痛点/场景/目标）
3. **系统架构师** — 技术架构（选型/设计/方案/标准）
4. **开发组长** — 落地实现（开发/代码/规范/联调）
5. **开发工程师** — 执行细节（模块/自测/适配）
6. **测试工程师** — 质量保障（测试/缺陷/标准/验收）

## 使用场景

- 项目立项报告（海航版12章模板）
- 可行性分析报告
- 需求规格说明书
- 各类需要多角色签审的企业文档

## HTML结构示例

```html
<h3>（一）项目现状</h3>
<div class="kb-card" style="border-left:4px solid #74b9ff;padding:10px;background:#f8f9fa;">
  <p style="margin:0;color:#636e72;font-size:0.9em;">
    <strong>✏️ 编写指引</strong>：项目经理补充说明...
  </p>
</div>

<!-- 项目经理补充 -->
<div class="kb-card" style="border-left:4px solid #a29bfe;padding:10px;margin:8px 0;">
  <p><strong>【项目经理补充】</strong>现状描述内容...</p>
</div>

<!-- 产品经理补充 -->
<div class="kb-card" style="border-left:4px solid #a29bfe;padding:10px;margin:8px 0;">
  <p><strong>【产品经理补充】</strong>业务视角描述...</p>
</div>
```

## 关键规则

- 每个角色补充使用独立card，不合并
- 右侧边框统一使用紫色 `#a29bfe` 区分角色补充
- 编写指引card使用蓝色 `#74b9ff` + 浅灰背景
- 章节标题使用 `h2`/`h3`/`h4` 层级
- 编写指引使用灰色小字 `color:#636e72;font-size:0.9em`
