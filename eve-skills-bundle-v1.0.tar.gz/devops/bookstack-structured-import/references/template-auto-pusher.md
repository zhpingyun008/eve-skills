# Template Auto-Pusher 模式

## 场景
从Skill技能库自动生成文档模板并推送到 BookStack 文档模板库书架（Shelf ID=1416）。

## 核心模式

### 模板→Book映射
```
文档模板库书架 (ID=1416)
├── 01 📊 项目管理模板 (Book 1417) ← feasibility-charter-generator 等
├── 02 💻 技术文档模板 (Book 1418) ← api-contract-generator 等
├── 03 📝 会议纪要模板 (Book 1419) ← meeting-minutes-action-tracker
├── 04 📋 需求规格模板 (Book 1420) ← srs-auto-generator, srs-ai-review
├── 05 🎨 设计文档模板 (Book 1421) ← architecture-highlevel-designer
├── 06 🧪 测试文档模板 (Book 1422) ← test-report-auto-generator
├── 07 🔧 运维文档模板 (Book 1423) ← multi-env-deploy-rollback
└── 08 📈 汇报总结模板 (Book 1424) ← pm-daily-report 等
```

### 模板格式
每个模板保留原始Markdown格式（可复制粘贴），使用 `<pre>` 标签包裹。
模板内容含 `{{placeholder}}` 标记供后续填充实际数据。

### 定时同步Cron
每周一凌晨3点自动同步（`0 3 * * 1`），使用 no_agent 模式直接执行脚本。

### 代码结构
- 脚本：`~/.hermes/scripts/template_auto_pusher.py`
- 模板定义在 TEMPLATE_BOOKS 字典中，按分类组织
- 每个分类含 book_id, skills 引用, templates 列表(name+content)
