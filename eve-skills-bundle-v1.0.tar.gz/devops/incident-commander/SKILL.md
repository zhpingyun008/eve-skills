---
name: incident-commander
description: 自主SRE事故指挥官 — 真实事故响应+混沌韧性演练双模式。检测→诊断→修复→验证→学习 全闭环。对标 Lethe044 hermes-incident-commander。触发词："incident"/"事故响应"/"SRE"/"service down"/"生产事故"。
depends_on:
  - k8s-deployer
  - chaos-engineer
related_skills:
  - maestro-orchestrator
  - k8s-resource-manager
  - cloud-cost-optimizer
category: devops
triggers:
  - "incident"
  - "事故"
  - "SRE"
  - "service down"
  - "生产事故"
  - "outage"
  - "alert"
  - "故障"
  - "drill"
  - "演练"
  - "chaos drill"
  - "韧性演练"
  - "resilience test"
  - "改进项"
  - "待办改进"
  - "复盘执行"
  - "postmortem execution"
  - "improvement items"
  - "BookStack down"
  - "BookStack访问不了"
  - "bookstack修复"
  - "bookstack页面"
  - "bookstack样式"
  - "bookstack CSS"
  - "bookstack无样式"
  - "bookstack白板"
  - "bookstack session"
  - "bookstack 登录丢失"
  - "bookstack 踢回登录"
  - "自愈反杀"
  - "restart cascade"
  - "smart restart"
  - "cascade failure"
  - "经验教训"
  - "agent timeout"
  - "agent无响应"
  - "gateway timeout"
  - "Gateway health check"
  - "profile disconnected"
  - "failed to start"
  - "EADDRINUSE"
  - "health alert"
  - "health alert script"
  - "health-alert.sh"
  - "daily health report"
  - "daily-health-report"
  - "自动告警"
  - "主动巡检"
  - "健康报告"
  - "修复后监控"
  - "post-recovery"
  - "post-outage"
  - "hardening cycle"
  - "监控基建"
  - "端口不匹配"
  - "port mismatch"
  - "自愈脚本"
  - "self-heal"
  - "anti-degradation"
  - "health check port"
  - "SYSTEM_AUTO_REPAIR"
  - "自愈失败"
  - "auto-repair"
  - "记忆压缩"
  - "memory compression"
  - "SYSTEM_ALERT"
  - "健康告警"
  - "cron error"
  - "cron 报错"
  - "empty response"
  - "模型超时"
  - "provider timeout"
  - "token expired"
  - "key过期"
  - "credential expired"
  - "ZAI_API_KEY"
  - "401认证失败"
  - "credential pool exhaustion"
  - "凭据过期"
  - "credential_pool"
  - "all exhausted"
  - "no available entries"
  - "OOM"
  - "Out of memory"
  - "killed process"
  - "dmesg"
  - "memory pressure"
  - "oom_score_adj"
  - "OOM保护"
  - zombie
  - 僵尸进程
  - 僵尸Gateway
  - HTTP 000
  - 000响应
  - 进程存活但无响应
  - 进程活着但HTTP
---

# incident-commander — 自主SRE事故指挥官


## Overview

Brief description of this skill's purpose and capabilities.
P0 MTTR从45-60分钟缩短到分钟级，全自动化事故生命周期。

## 架构管道

```
DETECT → TRIAGE → DIAGNOSE → REMEDIATE → VERIFY → LEARN
   │         │         │           │           │        │
 监控告警   严重度    根因分析    自动修复    验证恢复  创建技能
 cron触发   分类      hypothesis   apply      health    沉淀经验
```

## P0-P2严重度分类

| 级别 | 描述 | 响应 | 示例 |
|------|------|------|------|
| P0 | 服务完全不可用 | 立即 | 全站宕机, DB崩溃 |
| P1 | 核心功能受损 | 5分钟 | 支付/登录失败 |
| P2 | 非核心降级 | 30分钟 | 后台页面慢 |

## 事故场景（预置）

```bash
# 演示场景
demo/disk-full-logs      # 磁盘满
demo/svc-crash-nginx     # Nginx崩溃
demo/cpu-runaway-process  # CPU跑满
demo/memory-leak          # 内存泄漏
demo/db-connection-exhausted # 数据库连接耗尽
demo/hermes-web-ui-down  # Hermes Web UI @reboot启动失败
```

### 场景: 已自愈的健康告警 — 已恢复的实时告警验证 (already-healed-alert)

**触发条件**: 收到 `SYSTEM_ALERT` 报告服务宕机（如"Profile Gateway缺失: 0个(应有11个)"），但实际调查时所有服务均已在线且健康。**自然倾向是认为"假警报/脚本bug"，但实际可能是真正的宕机事件已被autoheal自动恢复。**

**关键洞察 — 时间戳对齐是第一诊断步骤**: 在判断"假警报"之前，必须先检查告警时间戳 vs 当前时间。如果告警在5+分钟前触发，autoheal系统可能已经完成了恢复。**千万不要跳过此步骤直接认定脚本bug**。

```bash
# Step 0: 时间戳对齐 — 根因预判
# 告警消息中显示的时间 = 告警检测时间
# 当前时间 = 调查时间
# 如果间隔 > 2分钟 → autoheal可能已介入
# 如果间隔 > 5分钟且autoheal存在 → 大概率已自愈

# Step 1: 验证autoheal日志 — 确认是否发生过恢复
cat /tmp/gateway-autoheal-$(date +%Y%m%d).log 2>/dev/null | tail -20
# 寻找: DEAD → Restarting → RECOVERED 模式
# 如果有RECOVERED记录 → 是真事故，已自愈
# 如果日志为空 → 可能假警报或autoheal未触发

# Step 2: 多维度健康验证（进程+端口+HTTP三线并行）
echo "=== 进程检查 ==="
ps aux | grep 'gateway run --profile' | grep -v grep | wc -l
echo "=== 端口检查 ==="
ss -tlnp | grep -cE ':864[3-9]|:865[0-4]'
echo "=== HTTP健康检查 ==="
# 只检查Profile Gateway端口（8648是WebUI非Profile）
for port in 8643 8644 8645 8646 8647 8649 8650 8651 8652 8653 8654; do
  code=$(curl -s -o /dev/null -w "%{http_code}" --connect-timeout 3 http://127.0.0.1:$port/health 2>/dev/null || echo "000")
  [ "$code" != "200" ] && echo "  :$port → FAIL ($code)"
done
echo "全部通过则确认已自愈"

# Step 3: 排除假警报 — 验证检测脚本逻辑
bash ~/scripts/gateway-autoheal.sh 2>&1 | grep "^OK"
# 预期: "OK=11 FAIL=0"

# Step 4: 验证健康巡检日志
tail -5 ~/logs/health-alert.log
# 寻找: "✅ Gateway正常: 1主+N个Profile=N" 或 "巡检完成: 0个问题"
```

**诊断决策树**:

```
告警时服务全绿
    │
    ├─ autoheal日志有RECOVERED记录 + 时间戳对齐告警时间
    │   → ✅ 真实事故，系统已完全自愈
    │   → 汇报: 事故时间线 + 自愈验证 + 无需人工干预
    │
    ├─ autoheal日志有RECOVERED但不完全(N/11)
    │   → ⚠️ 部分自愈，个别Profile可能二次崩溃
    │   → 需手动检查并修复缺失的Profile
    │
    ├─ autoheal日志为空 且 检测脚本逻辑正常
    │   → ❓ 可能是假警报或旧的残留告警消息
    │   → 检查告警消息中的版本号 vs 当前脚本版本号
    │   → 如果版本号不匹配: 陈旧告警延迟交付(stale-alert-delivery)
    │
    └─ 检测脚本逻辑有bug (grep模式不匹配/阈值错误)
        → ❌ 假警报 — 修复脚本逻辑
```

**常见误判陷阱**:

| 陷阱 | 表现 | 正确做法 |
|------|------|----------|
| **起手就找脚本bug** | 先假设是假警报再看状态 | 先时间戳对齐 → 先查autoheal日志 → 再考虑脚本bug |
| **只查进程不查端口** | `ps | grep` 看到进程就认为健康 | 进程存活 ≠ 端口监听 ≠ HTTP响应200 — 三线全验 |
| **忽略autoheal时间窗口** | 告警23:53, 查看时23:55, 中间2分钟autoheal已完成 | 任何告警在2+分钟后查看, autoheal可能已介入 |
| **对"000"显示式端口误判** | `ss -tlnp` 显示端口LISTEN认为健康 | 即使端口LISTEN, curl仍可能000 (HTTP server内部死锁/zombie) |

**命令陷阱 — ps aux 的命令行截断**: `ps aux` 的命令列(COMMAND)会截断超过宽度的命令行参数，可能看不到 `--profile` 标志。使用 `ps auxww` 获取完整命令行:
```bash
# ❌ 可能截断, 看不到 --profile 参数
ps aux | grep 'gateway run' | grep -v grep
# ✅ 完整输出, 确保看到全部参数
ps auxww | grep 'gateway run' | grep -v grep
```
**重要规则**: 当使用 `ps | grep` 判断进程存在性时，始终用 `ps auxww` 而非 `ps aux`，避免命令行截段产生误判。`ps aux` 对短终端宽度(WSL默认80列)自动截断到80字符。

**命令陷阱 — bash包装进程污染计数 (bash-wrapper-pollution)**: 当服务通过bash包装脚本启动时（如PID 89829: `/usr/bin/bash -lic set +m; cd ~/.hermes && python3 -m hermes_cli.main gateway run --profile pm`），`ps aux | grep 'gateway run --profile'` 会**同时匹配bash包装进程和实际的Python网关进程**，导致profile_gw计数从11翻倍为12，触发假泄漏告警。在WSL/cron环境中，`cronjob run` 和 `hermes gateway run` 常通过bash -lic包装启动，每次调度都会产生一个额外的bash层进程。**修复: 在grep链中添加 `grep -v bash`** 过滤bash包装进程:

```bash
# ❌ 错误: 计数含bash包装进程 (profile_gw=12, 其中1个是bash)
profile_gw=$(ps auxww | grep 'gateway run --profile' | grep -v grep | wc -l)

# ✅ 正确: 排除bash包装进程 (profile_gw=11, 纯净)
profile_gw=$(ps auxww | grep 'gateway run --profile' | grep -v grep | grep -v bash | wc -l)
```

**关键教训** (本场景):

| # | 教训 | 规则 |
|---|------|------|
| 1 | 告警时全绿 ≠ 假警报 — autoheal可能在调查窗口内完成恢复 | ⚡ 先查autoheal日志+时间戳对齐, 再判断是否为脚本bug |
| 4 | `ps aux` 截断命令行参数可能导致误判grep模式 | ⚡ 进程检测始终用 `ps auxww` 获取完整命令行 |
| 5 | **grep模式顺序必须匹配实际命令行参数顺序** — `--profile` 在实际进程中是 `hermes --profile arch gateway run`，grep `gateway run --profile` 匹配0个；`--replace` 是所有Gateway的共同标志，grep `gateway run --replace` 误算全部12个(主+11Profile) | ⚡ 永远检查实际 `ps auxww` 输出中的参数顺序，然后再写grep模式。主Gateway: `grep 'gateway run --replace' | grep -v -- '--profile'`；Profile Gateway: `grep -- '--profile'`（直接用`--profile`标志匹配，不管它在参数中的位置） |
| 3 | bash包装进程污染 `ps | grep` 计数 — `bash -lic 'python3 ... gateway run --profile X'` 在 `ps` 中显示为两个进程(bash + python3)，都匹配grep模式 | ⚡ `ps` 计数grep链始终追加 `grep -v bash`，排除包装层进程 |
| 4 | 三线(进程+端口+HTTP)并行验证优于单线诊断 | ⚡ 进程存活性==0 (真实), HTTP==200 (功能), 端口监听==中间态 |
| 5 | autoheal日志是事故本质的证据 | ⚡ 任何告警调查第一步: `cat /tmp/gateway-autoheal-*.log \\| tail` |

### 场景: 瞬态Cron错误逆向诊断 — 已自愈的健康告警 (transient-cron-error)

**触发条件**: 收到 `SYSTEM_ALERT` 报告 "Cron错误: N个"，但调查时 `hermes cron list` 显示全部 `last_status: ok`，错误已自愈消失。需要从日志痕迹反向诊断根因。

**经典症状**:
- health-alert.log 显示 04:41=1问题, 04:42=1问题, 04:43=1问题, 但 04:47=0问题
- `hermes cron list | grep -c "error"` 当前返回 0
- 无任何 cron 显示 `last_status: error`
- 所有服务全绿（Gateway/Dashboard/WebUI/BookStack 均 200）

**关键洞察 — Cron List API 状态滞后陷阱 (API-stale-cache)**: 当告警触发时立即调用 `cronjob list` 可能看到 `last_status: "error"`，但直接读取 on-disk `~/.hermes/cron/jobs.json` 已显示 `last_status: "ok"`。这是因为 cron list API 可能缓存了 **旧状态**（延迟最长可达 5 分钟）。**诊断时必须同时验证 API 和 on-disk 两份数据源**，避免误判为"仍有错误"而浪费时间。验证命令: `python3 -c "import json;d=json.load(open('$HOME/.hermes/cron/jobs.json'));jobs=d.get('jobs',[]) if isinstance(d,dict) else d;target=[j for j in jobs if j.get('id')=='<ERROR_JOB_ID>'];print(target[0].get('last_status','?')) if target else print('NOT_FOUND')"`。如果 API 返回 `error` 但 on-disk 返回 `ok`，说明 cron 已自愈，无需修复。

**关键洞察 — grep 陷阱 (已修复 v1.1)**: `health-alert.sh` v1.0 的 `check_cron_errors()` 函数执行 `hermes cron list | grep -c "error"`，这是 **大小写敏感的子串匹配**，会命中任何包含 "error" 的行，不仅仅是状态字段。v1.1 已修复为精确匹配 `Last run:` 行的末位状态字段。瞬态匹配来源包括：
- cron 输出文本中包含 "error" 字样的 **job 名称**（如 cron 名为 "...no error..."）
- cron 的 **prompt** 中包含 "error"（如 "check for errors"）
- cron 配置中 **model/provider 字段** 包含 "error" 相关文字
- cron 的 **last_delivery_error** 输出内容包含 "error" 字串（即使 last_status=ok）
- **⚠️ 新旧 cron 交接瞬态**: 旧 cron 被删除后，新创建的 cron 尚未首次运行 → `last_status: null` 可能被某些版本的系统输出为含 "error" 的行；或 cron 删除/创建操作本身的 CLI 输出包含 "error"

**诊断流程 (反向重构法)**:

```bash
# Step 0: 确认当前状态 — 全部ok?
hermes cron list 2>&1 | grep -c "error"
# → 0 = 错误已自愈，开始反向诊断

# Step 1: 检查告警时间窗，找瞬态事件
tail -10 ~/logs/health-alert.log
# 重点: 找到首次检测到错误的时间 → 最后检测到错误的时间 → 首次恢复的时间
# 计算持续时间: 如果 <10分钟 → 瞬态

# Step 2: 检查告警时间窗内是否有cron变更
# 检查被删除/新建的 cron
python3 -c "
import json
with open('$HOME/.hermes/cron/jobs.json') as f:
    jobs = json.load(f)
print(f'Total crons: {len(jobs)}')
# 检查最近创建时间戳 (如果有)
"
# 对比记忆中的cron列表与当前列表

# Step 3: 检查最近是否有 auto-repair 事件
cat ~/logs/health-alert.log | grep -E "自愈|重启|auto_repair|repaired" | tail -5
# 常见模式: health-alert.sh 自身的自动修复动作可能在日志输出中包含 "error"

# Step 4: 反向推断最可能根因
# 根据时间窗内的已知事件做贝叶斯推断:
# 
# 可能根因A: 新旧cron交接瞬态 (概率: 高)
#   - 时间窗内Bailongma健康巡检cron被替换 (d23c93007fa9 → 3ff1da7e0dea)
#   - 旧cron删除 + 新cron创建 = 这段时间hermes cron list输出波动
#   - 证据: 健康告警日志显示04:41首次检测, 04:47恢复。cron替换发生在04:40-04:50区间
#   - 验证: 检查是否有两个cron job_id指向同一服务名
#     hermes cron list 2>&1 | grep -A2 "Bailongma" | grep "job_id"
#
# 可能根因B: health-alert.sh自我匹配 (概率: 中)
#   - health-alert.sh自身输出到stdout时包含"error"关键字
#   - 但 check_service() 输出 "⚠️ Cron错误: ${errs}个" 才触发，非 self-match
#   - 除非 health-alert 的 cron prompt 本身包含 "error" 字串
#
# 可能根因C: 告警脚本的cron prompt行为异常 (概率: 低)
#   - hermes cron list 输出被截断/混乱，临时包含错误文本
#   - 再次执行时正常

# Step 5: 确认所有服务正常 (虽已自愈，仍需验证)
for p in 8648 8654 8050 8642 3721 8080 4000; do
  code=$(curl -s -o /dev/null -w "%{http_code}" --connect-timeout 2 http://127.0.0.1:$p/ 2>/dev/null || echo "000")
  echo "Port $p: HTTP $code"
done
```

**修复方式**: 

瞬态已自愈，无需修复。但应降低同类误报率。

# 方案: 三阶段验证 (v2.2 — 已验证通过)

比3轮去抖(15分钟确认)快, 且排除"running"瞬态状态:

```bash
# v2.2: 精确过滤 — 只检查"Last run:"行的末尾状态字段
# 排除"ok"和"running"状态(执行中的作业不是错误)
# 三阶段验证: 首次→15s再验证→30s最终确认
check_cron_errors() {
    local cron_out=$(hermes cron list 2>/dev/null)
    local err_lines=$(echo "$cron_out" | grep "Last run:" | grep -vP '\b(ok|running)\s*$')
    local errs=$(echo "$err_lines" | grep -c . 2>/dev/null || echo 0)
    if [ "$errs" -gt 0 ] 2>/dev/null; then
        local suspect_detail=""
        while IFS= read -r line; do
            local ts=$(echo "$line" | sed -n 's/.*Last run:  \([0-9T:.-]\+\).*/\1/p')
            local status=$(echo "$line" | grep -oP '\b\w+\s*$' | tr -d ' ')
            suspect_detail="${suspect_detail}[${status}@${ts}] "
        done <<< "$err_lines"

        # 瞬态过滤: 等15s后二次验证
        sleep 15
        local cron_out2=$(hermes cron list 2>/dev/null)
        local err_lines2=$(echo "$cron_out2" | grep "Last run:" | grep -vP '\b(ok|running)\s*$')
        local errs2=$(echo "$err_lines2" | grep -c . 2>/dev/null || echo 0)

        if [ "$errs2" -gt 0 ] 2>/dev/null; then
            # 三次验证: 等30s后最终确认
            sleep 30
            local cron_out3=$(hermes cron list 2>/dev/null)
            local err_lines3=$(echo "$cron_out3" | grep "Last run:" | grep -vP '\b(ok|running)\s*$')
            local errs3=$(echo "$err_lines3" | grep -c . 2>/dev/null || echo 0)
            if [ "$errs3" -gt 0 ] 2>/dev/null; then
                ALERTS="${ALERTS}⚠️ Cron错误(三验证确认): ${errs3}个 ${suspect_detail}\\\\n"
                ISSUES=$((ISSUES+1))
            else
                echo "[$NOW] ⚠️ Cron瞬态异常(已自愈): ${suspect_detail}" >> "$LOG"
            fi
        else
            echo "[$NOW] ⚠️ Cron瞬态异常(已自愈): ${suspect_detail}" >> "$LOG"
        fi
    fi
}
```
# 精确Last run状态行匹配 (v1.0->v1.1已修复):
# BAD:  hermes cron list 2>/dev/null | grep -c "error"          (v1.0假阳性源)
# BAD:  hermes cron list 2>/dev/null | grep -E "last_status: error|last_status: fail"  (CLI输出格式不匹配)
# GOOD: hermes cron list 2>/dev/null | grep "Last run:" | grep -vP '\bok$'
# 原理: CLI输出中每行格式为 "Last run:  2026-05-17T05:49:44.669642+08:00  ok"
#       grep "Last run:" 只取状态行 → grep -vP '\bok$' 排除以" ok"结尾的正常行 → 剩余即错误行
| 9 | **`cronjob run`可能在cron后端冗余时创建重复条目** | ⚡ 对cron运行`action='run'`后cron列表可能出现新job_id + 旧job_id并存。排查时先list确认无重复再操作 |
| 10 | **残留告警信号 ≠ 当前系统故障** | ⚡ health-alert可能捕获了已自愈的瞬态错误（如脚本补丁刚应用完）。先验证所有服务+直接跑cron脚本确认 |
| 11 | **👻 静默幽灵Job: 内部DB有但CLI不可见** | ⚡ 如果在 `cronjob(action='list')` 工具输出中看到 job 但 `hermes cron list` CLI 中不显示，这是一个从未成功注册到调度器的幽灵job。特征: `last_run_at: null`, `last_status: null`, `enabled: true`。`hermes cron list run <id>` 会返回 \"Job not found\"。它会间歇性触发 health-alert 误报——因为两次查询结果不一致。该job会在系统GC时自动消失(通常<30分钟)，无需手动干预。验证: 再次list确认总数减少(幽灵已清除)。 |
| 12 | **👻 告警中作业名为空`[→@timestamp]` = 新建cron首次调度失败** | ⚡ 当 health-alert 告警消息中 job name 为空（格式为 `[→@timestamp]` 而非 `[Job名→error@timestamp]`），说明失败 cron 没有 "Last run:" 行——即该job创建后**从未执行过**。根因: cron调度器在job首次执行时(新cron从last_run_at=null变为状态error)产生了瞬态状态。这触发 `grep -B2 "Last run:"` 无法找到上两行的Name字段（因为前一个循环该行不存在），导致name提取为空白。与"幽灵job"（DB有/CLI无）不同：此job在API和CLI中都可见，只是从未调度成功。**处理: 无需干预，下个调度周期自动恢复。** |

**瞬态过滤核心原则** (v2.2 更新):

| 原则 | 说明 | 
|------|------|
| 三阶段验证而非单次验证 | 15s+30s逐级确认, 过滤>45s的瞬态作业, 不遗漏真实错误 |
| 排除running瞬态 | `grep -vP '\b(ok|running)\s*$'` 执行中的作业不是故障 |
| 瞬态记录不告警 | 减少人类疲劳, 但保留日志供事后审计 |
| 诊断信息前置 | 告警消息直接包含状态码+时间戳, 不需要再查日志 |
| 永不跳过第一步检查 | 先精确匹配Last run状态行, 再过滤瞬态, 两步保险 |

**关键教训**:

| # | 教训 | 规则 |
|---|------|------|
| 1 | `grep -c "error"` 是子串匹配,非状态匹配 | ⚡ `health-alert.sh` v1.0 的 cron error 检测粒度太粗，v1.1已修复：`grep "Last run:" | grep -vP '\bok$'` |
| 2 | 修复建议 `grep -E "last_status: error"` 在CLI输出格式上不成立 | ⚡ CLI输出格式为 `Last run:  ...  ok`，无 `last_status:` 字段。修复方案必须先验证实际CLI输出格式 |
| 3 | 瞬态 cron 错误通常 <10分钟自动恢复 | ⚡ 收到告警后先查看日志时间窗，如果在缩小则等1-2轮再诊断 |
| 4 | cron 替换操作本身就是瞬态错误的常见来源 | ⚡ 新旧 cron 交接时 hermes cron list 输出波动，可能被误检测 |
| 4 | 已自愈的错误不代表不需要诊断 | ⚡ 如果同类瞬态反复出现(>3次/天)，说明有潜在大模式需要修复 |
| 5 | 告警去抖可降低假阳性，降低人类疲劳 | ⚡ 10秒二次验证优于3轮去抖(15分钟): 更快过滤瞬态, 且不增加假阴性风险 |
| 6 | **Cron prompt可能引用错误脚本** — 报错cron的prompt引用 `bailongma-bridge.py health`，但正确脚本是 `check_health.py check` | ⚡ 诊断时必须同时验证 script CLI 正确性 AND 模型提供商可靠性，不能只看模型问题 |
| 6b | **模型名前缀格式各provider不同** — `deepseek-ai/deepseek-v4-flash` 在 openrouter/nvidia 有效，但 deepseek 原生 provider 要求 `deepseek-v4-flash`（无 `deepseek-ai/` 前缀） | ⚡ 切换cron的provider时必须同时验证模型名是否符合新provider的命名规范。验证: `hermes chat --provider <新provider> -m <新模型名> -q "ping" -Q`。常见映射: openrouter=`deepseek-ai/deepseek-v4-flash`, nvidia=`deepseek-ai/deepseek-v4-flash`, deepseek原生=`deepseek-v4-flash`, zai=`z-ai/glm-4-flash` |
| 7 | **并发退化模式** — 服务短暂宕机 + cron模型报错同时发生，双重信号叠加触发一个告警 | ⚡ 诊断时拆分为 **服务层问题**（check_health.py自愈检测）和 **cron层问题**（LLM模型空响应）两条线分别排查 |
| 8 | **check_health.py自愈成功 ≠ cron健康** — 自愈脚本重启了服务，但不影响旧cron的LLM模型空响应报错 | ⚡ 两个子系统独立运作，各自产生自己的健康状态，不能因为服务自愈了就认为cron也自愈了 |

---

### 场景: Cron 模型/提供商错误排障 — health-alert触发 (cron-model-error)

**触发条件**: `SYSTEM_ALERT` 报告 "⛔ Hermes 健康告警 / 问题数: 1+ / Cron错误: N个"。health-alert.sh 输出 "1 issues found"。根因为 `check_cron_errors()` 检测到 `hermes cron list` 中有 `error` 状态的job。

**典型错误A**: `Agent completed but produced empty response (model error, timeout, or misconfiguration)`

**关键洞察**: 这个错误 **不是脚本/服务故障**，而是 cron 的 LLM（模型/提供商）返回了空响应。cron 的 `terminal` 脚本执行本身是成功的。错误来自 LLM 生成 agent response 阶段。因此修复方向是 **模型/提供商** 而非脚本本身。

**典型错误B — 瞬态 `(No response generated)` 模式 (transient-no-response)**: cron job 输出文件的 `## Response` 段为 `(No response generated)`，但脚本本身运行正常。

**与典型错误A的关键区别**:

| 维度 | 典型错误A (empty response) | 典型错误B (No response generated) |
|------|---------------------------|-----------------------------------|
| **症状** | Agent完成执行但工具返回空 | Agent本身未产生任何响应 |
| **频次** | 每次运行(持续失败) | 间歇性(大部分运行正常) |
| **脚本测试** | 可能正常/异常 | ✅ 直接运行脚本一定正常 |
| **根因** | 模型/提供商/凭证问题 | **瞬态Provider API故障** — LLM调用超时或空响应 |
| **修复** | 切换模型/修复凭证 | **无需修复** — 下个周期自动恢复 |

**诊断方法**:
```bash
# Step 1: 确认症状 — 检查cron输出文件
cat ~/.hermes/cron/output/<JOB_ID>/$(ls -t ~/.hermes/cron/output/<JOB_ID>/*.md | head -1) | grep -A2 "## Response"
# 输出: (No response generated) → 瞬态

# Step 2: 确认非脚本故障 — 直接运行脚本
cd ~/.hermes/skills/agent-skills/<skill>/scripts && python3 <script>.py 2>&1
echo "EXIT=$?"
# exit 0 + 正常输出 → 瞬态Provider问题

# Step 3: 检查历史模式 — 区分间歇性 vs 趋势
ls -t ~/.hermes/cron/output/<JOB_ID>/*.md | while read f; do
  resp=$(grep -A2 "## Response" "$f" | tail -1)
  echo "$(basename $f): $resp"
done | tail -20
# 模式A: 混合出现 [SILENT]|✅|(No response generated) → 瞬态
# 模式B: 连续5+次 (No response generated) → Provider真问题

# Step 4: 判断是否需要干预
# 规则: 若连续3次以上都 (No response generated) → 切换provider
# 若间歇性出现(几分钟一次) → 无需干预，自愈
```

**变体A: 凭证池枯竭 (credential-pool-exhaustion)** — 当cron使用OpenRouter免费模型时，日限额(429)耗尽后自动切到备用key，若备用key也无效(401)，凭证池全部枯竭，最终报 `Non-retryable client error: 401 — Missing Authentication header`。**核心症状路径**: 429→rotate→401→all_exhausted。诊断日志关键词：`marking OPENROUTER_API_KEY exhausted (status=429), rotating` → `marking api-key-2 exhausted (status=401), rotating` → `no available entries (all exhausted or empty)`。

**变体B: 空API Key配置 (empty-api-key)** — provider的 `api_key` 在 config.yaml 中被显式设为空字符串 `''`

**变体C: API Key直接过期 (expired-api-key)** — 环境变量中的API Key存在但已失效（被提供商吊销/过期），导致直接401无限流转跳。与变体A/B的核心区别：
- 变体A（凭证池枯竭）：先429限流→rotate→备用key也401→耗尽——有使用历史
- 变体B（空API Key）：config.yaml中`api_key: ''`——从无有效key
- 变体C（Key直接过期）：key存在、config正确、曾经可用，但提供商侧已吊销——无前置429，直接401

**诊断特征：**
```bash
# 1. credential pool中key存在但curl直测返回401+ "expired" 或 "invalid"
curl -s -X POST https://api.z.ai/api/paas/v4/chat/completions \
  -H "Authorization: Bearer $ZAI_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"model":"glm-4-flash","messages":[{"role":"user","content":"ping"}],"max_tokens":1}' \
  | python3 -c "import json,sys;d=json.load(sys.stdin);print(d.get('error',{}).get('message','?'))"
# 输出: "token expired or incorrect"  → 确认key过期

# 2. credential pool状态显示key存在但未标记exhausted（auth.json中last_status=null）
python3 -c "
import json
with open('/home/yestin/.hermes/auth.json') as f:
    data = json.load(f)
cp = data.get('credential_pool', {})
for provider, entries in cp.items():
    for e in entries:
        print(f'{provider}/{e[\"label\"]}: status={e[\"last_status\"]}, err={e[\"last_error_code\"]}, reqs={e[\"request_count\"]}')"

# 3. agent.log仅有直接401，无429→rotate过渡
grep "marking.*exhausted\|Missing Authentication\|token expired" ~/.hermes/logs/agent.log | tail -5

# 4. 其他同provider的cron当前显示"ok"（因本次尚未运行），但下次调度必然失败
hermes cron list 2>/dev/null | grep "provider: zai" | grep "last_status"
# 注意：所有使用zai provider的cron都处于待爆炸状态
```

**修复流程：**
```bash
# Step 1: 确认过期key并获取新key
# 从提供商控制台/API后台生成新Key

# Step 2: 更新环境变量
export ZAI_API_KEY="<新key>"
# 持久化到 .bashrc 或 .env
sed -i 's/^export ZAI_API_KEY=.*/export ZAI_API_KEY=<新key>/' ~/.bashrc 2>/dev/null
echo "ZAI_API_KEY=<新key>" >> ~/.hermes/.env

# Step 3: 清除credential pool的过期状态
# credential pool不会自动清除过期的key标记（auth.json中last_status=null但key已无效）
# 不需要手动清除，新key被环境变量加载后下次调用自动使用新值
# 但为了验证，可以强制刷新pool:
hermes auth list --provider zai

# Step 4: 验证新key
curl -s -X POST https://api.z.ai/api/paas/v4/chat/completions \
  -H "Authorization: Bearer $ZAI_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"model":"glm-4-flash","messages":[{"role":"user","content":"ping"}],"max_tokens":10}' \
  | python3 -c "import json,sys;d=json.load(sys.stdin);print('✅ OK' if d.get('choices') else '❌ FAIL:', d.get('error',{}).get('message','?'))"

# Step 5: 验证所有同provider cron健康
hermes cron list 2>/dev/null | grep "Last run:" | grep -vP '\bok$'  # 预期无输出
bash ~/scripts/health-alert.sh 2>&1 | grep "issues"  # 预期: "OK: 0 issues found"
```

**与变体A/B的核心区别：**

| 维度 | 变体A (凭证池枯竭) | 变体B (空API Key) | 变体C (Key过期) |
|------|-------------------|------------------|-----------------|
| 症状 | 429→rotate→401→all_exhausted | 直接401 "Missing Authentication header" | 直接401 "token expired/incorrect" |
| agent.log | 有`marking...exhausted...rotating`轮转日志 | 无轮转日志，直接401 | 无轮转日志，直接401 |
| curl直测 | 返回429 或 401(备用key) | 返回401 "Missing Authentication" | 返回401 "expired/incorrect" |
| 修复 | 等待冷却/换免费模型 | 配置有效key 或 全库迁移 | 获取新Key替换 |
| 影响范围 | 仅受影响provider的cron | 全库所有使用此provider的cron | 全库所有使用此provider的cron |
| 恢复方式 | 自动冷却后恢复 | 永久失败，必须人工修复 | 必须换新Key，同provider所有cron待爆炸 |

**关键教训：**
| # | 教训 | 规则 |
|---|------|------|
| 1 | Key过期后credential pool不主动标记（auth.json中last_status=null） | ⚡ curl直测是唯一可靠验证方式，不能依赖credential pool状态 |
| 2 | 同provider其他cron当前"ok"只是还没运行到 | ⚡ 修复过期key后必须全库扫描同provider cron，每个都是待爆炸状态 |
| 3 | 已自愈的401错误不代表Key已恢复 | ⚡ 服务自愈可能是其他provider接管了调度，不代表原provider key正常 |，这**不是**运行时凭证耗尽，而是**永久性配置缺陷**。与凭证池枯竭不同：
- 凭证池枯竭：key先正常使用→429触发→rotate→全部耗光→401（有使用历史）
- 空API Key配置：**从来就没有key**→每次请求都401（无使用历史，永久失败）
- 诊断特征：`agent.log` 中无 `marking...exhausted...rotating` 轮转日志，直接报 `Missing Authentication header`

**诊断流程 (6步法)**: 先验凭证池, 后验配置, 再验脚本, 终验模型

```bash
# Step 0: 区分凭证池枯竭 vs 空API Key — 看agent.log中有无轮转日志
# 凭证池枯竭: grep "marking.*exhausted" ~/.hermes/logs/agent.log | grep "$ERROR_JOB_ID"
# 空API Key: 找不到轮转日志，但grep "Missing Authentication header" ~/.hermes/logs/errors.log | grep "$ERROR_JOB_ID"
# 空API Key: 比较老版本 config.yaml，看api_key字段是否为 ''
grep -A3 "openrouter:" ~/.hermes/config.yaml  # 检查api_key值
if grep -A3 "openrouter:" ~/.hermes/config.yaml | grep -q "api_key: ''"; then
  echo "⚠️ 空API Key检测: openrouter.api_key 为空字符串"
  echo "   → 此provider所有路由都会401，不是临时凭证耗尽"
  echo "   → 修复: 配置有效key或切换cron到其他provider(如zai)"
fi
# 也检查其他provider的key状态
for prov in $(grep -E "^[a-z]+:" ~/.hermes/config.yaml | awk '{print $1}'); do
  key=$(sed -n "/^$prov:/,/^[a-z]/p" ~/.hermes/config.yaml | grep "api_key" | head -1)
  echo "$prov: $key"
done

# Step 0a: 如果是空API Key — 直接进入修复模式(模式A)，同时将全库中所有使用此provider的cron迁移到稳定provider
# 空API Key是永久性缺陷，修复一个cron不够，必须全库扫描

```bash
# Step 1: 定位报错cron
hermes cron list 2>&1 | grep -A 10 "error"
# 记录: job_id, name, model, provider, last_run_at, 具体错误信息

# Step 2: 确认脚本/服务本身健康 (非脚本故障)
# 直接运行脚本应该正常:
cd ~/.hermes/skills/agent-skills/bailongma-bridge/scripts && python3 check_health.py
# 预期: "OK Bailongma is alive" + exit 0
# 如果脚本失败: 这是真正的脚本/服务故障，走其他场景
#
# ⚠️ 关键陷阱: cron prompt引用的脚本 ≠ 正确的健康检查脚本
# 旧cron可能写的是 `bailongma-bridge.py health` 但实际正确脚本是 `check_health.py check`
# 即使服务本身健康，cron执行了错误脚本/错误参数也会报错
# 必须同时验证: a) 服务层健康 (直接运行正确脚本) b) cron prompt中的命令是否引用了正确的脚本
#
# ⚠️ 扩展陷阱: 脚本存在 ≠ 参数正确
# cron prompt可能引用了一个存在的脚本文件，但传入了该脚本不支持的参数！
# 示例: bailongma-bridge.py 仅支持 send/status/memories/search/quota/stop/start/health，
# 但cron prompt写道: `bailongma-bridge.py --action prefetch --service hermes --action aci_preheat`
# → 脚本根本没有 --action 参数！一切参数都是虚构的
# → 正确脚本应是 hermes-prefetch-update.py (纯python, 支持无参数或 --oneshot)
# → 诊断方法: 直接运行脚本 --help 查看usage，确认支持哪些参数

# Step 3: 确认错误为模型超时/空响应 (非cron执行失败)
hermes cron list 2>&1 | grep -B3 "empty response"
# 包含 "empty response" → 模型/提供商问题
# 包含 Python ImportError/RuntimeError → 脚本/沙箱问题
# 包含 "timed out"/"timeout" → 网络/提供商问题

# Step 4: 验证其他同类模型cron的健康状况
hermes cron list 2>&1 | grep -B5 "glm-4.5-air:free" | grep "last_status"
# 检查是否多个免费模型cron同时报错 → 提供商级别故障

# Step 5: 检测亡灵👻执行 — list中不存在的cron在output目录/agent.log中有最近痕迹
# 场景: cron已被替换/删除，但调度器保留了最后一个已入队的执行slot
# 特征: `hermes cron list`无error状态的job，但health-alert报了 Cron错误: 1个
# 诊断方法A: 检查output目录
ls -t ~/.hermes/cron/output/ | while read dir; do
  job_file=$(ls -t ~/.hermes/cron/output/$dir/*.md 2>/dev/null | head -1)
  if [ -n "$job_file" ]; then
    job_time=$(stat -c %Y "$job_file" 2>/dev/null)
    now=$(date +%s)
    age=$(( (now - job_time) / 60 ))
    if [ "$age" -le 5 ]; then  # 最近5分钟内有输出
      if ! hermes cron list 2>/dev/null | grep -q "$dir"; then
        echo "⚠️ 亡灵👻 cron: $dir (last run ${age}m ago, NOT in active list)"
        cat "$job_file" | head -5
      fi
    fi
  fi
done
# 诊断方法B (更直接): 扫描agent.log找 ERROR [cron_<OLD_JOB_ID>_]
grep -E "ERROR.*\[cron_[a-f0-9]+_" ~/.hermes/logs/agent.log | tail -5
# 交叉验证: 从ERROR行提取job_id, 确认该job_id不在当前cron列表中
# 优势: 即使output目录已清理, agent.log仍保留完整执行记录
# 如果发现亡灵cron: 这是瞬态告警，验证新cron已就绪即可，无需修复旧cron
```

**修复模式 (二选一)**:

| 模式 | 操作 | 效果 | 推荐 |
|------|------|------|------|
| **A: 删除+重建 ⭐** | `cronjob remove` → `cronjob create` (稳定模型) | **立即清除**错误状态，health-alert即刻归零 | 总是首选 |
| **B: 仅更新模型** | `cronjob update --model '{"model":...,"provider":...}'` | 错误状态保留到下次自然调度（等待期告警持续） | 仅当需要保留job_id时 |

```bash
# 模式A: 删除+重建 (推荐)
# Step 1: 删除旧cron
cronjob remove --job-id "$ERROR_JOB_ID"
# Step 2: 确认无重复cron残留 (自愈系统可能自动创建新cron)
hermes cron list 2>&1 | grep -c "$CRON_NAME"
# 如果 >1: 有重复! 逐一删除多余的
# 保留最完整的一个 (模型最稳定/提示最清晰)
# Step 3: 重建cron (使用稳定模型)
cronjob create \
  --name "Bailongma健康巡检" \
  --schedule "*/5 * * * *" \
  --prompt "Run Bailongma health check. Execute: cd ~/.hermes/skills/agent-skills/bailongma-bridge/scripts && python3 check_health.py" \
  --model '{"model":"z-ai/glm-4-flash","provider":"zai"}' \
  --enabled-toolsets '["terminal"]' \
  --deliver "local"
# Step 3: 立即验证health-alert归零
bash ~/scripts/health-alert.sh
# 预期: "OK: 0 issues found"
```

**Cron模型可靠性排名**:

| 排名 | 模型 | 提供商 | 成本 | 可靠性 | 适用场景 |
|------|------|--------|------|--------|----------|
| 🥇 | `z-ai/glm-4-flash` | zai | ¥0.10/M | ⭐⭐⭐ | **所有cron首选** — 稳定不超时 |
| 🥇⑵ | `deepseek-v4-flash` | nvidia | $0.15/M | ⭐⭐⭐⭐ | **最佳稳定组合** — 避免deepseek provider瞬态空响应; 适合需要高质量+高频执行 |
| 🥈 | `deepseek-v4-flash` | deepseek/nvidia | $0.15/M | ⭐⭐⭐ | 需要高质量分析时 |
| 🥉 | `glm-4.5-air` | zai | ¥0.05/M | ⭐⭐½ | 中等频率cron(每2h+) |
| ❌ | `z-ai/glm-4.5-air:free` | openrouter | **免费** | ⭐ | 高频cron易超时 — **不推荐用于*/5 */15等服务巡检** |

**模型选择原则**:
- **高频cron** (每1-15分钟): 必须用 `z-ai/glm-4-flash` (zai) — 稳定+低成本
- **中频cron** (每1-6小时): 可用 `glm-4.5-air` (zai) — 平衡质量成本
- **低频cron** (每12h+ / daily): 可用免费模型 — 失败影响小
- **❌ 永远不要** 在高频服务巡检cron上用OpenRouter免费模型 → 间歇性空响应

**验证清单**:

```bash
# 全服务验证
for p in 8648 8654 8050 8642 8080; do
  code=$(curl -s -o /dev/null -w "%{http_code}" --connect-timeout 3 http://127.0.0.1:$p/ 2>/dev/null || echo "000")
  echo "Port $p: HTTP $code"
done

# Bailongma专项验证
cd ~/.hermes/skills/agent-skills/bailongma-bridge/scripts && python3 check_health.py

# Cron错误清零验证
hermes cron list 2>&1 | grep -c "error" | xargs -I{} echo "Cron errors: {}"

# Health-alert清零验证
bash ~/scripts/health-alert.sh
# 预期: "OK: 0 issues found"

# 磁盘
df / | tail -1 | awk '{print "Disk:", $5}'

# 全服务绿灯标注
echo "=== ✅ 全服务绿灯 ==="
```

**批量化操作: Provider故障→全库扫描迁移**:

当某个provider的API key失效（如DeepSeek 401）时，**不要只修单个cron**。除当前报错的cron外，其他使用同provider的cron尚未运行因此显示"ok"，但下次调度必然失败。必须全库扫描 + 批量迁移。

```bash
# Step 1: 找到所有使用失效provider的cron
FAILED_PROVIDER="deepseek"  # 从报错cron中读取
hermes cron list 2>&1 | python3 -c "
import sys, json, re
lines = sys.stdin.read()
# 解析cron列表，找出provider=$FAILED_PROVIDER的job
jobs = re.findall(r\"job_id: ([a-f0-9]+).*?provider: $FAILED_PROVIDER\", lines, re.DOTALL)
print(json.dumps(list(set(jobs))))
"
# 或者更简单的grep:
hermes cron list 2>&1 | grep -B1 "provider: deepseek" | grep "job_id" | awk '{print $2}'

# Step 2: 全部批量更新到稳定provider
for JOB_ID in $(hermes cron list 2>&1 | grep -B1 "provider: deepseek" | grep "job_id" | awk '{print $2}'); do
  cronjob update --job-id "$JOB_ID" --model '{"model":"z-ai/glm-4-flash","provider":"zai"}'
  echo "✅ $JOB_ID migrated"
done

# Step 3: 验证全库无残留失败provider
hermes cron list 2>&1 | grep -c "provider: deepseek.*status: error"  # 预期0
# 注意: 还有一些使用deepseek provider且last_status=ok的job也需要迁移
# 它们尚未失败只是因为还没运行，但下次调度必然401
hermes cron list 2>&1 | grep "provider: deepseek" | wc -l  # 预期0
```

**关键教训** — 新增"全库迁移"原则:

| # | 教训 | 规则 |
|---|------|------|
| 1 | cron error "empty response" = 模型问题，非脚本问题 | ⚡ 直接运行脚本验证 + 切换稳定模型(glm-4-flash zai) |
| 2 | `cronjob update --model` 不立即清除error状态 | ⚡ 用 `remove + create` 模式彻底重置 |
| 3 | 删除旧cron后 health-alert 立即归零 | ⚡ `check_cron_errors()` grep "error" → 无error状态job即清零 |
| 4 | OpenRouter免费模型在高频cron上不可靠 | ⚡ 服务巡检(≤15min频率)必须用 `z-ai/glm-4-flash` (zai) |
| 5 | 同类告警持续出现表示有深层趋势 | ⚡ Bailongma健康巡检反复出问题 → 最终修复方案是模型升级而非反复重启脚本 |
| 6 | **Provider故障是全库问题，不是单点问题** | ⚡ 修复报错cron后必须 `hermes cron list | grep "provider: $FAILED"` 全库扫描, 将所有使用同provider的cron全部迁移。那些last_status=ok的只是还没运行到下次调度，必然失败。**空API Key场景尤其严重** — 没有任何cron能通过该provider成功，必须全库迁移。 |
| 7 | **自愈系统可能自动替换cron但保留原broken provider** | ⚡ 旧cron (job_id A) 被清除后, 自愈系统可能创建新cron (job_id B) 但保留原broken model/provider。必须找到新cron并验证其model/provider是否可靠。 |
| 6 | 修复过程可能触发cron自动创建新实例 | ⚡ cronjob update/run 可能让系统创建新cron → 完成后用 `hermes cron list | grep -c "$NAME"` 检查重复并清理 |
| 9 | **凭证池枯竭(credential-pool-exhaustion)是独立故障模式** | ⚡ 与"empty response"不同, 需先验agent.log中的credential_pool关键词, 走凭证修复路径 |
| 10 | **空API Key (`api_key: ''`) 是配置缺陷，不是运行时问题** | ⚡ 诊断时先检查 config.yaml 中 provider 的 `api_key` 字段是否为空字符串。`grep -A3 "openrouter:" ~/.hermes/config.yaml`。如果为空，所有该provider的cron都会永久401，不存在凭证轮转历史。修复: 配置有效key 或 全库迁移cron到其他provider。 |
| 8 | **脚本文件存在 ≠ 参数正确** — cron prompt可能引用存在的脚本文件但传入不存在的参数 | ⚡ 诊断时必须 `python3 <script> --help` 验证参数签名，不要假设参数存在。常见陷阱：bailongma-bridge.py 无 `--action` 参数，正确脚本是 hermes-prefetch-update.py |
| 9 | **`cronjob update`存在持久化同步bug** — API返回`success:true`但`~/.hermes/cron/jobs.json`可能未被更新。prompt/model/provider字段维持旧值，导致下次调度仍用旧模型重复失败。这是cron层面特有的问题（非配置文件层面）。 | ⚡ 每次`cronjob update`后必须通过`python3 -c "import json;d=json.load(open('/home/yestin/.hermes/cron/jobs.json'));print([j for j in d['jobs'] if j['id']=='<JOB_ID>'][0].get('model'))"`直接读文件验证字段是否实际写入。如果jobs.json仍是旧值，需要执行**第二次**`cronjob update`调用。 |
| 10 | **`zai/glm-4-flash`可能不稳定导致单cron空响应** — 即使其他使用同provider的cron都正常（它们通过不同slots调度），单个cron仍可能间歇性返回empty response。这不是脚本/服务故障。 | ⚡ 当某cron报empty response但其他`zai/glm-4-flash` cron正常时，切换至`deepseek/deepseek-v4-flash`作为稳定替代。验证：`hermes chat --provider deepseek -m deepseek-v4-flash -q "ping" -Q`。故障cron的prompt中增加`--oneshot`参数确保脚本输出可见。 |
| 11 | **`(No response generated)` ≠ `empty response`** — 前者是cron agent的LLM完全没产生输出(瞬态 Provider API 故障)，后者是工具返回了空数据(模型/凭证问题) | ⚡ 先看输出文件 `## Response` 段。如果是 `(No response generated)` → 直接运行脚本确认正常即可，无需修provider。间歇性出现(<3次/天)直接跳过，连续出现才切换模型。 |

### 场景: 健康监控脚本自身损坏 — 元级自愈 (health-alert-self-corruption)

**触发条件**: `SYSTEM_ALERT` 或健康告警触发时，脚本 `health-alert.sh` 自身无法执行。典型症状：当运行 `bash ~/scripts/health-alert.sh` 时，每一行都报 `1: command not found`、`2: command not found` 等语法错误。

**根因**: 脚本文件被注入了行号前缀（`    1|#!/bin/bash`），使 `#!/bin/bash` 不在文件偏移0位置 → shebang 被忽略 → bash 将 `    1|` 解释为命令 `1` → 全部报错。常见来源：write_file 工具从 read_file 格式输出中获取内容（包含行号前缀）并写入文件。

**诊断流程**:

```bash
# Step 1: 症状确认 — 运行脚本时每行都是 "N: command not found"
bash ~/scripts/health-alert.sh 2>&1 | head -5
# 输出: 1: command not found, 2: command not found, ...

# Step 2: 查看原始文件确认行号污染
head -3 ~/scripts/health-alert.sh | cat -A
# 正常:   #!/bin/bash$   ← 无行号
# 污染:   1|#!/bin/bash$  ← 每行前有 "    N|"

# Step 3: 修复 — 重写干净版本
# 从记忆/备份/已知正确版本重建。
# 注意: write_file 时确保传入的内容不含 read_file 行号前缀

# Step 4: 验证
bash -n ~/scripts/health-alert.sh && echo "SYNTAX OK"
bash ~/scripts/health-alert.sh  # 预期: "OK: 0 issues found" (或实际问题数)

# Step 5: 确认 cron 调度正常
hermes cron list 2>/dev/null | grep -A2 "Health Alert"
# 预期: last_status: ok
```

**关键教训**:

| # | 教训 | 规则 |
|---|------|------|
| 1 | 监控脚本自身可能损坏，且难以被自身发现 | ⚡ health-alert.sh 不可自检 — 它坏了就是盲区。需要会话级人工/AI巡检发现 |
| 2 | write_file 工具在部分读取后写入可能导致行号污染 | ⚡ 使用 write_file 前必须确保内容干净，尤其是 read_file 输出不能直接回写 |
| 3 | 监控脚本损坏 ≠ 系统故障 | ⚡ 先修脚本再修系统。不要因为 health-alert.sh 报错就认为系统有问题 |
| 4 | health-alert.sh v2.1 已在文件头标注版本号便于溯源 | ⚡ 所有运维脚本必须版本标注，便于判断文件是否被意外覆盖/损坏 |

---

### 场景: SYSTEM_AUTO_REPAIR 通知处理 — 自愈失败报告的验证 (auto-repair-notification)

**症状**: 收到 `SYSTEM_AUTO_REPAIR` 消息，包含 `✅ {某项修复成功}` + `❌ {某项自愈失败}`。最常见场景：记忆压缩成功但WebUI自愈失败。

**关键洞察**: 自愈失败报告 **不一定等于服务实际宕机**。WebUI可能已经由其他机制（如hermes-webui-autostart cron每3分钟巡检）自动恢复。需要**验证实际状态**而非盲目重启。

**关键洞察: Cron 可能已被自动替换** — 自愈系统检测到cron持续失败时，可能**自动删除旧cron并创建新cron**（不同job_id、不同模型/提供商）。不要默认旧cron仍然存在。

```bash
# Step 0: 检查cron是否已被自动替换
# 如果已知旧job_id但list中找不到 → 已被自愈系统删除
# 对比cron列表中的新cron → 模型/提供商可能已自动切换
# 常见模式: deepseek-v4-flash → z-ai/glm-4-flash (更便宜的可靠cron层模型)
hermes cron list | grep -E "(Bailongma|巡检|health check)"  # 找新cron的job_id
# 如果有新job_id出现且旧job_id消失 → 自动替换已发生
# 验证新cron: 检查model/provider是否更可靠
# 如果新cron尚未运行: 它将在下次调度时自动执行并置为ok
```

**诊断流程 (4步法)**:

**⚠ IPv6/IPv4 双栈陷阱**: `curl http://localhost` 默认先尝试 IPv6 (`::1`)，若服务仅监听 `0.0.0.0`（IPv4），IPv6 连接会返回 `Connection refused`，然后 curl 才降级到 IPv4 (`127.0.0.1`)。如果健康检查在降级完成前读取结果，会误判为 HTTP 000。**修复: 始终先用 `127.0.0.1` 验证，仅在 IPv4 也失败时才确认宕机。**

```bash
# Step 1: 独立验证所有服务 — 不依赖失败报告
for p in 8648 8050 8642 8080; do
  # 先试 127.0.0.1 (IPv4) 避免 ::1 (IPv6) 的连接拒绝误报
  code=$(curl -s -o /dev/null -w "%{http_code}" --connect-timeout 2 http://127.0.0.1:$p/ 2>/dev/null || echo "FAIL")
  # 如果 127.0.0.1 失败，再试 localhost (可能 IPv6-only 服务)
  [ "$code" = "FAIL" ] && code=$(curl -s -o /dev/null -w "%{http_code}" --connect-timeout 2 http://localhost:$p/ 2>/dev/null || echo "FAIL")
  echo "  Port $p: HTTP $code"
done

# Step 2: 检查进程和端口
ps aux | grep -E 'web-ui|app\.py|gateway' | grep -v grep | head -5
ss -tlnp | grep -E '8648|8050|8642|8080'

# Step 3: 检查最近告警日志确认故障模式
tail -5 ~/logs/health-alert.log          # 巡检日志
tail -5 ~/logs/health-alerts.jsonl       # 告警事件历史
grep -i "webui\|自愈\|重启失败\|宕机" ~/logs/health-alert.log 2>/dev/null

# Step 4: 记忆文件大小检查（自愈失败常伴随记忆膨胀）
wc -c ~/.hermes/memories/MEMORY.md ~/.hermes/memories/USER_PROFILE.md
# 如果>4KB: 需要压缩（合并§分隔的重复条目，保留核心事实）
# 如果<1KB: 压缩成功，无需额外操作
```

**决策树 (3分支)**:

```
自愈失败报告
    │
    ├─ ✅ 实际服务正常 → 瞬态故障已自动恢复
    │   → 记录+更新记忆，无需重启
    │
    ├─ ❌ 实际服务宕机 → 执行完整事故响应
    │   → 参考 gateway-dashboard-down 或 webui-down 场景
    │
    └─ ⚠️ 记忆膨胀+服务正常 → 仅记忆问题
        → 压缩记忆，检查 health-alert 是否误报
```

**4层根因分析 (RCA Pyramid)**:

| 层级 | 根因 | 证据 |
|------|------|------|
| 🅰 直接原因 | 自愈脚本某次执行失败 | SYSTEM_AUTO_REPAIR 消息❌ |
| 🅱 深层原因① | 瞬态端口冲突/进程重启竞争 | 之后其他cron已自动恢复 |
| 🅲 深层原因② | 健康告警触发顺序问题（health-alert.sh在前，hermes-webui-autostart在后） | 巡检时间戳显示间隔不足 |
| 🅳 深层原因③ | 自愈脚本无等待窗口 — `sleep 5` 对Node.js慢启动不够 | 慢启动需要轮询等待(最长30s) |

**关键教训**:

| # | 教训 | 规则 |
|---|------|------|
| 1 | 自愈失败报告不=服务宕机 | ⚡ 先独立验证所有服务端口HTTP响应，不轻信失败消息 |
| 2 | 多自愈脚本可能竞争修复 | ⚡ health-alert.sh(5min) + webui-autostart(3min) + svc.py heal 三路修复可能重叠冲突 |
| 3 | 记忆膨胀常与自愈失败伴生 | ⚡ 检查记忆大小是否是service fail的根因（而不是service本来没问题却报告了失败） |
| 4 | 慢启动服务需要轮询等待 | ⚡ 启动后固定sleep 5不够，需 for+curl 轮询最长30s |
| 5 | 自愈系统可能自动替换cron而非修复 | ⚡ cron失败后对比job_id是否已变；若已替换则验证新cron的model/provider是否更可靠；服务本身可能一直健康 |
| 6 | 告警阈值若过期会产生误报 | ⚡ 审计 health-alert.sh 中 check_gateway_leak 阈值是否与实际架构匹配 |
| 7 | **`cronjob run`可能在cron后端冗余时创建重复条目** | ⚡ 对cron运行`action='run'`后cron列表可能出现新job_id + 旧job_id并存。排查时先list确认无重复再操作 |
| 8 | **清理重复cron须用remove而非delete** | ⚡ 使用`cronjob(action='remove', job_id='<duplicate_id>')`删除多余cron。如果误删了原cron，需重新`cronjob(action='create', ...)`恢复 |
| 8b | **⚠️ 重复cron删除级联陷阱 (cascade-deletion)** — 当多个cron job共享相同的**名称/Name**字段时（如`ACI预热缓存更新（每15分钟）`），删除其中任意一个可能导致**所有同名cron被级联删除**，包括原本健康的那个 | ⚡ 删除重复cron前必须：① `hermes cron list` 检查同名cron的数量和job_id；② **先将健康的job rename为不同名称**再删除其他副本，或者一次删除所有同名cron后再重建唯一的一个；③ 删除后立即 `hermes cron list` 确认健康cron未被误删；④ 如果发现级联删除: 立即从记忆/输出日志中提取原先的prompt内容，用 `cronjob(action='create', ...)` 重建 |
| 9 | **残留告警信号 ≠ 当前系统故障** | ⚡ health-alert可能捕获了已自愈的瞬态错误（如脚本补丁刚应用完）。先验证所有服务+直接跑cron脚本确认 |
| 9b | **👻 陈旧告警延迟交付 — 异步通知通道的版本滞后 (stale-alert-delivery)** | ⚡ health-alert.sh 使用 `&` 后台或 `cmmi5-chat-router.py` 异步发送告警。当脚本从 vN 升级到 vN+1 时，**旧版脚本已在运行的告警检测循环**仍会产生符合旧版阈值的告警输出，并通过异步通道延迟交付。特征: 告警消息中的版本号(~v2.3) 低于当前脚本版本号(~v2.4); 立即运行 health-alert.sh 返回 0 issues; 告警时间戳接近但早于脚本部署时间; 无新告警持续产生。反向诊断: `tail -3 ~/logs/health-alert.log` 确认最近巡检报 0 issues; `ps aux | grep '[h]ealth-alert\|[c]mmi5-chat-router'` 确认无旧版脚本的残余进程。修复: 脚本升级后立即 `pkill -f 'health-alert.sh\|cmmi5-chat-router.py.*SYSTEM_ALERT'` 清理旧版进程，阻断陈旧告警管道。 |
| 10 | **亡灵👻执行：已移除的cron仍可能执行最后一次** | ⚡ 当一个cron被`cronjob remove`从活跃列表移除后，调度器可能仍保留了一个已入队的执行slot。该"亡灵执行"会触发生成`(No response generated)` → 触发error标志 → 告警。诊断方法A: 对比`hermes cron list`中的job_id列表与`~/.hermes/cron/output/`下的目录，寻找list中不存在但output中最近时间戳出现的旧job_id。诊断方法B (更直接): 扫描`~/.hermes/logs/agent.log`中的`ERROR [cron_<OLD_JOB_ID>_<timestamp>]`行——即使job已从列表中删除，agent.log仍保留完整的执行记录，包含具体错误码和消息。交叉验证: agent.log有ERROR行+cron list无此job_id=亡灵执行。如找到，这是瞬态告警，无需额外修复，验证新cron已就绪即可。 |

**验证清单**:

```bash
# 全服务验证
echo "WebUI:     $(curl -s -o /dev/null -w '%{http_code}' http://localhost:8648/)"  # 200
echo "Dashboard: $(curl -s -o /dev/null -w '%{http_code}' http://localhost:8050/)"  # 200
echo "Gateway:   $(curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:8642/health)" # 200
echo "BookStack: $(curl -s -o /dev/null -w '%{http_code}' http://localhost:8080/)"  # 302

# 记忆验证
wc -c ~/.hermes/memories/MEMORY.md  # < 4000

# 告警确认
bash ~/scripts/health-alert.sh | grep "issues"  # "OK: 0 issues found"
```

### 场景: 告警阈值审计 — 架构变更后的阈值漂移修复 (alert-threshold-audit)

**触发条件**: 系统架构变更（新增Agent/服务/迁移端口/从单进程迁移到多Profile）后，health-alert.sh/unified-health-check.py/anti-degradation.sh 等告警脚本产生误报，或自愈失败报告（SYSTEM_AUTO_REPAIR ❌）与实际情况不符。

**架构范式变更特殊提示**: 当系统从多进程架构变为单进程+多Profile时（例如从"单Gateway"变为"1主+11Profile Gateway"），健康检查的检测逻辑需要完全重写而非简单调整阈值数字。以下是已验证通过的 **v2.4动态检测模式**:

```bash
# ✅ v2.6: 精确计数 — 按标志分类检测 + 动态读取预期Profile数
# ⚠️ 关键陷阱: 实际进程命令行参数顺序为 `hermes --profile arch gateway run --replace`
#    grep 'gateway run --profile' 不匹配(profile在gateway run之前)！
#    grep 'gateway run --replace' 匹配全部12个(所有Gateway都带--replace)！
check_gateway_leak() {
    local profile_dir="$HERMES/profiles"
    # 动态检测: 从目录读取预期Profile数，不硬编码
    local expected_profiles=0
    [ -d "$profile_dir" ] && expected_profiles=$(ls -d "$profile_dir"/*/ 2>/dev/null | wc -l)
    [ "$expected_profiles" -lt 1 ] && expected_profiles=11  # fallback

    # 精确计数: 按启动标志分类，避免通用grep误匹配
    # v2.6修复: Profile Gateway参数顺序是--profile先于gateway run，且所有Gateway都带--replace
    # 主Gateway: grep --replace + grep -v --profile 排除Profile Gateway
    local main_gw=$(ps aux | grep 'gateway run --replace' | grep -v grep | grep -v -- '--profile' | wc -l)
    # Profile Gateway: 直接用 --profile 标志匹配（不管参数位置）
    local profile_gw=$(ps aux | grep -- '--profile' | grep -v grep | wc -l)

    # 分类告警: 主GW异常 vs Profile异常分开报告
    if [ "$main_gw" -eq 0 ]; then
        # P0: 主Gateway宕机 — 服务完全不可用
        ALERTS="${ALERTS}❌ 主Gateway宕机: 0个进程(应有1个)\\\n"
    elif [ "$main_gw" -gt 1 ]; then
        # P1: 主Gateway重复 — 可能有--replace未生效
        ALERTS="${ALERTS}⚠️ 主Gateway重复: ${main_gw}个(应有1个)\\\n"
    fi

    if [ "$profile_gw" -lt "$expected_profiles" ]; then
        # P1: Profile不足 — 可能启动延迟或崩溃
        local missing=$((expected_profiles - profile_gw))
        ALERTS="${ALERTS}⚠️ Profile Gateway缺失: ${profile_gw}个(应有${expected_profiles}个, 缺失${missing}个)\\\n"
    elif [ "$profile_gw" -gt "$expected_profiles" ]; then
        # P1: Profile溢出 — 可能有泄漏
        local extra=$((profile_gw - expected_profiles))
        ALERTS="${ALERTS}⚠️ Profile Gateway泄漏: ${profile_gw}个(正常${expected_profiles}个, 多${extra}个)\\\n"
    fi
}
```

**关键改进点对比**:

| 维度 | v2.3(旧) | v2.4(新) |
|------|----------|----------|
| 主GW检测 | 通用grep匹配 | `--replace`标志精确匹配 — 无歧义 |
| Profile检测 | 固定阈值>10 | `--profile`标志匹配 + 目录动态读取（当前11个） |
| 泄漏阈值 | >10触发（假警报） | 与实际Profile计数精确比较 |
| 架构适应 | 手动修改阈值 | 自动检测，架构变化后无需修改脚本 |
| 误报风险 | 高（不停假警报） | 零（精确匹配） |

**典型症状矩阵**:

| 误报类型 | 表现 | 根因 | 修复 |
|----------|------|------|------|
| Gateway进程数误报 | `⚠️ Gateway泄漏`但实际正常 | 阈值设≤14，但CMMI5架构有12进程(1主+11Agent) | 阈值上调至≤20或≤25 |
| 架构范式变更误报 🆕 | `⚠️ Agent不完整: 1个(正常12)` | 架构从12进程(1主+11Agent)变为单Gateway+chat-router角色切换，健康检查仍按旧架构检测 | 移除旧进程数预期，改为0=宕机, 1=正常, >10=泄漏 |
| Agent不足误报 | `⚠️ Agent不完整` | 阈值设<12但Agent启动有延迟 | 阈值下调至<10 |
| WebUI修复失败 | `❌ WebUI自愈失败`但实际HTTP 200 | 修复命令太重量级(全重启)或检查的端口错误 | 轻量级重启+正确端口 |
| 端口检查失误 | 健康检查报告❌但服务实际运行 | 脚本硬编码端口过时(5000→8050) | 端口常量与实际对齐 |

**审计流程 (5步法)**:

```bash
# Step 1: 发现所有健康检查/自愈脚本
# 系统至少有这些脚本可能包含硬编码阈值/端口:
scripts=(
  ~/scripts/health-alert.sh          # 告警阈值(进程数/端口/磁盘)
  ~/scripts/unified-health-check.py  # 服务修复命令+端口
  ~/scripts/anti-degradation.sh      # 自愈阈值
  ~/scripts/hermes-svc.py            # 端口常量
  ~/.hermes/healer/monitor.py        # healer探针阈值
  ~/.hermes/healer/gateway_health.py # gateway专用检测
)
for s in "${scripts[@]}"; do
  [ -f "$s" ] && echo "FOUND: $s ($(wc -l < "$s") lines)"
done

# Step 2: 提取所有硬编码的数字/端口/路径阈值
grep -nE 'gt |lt |== |port |PORT|[0-9]{4,5}' ~/scripts/health-alert.sh | grep -vE '^[0-9]+:(\s*#|$)' | head -20
grep -nE 'port:? ?[0-9]|PORT ?= ?[0-9]' ~/scripts/unified-health-check.py | head -20
grep -nE '= ?[0-9]{4}' ~/scripts/hermes-svc.py

# Step 3: 对照实际状态验证每个阈值
# 实际Gateway进程数:
actual_gw=$(ps aux | grep 'hermes.*gateway' | grep -v grep | grep -v cmmi5 | wc -l)
echo "实际Gateway进程: $actual_gw"
# 实际服务端口:
ss -tlnp | grep -E '8050|8648|8642|8080|4000'
# 实际进程数:
ps aux | grep -E 'app\.py|web-ui|gateway' | grep -v grep | wc -l

# Step 4: 分类阈值漂移
# A. 架构变更型: 旧架构2GW→新架构12GW, 阈值需要>20(溢出)/<10(不足)
# B. 端口漂移型: 5000→8050, 8688→8648
# C. 修复策略型: 全重启→轻量级重启
# D. Cron提示漂移: 检查端口名不对

# Step 5: 修复 (阈值上调原则: 留安全缓冲, 不紧不松)
# Gateway: 正常12 → 溢出>20(留8个缓冲), 不足<10(允许Agent启动延迟)
# WebUI: 修复命令为轻量级node直接启动, 非hermes-svc.py全重启
# 端口: 以ss -tlnp为准, 更新所有脚本中的硬编码常量
```

**阈值设计原则**:

| 原则 | 说明 | 示例 |
|------|------|------|
| 安全缓冲 | 阈值=正常值×1.5~2倍 | Gateway: 正常12, 溢出>20(非>14) |
| 启动延迟容忍 | 允许服务启动时的短暂不足 | Agent: 正常12, 不足<10(非<12) |
| 以实际架构为准 | 非假设值 | 先 `ps aux \| grep` 数实际进程数 |
| 修复轻量化 | 宕机修复尽量只修故障组件 | WebUI修复用node直接启动, 不碰Gateway/Dashboard |

**关键教训**:

| # | 教训 | 规则 |
|---|------|------|
| 1 | 架构变更后告警阈值不会自动更新 | ⚡ CMMI5 Agent新增/服务迁移后立即审计所有健康脚本 |
| 2 | 阈值过紧=误报, 过松=漏报 | ⚡ 留1.5~2倍缓冲, 以实际进程数×1.5为准 |
| 3 | 修复策略比检测更重要 | ⚡ 宕机修复用轻量级操作而非全服务重启 |
| 4 | 健康脚本散落在多个位置 | ⚡ 维护一个"所有健康脚本清单"并随新脚本更新 |
| 5 | Cron提示也可能引入错误 | ⚡ Cron的prompt也可能含过时端口/路径, 同属阈值审计范围 |
| 6 | **架构范式变更 > 阈值数字调整** — 当系统从多进程架构(12个独立gateway进程)变为单进程+chat-router时，健康检查的整个检测逻辑(计进程数)已不再适用。不是调整阈值数字，而是需要**重写检测逻辑**。 | ⚡ 架构变更后检查健康脚本的检测逻辑是否仍适用：不仅仅是阈值数字，还包括ps aux grep模式、预期进程数范围、告警条件等。根本思路：检测项必须匹配架构范式，而非微调旧阈值。 |
| 6b | **版本标签漂移陷阱 — 脚本版本号已更新但底层检测逻辑未同步** | ⚡ `health-alert.sh` v2.3的Header版本号已从v1.0更新，但`check_gateway_leak()`函数体仍使用旧阈值(old: `all_gw -lt 10 → 不完整(正常12)`)。这导致告警消息中外显版本号(v2.3)与其实际检测逻辑(v1.0行为)不匹配，给诊断者造成极大的困惑。**修复必须同原子化绑定三者：header版本号 + 检测逻辑 + cron任务名。** 推荐做法：修改检测逻辑前首先同步更新版本号，或者在单次修改中同时更新两者。检查清单：{header版本号, check_gateway_leak阈值, check_cron_errors正则, check_disk阈值, check_memory_growth阈值} 五者是否一致。 |
| 6c | **重复假警报陷阱 — 同一类误报反复出现说明阈值调整治标不治本** | ⚡ Gateway假警报在v1.0→v2.3→v2.4共出现3次。前两次只调整了阈值数字(≤2→≤10)，未从根本上将硬编码阈值改为动态检测。**当同一类假警报出现≥2次后，必须从"调数字"升级为"改检测方式"** ——用目录动态扫描+标志精确匹配替代固定阈值。判断标准：如果下次架构扩展(新增第12个Profile)会导致第4次假警报，说明当前修复仍是治标。 |
| 7 | **自愈脚本端口错配 → cron状态污染 → 健康告警级联误报** | ⚡ 自愈脚本(gateway-autoheal.sh)中的端口映射如果与实际不符，会：①每2分钟检查错误端口→全部响应000→错误报告"FAIL"→②hermes cron list标记last_status="fail"→③health-alert.sh的check_cron_errors()检测到非ok状态→④发出"Cron错误"告警。诊断线索：一个cron持续输出"FAIL"字样(是其正常修复信号)但hermes cron list显示非ok状态。修复：将自愈脚本端口映射与实际`ss -tlnp`监听端口对齐。 |

--- 

### 场景: Hermes Gateway & Dashboard 宕机恢复 (gateway-dashboard-down)

**症状**: `hermes-svc.py status` 显示 Gateway [❌] / Dashboard [❌] 或 curl 返回 000。

**根因分类**:

| 服务 | 常见宕机根因 |
|------|-------------|
| Gateway (8642) | 进程崩溃、用错 CLI 语法 (`--port` 不存在)、配置文件缺失 |
| Dashboard (5000) | 进程被杀、重复进程冲突、Port busy |
| BookStack (8080) | 仅做参考(自愈cron每5min恢复) |

**诊断流程 (5步法)**:

```bash
# Step 1: 服务状态确认
python3 ~/scripts/hermes-svc.py status
# 输出: Web UI [❌/✅] Dashboard [❌/✅] Gateway [❌/✅]

# Step 2: 先洁再启 — 杀掉重复/僵尸进程
python3 ~/scripts/hermes-svc.py heal
# 修复重复进程/死锁后，查看清理结果

# Step 3: 启动Gateway (关键: 语法陷阱)
# ❌ 错误: npx hermes gateway --port 8642
#    → "invalid choice: '8642'" — --port 参数不存在
# ✅ 正确: cd ~/.hermes && npx hermes gateway run
#    端口从 config.yaml 的 platforms.api_server.port: 8642 读取
#    必须使用 terminal(background=true) 启动
#    启动后 3-5s 才能响应健康检查

# Step 4: 启动Dashboard (必须用background模式)
# ✅ 正确: terminal(background=true) 启动:
#    cd ~/projects/hermes-dashboard && python3 app.py
# ❌ 错误: 使用 & 后台 — 被沙箱拦截或进程追踪丢失

# Step 5: 统一验证
sleep 3
curl -s -o /dev/null -w "%{http_code}" http://localhost:8642/health  # Gateway: 200
curl -s -o /dev/null -w "%{http_code}" http://localhost:5000/        # Dashboard: 200
curl -s -o /dev/null -w "%{http_code}" http://localhost:8080/        # BookStack: 302
```

**关键教训** (必须编码到技能)：

| # | 教训 | 规则 |
|---|------|------|
| 1 | `hermes gateway --port` 不存在 | ⚡ 必须用 `hermes gateway run`，端口从 config.yaml 读取 |
| 2 | Dashboard 用 `&` 后台会被沙箱拦截 | ⚡ 必须用 `terminal(background=true)` Hermes 接口 |
| 3 | 重启前必须先 heal 杀重复进程 | ⚡ 先 `hermes-svc.py heal` 再启动，否则端口冲突 |
| 4 | Gateway 启动后需要 3-5s 预热 | ⚡ 预热完成后才能收到 200 响应 |
| 5 | 验证必须涵盖全部 3 个核心服务 | ⚡ Gateway(8642)/Dash(8050)/BS(8080) 三端口全检 |

---

### 场景: Zombie Profile Gateway — 进程存活但HTTP无响应 (zombie-gateway-process)

**触发条件**: health-alert 报告 Profile Gateway 缺失（N/11），但 `ps` 显示对应 PID 存活（Sl 或 Ss 状态）。`curl` 返回 HTTP 000（connection refused）或完全空响应。存在两种变体：

**变体A — 端口LISTEN但HTTP死锁**: `ss -tlnp` 显示目标端口仍在 LISTEN 状态，但 `curl` 返回 000（服务进程内部 HTTP server 死锁/冻结，socket残留但无响应）
**变体B — 端口不LISTEN的幽灵进程**: `ss -tlnp` 无该端口记录，但 `ps` 显示进程存活（进程TCP线程已崩溃，主线程/父进程悬空）

**经典症状**:
- `health-alert.sh` 输出 `⚠️ Profile Gateway缺失: 10个(应有11个, 缺失1个)`
- **变体A**: `ss -tlnp | grep :PORT` 显示端口在 LISTEN，有 PID；`ps -p PID` 显示进程存活；但 `curl http://127.0.0.1:PORT/health` 返回 HTTP 000（连接被拒绝）
- **变体B**: `ss -tlnp | grep :PORT` 显示空（无监听）；但 `ps aux | grep 'gateway.*--profile pm'` 显示 PID 存活（Sl 状态）；`curl -sv http://127.0.0.1:PORT/health` 返回 "Connection refused"
- 再次检查时 `ss` 的 PID 可能已经变化（autohealer 介入杀掉了旧进程并重启）
- 端口未释放（变体A）或端口已释放但进程残留（变体B）

**根因分析**:
| 可能根因 | 诊断线索 |
|----------|----------|
| 进程内部 deadlock/freeze | PID 存活时间>预期但无 CPU 活动（`ps -p PID -o %cpu` ≈ 0） |
| 孤儿进程信号传播 | gateway.lock PID 不匹配，进程收到 SIGTERM 但内核保留了端口 |
| Python 子解释器崩溃 | 主线程死锁，Python GIL 死锁 |
| 旧进程句柄泄漏 | 端口由关闭的 fd 持有但仍在 LISTEN 状态 |

**诊断流程 (4步法) — 需同时覆盖变体A和变体B**:
```bash
# Step 1: 双重印证 — 同时查 ps 和 ss，对比结果
# 变体A: ss 有端口 + curl 000 → HTTP server 死锁
# 变体B: ps 有进程 + ss 无端口 → TCP 线程已崩溃
PID_PS=$(ps aux | grep "gateway run --profile <profile>" | grep -v grep | awk '{print $2}')
PID_SS=$(ss -tlnp "sport = :PORT" 2>/dev/null | grep -oP 'pid=\K[0-9]+' | head -1)

echo "ps PID: ${PID_PS:-NONE}  |  ss PID: ${PID_SS:-NONE}"

if [ -n "$PID_PS" ] && [ -z "$PID_SS" ]; then
    echo "⚠️ 变体B检测: PID=$PID_PS 存活但端口无监听 → 幽灵进程"
elif [ -n "$PID_PS" ] && [ -n "$PID_SS" ] && [ "$PID_PS" != "$PID_SS" ]; then
    echo "⚠️ PID竞态: ps=$PID_PS vs ss=$PID_SS → autohealer已介入重启"
fi

# Step 2: 确认僵尸态 — 对比进程状态 vs HTTP响应
PID="${PID_SS:-$PID_PS}"  # 优先用ss的PID（若是变体A），否则用ps的PID（变体B）
if [ -n "$PID" ] && [ -d "/proc/$PID" ]; then
    CPU=$(ps -p "$PID" -o %cpu --no-headers 2>/dev/null || echo "?")
    HTTP=$(curl -s -o /dev/null -w "%{http_code}" --max-time 3 "http://127.0.0.1:PORT/health" 2>/dev/null || echo "000")
    echo "PID=$PID alive, CPU=${CPU}%, HTTP=$HTTP"
    # 如果 HTTP=000 且 PID存活 → 僵尸进程（变体A或B）
fi

# Step 3: 跟踪PID变更 — 判断autohealer是否已介入
# 第一次检查的PID vs 第二次检查的PID → 不同说明autohealer已重启

# Step 4: 等待+重试 — 区分 僵尸态 vs 预热态
for i in 1 2 3; do
    sleep 2
    HTTP=$(curl -s -o /dev/null -w "%{http_code}" --max-time 2 "http://127.0.0.1:PORT/health" 2>/dev/null || echo "000")
    if [ "$HTTP" = "200" ]; then
        echo "✅ 第${i}次重试: HTTP 200 — 已恢复（预热完成）"
        break
    fi
done
```

**autohealer 修复路径**:
gateway-autoheal.sh 的 `restart_one()` 函数通过以下方式处理僵尸进程：
1. `ss -tlnp` 检测端口 → 获取 PID
2. `curl` 健康检查 → 发现 HTTP 000（非 200）
3. `kill -9 PID` 强行杀死僵尸进程
4. 删除 `gateway.lock` 和 `auth.lock` 防止 PID 复用竞赛
5. 重启新进程（带 OOM 保护 `echo -500 > /proc/self/oom_score_adj`）
6. sleep 4 等待预热
7. curl 验证 HTTP 200

**关键教训**:
| # | 教训 | 规则 |
|---|------|------|
| 1 | 进程存活 + 端口LISTEN ≠ 服务健康 | ⚡ 永远用 HTTP 健康检查（curl + HTTP 200）验证，而非仅看进程和端口存在性 |
| 2 | zombie进程的PID可能在两次检查间变化 | ⚡ autohealer检测到HTTP 000后会杀旧进程开新进程，PID会变更。第一次检查发现有PID但HTTP 000，第二次检查PID已变且可能仍是000（预热中）。两次检查的PID不同 → autohealer已介入 |
| 3 | 预热窗口可能导致误判 | ⚡ 进程刚启动的1-3秒内HTTP可能返回000。等待2-3秒重试可区分"预热"vs"僵尸" |
| 4 | 端口LISTEN但服务死亡 → 最易被忽视的故障模式 | ⚡ `ss -tlnp` 显示端口在监听时，人类容易误判为服务正常。必须强制always curl验证 |
| 5 | **幽灵进程变体B: PID存活但端口不LISTEN** — `ps aux` 有进程 (`Sl`状态) 但 `ss -tlnp` 无该端口，curl 返回空响应（非 HTTP 000，直接白屏） | ⚡ 诊断时必须同时查 `ps aux | grep 'gateway.*--profile NAME'` 检查进程是否存在，**无论 `ss -tlnp` 是否显示端口**。端口LISTEN的变体A + 端口不LISTEN的变体B是僵尸网关的两个互补形态，同时走两条检测线。修复命令：`kill $PID_PS; cd ~/.hermes && nohup python3 -m hermes_cli.main gateway run --profile NAME > /dev/null 2>&1 &` |

---

### 场景: OOM Killer 事故 — 关键进程被内存不足杀死 (oom-killer-incident)

**触发条件**: 收到 `SYSTEM_ALERT` 报告 Profile Gateway 全部缺失 / 多个服务同时崩溃，诊断发现 `dmesg` 中有 `Out of memory: Killed process` 记录。特征: 轻量级进程（如 Profile Gateway）在系统内存紧张时被 OOM killer 优先杀死，而内存"重罪犯"（如 Node.js test runner）存活。

**经典症状**:
- health-alert.log 显示从全绿("0 issues")骤变为多个服务失联
- `ps aux` 发现全部 Profile Gateway 消失 (0/11)，仅剩主Gateway
- `dmesg | grep -i "killed process"` 显示 OOM killer 事件
- `free -m` 显示 `available` 低于 1GB
- 典型触发器: vitest/node 进程消耗 1.4GB+ RSS

**诊断流程 (4步法)**:

```bash
# Step 0: 确认OOM事件 — 核心证据
dmesg | grep -i "Out of memory"
# 输出: [timestamp] Out of memory: Killed process PID (process name) total-vm:XkB anon-rss:XkB
# 记录: 进程名、PID、消耗内存、触发时间

# Step 1: 确认服务崩溃范围
echo "=== 主Gateway ==="
curl -s -o /dev/null -w "%{http_code}" --connect-timeout 3 http://127.0.0.1:8642/v1/health
echo ""
echo "=== Profile Gateway ==="
total=0; ok=0
for p in arch cm dev doc pm qa req sec spi test yestin; do
  port=$(grep -oP 'port:\s*\K\d+' ~/.hermes/profiles/$p/config.yaml 2>/dev/null | head -3 | tail -1)
  code=$(curl -s -o /dev/null -w "%{http_code}" --connect-timeout 3 "http://127.0.0.1:$port/health" 2>/dev/null || echo "000")
  total=$((total+1))
  if [ "$code" = "200" ]; then ok=$((ok+1)); fi
  echo "  $p :$port → HTTP $code"
done
echo "总览: ✅ $ok / ❌ $((total-ok)) / 总计: $total"

# Step 2: 检查自动恢复机制是否生效
cat /tmp/gateway-autoheal-$(date +%Y%m%d).log 2>/dev/null | tail -10
# 寻找: DEAD → Restarting → RECOVERED 或 FAILED 模式

# Step 3: 检查内存状态 — 确认压力是否持续
free -h
echo ""
ps aux --sort=-%mem | head -8
# 如果可用内存仍 <500MB: 需要立即释放内存
# 如果可用内存 >2GB: OOM压力已缓解
```

**根因决策树**:\n\n**⚠️ 关键鉴别诊断 — 先验 dmesg 时间戳**: 当收到告警时 Profile Gateway 全部消失，第一步不是假定 OOM 是根因，而是检查 **dmesg 时间戳 vs 告警时间戳** 是否对齐。OOM事件可能在Gateway恢复之后才发生（分离事件），而非根因。\n\n```bash\n# 关键鉴别命令 — 看时间戳是否对齐\ndmesg -T 2>/dev/null | grep -i \"Out of memory\"\n# OOM时间: [Mon May 18 00:27:42 2026]\n# 告警时间: 2026-05-17T23:53:03+08:00\n# → 如果 OOM 发生在告警 30+ 分钟后 → 分离事件，OOM不是根因\n#\n# 检查主Gateway重启时间 (--replace)\nps -p $(ss -tlnp | grep ':8642' | grep -oP 'pid=\\K[0-9]+') -o lstart --no-headers 2>/dev/null\n# START时间: \"Mon May 17 23:49:...\" \n# → 如果接近告警时间(23:53)，根因是 --replace 重启导致的级联杀死\n```\n\n```\nProfile Gateway全部消失 + dmesg有OOM记录\n    │\n    ├─ [新分支] dmesg OOM时间 > 告警时间 +30min 且 主Gateway重启时间接近告警时间\n    │   → **两件事无关！** 根因是 `gateway run --replace` 重启导致的级联杀死\n    │   → 主Gateway(--replace)在graceful drain阶段发送SIGTERM给所有子Profile Gateway\n    │   → autoheal会自动恢复(通常2-5分钟内10/11), 个别Profile(QA)可能延迟\n    │   → OOM杀vitest是30分钟后的分离并发事件，与本次故障无关\n    │   → 处理: 验证autoheal已恢复全部11个即可，无需修复\n    │\n    ├─ dmesg OOM时间 ≈ 告警时间 (±5min)\n    │   ├─ OOM杀死了vitest(test runner) + Gateway进程\n    │   │   → test runner是内存消耗大户(~1.4GB), Gateway是轻量级受害者\n    │   │   → 无配置问题，只需加固OOM保护\n    │   │\n    │   ├─ OOM杀死了mysql/mariadb\n    │   │   → 数据库重启可能导致数据丢失\n    │   │   → 需恢复DB + 检查事务完整性\n    │   │\n    │   ├─ 内存泄漏导致OOM反复触发\n    │   │   → 先释放内存(free + kill 泄漏进程)\n    │   │   → 再恢复服务\n    │   │\n    │   └─ OOM唯一受害者 = Gateway进程(其他都正常)\n    │       → OOM分数问题: Gateway进程的 oom_score_adj 默认0\n    │       → 加固: 降低至 -500 (更不易被kill)\n    │\n    └─ dmesg无OOM记录\n        → 根因是 `gateway run --replace` 重启级联杀死（最可能）\n        → `--replace` 设计行为 —— 主Gateway替换时graceful drain会杀子进程\n        → pending cron里的 health-alert 是有效的(告警了真实问题)，但系统已自愈\n        → 处理: 验证全部已恢复, 若QA Gateway延迟了则记录为已知特性\n```

**修复流程 (4步)**:

```bash
# Step 1: 确认所有Profile已自动恢复 (autoheal每2分钟)
# 如果不是所有都已恢复，手动启动缺失的:
for profile in arch cm dev doc pm qa req sec spi test yestin; do
  port=$(grep -oP 'port:\s*\K\d+' ~/.hermes/profiles/$profile/config.yaml 2>/dev/null | head -3 | tail -1)
  code=$(curl -s -o /dev/null -w "%{http_code}" --connect-timeout 3 "http://127.0.0.1:$port/health" 2>/dev/null || echo "000")
  if [ "$code" != "200" ]; then
    echo "⚠️ $profile($port) DOWN, restarting..."
    cd ~/.hermes && nohup .venv/bin/hermes gateway run --profile "$profile" > /dev/null 2>&1 &
    sleep 4
    code2=$(curl -s -o /dev/null -w "%{http_code}" --connect-timeout 3 "http://127.0.0.1:$port/health" 2>/dev/null || echo "000")
    echo "   → HTTP $code2 $([ "$code2" = "200" ] && echo '✅' || echo '❌')"
  fi
done

# Step 2: 加固 OOM 保护 — 修改 autoheal 启动命令，子进程自设 oom_score_adj
# 在 restart_one() 函数中，将启动命令改为 bash -c 包装:
# 原: nohup "VENV/hermes" gateway run ...
# 改: nohup bash -c 'echo -500 > /proc/self/oom_score_adj && exec "VENV/hermes" gateway run ...'
cat >> ~/scripts/gateway-autoheal.sh << 'OOM_PATCH'
# 修改 restart_one() 中的启动行:
# 从: cd "$HERMES" && nohup "$VENV/hermes" gateway run --profile "$profile" ...
# 到: cd "$HERMES" && nohup bash -c 'echo -500 > /proc/self/oom_score_adj 2>/dev/null; exec "'"$VENV/hermes"'" gateway run --profile "'"$profile"'"' ...
OOM_PATCH

# Step 3: 如当前有内存压力，释放内存
# 找出内存消耗最大的非关键进程:
ps aux --sort=-%mem | head -5 | awk '{print $2, $4"%", $11}'
# 释放PageCache (安全，始终可做):
sync && echo 3 > /proc/sys/vm/drop_caches 2>/dev/null || echo "drop_caches not available"

# Step 4: 验证全集群恢复
bash ~/scripts/health-alert.sh 2>&1
# 预期: "OK: 0 issues found"
```

**4层根因分析 (RCA Pyramid)**:

| 层级 | 根因 | 证据 |
|------|------|------|
| 🅰 直接原因 | OOM Killer 杀死全部 11 个 Profile Gateway 进程 | `dmesg: Out of memory: Killed process X (node (vitest 2))` |
| 🅱 深层原因① | vitest Node.js 进程消耗 ~1.4GB RSS (~10.8GB VM)，系统内存耗尽 | `ps aux: vitest 2 占用 10.8GB VM / 1.4GB RSS`，`free -m: available < 500MB` |
| 🅲 深层原因② | Profile Gateway 无 OOM 保护 (oom_score_adj=0)，OOM killer 优先杀轻量级进程而非内存"重罪犯" | `cat /proc/{gw_pid}/oom_score_adj → 0` |
| 🅳 深层原因③ | 无内存压力预警机制，OOM 触发前无告警 | health-alert 不监控系统内存使用率 |

**关键教训**:

| # | 教训 | 规则 |
|---|------|------|
| 1 | OOM killer 优先杀轻量级进程而非内存"重罪犯" | ⚡ 关键服务进程必须设置 oom_score_adj=-500 (负值=不易被kill) |
| 2 | OOM 时 auto-heal 可能恢复不全（时序竞态） | ⚡ 恢复后必须验证 11/11 Profile 全部在线，检查 auto-heal log 确认无遗漏 |
| 3 | 恢复时序: OOM → autoheal 2min内恢复 → health-alert 5min才发现 → 告警时已部分恢复 | ⚡ 告警消息的"0个Profile"可能已过时，验证时必须实时检查 |
| 4 | vitest/Node.js test runner 是常见 OOM 触发器 | ⚡ 内存密集型非关键进程应设置 oom_score_adj=+500 (优先被杀) |
| 9 | **WebUI是OOM后最容易被遗忘的服务** — Gateway有AutoHeal每2分钟巡检自动恢复，但WebUI(8648)无独立自愈机制。OOM后Gateway恢复但WebUI可能离线20+分钟无人发现。health-alert.sh虽有WebUI自愈逻辑但在Gateway告警突出时可能被掩盖(告警消息只显示首个issue) | ⚡ OOM恢复后不做假设所有服务已恢复——必须显式验证WebUI(8648)+Dashboard(8050)+BookStack(8080)全部HTTP 200。Post-OOM验证检查表必须包含全部4项: Gateway(8642)+11×Profile(8643-8654)+WebUI(8648)+Dashboard(8050)+BookStack(8080)。考虑为WebUI增加独立自愈cron |
| 6 | **OOM时间戳必须与告警时间对齐才能确定因果关系** — 本系统中OOM可能杀死vitest进程而Gateway完全不受影响(分离事件)。不要看到dmesg有OOM就认定Gateway被OOM杀了 | ⚡ 检查 dmesg -T OOM时间 vs 告警时间。如果差距>5分钟且主Gateway重启时间接近告警时间，根因是 `--replace` 重启级联而非OOM |\n| 7 | 无内存监控=OOM盲区 | ⚡ health-alert 增加内存检查项: `free -m | awk '$NF<500{print \"LOW MEM\"}'` |
| 6 | **Post-OOM二次崩溃模式** — autoheal恢复全部Profile后，个别Profile可能在3分钟内再次崩溃 | ⚡ 原因: ① 被OOM杀死时正在处理长任务(drain 120s超时); ② PID lock gateway.lock在kill -9后未清除，重启时产生"Another gateway instance already running"竞争; ③ PID复用(旧PID被kill -9后系统分配相同PID给新进程)导致lock file校验失败。**诊断**: 检查重启后3-5分钟的gateway.log, 寻找"drain timed out after 120s"和"Shutdown diagnostic"模式。**修复**: 重启后间+1轮autoheal间隔(2min)再验证, 如果二次崩溃则额外kill残留lock file再启动。 |
| 7 | **autoheal的kill -9 + restart可能触发gateway.lock PID竞赛** — 当gateway.lock中的PID与重启后的新进程PID相同时(OS重用), 新进程读到旧lock文件认为\"已有实例运行\" | ⚡ autoheal的restart_one()在kill -9后必须同时删除`~/.hermes/profiles/<profile>/gateway.lock`和`~/.hermes/profiles/<profile>/auth.lock`, 然后再sleep 1+启动。修复验证: 重启后检查`cat gateway.lock`的PID与`ps aux`的PID一致。 |
| 8 | **SIGKILL后的优雅关闭(graceful shutdown)是误导信号** — 被autoheal kill -9的进程可能因为操作系统的信号队列延迟或cgroup传播机制, 在新的派生进程上以SIGTERM/优雅关闭的形式出现 | ⚡ 不要被gateway.log中的"Stopping gateway... Sent shutdown notification to feishu"误导——这可能是旧进程的取消信号在进程树中传播。验证方法: 确认dmesg中OOM事件的精确时间戳, 比较gateway.shutdown时间戳和autoheal的kill -9时间戳。如果shutdown在kill之后, 则是信号传播而非自发性退出。 |

| 层级 | 根因 | 证据 |
|------|------|------|
| 🅰 直接原因 | Gateway/Dashboard 进程未运行 | `curl → 000`, `ss -tlnp → 无监听` |
| 🅱 深层原因① | CLI 语法错误 / 进程被误杀 | `hermes gateway --port 8642`→"invalid choice" |
| 🅲 深层原因② | heal 杀掉了 dashboard 但未自动重启 | heal 后只剩 1 个 dash 但也没了 |
| 🅳 深层原因③ | 无Gateway自动保活机制+无限流阈值 | 只有 Web UI 有 unified-health-check 覆盖 |

**关联规则**:\n- 添加 Gateway 到 `~/.hermes/healer/orchestrator.py` 的探针列表 (当前只有 11 探针，缺端口级服务探针)\n- 任何服务重启后必须走 **先 heal → 再 start → 再验证** 三阶段流程\n- 如果 `hermes-svc.py status` 显示多服务宕机，优先修复 Gateway (API入口)，再修 Dashboard\n- **`gateway run --replace` 重启是设计行为**，会graceful drain时发送SIGTERM杀死所有子Profile Gateway。这不代表故障，autoheal会自动恢复。当仅Profile全挂而主Gateway健康时，先查 `--replace` 再查OOM。

---

### 场景: 自愈脚本静默失败 — `set -e` + `curl` 陷阱 (self-heal-script-silent-failure)

**触发条件**: 自愈脚本（如 `gateway-autoheal.sh`, `anti-degradation.sh`）按cron正常运行（last_status=ok）但实际未修复任何故障。本应重启的服务持续宕机，但健康检查报告"正常"。

**经典症状**:
- `hermes cron list` 显示自愈cron `last_status: ok`
- 脚本直接运行返回空输出或退出码≠0
- 实际服务宕机（端口000）但自愈脚本未干预
- 手动运行脚本 `/tmp/gateway-autoheal-$(date +%Y%m%d).log` 日志为空

**根因1: `set -e` + `curl` 静默崩溃 (exit=7 trap)**

```bash
#!/bin/bash
set -e                              # ← 罪魁祸首: 任何非0退出码立即退出

check_one() {
    curl -s -o /dev/null -w "%{http_code}" --connect-timeout 3 "$url"
    # curl连接被拒 → exit=7 → 被set -e捕获 → 脚本立即退出，无任何输出
}

for port in "${PORTS[@]}"; do
    code=$(check_one $port)         # ← set -e 在$()内被抑制，但函数内curl已失败
    if [ "$code" = "200" ]; then    # ← 代码走不到这里
        total_ok=$((total_ok+1))
    else
        total_fail=$((total_fail+1))  # ← 也走不到
    fi
done

echo "OK=$TOTAL_OK FAIL=$TOTAL_FAIL"  # ← 永远不会执行
```

**原理**: `set -e` 使shell在**任何未捕获的简单命令**返回非0时立即退出。`curl`连接被拒（服务未监听）返回exit=7。在`$()`命令替换内的curl返回值不会触发`set -e`（被抑制），但：
- 在函数内部的命令替换外，`set -e` 仍会触发
- 某些bash版本中，`$(func)` 中func内的`set -e` 行为因版本而异
- 结果: 脚本无任何输出, cron判为ok（无错误输出=成功），但实际什么都没做

**诊断方法**:
```bash
# Step 1: 检查脚本退出码
bash -x ~/scripts/gateway-autoheal.sh check 2>&1 | tail -20
# 看到: + curl ... → exit=7 → + echo 'OK=0 FAIL=0' 没输出 → exit code ≠0

# Step 2: 确认set -e存在
head -10 ~/scripts/gateway-autoheal.sh | grep 'set -[a-z]*e'
# 如果找到: set -e 或 set -eu 等 → 罪魁祸首

# Step 3: 验证不加set -e时脚本是否正常工作
# 临时注释掉set -e或改为set +e再运行
sed 's/set -e/set +e/' ~/scripts/gateway-autoheal.sh | bash 2>&1
# 应看到完整输出: OK=11 FAIL=0 或 OK=0 FAIL=11
```

**根因2: 硬编码端口/配置映射漂移**

自愈脚本中硬编码了端口→profile的映射表，但各profile的实际端口从`config.yaml`读取，两者可能完全错位：

```bash
# ❌ 错误: 硬编码 — 会随配置变更漂移
declare -A AGENTS
AGENTS=( 
    [8643]="arch"  [8644]="cm"   [8645]="dev"  # 但config.yaml中dev=8646!
    [8646]="doc"                                # 但doc=8650!
    ...
)

# ✅ 正确: 从实际配置文件动态读取
for p_dir in "$HOME/.hermes/profiles"/*/; do
    profile=$(basename "$p_dir")
    config="$p_dir/config.yaml"
    if [ -f "$config" ]; then
        port=$(grep -oP 'port:\s*\K\d+' "$config" 2>/dev/null | head -3 | tail -1)
        [ -n "$port" ] && AGENTS[$port]=$profile
    fi
done
```

**诊断方法**:
```bash
# 找出实际端口 vs 脚本硬编码端口的差异
echo "=== 脚本硬编码 ==="
grep -oP '\[[0-9]+\]="[a-z]+"' ~/scripts/gateway-autoheal.sh

echo "=== 实际config.yaml ==="
for p in arch cm dev doc pm qa req sec spi test yestin; do
  port=$(grep -oP 'port:\s*\K\d+' "$HOME/.hermes/profiles/$p/config.yaml" 2>/dev/null | head -3 | tail -1)
  echo "$p → $port"
done

# 手动校验: 用脚本的端口检查实际监听
for port in 8643 8644 8645 8646 8647 8648 8649 8650 8651 8652 8653 8654; do
  code=$(curl -s -o /dev/null -w "%{http_code}" --connect-timeout 3 "http://127.0.0.1:$port/health" 2>/dev/null || echo "000")
  echo "Port $port: HTTP $code"
done
```

**修复方案** (两步必须同时执行):

```bash
# 修复1: 移除set -e或替换为set +e
# 脚本应显式处理错误，而非让shell静默退出
sed -i 's/^set -e$/set +e/' ~/scripts/gateway-autoheal.sh

# 修复2: 端口映射动态化 — 从config.yaml读取而非硬编码
# 用以下模式替换硬编码declare -A:
cat >> ~/scripts/gateway-autoheal.sh << 'PATCH'
# 动态端口映射 — 从各profile config.yaml读取
for p_dir in "$HOME/.hermes/profiles"/*/; do
    profile=$(basename "$p_dir")
    config="$p_dir/config.yaml"
    if [ -f "$config" ]; then
        port=$(grep -oP 'port:\s*\K\d+' "$config" 2>/dev/null | head -3 | tail -1)
        [ -n "$port" ] && AGENTS[$port]=$profile
    fi
done
PATCH

# 验证: 脚本应正常输出
bash ~/scripts/gateway-autoheal.sh check
# 预期: OK=11 FAIL=0 (非空输出)
```

**4层根因分析 (RCA Pyramid)**:

| 层级 | 根因 | 证据 |
|------|------|------|
| 🅰 直接原因 | `gateway-autoheal.sh` 静默退出，未重启任何Profile Gateway | `bash check → exit 7`, 空输出 |
| 🅱 深层原因① | `set -e` 使curl exit=7时无任何输出地退出 | `set -e` 在脚本第6行 |
| 🅲 深层原因② | 硬编码端口映射与实际config.yaml错位(4/11个端口错误) | 脚本端口 vs config端口 对比显示差值 |
| 🅳 深层原因③ | 端口对接使用 hardcode (不读实际配置)，导致配置变更后自动漂移 | config.yaml中dev=8646但脚本写8645→dev |

**关键教训**:

| # | 教训 | 规则 |
|---|------|------|
| 1 | `set -e` + `curl` = 静默死亡组合 | ⚡ 自愈/巡检脚本永不用 `set -e`，用 `set +e` + 显式错误处理 |
| 2 | 端口映射可以且必将漂移 | ⚡ 从不硬编码端口/配置列表，永远从实际文件动态读取 |
| 3 | cron报ok ≠ 脚本正常工作 | ⚡ cron只检查脚本exit_code和stderr。静默exit=0但什么都没做 → cron判ok |
| 4 | 自愈脚本自身出bug = 单点故障 | ⚡ 自愈脚本本身需要被监控（验证输出非空、修复数>0） |
| 5 | 端口映射硬编码 = 双份运维负担 | ⚡ 每次重构profile（增删改端口）都要同步更新脚本，否则自愈失效 |
| 6 | **自愈脚本端口错配 → cron状态污染 → 健康告警级联误报** | ⚡ 自愈脚本连接错误端口→全部返回000→自愈脚本内部TOTAL_FAIL++但被set -e吞掉→cron判ok→实际故障持续→health-alert检测到故障→cron告警+gateway告警双重触发。自愈脚本的一个bug可导致整个监控系统误报。 |

---

### 场景: BookStack 页面无样式(白板/无CSS) (bookstack-no-css)

**症状**: BookStack 返回 HTTP 200，页面内容存在但完全无样式（白板/无格式文字），浏览器F12显示 `styles.css 404`、`app.js 404`。

**根因分析**:

```bash
# Step 1: 确认CSS/JS丢失
curl -sI http://127.0.0.1:8080/dist/styles.css  # HTTP 404
curl -sI http://127.0.0.1:8080/dist/app.js       # HTTP 404

# Step 2: 检查 public/dist/ 是否存在
ls /home/yestin/projects/BookStack/public/dist/  # → "NOT FOUND"

# Step 3: 检查构建文件是否被删
cd /home/yestin/projects/BookStack && git status --short
# 发现: D dev/build/esbuild.mjs, D dev/build/livereload.js 等被删除

# Step 4: 恢复构建文件 + 重新编译
git checkout -- dev/build/
npm run production
# 确认: ls public/dist/styles.css  # → 147KB
```

**4层根因分析**:

| 层级 | 根因 | 证据 |
|------|------|------|
| 🅰 直接原因 | `public/dist/styles.css` 不存在 | `curl → 404` |
| 🅱 深层原因① | 前端构建文件 `dev/build/esbuild.mjs` 被删除 | `git status → D dev/build/esbuild.mjs` |
| 🅲 深层原因② | 代码更新后未重新 `npm run production` | git log 显示近期提交 |
| 🅳 深层原因③ | PHP服务器能启动但BookStack不检查前端资产 | 无启动时 health check 验证 public/dist/ |

**关键教训**:

| # | 教训 | 规则 |
|---|------|------|
| 1 | BookStack是Laravel项目，静态资源需编译 | ⚡ 任何 git pull/checkout 后必须 `npm run production` |
| 2 | PHP服务器启动≠BookStack完整可用 | ⚡ 健康检查需验证 `styles.css` 返回200 |
| 3 | 构建工具依赖: sass + esbuild + npm-run-all | ⚡ 缺任一依赖都会导致 `npm run production` 失败 |

---

### 场景: Multi-Service Drift Recovery — svc.py端口漂移+Gateway泄漏+Cron崩溃多问题并发 (multi-service-drift)

**症状**: `hermes-svc.py status` 显示多个服务状态异常、cron报错、Gateway进程数远超预期。

**根因分类 (三层因果链)**:

| 层 | 问题类型 | 典型表现 | 根因 |
|----|----------|----------|------|
| 🅰 端口漂移 | svc.py报告的端口与服务实际端口不一致 | Dashboard[✅]:5000但实际在8050；WebUI[❌]:8688但实际在8648 | svc.py常量在服务迁移后未更新 |
| 🅱 进程泄漏 | Gateway进程数远超预期 | `ps aux \| grep gateway \| wc -l` → 13+ (应为1主+11Agent=12) | `hermes gateway run --replace` 未正确替换旧进程，autoheal cron反复启动 |
| 🅲 Cron持续报错 | 特定cron每次运行都error | `RuntimeError: cannot schedule new futures after interpreter shutdown` | ThreadPoolExecutor内联代码在Hermes cron沙箱中异常退出 |

**诊断流程 (4步并发扫描)**:

```bash
# Step 1: 服务状态 vs 实际端口 — 找出漂移
python3 ~/scripts/hermes-svc.py status
# 记录报告的端口
ss -tlnp | grep -E '8050|8642|8648|8080'  # 实际监听端口
# 对比: svc.py报告的端口 vs 实际监听端口
# 常见漂移: Dashboard 5000→8050, WebUI 8688→8648

# Step 2: 进程计数 — 找泄漏
ps aux | grep 'gateway' | grep -v grep | wc -l
# 预期: 1 (主Gateway) + 11 (Agent Gateways) = 12
# 如果 > 12 → 泄漏

# Step 3: cron错误 — 区分模型问题 vs 脚本问题
hermes cron list 2>/dev/null | grep -B3 "error"
# 错误信息分类:
#   "Agent completed but produced empty response" → 模型/提供商问题，切换provider
#   "RuntimeError: cannot schedule new futures" → 脚本ThreadPoolExecutor泄漏，需简化命令
#   "ImportError"/其他Python错误 → 脚本bug

# Step 4: 记忆膨胀 — 检查MEMORY.md大小
wc -c ~/.hermes/memories/MEMORY.md
# > 4000字节 → 需要压缩
```

**修复流程 (先P0后P1)**:

```bash
# P0-1: 修复Gateway泄漏
# 1a. 确认实际架构 (主GW:8642 + 11 Agent:8659-8676)
#     端口从各profile config.yaml > platforms.api_server.extra.port 读取
#     实际端口范围 8659-8676，非旧文档的 8643-8653
# 1b. 精确清理: 只杀超出12个的进程
# 1c. 重启主Gateway: terminal(background=true) cd ~/.hermes && python3 -m hermes_cli.main gateway run --replace
# 1d. Agent Gateways 由 autoheal cron 自动恢复

# P0-2: 修复svc.py端口漂移
# 修改 ~/scripts/hermes-svc.py:
patch(path="~/scripts/hermes-svc.py",
    old_string="DASHBOARD_PORT = 5000",  # 旧值
    new_string="DASHBOARD_PORT = 8050")  # 实际值
patch(path="~/scripts/hermes-svc.py",
    old_string="WEB_UI_PORT = 8688",     # 旧值
    new_string="WEB_UI_PORT = 8648")     # 实际值

# P0-3: 修复cron报错
# 对于"empty response" → 切换模型provider
cronjob update --job-id <ID> --model '{"model":"z-ai/glm-4-flash","provider":"zai"}'
# 对于"RuntimeError: futures" → 更新cron命令为纯SQLite操作
cronjob update --job-id <ID> --prompt "python3 -c \"简单SQLite命令\""

# P1: 记忆压缩
# 合并§分隔的日志条目，保留关键事实
```

**4层根因分析 (RCA Pyramid)**:

| 层级 | 根因 | 证据 | 修复 |
|------|------|------|------|
| 🅰 直接原因 | svc.py常量过时 / Gateway进程堆积 / Cron脚本bug | status❌/进程数>12/error日志 | 修复常量/清理进程/简化命令 |
| 🅱 深层原因① | 服务迁移后svc.py未同步更新 / --replace机制失效 | Dashboard实际8050但svc.py写5000 | svc.py常量必须反映实际端口 |
| 🅲 深层原因② | 无自动端口审计 / 无进程数告警阈值 | 漂移发生多日未被发现 | 需定期ss端口 vs svc.py常量一致性检查 |
| 🅳 深层原因③ | cron脚本编写时未考虑Hermes沙箱环境(ThreadPoolExecutor兼容性) | 简单inline Python应避免线程池 | cron命令保持最少依赖: 纯SQLite/curl/bash |

**关键教训** (必须编码到技能)：

| # | 教训 | 规则 |
|---|------|------|
| 1 | svc.py常量必须与实际端口保持一致 | ⚡ 每次迁移/新增服务后必须更新svc.py |
| 2 | Dashboard默认端口8050(非5000), WebUI默认端口8648(非8688) | ⚡ 以`ss -tlnp`实际监听为准，非猜测 |
| 3 | Gateway架构=1主+11Agent，不要误判为泄漏 | ⚡ 检查前先确认架构，12个=正常，13+才泄漏 |
| 4 | WebUI端口由config.js控制(默认8648), argv参数无效 | ⚡ 用PORT=8648环境变量或`hermes-web-ui start 8648`(CLI传参有效) |
| 5 | cron脚本用最简单命令避免ThreadPoolExecutor | ⚡ 纯SQLite/curl/bash命令, 避免多线程Python内联代码 |
| 6 | 记忆文件>4000字节必须压缩 | ⚡ 合并§分隔日志为紧凑摘要，保持核心条目 |
| 7 | 健康检查脚本端口必须与实际服务端口一致 | ⚡ 审计 unified-health-check.py / anti-degradation.sh / hermes-svc.py 中所有硬编码端口 vs ss -tlnp 实际监听 |
| 8a | Gateway泄漏告警阈值需匹配实际架构(1主+11Agent=12正常) | ⚡ health-alert.sh中check_gateway_leak(): 用grep -E 'gateway (run|restart)'全检测；0=宕机(P0), <12=Agent不完整(P1), >14=泄漏(P0)；同时检测stuck restart进程 |
| 8b | 升级脚本后必须清理遗留的告警进程 — `cmmi5-chat-router.py` 用 `&` 后台执行会产生孤儿进程 | ⚡ health-alert.sh改造: 用 `timeout 30 python3 ...` 替代裸 `&`，或启动前 `pkill -f "cmmi5-chat-router.py.*SYSTEM_ALERT"` 杀旧进程；升级脚本后必须 `pkill -f "cmmi5-chat-router.py"` 清理旧告警发送实例 |
| 8c | 系统全绿但告警仍在发 → 检查残留的 `cmmi5-chat-router.py` 进程和 `health-alert.log` 时间戳 | ⚡ 诊断命令: `ps aux \| grep '[c]mmi5-chat-router'` 确认无孤儿进程；`tail -5 ~/logs/health-alert.log` 确认最近巡检报0 issues |
| 8 | 慢启动服务(如Node.js WebUI)需要轮询等待 | ⚡ 自愈脚本用 for+轮询循环(最长30s)替代固定sleep(5s) |

**P2-3: Evolution Engine Score Validation (P0/P1修复后的最终验证)**

P0/P1修复完成后，进化引擎评分可能仍因陈旧数据而偏低。运行以下流程将评分恢复到真实水平:

```bash
# Step 1: 刷新自愈数据 (修复self_healing<100的常见原因)
# 如果healer metrics.json >2h旧, self_healing维度扣3分
python3 ~/.hermes/healer/orchestrator.py --check
# 验证: 输出应全部OK, metrics.json刷新

# Step 2: 压缩记忆 (修复memory_efficiency<100)
wc -c ~/.hermes/memories/MEMORY.md
# 如果 >2400B (>30%): 合并§分隔日志条目, 保留核心事实
# 目标: <2000B (<25%)

# Step 3: 运行进化引擎分析
cd ~/.hermes && python3 skills/meta/meta-evolution/scripts/evolution_engine.py --analyze
# memory_efficiency: 90→100 (记忆压缩后)
# self_healing: 97→100 (healer刷新后)
# learning_accumulation: 93→100 (自然恢复)

# Step 4: 验证总分
# 检查 self_assessment_latest.json 中的 overall_score
# 预期: 100.0/100, total_issues=0
```

**进化引擎维度映射**:

| 维度 | 常见降分原因 | 修复方法 |
|------|-------------|---------|
| memory_efficiency | MEMORY.md >2400B(>30%) | 压缩记忆到<2000B |
| self_healing | metrics.json >2h旧 | 触发healer检查刷新 |
| learning_accumulation | 轨迹数据不足 | 自然累积(不可手动加速) |

**修复清单验证 (扩展版)**:

```bash
# 验证0: 进化引擎评分(优先运行)
cd ~/.hermes && python3 skills/meta/meta-evolution/scripts/evolution_engine.py --analyze --json 2>/dev/null | python3 -c "import sys,json;d=json.load(sys.stdin);print(f'Score: {sum(x[\"score\"] for x in d[\"dimensions\"])}/{len(d[\"dimensions\"])*100}')"

# 验证1: svc.py常量正确
grep -E "WEB_UI_PORT|DASHBOARD_PORT|GATEWAY_PORT" ~/scripts/hermes-svc.py

# 验证2: Gateway进程数正常(12-13个可接受)
[ $(ps aux | grep 'gateway' | grep -v grep | wc -l) -le 13 ] && echo "OK" || echo "LEAK"

# 验证3: 核心服务可用
curl -s -o /dev/null -w "GW: %{http_code}\n" http://127.0.0.1:8642/health
curl -s -o /dev/null -w "Dash: %{http_code}\n" http://127.0.0.1:8050/
curl -s -o /dev/null -w "BS: %{http_code}\n" http://127.0.0.1:8080/

# 验证4: Cron错误数
hermes cron list 2>/dev/null | grep -c "error"  # 预期: 0

# 验证5: 记忆大小
wc -c ~/.hermes/memories/MEMORY.md | awk '$1<2400{print "MEMORY OK"} $1>=2400{print "MEMORY NEED COMPRESS"}'

# 验证6: Gateway进程健康(确认无重复)
ps aux | grep 'gateway' | grep -v grep | awk '{print $2, $NF}' | sort -n
```

--- 

### 场景: BookStack 页面访问异常(登录后会话丢失) (bookstack-session-failure)

**症状**: BookStack可以访问登录页，登录后短暂进入首页但任何导航立即踢回登录页。curl登录+导航正常，仅浏览器有问题。

**根因分析(三重根因叠加)**:

```bash
# Step 1: 识别浏览器特有的Cookie问题
curl -c /tmp/cookies.txt -b /tmp/cookies.txt -X POST \
  -d "email=admin@admin.com&password=password" \
  http://127.0.0.1:8080/login -L -o /dev/null -w "%{http_code}"
# → 200 (curl正常，浏览器不正常)

# Step 2: 检查PHP session.save_path
/home/yestin/opt/php/usr/bin/php8.3 -c /home/yestin/opt/php/php.ini \
  -r "echo ini_get('session.save_path');"
# → /var/lib/php/sessions → 目录不存在! → 会话创建失败

# Step 3: 检查APP_URL与浏览器访问域名一致性
grep APP_URL /home/yestin/projects/BookStack/.env
# → APP_URL=http://localhost:8080 
#    但浏览器访问 http://127.0.0.1:8080 → Cookie域名不匹配!

# Step 4: 检查SESSION_DOMAIN是否配置
grep SESSION_DOMAIN /home/yestin/projects/BookStack/.env
# → 未配置 → Cookie无显式域名绑定 → 跨"域名"不可用
```

**4层根因分析**:

| 层级 | 根因 | 证据 |
|------|------|------|
| 🅰 直接原因 | 浏览器登录后会话丢失，302踢回/login | `browser: GET /books → 302 → /login` |
| 🅱 深层原因① | Cookie域名不匹配: `127.0.0.1` ≠ `localhost` | APP_URL=localhost 但浏览器用127.0.0.1 |
| 🅲 深层原因② | PHP session.save_path目录不存在 | `/var/lib/php/sessions` 不存在 |
| 🅳 深层原因③ | SESSION_DOMAIN未显式配置 | .env中无此配置项 |

**修复措施(5项全补)**:

| # | 文件 | 修改 | 作用 |
|---|------|------|------|
| 1 | `php.ini` | `session.save_path=/tmp/php-sessions` | 会话目录可用 |
| 2 | `.env` | `APP_URL=http://127.0.0.1:8080` | URL与浏览器一致 |
| 3 | `.env` | `SESSION_DOMAIN=127.0.0.1` | 关键: Cookie域名绑定 |
| 4 | `.env` | `SESSION_SECURE_COOKIE=false` | HTTP环境兼容 |
| 5 | `.env` | `SESSION_LIFETIME=120` | 2小时会话 |

**关键教训**:

| # | 教训 | 规则 |
|---|------|------|
| 1 | URL/Cookie/域名必须三位一体一致 | ⚡ APP_URL = 浏览器访问URL = SESSION_DOMAIN |
| 2 | curl能工作≠浏览器能工作 | ⚡ 浏览器Cookie Domain隔离是真实战场 |
| 3 | PHP session.save_path必须存在且可写 | ⚡ PHP启动时静默失败，需显式检查和创建 |
| 4 | 浏览器隐式跨域: 127.0.0.1≠localhost | ⚡ 两个地址对浏览器是完全不同的域 |

---

**症状**: BookStack 8080 返回 000 (连接拒绝)，MariaDB socket存在但PHP进程消失。

**根因分析 (5步法)**:

```bash
# Step 1: 确认故障范围
bash /home/yestin/scripts/start-bookstack.sh status
# 输出: ✅ MariaDB 运行中 / ❌ PHP服务器未运行

# Step 2: 检查历史 — 自愈Cron是否搞砸了
cat /tmp/mariadb-startup.log
# 关键: "Starting crash recovery from checkpoint LSN=..." → MariaDB被非正常终止过
cat /tmp/bookstack-restart.log
# 确认: "[2026-05-14 01:20] smart_restart triggered" → 自愈Cron在几分钟前执行了restart

# Step 3: 分析restart逻辑的问题
# 旧代码: restart() = stop() + start()
#     stop() 用 pkill -f mariadbd 杀全栈 ← 手术刀变炸弹
#     → 即使只有PHP崩溃，MariaDB也被误杀
#     → InnoDB crash recovery触发 → 启动变慢

# Step 4: 评估影响
# PHP崩溃 + MariaDB crash recovery = ~30s额外停机
# 如果MariaDB正在写事务，可能丢失最后一条记录

# Step 5: 修复 → 智能重启
# 新增 smart_restart()：仅重启异常组件，健康组件跳过
bash /home/yestin/scripts/start-bookstack.sh smart-restart
# 输出:
#   ✅ MariaDB: 正常，跳过重启
#   🔄 PHP服务器: 异常(HTTP 000)，重启中...
#   ✅ PHP服务器: 已恢复
```

**4层根因分析 (RCA Pyramid)**:

| 层级 | 根因 | 证据 |
|------|------|------|
| 🅰 直接原因 | PHP进程崩溃 | `curl localhost:8080 → 000` |
| 🅱 深层原因① | restart暴力pkill杀全栈(含健康MariaDB) | `mariadb-startup.log: "Starting crash recovery"` |
| 🅲 深层原因② | stop()无优雅shutdown，pkill不给缓冲区刷新时间 | `stop()` 中 `pkill -f mariadbd` 无前置 `mariadb-admin shutdown` |
| 🅳 深层原因③ | Cron输出掩盖restart事件 — 报告"一切正常"但实际执行了重启 | 01:20 cron输出: "[健康巡检完成，所有服务运行正常]" |

**关键教训** (必须编码到技能):

| # | 教训 | 规则 |
|---|------|------|
| 1 | 自愈restart不能比故障本身更危险 | ⚡ 用 `smart_restart` 而非 `restart`，只修异常组件 |
| 2 | `stop()` 必须优雅shutdown | ⚡ MariaDB用 `mariadb-admin shutdown`，PHP用 `kill` (非 `kill -9`) |
| 3 | Cron报告必须包含重启事件 | ⚡ 格式: `[STATUS:RESTARTED] PHP restarted, MariaDB skipped` |
| 4 | 每次restart必须写追踪日志 | ⚡ `/tmp/bookstack-restart.log` 记录时间和组件 |
| 5 | `start-bookstack.sh status` 检查 `/login` 而非 `/` | ⚡ `/login` 页面需PHP+DB双通，`/` 可能被302重定向误判 |

**修复措施**:
1. **stop()优雅化**: `pkill -f mariadbd` → `mariadb-admin shutdown` (graceful) + 超时后 `kill -9` (force fallback)
2. **新增smart_restart()**: 分别检查MariaDB(DB连接)和PHP(curl 8080)，仅重启异常组件
3. **重启追踪日志**: `/tmp/bookstack-restart.log` 记录每次重启触发时间和组件
4. **Cron上报格式**: 使用 `[STATUS:OK|RESTARTED|FAIL]` 三元组，RESTARTED时注明组件
5. **智能重启脚本**: `~/scripts/start-bookstack.sh smart-restart`

**症状**: 访问 http://localhost:8648 连接被拒绝

**诊断流程 (8步法)**:

```bash
# Step 1: 检查进程
ps aux | grep hermes-web-ui
ss -tlnp | grep 8648      # 端口是否监听？

# Step 2: 检查@reboot是否执行
journalctl -u cron | grep hermes-web-ui
# 或
grep -r "hermes-web" /var/log/syslog

# Step 3: 检查日志找根因
tail -30 ~/.hermes-web-ui/server.log
# 关键错误: "spawn hermes ENOENT" → Node.js找不到hermes CLI
# 或: "Gateway health check timed out after 15000ms"

# Step 4: 检查统一健康巡检是否覆盖
grep "8648\|HermesWebUI" ~/scripts/unified-health-check.py

# Step 5: 检查 Node.js 版本兼容性
node --version                                          # 需要 ≥ v23
# 如版本 < v23:
#   下载: curl -sL https://nodejs.org/dist/latest-v23.x/node-v23.11.1-linux-x64.tar.xz
#   解压 → cp bin/node → ~/.hermes/node/bin/node (替换 old node)
#   验证: node --version → v23.x.x

# Step 6: 检查 hermes CLI 是否在 Node.js PATH 中 (GatewayManager 用 spawn 调用)
ls -la ~/.hermes/node/bin/hermes                        # 应存在
# 如不存在: ln -sf ~/.hermes/.venv/bin/hermes ~/.hermes/node/bin/hermes
# 验证: ~/.hermes/node/bin/hermes --version

# Step 7: 检查是否因 profile 过多导致启动缓慢
hermes profile list                                     # 每个 profile 触发一次 gateway restart
# 每个 profile 的 gateway 启动耗时 ~15s timeout
# 修复: 删除 profile 中的 platforms/gateway 配置，或删除无用 profile
# hermes profile delete <name>
# 或编辑 ~/.hermes/profiles/<name>/config.yaml 去掉 platforms: 段

# Step 8: 检查 gateway 端口冲突
ss -tlnp | grep -E '8642|8653'                          # 确认已有 gateway 运行
hermes gateway status                                    # gateway 状态
# 错误: "Another gateway instance started during our startup" → profile 间 gateway 冲突
# 修复: 每个 profile 需独立 gateway 配置，或删除非必要 profile 的 gateway

# 修复 + 注册
hermes-web-ui start 8648                              # 手动启动
# 然后加入 unified-health-check.py:
# "HermesWebUI": {"port": 8648, "url": "/", "repair": "export PATH=$HOME/.hermes/.venv/bin:$HOME/.hermes/node/bin:$PATH && hermes-web-ui start 8648 &>/tmp/hermes-web-ui.log &" }
```

**4层根因分析 (RCA Pyramid)**:

| 层级 | 根因 | 证据 |
|------|------|------|
| 🅰 直接原因 | 进程未运行，端口8648无人监听 | `ss -tlnp | grep 8648` → 无输出 |
| 🅱 深层原因① | Node.js spawn hermes CLI时报ENOENT | server.log: `Error: spawn hermes ENOENT` — PATH环境变量问题 |
| 🅲 深层原因② | 健康巡检未覆盖8648端口 | unified-health-check.py缺HermesWebUI条目 |
| 🅳 深层原因③ | @reboot单次执行无重试机制 | 一旦启动后进程崩溃，无自动恢复 |

### 核心教训**: 任何新服务上线必须同时注册到健康巡检。
规则: 每新增一个@reboot服务 → 同步更新 unified-health-check.py。

### 多Profile Gateway启动超时陷阱

**症状**: `hermes-web-ui start 8648` 启动极慢(10+profile → 2.5分钟)，`Server: http://localhost:8648` 一直未出现

**Root Cause**: GatewayManager tries to start profile gateways on startup. 

**❗ Critical Discovery (v0.5.16): Gateway Timeout Errors Are NON-FATAL**
Even when 10 profile gateways time out (showing "Gateway health check timed out after 15000ms" ×10), the Web UI still works. Group Chat agents connect through the **single default gateway + chat-router**, NOT through 10 independent profile gateways. The profile gateways are legacy artifacts — their failure does NOT affect functionality.

**Fix** (v0.5.16 verified):
```bash
# Disable each CMMI5 profile's gateway auto-start
for p in arch design dev test cm qa spi sam pm req; do
  sed -i 's/enabled: true/enabled: false/' ~/.hermes/profiles/$p/config.yaml
done

# Restart Web UI (CLI restart handles port cleanup)
cd ~/.hermes/node-v22/lib/node_modules/hermes-web-ui
node bin/hermes-web-ui.mjs restart 8648
```

**Verification**: After fix, `grep -c "failed to start" ~/.hermes-web-ui/server.log` should be 0. `curl -s -o /dev/null -w "%{http_code}" http://localhost:8648/` should return 200 in <1s.

**根因**: hermes-web-ui v0.5.16+ 的 GatewayManager 会为 **所有** profile 尝试启动网关。每个非default profile的 gateway 启动耗时 ~15s timeout。v0.5.16 并行处理(~15s总等待)但 HTTP 服务立即启动；v0.5.17 串行阻塞 HTTP 启动。

**关键发现**:
1. `gateway: {enabled: false}` 在 profile config.yaml 中**无效** — GatewayManager 按文件系统扫描 profile，不读此字段
2. `hermes profile delete <name>` **需要交互确认** (`Type 'pm' to confirm:`)，自动化脚本中不可用
3. Profile 名 `test` 是**保留名** (`_RESERVED_NAMES`)，`hermes profile create test` 失败

**解决**:
```bash
# 摧毁式删除 (自动化)
rm -rf ~/.hermes/profiles/<name>
# 或 Python API 绕过 CLI 限制:
python3 -c "from hermes_cli.profiles import create_profile; create_profile('pm', clone_from='default', clone_config=True, no_alias=True)"

# 创建后立即清理 gateway 运行时数据 (否则下次启动还会尝试启动网关)
rm -rf ~/.hermes/profiles/<name>/.hermes

# 最小化 profile config.yaml (去掉 platforms 段以避免 gateway 尝试)
cat > ~/.hermes/profiles/<name>/config.yaml << 'EOF'
model:
  default: deepseek-v4-flash
  provider: deepseek
providers:
  deepseek:
    api_key: ${DEEPSEEK_API_KEY}
    base_url: https://api.deepseek.com/v1
fallback_providers: '["zai","baidu","openrouter"]'
EOF
```

**验证**: `hermes profile list` 显示 Gateway 列为 `stopped` 而非 `running`，且启动日志不再有 `Starting gateway for profile "..."` 行。

### hermes-web-ui 版本升级/回退流程

**升级验证**:
```bash
# 检查当前版本
hermes-web-ui --version
npm list -g hermes-web-ui

# 安装特定版本
npm install -g hermes-web-ui@0.5.16   # 降级/指定版本
npm install -g hermes-web-ui@0.5.17   # 升级

# 验证目标版本
hermes-web-ui --version

# 启动测试
hermes-web-ui start 8648
curl -sI http://localhost:8648 | head -3
```

**回退条件**: 如果新版本导致 gateway 串行阻塞 HTTP 启动(如 v0.5.17)，用 `npm install -g hermes-web-ui@0.5.16` 回退即可。

### Node.js 运行时升级流程

需要在Hermes环境下升级Node.js (替换 `~/.hermes/node/bin/node`):

```bash
# 1. 确认当前版本和架构
node --version
uname -m

# 2. 查询最新 v23 版本
curl -sL https://nodejs.org/dist/latest-v23.x/ | grep -oP 'node-v23\.\d+\.\d+-linux-x64\.tar\.xz' | sort -V | tail -1

# 3. 下载 + 部署
cd /tmp
curl -sLO https://nodejs.org/dist/v23.11.1/node-v23.11.1-linux-x64.tar.xz
tar xf node-v23.11.1-linux-x64.tar.xz

# 4. 替换二进制 (需要先停掉所有 node 进程)
# **关键**: 不能直接 cp 当文件被使用时(Text file busy)
# 方法: rename 旧文件 → copy 新文件
mv ~/.hermes/node/bin/node ~/.hermes/node/bin/node-v22
cp node-v23.11.1-linux-x64/bin/node ~/.hermes/node/bin/node

# 5. 更新本地 symlink
ln -sf ~/.hermes/node/bin/node ~/.local/bin/node

# 6. 验证
node --version  # 应显示 v23.x.x

# 7. 重启 hermes-web-ui
hermes-web-ui stop; sleep 1
hermes-web-ui start 8648
```

**清理**: 验证成功后删除旧二进制和临时文件:
```bash
rm ~/.hermes/node/bin/node-v22
rm -rf /tmp/node-v23.11.1-linux-x64*
```

**回退**: `mv ~/.hermes/node/bin/node-v22 ~/.hermes/node/bin/node`

### 关键发现: hermes-web-ui CLI wrapper vs 直接Node.js启动

**问题**: `hermes-web-ui start 8648` CLI wrapper 使用 Node.js `spawn()` 调用 hermes CLI，在 cron/PATH受限环境中常报 `spawn ENOENT`，进程启动即崩溃。

**修复**: 使用直接Node.js调用，绕过CLI wrapper:

```bash
# ✅ 正确方案A: 使用包的bin入口(.mjs文件)
cd ~/.hermes
node-v23/bin/node node-v23/lib/node_modules/hermes-web-ui/bin/hermes-web-ui.mjs start 8648

# ✅ 正确方案B: 直接启动server (PORT环境变量控制)
cd ~/.hermes
PORT=8648 node-v23/bin/node node-v23/lib/node_modules/hermes-web-ui/dist/server/index.js &

# ✅ 正确方案C (Python subprocess):
subprocess.Popen(
    [NODE_BIN, WEBUI_SERVER_ENTRY, "start", "8648"],
    # 路径: WEBUI_SERVER_ENTRY = ~/.hermes/node-v23/lib/node_modules/hermes-web-ui/bin/hermes-web-ui.mjs
    cwd=HERMES_HOME,
    env={**os.environ, "PORT": "8648"},
    start_new_session=True,
)
```

**方案A vs 方案B 选择依据:**
- 方案A (hermes-web-ui.mjs): 包管理Server进程(PID文件+日志文件)，支持`stop`/`restart`命令。推荐用于长期运行。
- 方案B (index.js): 裸Node.js进程，无进程管理。启动更快但无法优雅停止。仅用于快速验证。

**关键路径确认:**
包结构: `~/.hermes/node-v23/lib/node_modules/hermes-web-ui/`
- bin入口: `bin/hermes-web-ui.mjs` (读取package.json, PID_DIR=~/.hermes-web-ui/)
- server入口: `dist/server/index.js` (读取config.js, 默认PORT=8648)
- config: `dist/server/config.js` (port: process.env.PORT || 8648)

**start-webui.sh 模板**:
```bash
#!/bin/bash
export PORT=8648
NODE_BIN="$HOME/.hermes/node-v23/bin/node"
WEBUI_SERVER="$HOME/.hermes/node-v23/lib/node_modules/hermes-web-ui/dist/server/index.js"
pkill -f "hermes-web-ui.*index.js" 2>/dev/null || true
sleep 1
exec nohup "$NODE_BIN" "$WEBUI_SERVER" >> "$HOME/logs/webui.log" 2>&1 &
echo "✅ WebUI started on port $PORT"
```

**健康巡检集成** — health-alert.sh 必须包含WebUI自动重启:
```bash
# 巡检+自愈
check_service "WebUI" "http://127.0.0.1:8648/"

# WebUI宕机自动重启
if ! curl -s -o /dev/null --connect-timeout 2 http://127.0.0.1:8648/; then
    echo "[$(date)] 🔄 WebUI宕机，自动重启..."
    bash "$HOME/.hermes/scripts/start-webui.sh" >> "$HOME/logs/health-alert.log" 2>&1
    sleep 4
fi
```

**svc.py WebUI进程检测模式** — 必须精确匹配:
```python
# ✅ 正确: 匹配 'hermes-web-ui' 进程名
out, _ = run("ps aux | grep 'hermes-web-ui' | grep -v grep | grep -v 'bash -lic' | wc -l")

# ❌ 错误: 匹配 'web-ui/index.js' — 不匹配实际进程
out, _ = run("ps aux | grep 'web-ui/index.js' | grep -v grep | wc -l")
# ss显示进程名为 "MainThread"，ps显示 "node ... hermes-web-ui/dist/server/index.js"
```

**关联规则**:
- `unified-health-check.py` 每5分钟由cron运行，自动检测+重启
- 所有@reboot服务必须纳入此巡检，否则宕机后永久失联

## 使用方式

```bash
# 手动触发事故响应
python3 scripts/incident_commander.py --alert "disk usage 95%" --severity P1

# Cron自动巡检 (每5分钟)
# cron: */5 * * * * python3 scripts/incident_commander.py --patrol

# 复盘报告
python3 scripts/incident_commander.py --postmortem INCIDENT_ID
```

## Hermes能力集成

| 能力 | 用途 |
|------|------|
| 持久记忆 | 记录事故模式，积累经验 |
| 技能自创建 | 每次事故解决→生成预防技能 |
| Cron调度 | 定期健康巡检 |
| 网关推送 | Telegram/Discord告警通知 |
| 子代理 | 并行诊断多个假设 |
| 会话搜索 | 查询历史相似事故 |

## 输出

1. 事故报告 (时间线+根因+修复措施)
2. 预防技能 (自动创建)
3. 团队通知 (Telegram/Discord)
4. 指标更新 (MTTR/MTTD追踪)

---

## Real Incident Postmortem — 真实事故复盘模板

### 适用场景

真实生产事故发生后，需要将完整的根因分析、修复过程和经验教训结构化记录到BookStack知识库。不同于混沌演练（Drill），真实事故复盘需要**4层RCA（Root Cause Analysis）** 和**可追溯的修复措施**。

### 4层根因分析结构 (RCA Pyramid)

每一层回答一个"为什么"，层层深入：

```
🅰 直接原因     → "什么立即导致了故障？"     (进程崩溃/端口未监听)
🅱 深层原因①   → "为什么直接原因发生了？"     (spawn ENOENT/PATH问题)
🅲 深层原因②   → "为什么没有被自动发现？"     (健康巡检未覆盖)
🅳 深层原因③   → "为什么信息被掩盖了？"       (日志淹没/告警缺失)
```

### BookStack故障记录页模板

在BookStack创建故障记录页，结构如下：

```html
<h1>🛑 故障记录 YYYY-MM-DD: {服务名} {故障描述}</h1>

<h2>事件概述</h2>
<p><strong>时间</strong>: YYYY-MM-DD HH:MM CST<br>
<strong>服务</strong>: {服务名} (port {PORT})<br>
<strong>影响</strong>: {影响描述}<br>
<strong>修复</strong>: {修复摘要}</p>

<h2>根因分析</h2>
<table class="kb-table"><thead><tr><th>层级</th><th>根因</th><th>证据</th></tr></thead><tbody>
<tr><td>🅰 直接原因</td><td>{原因}</td><td><code>{命令/日志片段}</code></td></tr>
<tr><td>🅱 深层原因①</td><td>{原因}</td><td>{证据}</td></tr>
<tr><td>🅲 深层原因②</td><td>{原因}</td><td>{证据}</td></tr>
<tr><td>🅳 深层原因③</td><td>{原因}</td><td>{证据}</td></tr>
</tbody></table>

<h2>修复措施</h2>
<ol>
<li><strong>{措施1}</strong>: {具体操作} → {结果}</li>
<li><strong>{措施2}</strong>: {具体操作} → {结果}</li>
<li><strong>{措施3}</strong>: {具体操作} → {结果}</li>
</ol>

<h2>经验教训</h2>
<table class="kb-table"><thead><tr><th>#</th><th>教训</th><th>规则</th></tr></thead><tbody>
<tr><td>1</td><td>{教训简述}</td><td>{可执行的规则}</td></tr>
<tr><td>2</td><td>{教训简述}</td><td>{可执行的规则}</td></tr>
<tr><td>3</td><td>{教训简述}</td><td>{可执行的规则}</td></tr>
<tr><td>4</td><td>{教训简述}</td><td>{可执行的规则}</td></tr>
</tbody></table>

<h2>相关文件</h2>
<ul>
<li><strong>修复文件</strong>: <code>{文件路径}</code></li>
<li><strong>日志</strong>: <code>{日志路径}</code></li>
<li><strong>当前状态</strong>: {验证结果}</li>
</ul>
```

### 执行流程

```python
# Step 1: Create fault record page in Book 39
result = api('POST', '/pages', {
    'book_id': 39,
    'name': f'🛑 故障记录: {服务名} {故障描述} (YYYY-MM-DD)',
    'html': postmortem_html  # 使用上方模板
})
print(f"故障页已创建: /books/39/page/{result['slug']}")

# Step 2: Append entry to CMMI5更新日志 (page 285)
# 在 <h1> 之后插入新的h2条目，格式为：
# YYYY-MM-DD — {服务名} 故障修复+{修复要点}
# 含问题描述/根因/修复措施/指向详情页的链接

# Step 3: Update changelog page
new_entry = f"""
<h2>YYYY-MM-DD — {服务名} 故障修复+{修复要点}</h2>
<h3>🔍 问题</h3>
<p>{问题简述}</p>
<h3>根因</h3>
<ul><li>{根因1}</li><li>{根因2}</li></ul>
<h3>修复</h3>
<ul><li>{修复1}</li><li>{修复2(永久措施)}</li></ul>
<p><a href="/books/39/page/{slug}">📄 详细故障记录</a></p>
<div class="kb-cartoon-divider">✦ ✦ ✦ ✦ ✦</div>
"""
```

### 注意事项

- 每条经验教训必须包含**可执行的规则**（"必须"/"需要"），而非抽象建议
- 第4层RCA（深层原因③）通常是**流程/机制/文化问题**，而非技术问题
- 修复措施至少包含：临时修复（手动）+ 永久修复（自动巡检/告警）
- 完成后更新BookStack日志页285 + 持久记忆（INCIDENT-YYYYMMDD）
- 参考示例: Book ID 39, 页1143 (🛑 故障记录: Hermes Web UI 无法访问 2026-05-13)

---

## Post-Incident Monitoring Infrastructure — 修复后监控基建

### 适用场景

在完成多服务漂移/泄漏/崩溃的P0修复后，需要建立**主动监控+自动告警+自归档**三层防护网，防止同类问题再次发生。

### 三层防护架构

```
┌─ Layer 1: 实时监控 (Dashboard) ─────────────────┐
│  Dashboard :8050 → Gateway面板 + WebUI状态       │
│  手动打开查看                                     │
├─ Layer 2: 主动告警 (health-alert.sh) ────────────┤
│  */5 * * * * → 巡检→发现问题→飞书通知            │
│  异常自动通知，无需人工查看                       │
├─ Layer 3: 自动归档 (daily-health-report.py) ─────┤
│  0 */6 * * * → 采集→BookStack报告→永久存档       │
│  历史可追溯，便于趋势分析                         │
└──────────────────────────────────────────────────┘
```

### Type 1: Proactive Health Alert (health-alert.sh)

创建位置: `~/scripts/health-alert.sh`

**巡检项** (7项覆盖全部已知宕机模式):
```bash
# 1. Gateway健康 (HTTP 200?)
check_service "Gateway" "http://127.0.0.1:8642/health"
# 2. Dashboard健康 (HTTP 200?)
check_service "Dashboard" "http://127.0.0.1:8050/"
# 3. WebUI健康 (HTTP 200?)
check_service "WebUI" "http://127.0.0.1:8648/"
# 4. BookStack健康 (HTTP 200/302?)
```bash
# 4. Gateway进程异常 (0=全挂告警, >14=溢出告警)
#    正常架构: 1主GW + 11Agent GW = 12进程
#    告警: 0进程(全宕机) 或 >14进程(泄漏/溢出)
check_gateway_leak()    # ps aux | grep 'gateway run' | grep -v grep | wc -l
                       #   == 0  → CRITICAL: 全部宕机
                       #   > 14  → WARNING: 进程溢出
                       #   == 0  → CRITICAL: 全部宕机
                       #   > 14  → WARNING: 进程溢出
# 5. Cron错误 (>0告警)
check_cron_errors()     # hermes cron list | grep "Last run:" | grep -vP '\bok$' | wc -l
# 6. 磁盘使用 (>85%告警)
check_disk()            # df / | awk '{print $5}' > 85
# 7. 记忆膨胀 (>4KB告警+自动压缩)
check_memory_growth()   # wc -c < MEMORY.md > 4000
# ✅ v1.0升级: 检测到>4KB时自动压缩(保留最早条目)，仅在压缩失败后告警
# 此举将记忆修复粒度从30min(anti-degradation)提升到5min(health-alert)
# 设计原则: 常见退化模式直接在触警时自愈，高频巡检自带修复能力
```

**通知方式** (双重保障):
```bash
# 方式0: 清理残留 — 升级脚本后必须先杀旧告警进程
pkill -f "cmmi5-chat-router.py.*SYSTEM_ALERT" 2>/dev/null || true

# 方式1: 飞书(cmmi5-chat-router) — 必须加 timeout 避免孤儿进程
timeout 30 python3 ~/scripts/cmmi5-chat-router.py "SYSTEM_ALERT: ..." || echo "告警发送超时"

# 方式2: hermes chat
hermes chat -z "系统告警: ..." --model "z-ai/glm-4-flash" --provider "zai"
```

**Cron注册**:
```bash
cronjob create --name "Health Alert Monitor" --schedule "*/5 * * * *" \
  --prompt "Run health alert script: bash ~/scripts/health-alert.sh"
```

**触发条件**: 任何多服务故障修复后立即创建。异常时自动通知, 正常时静默("OK: 0 issues found")。

### Type 2: Auto-Generated Health Report (daily-health-report.py)

创建位置: `~/scripts/daily-health-report.py`

**采集指标**:
```python
# 自动采集以下数据生成BookStack风格化报告:
gw_health   = curl :8642/health       # Gateway状态
dash_health = curl :8050/             # Dashboard状态
bs_health   = curl :8080/             # BookStack状态
gw_count    = ps aux | grep gateway   # Gateway进程数
cron_err    = hermes cron list        # Cron错误数
cron_act    = hermes cron list        # Cron活跃数
disk        = df -h /                 # 磁盘使用
memory      = wc -c MEMORY.md         # 记忆大小
evo         = self_assessment.json    # 进化评分
alert       = bash health-alert.sh    # 告警检查结果
```

**输出格式**: BookStack卡通风格页面 (`kb-card-comic` + `kb-grid-3` + `kb-table-anime`)
**调度**: `0 */6 * * *` (每6小时自动归档)
**第一份报告**: 手动运行 `python3 ~/scripts/daily-health-report.py` 验证

**触发条件**: 进化引擎满分(100.0)或系统达到稳定状态后创建。让状态记录自动化, 无需人工写日报。

### Type 3: System Architecture Ops Documentation (BookStack Page)

在完成修复后, 将系统架构、端口映射、Cron调度、修复教训沉淀到BookStack:

**内容模板** (7大板块):
| # | 板块 | 内容 |
|---|------|------|
| 1 | 系统架构概览 | 服务名/端口/进程数/健康状态表 |
| 2 | 端口映射表 | 所有服务+Agent端口+配置位置 |
| 3 | Cron调度体系 | 按周期分组的任务清单 |
| 4 | 波次作战总结 | 修复历史(波次/方向/核心修复) |
| 5 | 关键修复教训 | 每个修复的根因/修复/教训 |
| 6 | 告警系统 | health-alert.sh配置+调度 |
| 7 | 关键文件清单 | 运维脚本路径+用途 |

**格式**: 卡通风格(large emoji封面 + kb-table + kb-grid-2彩色卡片)
**标签**: `系统架构`, `运维手册`, 日期标签, 相关服务标签
**归档位置**: Book 113(迭代升级记录)

**触发条件**: 完成≥2波次修复后创建, 为下次人工或AI介入提供完整上下文。

### Type 4: Anti-Degradation Self-Healing (anti-degradation.sh)

在健康告警系统(被动检测→通知)基础上, 建立**主动修复(检测→修复)**的第二道防线。

**定位区别**:

| 系统 | 频率 | 模式 | 触发 | 行为 |
|------|------|------|------|------|
| health-alert (Type 1) | 每5分钟 | 被动检测 | 发现问题→告警 | 通知人类/AI处理 |
| anti-degradation (Type 4) | 每30分钟 | 主动修复 | 发现问题→自愈 | 自动修复, 无需通知 |

**适用场景**: 已知可自动修复的退化模式(记忆膨胀/Gateway溢出/WebUI离线/Dashboard重复进程)

**创建位置**: `~/scripts/anti-degradation.sh`

**巡检+修复项** (4项全自动):
```bash
# 1. 记忆膨胀 → 自动压缩
#    触发: MEMORY.md > 3KB
#    修复: 合并§分隔的重复日志条目, 保留核心事实
#    验证: wc -c MEMORY.md < 3000

# 2. Gateway进程异常 → 自动清理
#    触发: count == 0 (全死) 或 count > 14 (溢出)
#    修复: count>14→杀多余进程保留最近12个; count==0→启动
#    验证: count == 12

# 3. WebUI离线 → 自动重启 (慢启动兼容)
#    触发: curl :8648 → 000
#    修复: hermes-web-ui start 8648 (轮询等待最长30s)
#    验证: curl :8648 → 200

# 4. Dashboard重复进程 → 自动清理 + 永久断根
# 4. Dashboard重复进程 → 自动清理 + 永久断根
#    触发: 特定Dashboard进程 > 1 (⚠️ 绝不能使用 grep 'app.py' 通用匹配)
#    临时修复 (清理): 
#     1) 找出谁占端口: fuser PORT/tcp (如8050)
#     2) 保留端口LISTEN进程（健康），杀非LISTEN的同一服务进程
#     3) ⚠️ 核心陷阱①: 清理完重复进程后，僵尸进程(zombie/defunct)可能仍holding端口
#        导致新进程启动报 "Address already in use / Port is in use by another program"
#     4) 验证端口释放: fuser PORT/tcp || echo "Port free"
#     5) 若端口仍被占: kill -9 $(fuser PORT/tcp 2>/dev/null) 强制释放
#     6) 再启动: 最终用 background=true 启动新进程
#    永久修复 (PID锁断根):
#     7) 在服务的 app.py/入口文件 中添加 PID 锁机制, 防止同一服务启动多个实例:
#        ```python
#        import os, sys, atexit
#        PID_FILE = "/tmp/<service-name>.pid"
#        def check_pid_lock():
#            if os.path.exists(PID_FILE):
#                with open(PID_FILE) as f:
#                    try: old_pid = int(f.read().strip())
#                    except: old_pid = None
#                if old_pid and os.path.isdir(f"/proc/{old_pid}"):
#                    print(f"[LOCK] Existing PID={old_pid} still running. Exiting.", flush=True)
#                    sys.exit(0)
#            with open(PID_FILE, "w") as f:
#                f.write(str(os.getpid()))
#            atexit.register(lambda: os.path.exists(PID_FILE) and os.remove(PID_FILE))
#        check_pid_lock()  # 放在所有 import 之前
#        ```
#     8) 重启服务使 PID 锁生效
#     9) 验证重复启动防护: 再次启动服务 → 应显示 `[LOCK] Existing PID=X still running. Exiting.`
#    验证: 
#     1) ss -tlnp | grep PORT → 应显示1个LISTEN进程
#     2) app.py进程 == 1 (bash wrapper不计)
#     3) cat /tmp/<service-name>.pid → 应与当前进程PID一致
#     4) 再次执行启动命令 → 显示 [LOCK] 信息且不启动新进程
```

**Cron注册**:
```bash
cronjob create --name "Anti-Degradation Loop" --schedule "*/30 * * * *" \
  --prompt "Run anti-degradation self-heal: bash ~/scripts/anti-degradation.sh"
```

**设计原则**:
1. **Fix-first, no alert** — 修复成功则静默, 无需通知
2. **Graceful degradation** — WebUI慢启动兼容(while循环轮询, 固定sleep(5)失败后回退)
3. **Kill safe** — 杀多余进程时保留最近PID而非最旧(防误杀新起进程)
4. **Threshold safety margin** — Gateway阈值留2个缓冲(正常12, 告警>14), 防误报
5. **Post-repair verification** — 每个修复项修复后立即验证, 失败记error但继续下一项

**关键验证 (OODA Loop)**: 通过health-alert来验证anti-degradation的效果:
```bash
# anti-degradation修复后, health-alert应报0个问题
bash ~/scripts/health-alert.sh  # → "OK: 0 issues found"
```

**触发条件**: 完成P0多服务故障修复后立即创建。作为"最后一英里"堡垒, 防止新部署/变更导致系统缓慢退化。

### 三层防护验证清单

```bash
# Layer 1: Dashboard 实时监控
curl -s http://127.0.0.1:8050/api/services | python3 -c "import sys,json;d=json.load(sys.stdin);print('GW:',d['gateway']['count'],'procs, alive:',d['gateway']['main_alive'],'| WebUI:',d['webui']['alive'])"

# Layer 2: 主动告警
bash ~/scripts/health-alert.sh
# 预期输出: "OK: 0 issues found"

# Layer 3: 自动归档
python3 ~/scripts/daily-health-report.py
# 预期输出: "✅ Report created: ID=X"
curl -s -o /dev/null -w "%{http_code}" http://localhost:8080/books/113
```

### 关键教训

| # | 教训 | 规则 |
|---|------|------|
| 1 | 修复后必须加监控, 否则同类问题会再次发生 | ⚡ 每次P0修复后72小时内必须建立告警 |
| 2 | Gateway泄漏不会自愈, 必须主动巡检 | ⚡ health-alert必须包含进程数阈值检查 |
| 3 | 知识文档必须在修复完成后立即创建 | ⚡ 48小时内不记录, 60%细节会被遗忘 |
| 4 | 告警必须双通道(飞书+hermes chat) | ⚡ 单通道故障时告警失效 |
| 5 | **`grep 'app.py'` 是危险模式 — 会误杀其他服务的 app.py 进程** | ⚡ 匹配Dashboard重复进程时用 `grep '/hermes-dashboard/app.py'` 仅匹配指定路径的进程。系统中可能有多个服务都用 app.py 作为入口文件（如PromptHub、Prompt Optimizer），通用匹配会导致误杀。同理适用于所有 `grep` 进程名检测模式：路径+进程名=安全，纯进程名=危险。

---

## Post-Incident Improvement Execution — 复盘改进执行

### 适用场景

在事故复盘报告（Postmortem）已写入知识库后，报告中的"改进项"(TODO items)需要被执行。此流程确保每项改进落到实处，防止复盘报告变成"阅后即焚"的文件。

### 7步执行法

```
┌─────────────┐
│ 1. 提取清单  │  从复盘报告中提取所有待办改进项
├─────────────┤
│ 2. 优先级排序 │  P0(阻塞) > P1(核心) > P2(优化)
├─────────────┤
│ 3. 并行派发  │  独立项并行执行(terminal/file终端)
├─────────────┤
│ 4. 逐个实施  │  每项: 创建→验证→确认
├─────────────┤
│ 5. 更新报告  │  BookStack/Wiki中状态标记为"已完成"
├─────────────┤
│ 6. 更新标签  │  添加"改进项: 全部已完成"标签
├─────────────┤
│ 7. 最终验证  │  start-all.sh status 全服务健康检查
└─────────────┘
```

### 执行模式

| 模式 | 适用场景 | 方法 |
|------|----------|------|
| **叶子模式** | 独立不依赖的任务 | `delegate_task(role="leaf")` 并行执行 |
| **顺序模式** | 有依赖链的任务 | 按依赖顺序逐个执行 |
| **合并模式** | 同类批量操作 | 脚本化批量处理 |

### 改进项状态管理

任务完成后的状态更新：

```python
# 1. BookStack页面: tag更新
PUT /api/pages/{id}  # tags添加"改进项: 全部已完成"

# 2. BookStack页面: 表格内容更新
PUT /api/pages/{id}  # HTML内 ⏳ 待办 → ✅ 已完成

# 3. Wiki文档: Markdown同步更新
write_file(~projects/hermes-wiki/incidents/...)

# 4. Todo tracker
todo(action="update", id="...", status="completed")
```

### 常用改进项类型

| 类型 | 典型示例 | 交付物 |
|------|----------|--------|
| 脚本修复 | start-bookstack.sh双重进程检测 | Bash脚本patch |
| Cron升级 | status→auto-restart | Cron update/create |
| 配置补全 | .env缺失环境变量 | 文件修改 |
| 文档创建 | Provider配置总览/Checklist | BookStack Page |
| 基础设施 | systemd user unit | `.config/systemd/user/*.service` |
| 监控增强 | 统一健康检查cron | 巡检脚本 + Cron |

---

## Drill Mode — 主动韧性演练

不同于被动响应真实事故，Drill Mode 主动注入故障来**验证自愈系统的有效性**。与 chaos-engineer + self-healer 协同工作。

### 演练流程 (5 Phase)

```bash
# Phase 1: Baseline
python3 chaos-engineer/scripts/verify_resilience.py --run
python3 ~/.hermes/healer/orchestrator.py --check

# Phase 2: Inject fault
# CPU: python3 chaos-engineer/scripts/cpu_stress.py --run --workers 8 --duration 30
# Memory: python3 chaos-engineer/scripts/mem_stress.py --run --size 200 --duration 5
# Process: python3 chaos-engineer/scripts/process_kill.py --run
# Orchestrated: python3 chaos-engineer/scripts/chaos_runner.py --plan experiments/cpu_burn.json

# Phase 3: Detect + Diagnose
python3 ~/.hermes/healer/orchestrator.py --check
python3 ~/.hermes/healer/diagnose.py "simulated error message"

# Phase 4: Heal
python3 ~/.hermes/healer/heal.py "ImportError: No module named 'x'" --dry-run

# Phase 5: Verify + Report
python3 chaos-engineer/scripts/verify_resilience.py --run
# Record incident: append to ~/.hermes/healer/incidents/journal.jsonl
```

### 实战经验 (DRILL-2026-05-05-001)

完整报告: `~/.hermes/healer/incidents/DRILL-2026-05-05-001.md`

**Finding 1**: `heal.py auto_install` 策略 FixAttempt 缺少 `details` 参数 (CRITICAL)
- **症状**: 任何 `ImportError` 触发 TypeError 崩溃而非自动修复
- **根因**: `FixAttempt.__init__()` 需要 4 个位置参数 `(strategy, timestamp, success, details)`，但 `auto_install()` (L424-430) 只传了 3 个
- **修复**: 在 `~/.hermes/healer/heal.py` L429 新增 `details=f"Auto-install attempt for package: {package_name or 'unknown'}"`
- **教训**: 任何 `FixAttempt` 创建点必须包含全部 4 个必需字段

**Finding 2**: 自愈系统缺 CPU 监测探针 (MINOR)
- **症状**: CPU 8 worker/30s 压力不触发任何告警
- **修复**: 在 `~/.hermes/healer/monitor.py` 新增 CPU idle 探针（读 /proc/stat, 阈值 <20% = WARNING, <5% = CRITICAL）
- **验证**: `python3 ~/.hermes/healer/orchestrator.py --check` 应显示 `cpu_utilization_pct`

**Finding 3**: chaos_runner 需要 `--run` 参数才能执行 (MINOR)
- **症状**: `--plan X.json` 单独执行只打印 help 不运行
- **修复**: `chaos_runner.py` L112 将条件从 `if not args.run` 改为 `if not args.run and not args.plan and not args.plan_stdout`
- **教训**: argparse 中 `--plan` 和 `--run` 是独立 flags，传 `--plan` 必须同时传 `--run` 或修改条件逻辑

### 报告模板

演练报告存至 `~/.hermes/healer/incidents/DRILL-YYYY-MM-DD-NNN.md`。结构:
- Executive Summary
- Drill Timeline (时间线+各阶段状态)
- Findings (bug/缺口/正向发现)
- Metrics (KPI达标表)
- Recommendations (优先级排序改进行动)

## Feedback Engine Patches
*自动生成于 2026-07-16 02:02:04*

## Tool Recommendations (from trajectory feedback)

### patch
Trajectory analysis shows **patch** strongly correlates with high session scores.
- Use `patch` for targeted find-and-replace edits instead of sed/awk.
- Supports fuzzy matching with 9 strategies for robust edits.
- Auto-runs syntax checks after modification.
- Preferred for surgical code changes over full file rewrites.

### Guardrails
- Ensure `old_string` is unique in the file unless `replace_all=True`.
- Include enough surrounding context to guarantee uniqueness.
- Use `mode='patch'` for V4A multi-file patches.

### Efficiency Tips
- Combine multiple edits into a single V4A patch when possible.
- Use `replace_all=True` for bulk replacements of the same pattern.
- Preview changes with `--dry-run` mode before applying.

---
## Feedback Engine Patches
*自动生成于 2026-07-17 02:02:37*

## Tool Recommendations (from trajectory feedback)

### read_file
Trajectory analysis shows **read_file** strongly correlates with high session scores.
- Preferred over cat/head/tail in terminal.
- Use this for reading text files with line numbers and pagination.
- Supports offset and limit for large file navigation.

---
## Feedback Engine Patches
*自动生成于 2026-07-17 02:02:37*

## Tool Recommendations (from trajectory feedback)

### patch
Trajectory analysis shows **patch** strongly correlates with high session scores.
- Use `patch` for targeted find-and-replace edits instead of sed/awk.
- Supports fuzzy matching with 9 strategies for robust edits.
- Auto-runs syntax checks after modification.
- Preferred for surgical code changes over full file rewrites.

### Guardrails
- Ensure `old_string` is unique in the file unless `replace_all=True`.
- Include enough surrounding context to guarantee uniqueness.
- Use `mode='patch'` for V4A multi-file patches.

### Efficiency Tips
- Combine multiple edits into a single V4A patch when possible.
- Use `replace_all=True` for bulk replacements of the same pattern.
- Preview changes with `--dry-run` mode before applying.

---
## Feedback Engine Patches
*自动生成于 2026-07-21 08:58:12*

## Tool Recommendations (from trajectory feedback)

### write_file
Trajectory analysis shows **write_file** strongly correlates with high session scores.
- Use `write_file` to create new files or overwrite existing ones.
- Preferred over terminal heredoc for structured file creation.
- Automatically creates parent directories.

### Guardrails
- Always use absolute paths to avoid ambiguity.
- Creates parent directories — verify the intended path before writing.
- Overwrites entire file content — if you need targeted edits, use `patch` instead.

### Efficiency Tips
- Batch content creation: write whole files at once instead of appending line-by-line.
- For large files, consider splitting into multiple smaller files.
- Use `patch` for incremental updates to avoid full rewrites.

---
## Feedback Engine Patches
*自动生成于 2026-07-22 12:19:48*

## Tool Recommendations (from trajectory feedback)

### patch
Trajectory analysis shows **patch** strongly correlates with high session scores.
- Use `patch` for targeted find-and-replace edits instead of sed/awk.
- Supports fuzzy matching with 9 strategies for robust edits.
- Auto-runs syntax checks after modification.
- Preferred for surgical code changes over full file rewrites.

### Guardrails
- Ensure `old_string` is unique in the file unless `replace_all=True`.
- Include enough surrounding context to guarantee uniqueness.
- Use `mode='patch'` for V4A multi-file patches.

### Efficiency Tips
- Combine multiple edits into a single V4A patch when possible.
- Use `replace_all=True` for bulk replacements of the same pattern.
- Preview changes with `--dry-run` mode before applying.

---
## Feedback Engine Patches
*自动生成于 2026-07-22 12:19:49*

## Tool Recommendations (from trajectory feedback)

### read_file
Trajectory analysis shows **read_file** strongly correlates with high session scores.
- Preferred over cat/head/tail in terminal.
- Use this for reading text files with line numbers and pagination.
- Supports offset and limit for large file navigation.
