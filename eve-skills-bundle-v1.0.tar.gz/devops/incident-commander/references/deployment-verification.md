# Deployment Verification Pattern

## The Principle

**"I deployed the fix" is a hypothesis, not a fact — until independently verified.**

When a team member claims to have deployed a fix (started a service, pushed a script, configured a cron job), **always verify independently** before updating the incident status:

| Claim | What to verify | Method |
|-------|---------------|--------|
| "I wrote the script" | File content, not just existence | `cat <file>` |
| "I set up the cron job" | Cron actually runs and succeeds | `crontab -l` + `grep <script> cron.log` |
| "I fixed the startup command" | The command is syntactically valid | Try running it manually |
| "The service is running" | Port is listening AND API responds | `nc -z localhost <port>` + `curl` health endpoint |
| "I patched the bug" | Old string is gone, new string is present | diff the file before/after |

## Case Study: keepalive.sh (2026-06-06)

### Context
Three critical services (PM System :8768, Cold Email :8769, CMMI5 Engine :8770) had been down for 24+ hours. DevOps posted a detailed plan to deploy `keepalive.sh` — a cron-driven watchdog that would check and restart the services every minute.

### The Claim
> "我已经写好了keepalive.sh的思路，现在就去执行"
> "18:30前 | 部署keepalive.sh + cron | 现在做"

### The Reality
- ✅ Script file **was created** at `~/company/scripts/keepalive.sh`
- ✅ Cron entry **was configured** in crontab
- ❌ **But neither was verified** — the script had:
  - PM system command: `python -m pmserver` → **module does not exist** (real entry is `pm-api.py`)
  - Cold email command: `""` → **empty string** (real entry is `send-cold-email.py`)
  - CMMI5 command: `""` → **empty string** (real entry is `cmmi5-eve-bridge.py`)
- ❌ The cron ran every minute, failed every minute, and the log accumulated **25+ FAIL entries** — generating noise, not value

### The Root Cause
The author stopped at "I wrote it" and never took the final step: **running it once to see if it works**.

### The Fix
A second engineer (Maker2) independently:
1. Read the log file (`keepalive.log`) — noticed 25+ consecutive FAIL
2. Read the script (`keepalive.sh`) — found the wrong commands
3. Found the actual service files (`pm-api.py`, `send-cold-email.py`, `cmmi5-eve-bridge.py`)
4. Patched all three commands with correct paths
5. Posted findings publicly so the whole team learns

## Verification Checklist

Before marking a deployment task as "done", run this chain:

```
1. File exists?           → ls <path>
2. File is executable?    → head -1 <path>  (check shebang) + ls -l
3. Content is correct?    → cat <path> | grep -n <key-command>
4. Cron is configured?    → crontab -l | grep <script>
5. Run once manually?     → bash <path>  (dry run, check output)
6. Log is produced?       → cat <logfile>
7. Service is listening?  → nc -z localhost <port>
8. API is responding?     → curl http://localhost:<port>/health
```

Missing any step? The "deployment" is incomplete.

## Why This Pattern Matters

In multi-agent incident response, the **gap between intention and execution** is the most common failure mode. An agent can:
- Write a detailed plan ✓
- Create the file ✓
- Configure the cron ✓  
- **Forget to verify it actually works** ✗

This isn't laziness — it's the **planning fallacy**: humans (and agents) systematically underestimate the gap between "I wrote it" and "it runs correctly."

**Rule**: Every deployment claim must be followed by a verification post from a **different agent** before the incident is closed. No peer verification = no resolution.
