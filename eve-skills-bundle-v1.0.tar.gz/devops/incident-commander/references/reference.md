# incident-commander — Reference

## Overview
自主SRE事故指挥官 — 检测→诊断→修复→验证→学习 全闭环。对标 Lethe044 hermes-incident-commander。触发词："incident"/"事故响应"/"SRE"/"service down"/"生产事故"。

## Integration Points
- Hermes Agent skill ecosystem
- evolution_engine.py scoring system
- self-audit verification

## Key Resources
- SKILL.md: main skill definition
- scripts/: executable code (if present)

## Known Patterns

### Feishu Multi-Gateway Connection Conflict
**Symptom**: Feishu group chat not responding, WebSocket keepalive timeouts every ~10 min.
**Root cause**: Multiple Gateway processes (1 main + 10+ agent profiles) each establish an independent Feishu WebSocket connection. Feishu server cannot sustain 12 concurrent WS connections → keepalive timeout → reconnection cycle → message loss.
**Diagnosis**:
  1. Count Gateway processes: `ps aux | grep "hermes.*gateway" | grep -v grep`
  2. Check Feishu WS logs: `journalctl -u hermes-gateway.service | grep "feishu\|lark\|keepalive\|timeout"`
  3. Monitor lock files: `ls ~/.local/state/hermes/gateway-locks/feishu-*.lock`
**Fix**:
  1. Disable Feishu in profile configs: set `feishu.enabled: false` in each `~/.hermes/profiles/<agent>/config.yaml`
  2. Kill extra agent Gateways: `kill -9 <PID>` for all `hermes gateway run --profile <agent>`
  3. Clean stale lock files: `rm -f ~/.local/state/hermes/gateway-locks/feishu-*.lock`
  4. Verify: Only 1 Gateway (main) should have Feishu active
**Result**: 12 Gateways → 3 Gateways (1 main + 2 API-only profiles). Stable single Feishu WS connection, zero keepalive timeouts.

### Deployment Verification Pattern
**Symptom**: An agent claims "I deployed the fix" but the service remains down — the script has syntax errors, wrong paths, or empty commands.
**Root cause**: The gap between "I wrote it" and "it runs correctly" — agents stop after creating the file without verifying execution.
**Diagnosis**:
  1. Check the log that should be produced by the fix: `cat <logfile> | tail -20`
  2. Check the script itself, not just that it exists: `cat <script.sh>`
  3. Check the cron entry: `crontab -l | grep <script>`
**Fix**:
  1. Run the script manually once: `bash <script>`
  2. Watch for errors in stdout/stderr
  3. Verify the intended effect (port listening, API responding, pid file present)
  4. Mandatory peer review — a different agent verifies before closing the incident
**Prevention**:
  - Deployment Verification Checklist: file exists → executable → content correct → cron configured → runs once → log produced → service up → API responds
  - No incident closure without a verification post from a different role
  - See `references/deployment-verification.md` for full case study

### CMMI5 Pipeline Task Registration
**Context**: When pipeline is idle (all tasks completed), agents need new tasks to resume.
**Steps**:
  1. Register tasks: `cd ~/projects/hermes-infra/agent-bridge && python3 agent_bridge.py register --agent <AGENT> --name <TASK-NAME>`
  2. Create context transfer: `python3 agent_bridge.py context submit --source <AGENT> --target <AGENT> --type "任务分配" --summary "<summary>"`
  3. Verify: `python3 agent_bridge.py status`
**Agents**: PM, REQ, ARCH, DEV, SEC, TEST, QA, CM, DOC, SPI
