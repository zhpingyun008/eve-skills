# Multi-Agent Gateway Failure Recovery

## 典型场景: 系统重启后全部Agent离线

系统重启后，`hermes gateway list` 显示所有(或大部分)profile gateways为`stopped`。
Heartbeat脚本报 `0/15 Agents Healthy` 或类似数据。

## 根因分析

### 1. 旧PID残留 + Feishu锁冲突

重启后旧的gateway进程可能仍然存活(或PID文件残留)，
占用Feishu app_id资源。
新启动的gateway尝试连接Feishu时发现同一app_id已被占用，直接退出：

```
ERROR gateway.run: Gateway hit a non-retryable startup conflict: feishu:
Another local Hermes gateway is already using this Feishu app_id (PID XXXX).
```

### 2. Gateway `--replace` 效果有限

`hermes gateway run --profile <name> --replace` 并不会总是kill旧进程。
需要手动操作。

### 3. Heartbeat硬编码端口不匹配

`heartbeat-agent.py` 若写死端口(如 `"arch": 8662`)，重启后实际端口可能变，导致误报。

### 4. Profile独立.env的Key过期

部分profile(如`dev`)有自己独立的`.env`，可能包含已过期的API Key，
导致内部cron任务报401。

## 修复步骤

### Step 1: 扫描所有profile网关状态

```bash
hermes gateway list
```

### Step 2: 杀掉所有旧gateway进程(除default外)

```bash
# 从hermes gateway list获取旧PID
for pid in <OLD_PIDS>; do
    kill $pid 2>/dev/null && echo "Killed PID $pid"
done
```

### Step 3: 逐个重启

```bash
# 对每个stopped profile
hermes gateway run --profile <name> --replace
```

使用 `background=true` + 等待健康检查:

```bash
sleep 15
code=$(curl -s -o /dev/null -w "%{http_code}" --connect-timeout 3 \
  "http://127.0.0.1:<port>/health" 2>/dev/null || echo "000")
```

### Step 4: 验证心跳

```python
# 确保 heartbeat 脚本从 config.yaml 动态读取端口
# 不要硬编码端口号
import re
with open(f"~/.hermes/profiles/{name}/config.yaml") as f:
    for line in f:
        m = re.search(r'^\s*port:\s*(\d+)', line)
        if m:
            port = int(m.group(1))
```

### Step 5: 修复profile独立的过期Key

```bash
# 检查profile自有.env
cat ~/.hermes/profiles/<name>/.env | grep "API_KEY"

# 与主.env同步
WORK_KEY=$(grep "DEEPSEEK_API_KEY" ~/.hermes/.env | cut -d= -f2)
sed -i "s/DEEPSEEK_API_KEY=.*/DEEPSEEK_API_KEY=$WORK_KEY/" \
  ~/.hermes/profiles/<name>/.env

# 重启profile使新key生效
```

## 已知坑点

- **`test` profile名保留**: Hermes保留`test`为系统名，该profile永远无法启动，应从heartbeat排除
- **Feishu app_id全局唯一**: 所有profile通常共用同一Feishu app_id，一次只能一个gateway使用
- **Gateway日志中Port in use**: 即使kill了旧PID，OS可能短暂保留端口；`sleep 5`后再启动新实例
- **Profile cron job**: 每个profile的内部cron任务使用自己的.env配置，与主环境隔离
