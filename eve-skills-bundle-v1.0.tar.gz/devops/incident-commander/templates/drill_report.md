# SRE Drill Report Template

**Drill ID:** DRILL-YYYY-MM-DD-NNN  
**Date:** YYYY-MM-DD  
**Environment:** [WSL/Docker/K8s]

## Executive Summary
[1-2 sentence summary of the drill: what was tested, what was found, overall status]

## Drill Timeline

| Time | Phase | Action | Status |
|:----|:------|:-------|:------:|
| T+0s | Baseline | System health snapshot | ✅/❌ |
| T+N | Inject | Fault type + params | ✅/❌ |
| T+N | Detect | Healer check result | ✅/❌ |
| T+N | Diagnose | Error classification | ✅/❌ |
| T+N | Heal | Auto-remediation result | ✅/❌ |
| T+N | Verify | Recovery metrics | ✅/❌ |

## Findings

### Finding N: [Title] (SEVERITY)
- **Observation:** [What happened]
- **Impact:** [Why it matters]
- **Fix:** [How to fix]
- **Status:** FIXED / OPEN

## Metrics

| KPI | Target | Actual | Status |
|:----|:-----:|:-----:|:------:|
| Fault injection success | 100% | | ✅/❌ |
| Diagnose classification | >60% confidence | | ✅/❌ |
| Auto-heal success | 100% | | ✅/❌ |
| System recovery | 100% | | ✅/❌ |
| Incident recorded | ≥1 | | ✅/❌ |

## Recommendations

1. **HIGH**: [Most impactful fix]
2. **MEDIUM**: [Important improvement]
3. **LOW**: [Nice to have]
