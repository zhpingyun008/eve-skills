---
category: devops
description: Create, update, and organize reusable document templates in BookStack's
  📋 文档模板库 shelf. Covers creating template pages with placeholders/instructions under
  category books (项目管理模板/技术文档模板/会议纪要模板/需求规格模板等), managing template hierarchy, and
  converting real project pages into reusable templates.
name: bookstack-template-manager
triggers:
- 保存为模板 / 创建模板 / 模板管理 / 文档模版
- save as template / create template / template library / 项目管理模版
- BookStack template / 文档模板库 / reusable template / 可复用模板
- project template / 项目模板 / workload template / 工作量清单模板
---

# BookStack Template Manager

Manage reusable document templates in the 📋 文档模板库 shelf within BookStack. This skill covers creating, updating, and organizing template pages that serve as starting points for new project documents.

## Architecture

```
📋 文档模板库 (Shelf ID=1416)
├── 01 📊 项目管理模板 (Book ID=1417)
│   ├── 📋 XX项目需求工作量清单模板
│   ├── 📋 XX项目立项报告模板
│   ├── 📈 项目进度报告模板
│   └── ...
├── 02 💻 技术文档模板 (Book ID=1418)
├── 03 📝 会议纪要模板 (Book ID=1419)
├── 04 📋 需求规格模板 (Book ID=1420)
├── 05 🎨 设计文档模板 (Book ID=1421)
├── 06 🧪 测试文档模板 (Book ID=1422)
├── 07 🔧 运维文档模板 (Book ID=1423)
└── 08 📈 汇报总结模板 (Book ID=1424)
```

## Workflow

### Step 0: PRE-CREATION AUDIT — Extract reference template style FIRST
⚠️ **CRITICAL GATE**: Before writing ANY template HTML, you MUST fetch an existing template's HTML from the target book to confirm the exact CSS classes in use. Do NOT assume you know the style from memory.

```python
# Fetch a reference template to confirm CSS classes
import requests
r = requests.get('http://localhost:8080/api/pages/{reference_page_id}',
    headers={'Authorization': 'Token ...'})
ref_html = r.json()['html']
# Scan for key classes: kb-card-comic, kb-badge, kb-cartoon-divider, kb-section-title, kb-table-anime
```

Audit checklist (3 minimum — check 2-3 templates in the target book):
- [ ] All templates use `kb-card-comic` for header? (Not plain div with inline styles)
- [ ] Consistent badge colors: purple=category, green=status, blue=standard?
- [ ] Section headers use `kb-section-title` with inner `kb-icon` span?
- [ ] Tables use `kb-table kb-table-anime` with `#6c5ce7` purple for primary tables?
- [ ] Separators use `kb-cartoon-divider` with ✦ ✦ ✦ text?
- [ ] Info boxes use `kb-card` with colored left border?

**Only after confirming the pattern** should you proceed to write template HTML.

### Step 1: Survey existing template landscape
Before creating, check what already exists:
```python
# Get shelf details
GET /api/shelves/1416 → find all books
# Get template book contents
GET /api/books/{book_id} → list existing pages
```

### Step 2: Determine target category
| Template Type | Target Book | Book ID |
|---------------|-------------|---------|
| 项目管理 | 01 📊 项目管理模板 | 1417 |
| 技术文档 | 02 💻 技术文档模板 | 1418 |
| 会议纪要 | 03 📝 会议纪要模板 | 1419 |
| 需求规格 | 04 📋 需求规格模板 | 1420 |
| 设计文档 | 05 🎨 设计文档模板 | 1421 |
| 测试文档 | 06 🧪 测试文档模板 | 1422 |
| 运维文档 | 07 🔧 运维文档模板 | 1423 |
| 汇报总结 | 08 📈 汇报总结模板 | 1424 |

### Step 3: Create template page
```python
# Template page payload structure
payload = {
    "book_id": 1417,  # target book ID
    "name": "📋 XX项目需求工作量清单模板",
    "html": template_html,  # see Step 4
    # Note: `template: true` flag exists in BookStack API but 
    # existing templates don't use it — they're regular pages in a template book
}
POST /api/pages or PUT /api/pages/{id}
```

### Step 4: Template HTML structure — MUST use BookStack cartoon style
⚠️ **CRITICAL**: All existing templates in 项目管理模板 use the **卡通风格** (cartoon/comic style), NOT plain HTML. Match this exactly or the style will look inconsistent.

**Template structure — cartoon style template:**

```html
<!-- HEADER BANNER: kb-card-comic class + emoji + badges -->
<div class="kb-card-comic" style="text-align:center;padding:30px 20px;">
<div style="font-size:48px;margin-bottom:10px;">📋</div>
<h1 style="font-size:1.8em;font-weight:800;">XX项目需求工作量清单</h1>
<div style="margin-top:10px;">
<span class="kb-badge kb-badge-purple kb-badge-lg">📊 项目管理</span>
<span class="kb-badge kb-badge-green kb-badge-lg">✅ 标准模板</span>
<span class="kb-badge kb-badge-blue kb-badge-lg">📅 CMMI5规范</span>
</div>
<p style="color:#636e72;margin-top:12px;"><strong>项目名称</strong>: <span style="color:#999;">[请填写]</span></p>
</div>

<!-- CARTOON DIVIDER: ✦ ✦ ✦  -->
<div class="kb-cartoon-divider">✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦</div>

<!-- SECTION HEADER: kb-section-title + kb-icon -->
<h2 class="kb-section-title"><span class="kb-icon">📌</span>填写说明</h2>
<ol>
  <li><strong>序号</strong> — 自动递增，按模块分组</li>
  <!-- ... more items ... -->
</ol>

<!-- CARTOON DIVIDER -->
<div class="kb-cartoon-divider">✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦</div>

<!-- DATA TABLE: kb-table kb-table-anime -->
<h2 class="kb-section-title"><span class="kb-icon">📊</span>工作量清单总表</h2>
<table class="kb-table kb-table-anime">
<thead>
<tr style="background:#6c5ce7;color:white;font-weight:bold;">
  <th style="border:1px solid #dfe6e9;padding:8px;text-align:center;width:35px;">序号</th>
  <th style="border:1px solid #dfe6e9;padding:8px;text-align:left;width:110px;">功能/模块</th>
  <!-- ... all 14 columns with #6c5ce7 purple header ... -->
</tr>
</thead>
<tbody>
<tr>
  <td style="border:1px solid #dfe6e9;padding:6px;text-align:center;">1</td>
  <td style="border:1px solid #dfe6e9;padding:6px;font-weight:bold;">[模块名称]</td>
  <!-- ... example row cells ... -->
  <td style="border:1px solid #dfe6e9;padding:6px;text-align:center;">新增</td>
  <td style="border:1px solid #dfe6e9;padding:6px;font-size:11px;">SRS第X章</td>
</tr>
</tbody>
</table>

<!-- REFERENCE SECTION: cartoon divider + section title -->
<div class="kb-cartoon-divider">✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦</div>
<h2 class="kb-section-title"><span class="kb-icon">📐</span>工作量预估准则</h2>
<table class="kb-table kb-table-anime">
<thead>
<tr style="background:#a29bfe;color:white;">
  <!-- lighter purple for secondary tables -->
</tr>
</thead>
</table>

<!-- INFO CARD: kb-card -->
<div class="kb-card" style="border-left:4px solid #6c5ce7;padding:12px;">
<ul>
  <li><strong>研发 50-60%</strong> — 编码实现、单元测试、代码审查</li>
  <!-- ... -->
</ul>
</div>

<p style="text-align:center;color:#b2bec3;font-size:0.85em;">📋 文档模板库 · 项目管理模板 · 版本 V1.0</p>
```

**Key style rules:**
| Element | Class/Style | Description |
|---------|-------------|-------------|
| Header banner | `kb-card-comic` | Centered card with emoji icon + title + badges |
| Badges | `kb-badge kb-badge-{color} kb-badge-lg` | Colors: purple/green/blue/red/yellow |
| Dividers | `kb-cartoon-divider` | `✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦` text content |
| Section headers | `kb-section-title` + inner `<span class="kb-icon">` | Colored/icon headers |
| Primary table | `kb-table kb-table-anime` with #6c5ce7 purple header | Main data tables |
| Secondary table | `kb-table kb-table-anime` with #a29bfe lighter header | Reference/proportion tables |
| Info boxes | `kb-card` with colored left border | Tips/references |
| Badge colors | purple=category, green=status, blue=standard, red=important, yellow=medium | Use `kb-badge-{purple/green/blue/red/yellow}` |

**Placeholder convention:**
- `[请填写项目名称]` — gray `#999` text in brackets
- `[YYYY-MM-DD]` — date placeholder
- `[模块名称]`, `[子功能名称]` — generic placeholder text

### Step 5: Source templates from real project data
When the user asks to "save X as a template":

1. Get the source page HTML from BookStack:
   ```python
   GET /api/pages/{source_page_id}
   ```

2. **Generalize the content**: Replace specific project names/values with placeholders:
   - `HNair海外网订单后台系统` → `XX项目`
   - Specific dates → `[YYYY-MM-DD]`
   - Actual data rows → A single example row with `[placeholder]` values
   - Specific totals → Remove or replace with explanatory text

3. **Add instructions**: Include clear filling instructions at the top

4. **Post to target book**: Create under the appropriate category book in 📋 文档模板库

### Step 6: Verify
- Open the page URL in browser to check rendering
- Verify placeholders are clearly distinguishable (gray color or `[...]` brackets)
- Spot-check that example data makes sense

## Pitfalls
- ⚠️ BookStack API token format: `Authorization: Token {token}` (not Bearer)
- ⚠️ The `template: true` flag for BookStack pages is supported by the API but existing templates don't use it — they're regular pages organized under the template books
- ⚠️ When generalizing real project data, ensure all project-specific names/dates/values are replaced with placeholders — nothing hardcoded
- ⚠️ Keep HTML simple — BookStack WYSIWYG editor strips complex CSS on re-edit
- ⚠️ Use `json.loads(strict=False)` when parsing page HTML that may contain unescaped characters
- ⚠️ Template name should start with 📋 and contain "模板" suffix for consistency
- ⚠️ Long inline curl POST payloads with Chinese characters may fail — use Python scripts with json.dumps(ensure_ascii=False) instead
- ⚠️ **CRITICAL: Match existing template style!** Before creating, check existing templates in the target book (via browser). The 项目管理模板 book uses **卡通风格** (kb-card-comic/badges/cartoon-divider/section-title/kb-table-anime). Do NOT use plain `style="background:#2c3e50"` or the user will reject it as style mismatch.
- ⚠️ **Verify visually after creating** — API may accept the content but the rendered style could differ from expectations. Always open the page in the browser to confirm.

## Related Workflow: Page Rename + Cross-Reference Cleanup

When a project page is renamed (e.g., "HNair收银台系统" → "海外网订单后台系统"), related pages that reference the old name need batch updates.

### Workflow

```python
# Step 1: Rename the page
requests.put(f'http://localhost:8080/api/pages/{page_id}',
    headers=headers,
    json={"name": "新页面名称"})

# Step 2: Find related pages that reference the old name
# Check: SRS page → workload list page → project book pages
related_pages = [1917, 1919, ...]  # gather from context
for pid in related_pages:
    resp = requests.get(f'http://localhost:8080/api/pages/{pid}', headers=headers)
    data = resp.json()
    html = data.get('html', '')
    if old_name in html:
        # Step 3: Replace old name in content
        new_html = html.replace(old_name, new_name)
        requests.put(f'http://localhost:8080/api/pages/{pid}',
            headers=headers,
            json={"html": new_html})
```

### Pitfalls
- Use `str.replace(old, new)` — simple string replacement works for names
- Check the page's `html` field for references (BookStack API returns full rendered HTML)
- After cleanup, verify with `r['output'].count('OldName')` — should be 0
- Update page names in the same cycle: page name + book name + shelf name if applicable
- Also check for partial references (e.g., "HNair" → "海外" may catch more than expected)

## Related Skills
- **bookstack-structured-import**: Import actual project data (workload tables, WBS) into project books. Complementary — use when importing real data vs creating templates
- **bookstack-cartoon-style**: BookStack page CSS styling and theming
- **bookstack-kb-architecture**: Knowledge base shelf/book/chapter design