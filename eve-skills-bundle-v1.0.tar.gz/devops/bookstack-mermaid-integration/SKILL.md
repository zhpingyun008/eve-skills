---
name: bookstack-mermaid-integration
description: BookStack + Mermaid diagram rendering integration. Loads Mermaid CDN without auto-start, uses Blade template to extract Mermaid code from CodeMirror code blocks (.cm-line divs), renders via mermaid.render() API. Preserves original code for AI readability while displaying SVG rendered diagrams for humans.
category: devops
triggers:
  - "mermaid"
  - "bookstack diagram"
  - "渲染图表"
  - "BookStack图表"
  - "diagram rendering"
  - "流程图BookStack"
  - "mermaid not rendering"
  - "立项报告"
  - "项目图表"
  - "业务流程图"
  - "系统架构图"
  - "部署图"
  - "功能结构图"
  - "用例图"
  - "api-authoring"
  - "bookstack api mermaid"
  - "mermaid显示代码"
  - "mermaid空白"
  - "mermaid graph TD raw text"
  - "--&gt; mermaid"
  - "html entity mermaid"
  - "Mermaid在div中不渲染"
  - "bare div mermaid"
  - "Blade模板mermaid"
  - "Parse error on line 37"
  - "Expecting SEMI NEWLINE SPACE EOF subgr"
  - "F3 mermaid error"
  - "mermaid truncation"
  - "CodeMirror 36-line"
  - "mermaid diagram cut off"
  - "usecaseDiagram"
  - "PlantUML"
  - "用例图不显示"
  - "mermaid blank use case"
  - "usecase UC1"
  - "looksLikeMermaid"
  - "mermaid type detection"
  - "mermaid regex missing"
  - "F1[注册] F2[登录]"
  - "lxml mermaid collapse"
  - "beautifulsoup pre whitespace"
  - "multi-node declaration"
  - "多节点同行"
  - "Expecting SEMI NEWLINE bare node"
---

## Overview

Auto-validated skill providing structured execution and output generation for the Hermes agent system.


# BookStack + Mermaid 图表渲染集成

## Architecture

```
Custom Head (app-custom-head in DB)
  ├── Mermaid CDN script (startOnLoad: false)
  └── .mermaid CSS styles

base-body-end.blade.php (template override)
  └── JS: finds .cm-line divs, joins with '\n', calls mermaid.render()
  └── Inserts <div class="mermaid"> with SVG result
  └── Original code block stays untouched (AI-readable)
```

## Installation

### 1. Custom Head Content (Database) — CSS + JS (RECOMMENDED for v26.05-dev+)

BookStack v26.05-dev+ **DOES support `<script>` tags** in the `app-custom-head` setting. This is simpler than the Blade template approach — no file override, no blade cache clearing needed.

The script is injected into the `<head>` of every page, scans for Mermaid blocks, and lazy-loads the CDN.

**❗ MySQL backslash escaping (CRITICAL):** When storing JS code (with `\s`, `\n` etc.) via SQL, MySQL's `NO_BACKSLASH_ESCAPES` mode (default OFF) interprets `\` as an escape character. `\s` becomes `s`, `\n` becomes newline. **Always double backslashes** in SQL string literals:

- JS source `'\n'` → SQL `'\\n'` → DB stores `\n` (correct)
- JS source `\s` → SQL `\\s` → DB stores `\s` (correct)

**Full content (CSS + JS):**

```sql
UPDATE settings SET value = '<style>
pre.mermaid { text-align: center; margin: 16px 0; padding: 12px; background: #f8f9fa; border-radius: 8px; overflow-x: auto; border: 1px solid #dfe6e9; }
.dark-mode pre.mermaid { background: #2d2d2d; border-color: #636e72; }
pre.mermaid svg, .mermaid svg { max-width: 100%; height: auto; }
</style>
<script>
(function() {
  /* ... see full script below in step 2 ... */
})();
</script>' WHERE setting_key = 'app-custom-head';
```

**Update via MariaDB Unix Socket (PHP CLI often unavailable):**
```bash
python3 -c "
import subprocess
with open('/tmp/custom_head.html', 'r') as f:
    content = f.read()

# Double backslashes for MySQL, escape single quotes
mysql_val = content.replace('\\\\', '\\\\\\\\').replace(\"'\", \"''\")
sql = f\"UPDATE settings SET value = '{mysql_val}' WHERE setting_key = 'app-custom-head';\"

subprocess.run(
    ['/home/yestin/opt/mariadb/bin/mysql', '--socket=/tmp/mariadb.sock', '-u', 'root', 'bookstack', '-e', sql],
    capture_output=True, timeout=10
)
"
```

Or via UI: Settings → Customization → Custom HTML Head Content (textarea uses CodeMirror 6 editor — set value via `document.getElementById('setting-app-custom-head').value = ...`).

### 2. Blade Template Override (FALLBACK — only if Custom Head doesn't support script)

If your BookStack version strips `<script>` from custom head, use the Blade template override instead:

Write to `resources/views/layouts/parts/base-body-end.blade.php`:

Write to `resources/views/layouts/parts/base-body-end.blade.php`:

```blade
{{-- Mermaid Diagram Renderer for BookStack --}}
{{-- Supports: CodeMirror blocks, pre.mermaid, bare div text --}}
{{-- Dynamically loads Mermaid CDN, renders SVG below source block --}}
{{-- CRITICAL: After modifying, clear blade cache: find storage/framework/views/ -name "*.php" -delete --}}
<script nonce="{{ $cspNonce ?? '' }}">
(function() {
  'use strict';

  var MERMAID_MARKER = 'mermaid-rendered';
  var MERMAID_SCRIPT_ID = 'mermaid-loader';
  var MERMAID_CDN = 'https://cdn.jsdelivr.net/npm/mermaid@11/dist/mermaid.min.js';

  function looksLikeMermaid(text) {
    var firstLine = text.split('\n')[0].trim();
/^(graph\\s+|flowchart\\s+|sequenceDiagram|classDiagram|stateDiagram|usecaseDiagram|gantt|pie\\s+|timeline|mindmap|gitGraph|erDiagram|journey|quadrantChart|xychart|block|packet|architecture)/mi
  }

  /** Source 1: CodeMirror (.cm-editor) blocks — each line in .cm-line divs */
  function collectCodeMirrorTargets() {
    var targets = [];
    document.querySelectorAll('.cm-editor').forEach(function(container) {
      if (container.querySelector('.' + MERMAID_MARKER)) return;
      var lines = container.querySelectorAll('.cm-line');
      var parts = [];
      lines.forEach(function(line) { parts.push(line.textContent); });
      var code = parts.join('\n').trim();
      if (code.length < 10) return;
      if (!looksLikeMermaid(code)) return;
      targets.push({ container: container, code: code });
      var mark = document.createElement('div');
      mark.className = MERMAID_MARKER;
      mark.style.display = 'none';
      container.appendChild(mark);
    });
    return targets;
  }

  /** Source 2: <pre class="mermaid"> or <div class="mermaid"> blocks from WYSIWYG/API-created content */
  function collectPreMermaidTargets() {
    var targets = [];
    document.querySelectorAll('pre.mermaid, div.mermaid').forEach(function(el) {
      if (el.querySelector('.' + MERMAID_MARKER) || el.classList.contains(MERMAID_MARKER)) return;
      var code = el.textContent.trim();
      if (code.length < 10) return;
      if (!looksLikeMermaid(code)) return;
      targets.push({ container: el, code: decodeHTMLEntities(code) });
      el.classList.add(MERMAID_MARKER);
    });
    return targets;
  }

  /**
   * Source 3: Bare <div> text content (no wrapping).
   * API-created pages may store Mermaid code as raw text inside div.kb-card.
   */
  function collectBareDivTargets() {
    var targets = [];
    var mainContent = document.querySelector('main') || document.querySelector('.content-wrap');
    if (!mainContent) return targets;
    mainContent.querySelectorAll('div[class*="kb-"]').forEach(function(div) {
      if (div.querySelector('.' + MERMAID_MARKER)) return;
      if (div.querySelector('pre') || div.querySelector('table') || div.querySelector('img')) return;
      var text = div.textContent.trim();
      if (text.length < 20) return;
      if (!looksLikeMermaid(text)) return;
      targets.push({ container: div, code: decodeHTMLEntities(text) });
      var mark = document.createElement('div');
      mark.className = MERMAID_MARKER;
      mark.style.display = 'none';
      div.appendChild(mark);
    });
    return targets;
  }

  /**
   * Decode HTML entities for clean Mermaid input.
   * BookStack stores --&gt; as literal text; Mermaid expects -->.
   */
  function decodeHTMLEntities(str) {
    var el = document.createElement('textarea');
    el.innerHTML = str;
    return el.value;
  }

  function loadMermaidAndRender() {
    var targets = collectCodeMirrorTargets()
      .concat(collectPreMermaidTargets())
      .concat(collectBareDivTargets());
    if (!targets.length) return;
    if (document.getElementById(MERMAID_SCRIPT_ID)) return;

    var script = document.createElement('script');
    script.id = MERMAID_SCRIPT_ID;
    script.src = MERMAID_CDN;
    script.onload = function() {
      mermaid.initialize({ startOnLoad: false, securityLevel: 'loose' });
      targets.forEach(function(t, i) {
        var wrapper = document.createElement('div');
        wrapper.className = 'mermaid';
        wrapper.style.cssText = 'text-align:center;margin:16px 0;padding:12px;background:#f8f9fa;border-radius:8px;overflow-x:auto;';
        t.container.parentNode.insertBefore(wrapper, t.container.nextSibling);
        var id = 'mermaid-' + Date.now() + '-' + i;
        mermaid.render(id, t.code)
          .then(function(r) { wrapper.innerHTML = r.svg; })
          .catch(function(e) {
            wrapper.innerHTML = '<div style="color:#e74c3c;padding:16px;border:1px solid #e74c3c;border-radius:4px;">❌ ' +
              e.message.substring(0, 120) + '</div>' +
              '<pre style="font-size:11px;color:#666;margin:8px 14px;padding:8px;background:#f5f5f5;border-radius:4px;text-align:left;max-height:150px;overflow:auto;">' +
              t.code.replace(/</g,'&lt;') + '</pre>';
          });
      });
    };
    script.onerror = function() {
      targets.forEach(function(t) {
        var errorDiv = document.createElement('div');
        errorDiv.style.cssText = 'color:#e74c3c;padding:16px;text-align:center;border:1px solid #e74c3c;border-radius:4px;margin:16px 0;';
        errorDiv.textContent = '❌ 加载Mermaid失败，请检查网络';
        t.container.parentNode.insertBefore(errorDiv, t.container.nextSibling);
      });
    };
    document.head.appendChild(script);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function() { setTimeout(loadMermaidAndRender, 1000); });
  } else {
    setTimeout(loadMermaidAndRender, 1000);
  }
})();
</script>
```

### After Modifying: Clear Blade Cache

```bash
find /home/yestin/projects/BookStack/storage/framework/views/ -name "*.php" -delete
# Or restart BookStack:
bash ~/scripts/start-bookstack.sh restart
```

## Page Content Format (for editors)

When creating diagram content in BookStack WYSIWYG editor:

1. Click "源代码" (Source Code) button
2. Insert: `<pre class="mermaid">` + Mermaid code + `</pre>`
3. Click "保存" (Save)

Example:
```html
<pre class="mermaid">
graph TD
    A[Start] --> B[Process]
    B --> C[End]
</pre>
```

## Batch Overflow Fix Protocol (55+ Pages Confirmed)

When a user reports "Parse error on line 37: ... Expecting 'SEMI', 'NEWLINE', 'SPACE', 'EOF', 'subgr'" — this is **CodeMirror 36-line truncation**. The fix requires understanding how to properly count lines:

### Counting Methodology (Critical: `\n` vs literal `\n`)

```python
# In mermaid blocks extracted from <pre class="mermaid">:
code = extracted_text

# b.count('\n') = actual newline characters (0x0A) = CodeMirror line count
# b.count('\\n') = literal backslash+n in node labels like SPA\nPort:3000
# These are TWO DIFFERENT THINGS:
#   actual \n (0x0A) = CodeMirror line break -> counts as 1 line
#   literal \n (backslash + 'n') = inline mermaid label text -> NOT a line break

# CORRECT: CodeMirror lines = code.count('\n') + 1
# WRONG: subtracting literal \n count — they're already part of the same line
```

**Rule:** `code.split('\n')` gives the exact line array that CodeMirror renders. Literal `\n` (backslash+n) in node labels does NOT split here.

### Compression Pipeline (Order Matters)

For any mermaid block with >35 lines, apply in order:

```python
def fix_mermaid_overflow(code):
    # Phase 1: Strip leading/trailing blank lines
    lines = code.split('\n')
    while lines and lines[0].strip() == '': lines.pop(0)
    while lines and lines[-1].strip() == '': lines.pop()
    
    # Phase 2: Deduplicate consecutive blank lines (keep max 1)
    cleaned = []
    prev_empty = False
    for l in lines:
        if l.strip() == '':
            if prev_empty: continue
            prev_empty = True
        else:
            prev_empty = False
        cleaned.append(l)
    
    # Phase 3: Remove ALL blank lines if still over
    if len(cleaned) > 35:
        cleaned = [l for l in cleaned if l.strip() != '']
    
    # Phase 4: Merge trailing connection lines (after last subgraph end)
    if len(cleaned) > 35:
        subgraph_ends = [j for j, l in enumerate(cleaned) if l.strip() == 'end']
        if subgraph_ends:
            last_end = subgraph_ends[-1]
            after = cleaned[last_end+1:]
            if len(after) > 3:
                merged = '  ' + ' ; '.join(l.strip() for l in after)
                cleaned = cleaned[:last_end+1] + [merged]
    
    return '\n'.join(cleaned)
```

### Diagram Splitting (For 70+ Line Diagrams)

When compression alone can't reach ≤35 lines (common for erDiagram with 6+ entities or classDiagram with 15+ classes):

**erDiagram split + relationship merge approach:**

First, merge ALL relationship lines (everything before the first `ENTITY {` block) into a single `;`-separated line. This often saves 10-15 lines. Then split at entity boundaries:

```python
# Step 1: Strip blank lines
stripped = [l for l in lines if l.strip()]

# Step 2: Find entity start positions — lines ending with '{'
# IMPORTANT: Relationship lines like USER ||--o{ BOOKING : creates
# contain { in --o{ notation. Naive '{' detection will miscount.
# Only match lines that end with '{' AND are not relationship lines:
entity_starts = []
for i, line in enumerate(stripped):
    s = line.strip()
    if s.endswith('{') and '||' not in s and '--' not in s and not s.startswith('erDiagram'):
        entity_starts.append(i)

# Step 3: Find entity closing braces via depth tracking
# Track depth ONLY after an entity start (not globally)
entity_closes = []
entity_depth = 0
in_entity = False
for i, line in enumerate(stripped):
    s = line.strip()
    if s.endswith('{') and '||' not in s and '--' not in s and not s.startswith('erDiagram'):
        in_entity = True
        entity_depth = 1
        continue
    if in_entity:
        entity_depth += s.count('{') - s.count('}')
        if entity_depth <= 0:
            entity_closes.append(i)
            in_entity = False

# Step 4: Merge all relationship lines before first entity into one
rel_lines = stripped[:entity_starts[0]]
rel_merged = '; '.join([l.strip() for l in rel_lines])

# Step 5: Split after 3rd entity closing brace
split_at = entity_closes[2]  # 0-indexed: 3rd entity
part1 = [rel_merged] + stripped[entity_starts[0]:split_at + 1]
part2 = ['erDiagram'] + stripped[split_at + 1:]

# Create two <pre class="mermaid"> blocks
```

**Critical:** Ensure split point is at a **valid syntactic boundary** (after `}` closing an entity), NOT mid-entity. A bad split produces invalid Mermaid in both halves.

### Type-Specific Compression Recipes

| Type | Strategy | Example |
|------|----------|---------|
| **flowchart/graph** | Merge node declarations with `;` separator (`F1[注册]; F2[登录]; F3[个人中心]`), use `&` for arrow chains (`A1 & A2 & A3 & A4 --> B1` and `B1 --> C1 & C2 & C3 & C4`), merge trailing connections with `;` (`C1 --> D1; C1 --> D2; C3 --> D5; C4 --> D3`), remove all blank lines between subgraphs. **Ultra-compression: remove ALL subgraph wrappers** — delete every `subgraph "..."` and `end` line, promote node declarations to top level, then merge ALL connection lines into one `;`-separated statement. This is the single most effective technique when subgraphs are just organizational wrappers with no cross-subgraph edges. | 48L → 18L (3 subgraphs removed) |
| **erDiagram** | Remove blank lines, split at entity boundaries (2-3 entities per block) | 75L → 30L+31L |
| **classDiagram** | Merge member declarations with `;` (`+id +name +login() ; -password ; #role`) | 74L → 24L |
| **gantt** | Remove excess blank lines, split at section boundaries | 52L → 25L+25L |
| **mindmap** | Merge siblings at same indentation level with `\|` | 39L → 1L |
| **sequenceDiagram** | Limit participants (≤8), limit messages (≤8) | — |

### Verification Loop

```python
# After fix: verify ALL pages have zero overflow
cursor.execute("SELECT e.id, e.name FROM entities e WHERE e.type = 'page' ORDER BY e.id")
for pid, pname in cursor.fetchall():
    cursor.execute("SELECT p.html FROM entity_page_data p WHERE p.page_id = %s", (pid,))
    row = cursor.fetchone()
    if not row or not row[0] or 'mermaid' not in row[0]: continue
    html = row[0]
    blocks = re.findall(r'<pre[^>]*class="mermaid[^"]*"[^>]*>(.*?)</pre>', html, re.DOTALL)
    for i, b in enumerate(blocks):
        lines = b.count('\n') + 1
        if lines > 35:
            print(f"OVERFLOW: [{pid}] B#{i+1}: {lines}L")
```

### BookStack Cache Clearing

After batch DB updates, clear view cache so users see fixed content immediately:

```bash
find /home/yestin/projects/BookStack/storage/framework/views/ -name "*.php" -delete
```

Also update page timestamps to signal re-index:
```sql
UPDATE entities SET updated_at = NOW() WHERE id IN (page_id_list);
```

### Revision Tracking Pattern

When fixing pages via SQL, always maintain proper revision history:

```python
# 1. Get page metadata for revision entry
cursor.execute('SELECT name, slug FROM entities WHERE id = %s AND type = "page"', (page_id,))
page_name, page_slug = cursor.fetchone()
cursor.execute('SELECT slug FROM entities WHERE id = (SELECT book_id FROM entities WHERE id = %s AND type = "page") AND type = "book"', (page_id,))
book_slug = cursor.fetchone()[0]

# 2. Update entity_page_data — increment revision_count
cursor.execute('''
    UPDATE entity_page_data 
    SET html = %s, text = %s, revision_count = revision_count + 1
    WHERE page_id = %s
''', (new_html, new_text, page_id))

# 3. Insert page_revisions entry — use max revision_number + 1
cursor.execute('SELECT COALESCE(MAX(revision_number), 0) + 1 FROM page_revisions WHERE page_id = %s', (page_id,))
next_rev = cursor.fetchone()[0]

cursor.execute('''
    INSERT INTO page_revisions 
    (page_id, name, html, text, created_by, created_at, updated_at, slug, book_slug, type, markdown, summary, revision_number)
    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
''', (
    page_id, page_name, new_html, new_text,
    1,  # created_by (admin)
    now, now,
    page_slug, book_slug,
    'version',  # type
    '',  # markdown
    f'修复: usecaseDiagram→flowchart TD语法迁移',
    next_rev
))
```

**Note on `slug` vs `book_slug`**: BookStack pages may have a URL slug like `uml9` while the book slug is `02` or similar. Both are needed for the revision entry to generate correct revision URLs. If `book_slug` is wrong, revision history links will be broken.

### Real-World Results (2026-05-19)

- 55 pages fixed across 3 rounds
- Round 1: 42 pages (generic compression)
- Round 2: 26 pages (type-specific compression + diagram splitting)
- Round 3: 3 pages (precision trimming of borderline 36-38L blocks)
- Final state: **Zero overflow blocks across entire BookStack**

## Pitfalls

- ❌ **`<br>` inside `<pre class="mermaid">` causes parse error (CRITICAL)**: BookStack stores `<br>` as literal HTML inside the `<pre>` block. Browser's `textContent` strips the `<br>` tag, concatenating text without separator. In `Note over` or other multi-line Mermaid text:
  - ❌ `Note over A,B: text line 1<br>text line 2` in stored HTML
  - → `textContent` → `Note over A,B: text line 1text line 2` (concatenated, no line break)
  - ✅ Use `\\n` instead: `Note over A,B: text line 1\\ntext line 2`
  - **Fix**: Replace all `<br>` inside Mermaid `<pre>` blocks with literal `\n`
- ❌ **Multi-line node text with real newlines (CRITICAL)**: When creating Mermaid code via API (PUT /api/pages/{id}), **real newlines inside node brackets `[...]` cause parse errors**. Mermaid expects `\n` (literal backslash-n), not actual line breaks, for multi-line node text:
  - ❌ `AIR_API[航司API\n国航/南航/海航]` (real newlines in HTML) → Parse error on line 37
  - ✅ `AIR_API[航司API\\n国航/南航/海航]` (`\n` as literal backslash-n in HTML) → Correctly renders
  - **Fix method**: After API storage, scan `<pre class="mermaid">` blocks and merge continuation lines (lines inside brackets that span multiple lines) with `\n`. Use safe merging: ONLY merge lines that are continuations inside `[...]` brackets. Do NOT merge statement-level lines (e.g., `A --> B` followed by `C --> D` should remain as separate real newlines).
  - **Prevention**: In Python source code, use `\\n` inside triple-quoted string Mermaid code to produce literal `\n` in the output HTML
- ❌ **COUNTER-PITFALL: Over-zealous fix script merges statement-level newlines**: If the auto-fix script incorrectly collapses ALL lines (including statement separators like `A-->B` + `C-->D`) into one line with `\\n`, Mermaid will parse it as a single malformed statement:
  - ❌ `graph TB\\nStart([🏗️]) --&gt; Tech[选型]\\nTech --&gt; C4[建模]` → `Parse error on line 1: Expecting 'SEMI', 'NEWLINE', 'SPACE', got 'NODE_STRING'`
  - ✅ Proper multi-line format with real newlines between statements, `\n` only inside brackets:
    ```
    graph TB
        Start([🏗️]) --> Tech[选型\n工具评估]
        Tech --> C4[建模\nC4模型]
    ```
  - **Detection**: The Mermaid block has ≤2 real lines (newline characters) but many `\n` escape sequences — means the fix script over-merged
  - **Fix**: Replace `\\n` between statements with real newlines. Keep `\\n` only inside bracket-delimited node text
- ❌ NEVER use `mermaid.initialize({ startOnLoad: true })` — it corrupts CodeMirror code blocks by replacing content with rendered CSS
- ❌ Mermaid CDN without explicit `startOnLoad: false` defaults to true in some versions
- ❌ `textContent` on `.cm-content` loses newlines — always extract from `.cm-line` divs and join with '\n'
- ✅ Custom head content DOES support `<script>` tags in BookStack v26.05-dev — place the full JS initialization code there via DB update. Only fall back to Blade template if your version strips scripts.
- ❌ MySQL backslash escaping: When storing JS code in settings table via SQL, backslashes in regex (`\s`, `\n`) must be doubled. `content.replace('\\', '\\\\')` in Python before SQL, or `'\\s'` → `'\\\\s'` in raw SQL.
- ❌ Custom head content field is DISABLED on BookStack settings page — must update via DB
- ✅ Mermaid CSS styles must use `.mermaid` class (not `pre.mermaid`) since the injected wrapper is a div
- ❌ **HTML entities in stored code**: BookStack stores `--&gt;` (arrow) as literal text. Always call `decodeHTMLEntities()` before passing to `mermaid.render()`, or Mermaid silently fails (no error, no SVG)
- ❌ **Three content storage formats**: Mermaid code can be stored as (1) CodeMirror `.cm-editor` blocks, (2) `<pre class="mermaid">` in WYSIWYG, or (3) **bare text** inside `<div class="kb-card">` when pages are created via API. The loader must scan all three
- ❌ **Blade template cache**: After modifying `base-body-end.blade.php`, clear compiled templates with `find storage/framework/views/ -name "*.php" -delete`. Without this, changes won't take effect
- ❌ **API strips `<style>`**: BookStack API (`GET /api/pages/{id}`) removes `<style>` tags from returned HTML. The database has them intact. Always check `entity_page_data` directly in MySQL to verify CSS presence
- ✅ `<pre class="mermaid">` textContent extraction works fine (no line-joining needed, just `textContent.trim()`)
- ❌ **CodeMirror 36-line truncation (CRITICAL)**: BookStack's read-only CodeMirror view (used on page display) ONLY renders the first ~36 lines of any code block. Mermaid code exceeding 36 lines will have trailing connection lines silently dropped. This causes a parse error at the last visible subgraph node:
  ```
  Parse error on line 37: ... F3[...] ---------------------^
  Expecting 'SEMI', 'NEWLINE', 'SPACE', 'EOF', 'subgraph', 'end'
  ```
  **Fix strategies:**
  - Keep total Mermaid code ≤35 lines (count including `flowchart TB` and `end` lines)
  - Put inter-subgraph connections INSIDE subgraphs rather than after `end` statements
  - Move connection lines to BEFORE the subgraph `end` to save lines
  - Example: `A1 --> B1` inside subgraph S1 instead of `S1 --> S2` at the end
  - Shorten node labels to reduce line count (e.g., `ELK日志` instead of `ELK 日志系统`)
  - Never put external connections (e.g., `S1 --> S2 subgraph S2...`) as the last lines of a large diagram — they WILL be truncated
- ❌ **`sequenceDiagram` also affected**: Same 36-line limit applies. Keep sequenceDiagram simple (≤8 participants, ≤8 messages) to stay under limit
- ❌ **`-->>` arrow in `graph TD`/`flowchart` (CRITICAL)**: Mermaid v11 strictly enforces diagram-type-appropriate syntax. The `-->>` arrow **only works in `sequenceDiagram`**, **not in `graph TD` or `flowchart`**. Using it in a flowchart causes:
  ```
  Parse error on line 10: ...UC8[运营数据报表] UC3-->>System(支付网关:External)
  ----------------------^ Expecting 'AMP', 'COLON', 'PIPE'
  ```
  **Fix pattern:**
  - ❌ `UC3-->>System(支付网关:External)` — `-->>` is sequenceDiagram syntax
  - ✅ `UC3-->|调用支付|System[支付网关\\nExternal]` — Use `-->` with label `|...|` and `[...]` box node
  - ❌ `UC5-->>UC4` — Same issue
  - ✅ `UC5-->|触发通知|UC4` — Add label to clarify edge meaning
  - **Rule of thumb**: In `graph TD`/`flowchart`, only use `-->` (arrow with optional `|label|`), `===` (thick line), `-.-` (dotted line). Never use `-->>`, `->>`, `-)`, `--)` which are sequence diagram syntax.
- ❌ **Parentheses `()` vs brackets `[]` in flowchart nodes (CRITICAL)**: In `graph TD`/`flowchart`:
  - `(text)` = rounded pill node (typically used for start/end)
  - `[text]` = rectangular box node (for actions/processes)
  - `{text}` = diamond decision node
  - `((text))` = double-circle node (for actors/external entities)
  - **`System(External)` is wrong** when you mean a rectangular system component — use `System[External]` (box) or `System((External))` (external actor circle). Wrong node type causes parser confusion on adjacent syntax.
- ❌ **Gantt `after` keyword with Chinese/Unicode labels (CRITICAL)**: Mermaid's Gantt chart `after` keyword fails to parse when referencing a task by its Chinese/Unicode label. `after 用户调研与需求分析` causes `Invalid date:after 用户调研与需求分析`. Always use explicit task IDs:
  - ❌ `SRS编写与评审:after 用户调研与需求分析,3d` → ✅ `SRS编写与评审:r2, after r1, 3d` plus `用户调研与需求分析:r1, 2026-05-10, 8d`
  - Every task that is referenced by `after` MUST have a unique task ID (e.g., `r1`, `d1`, `dev1`, `t1`)
  - Task IDs are alphanumeric strings placed after the task label and separated by comma: `Task Label:task_id, after parent_id, duration`
  - This applies to ALL Gantt tasks that use `after` — not just Chinese labels. Use task IDs universally for Gantt.
- ❌ **`html` vs `text` column entity encoding mismatch (CRITICAL)**: When fixing Mermaid syntax via SQL update on `entity_page_data`, the `html` and `text` columns store arrows differently:
  - **`html` column**: `--&gt;` (HTML entity encoded — `>` is escaped as `&gt;`)
  - **`text` column**: `-->` (raw plaintext, no HTML encoding)
  
  **If you use the same search string for both columns, the replacement will silently fail on `text` (or `html`).**
  
  **Fix:** Always prepare two separate replacement pairs:
  ```python
  # HTML column — search with entity-encoded arrows
  OLD_HTML = '''usecaseDiagram\n    actor 用户 as User\n    User --&gt; (搜索航班)\n    User --&gt; (预订机票)'''
  NEW_HTML = '''flowchart TD\n    User((用户))\n    User --&gt; UC1[(搜索航班)]\n    User --&gt; UC2[(预订机票)]'''
  
  # Text column — search with raw arrows (no HTML entities)
  OLD_TEXT = '''usecaseDiagram\n    actor 用户 as User\n    User --> (搜索航班)\n    User --> (预订机票)'''
  NEW_TEXT = '''flowchart TD\n    User((用户))\n    User --> UC1[(搜索航班)]\n    User --> UC2[(预订机票)]'''
  ```
  
  **Same applies to any HTML entity**: `&lt;&lt;include&gt;&gt;` in `html` → `<<include>>` in `text`, `&amp;` → `&`, etc.

- ❌ **`page_revisions` insert requires correct slug/book_slug**: The revision entry in `page_revisions` needs the page's `slug` (from `entities` table, e.g. `uml9`) and its parent book's `slug` (e.g. `02`). Without these, the revision history shows broken links. Fetch them first:
  ```python
  cursor.execute('SELECT slug FROM entities WHERE id = %s AND type = "page"', (page_id,))
  page_slug = cursor.fetchone()[0]
  cursor.execute('SELECT slug FROM entities WHERE id = (SELECT book_id FROM entities WHERE id = %s AND type = "page") AND type = "book"', (page_id,))
  book_slug = cursor.fetchone()[0]
  ```

- ❌ **`usecaseDiagram` DEPRECATED in Mermaid v11+ (CRITICAL)**: Mermaid v11 **removed** `usecaseDiagram` entirely. The error `No diagram type detected matching given configuration for text: usecaseDiagram...` is unambiguous. Convert to `flowchart TD`:
  
  | Element | `usecaseDiagram` (broken) | `flowchart TD` (fixed) |
  |---|---|---|
  | Diagram type | `usecaseDiagram` | `flowchart TD` |
  | Actor | `actor 旅客 as User` | `User((旅客))` (double-circle) |
  | Use case | `usecase "登录" as UC1` | `UC1[(登录)]` (database-shape) |
  | Package | `package "name" {}` | `subgraph name ... end` |
  | Include | `UC4 ..> UC5 : <<include>>` | `UC4 -.->|include| UC5` |
  | Arrow | `User --> UC1` | `User --> UC1` (same) |
  | Styling | n/a | `style User fill:#6c5ce7,color:#fff` |
  
  **Full conversion example:**
  ```
  flowchart TD
      subgraph 系统名称
          UC1[(注册/登录)]
          UC2[(搜索航班)]
      end
      User((旅客))
      Admin((管理员))
      User --> UC1
      User --> UC2
      Admin --> UC2
      UC1 -.->|include| UC2
      style User fill:#6c5ce7,color:#fff
      style Admin fill:#6c5ce7,color:#fff
  ```
  
  **Node shape guide for flowchart:** `(text)`=pill(start/end), `[text]`=box(action), `{text}`=diamond(decision), `((text))`=circle(actor), `[(text)]`=database(data), `>text]`=flag(I/O).
  
  **Checklist after conversion:**
  - ✅ Remove all `usecaseDiagram` keyword occurrences
  - ✅ Remove `actor` keyword — use `((name))` circles
  - ✅ Remove `package` keyword — use `subgraph ... end`
  - ✅ Replace `..>` dashed arrows with `-.->`
  - ✅ Replace `<<include>>` labels with `|include|`
  - ✅ Add `style` rules for visual polish
  - ✅ Check 36-line CodeMirror limit if in code block

- ❌ **`usecaseDiagram` syntax — PlantUML vs Mermaid (CRITICAL, pre-v11 only)**: If you are on a Mermaid version BEFORE v11 that still supports `usecaseDiagram`, it uses **Mermaid-native syntax** (not PlantUML). If a use case diagram shows nothing (blank/empty), check whether the code uses PlantUML `usecase UC1 as "名称"` format instead of Mermaid's parenthesized format:
  - ❌ **PlantUML syntax (silently fails in Mermaid):**
    ```
    usecaseDiagram
        actor 旅客 as P
        usecase UC1 as "查询航班"
        P --> UC1
    ```
    → Mermaid ignores the diagram; blank output, no error message.
  - ✅ **Mermaid-native syntax (correct):**
    ```
    usecaseDiagram
        actor 旅客 as P
        P --> (查询航班)
    ```
    Use cases in Mermaid are written as `(名称)` directly in the relation line, NOT declared separately with `usecase X as "名称"`.
  - **Conversion table:**
    | PlantUML (broken) | Mermaid (correct) |
    |---|---|
    | `usecase UC1 as "查询航班"` | No separate declaration — just use `(查询航班)` |
    | `P --> UC1` | `P --> (查询航班)` |
    | `UC3 --> PG` | `(在线支付) --> PG` |
    | `UC5 ..> UC4 : include` | `(价格监控) ..> (订单管理) : include` |
  - **Rule of thumb:** In Mermaid's `usecaseDiagram`, `actor "名称" as ID` syntax is the same as PlantUML, but **use cases are never declared with `usecase` keyword** — they are inline parenthesized references on the relationship lines.
  - **Detection:** If a Mermaid `usecaseDiagram` block renders blank, check for `usecase UC` pattern (PlantUML) vs bare `(名称)` (Mermaid).
  - **Fix:** Remove all `usecase UC1 as "..."` lines. Replace `UC1`, `UC2` references in relationship lines with the actual use case names in parentheses: `(查询航班)`, `(在线支付)`, etc.

- ❌ **BeautifulSoup lxml 吞噬 mermaid 换行符 (CRITICAL)**: 当用Python构建含 `<pre class="mermaid">` 的HTML并以 `BeautifulSoup(html, 'lxml')` 解析时，`lxml` 会折叠 `<pre>` 内部的换行符。多行Mermaid节点声明被挤到同一行，触发 `Parse error on line N: Expecting 'SEMI', 'NEWLINE'`。**修复**: 始终使用 `html.parser` 而非 `lxml` — `BeautifulSoup(html, 'html.parser')`。此问题影响所有通过Python+BeautifulSoup注入Mermaid到BookStack的脚本。
- ❌ **`;` 分隔节点声明无效**: 在 `flowchart`/`graph` 中，`;` 只能用于分隔**完整语句**（`A --> B ; C --> D`），不能用于分隔**裸节点声明**（`A1[name]; A2[name2]`）。多个节点声明必须独占行。
- ❌ **`&` 扇出仅限右侧**: `A --> B & C & D` 有效（一个源→多目标），但 `A & B & C --> D` 无效（多源→一目标）。多源到一目标需用 `A --> D ; B --> D` 或独立行。
- ❌ **`&` batch syntax limitation**: The `&` batch connector (`User --> UC1 & UC2 & UC3`) ONLY works for **arrow connection lines**. It does NOT work for pure node declarations. `F1[注册]  F2[登录]` on the same line is invalid. Never merge bare node declarations with `&` or spaces — each node must be on its own line. erDiagram blocks have additional error sources beyond truncation:
  - **`decimal` is a reserved keyword** in Mermaid's erDiagram parser. Replace with `NUMERIC` or `DEC`:
    - ❌ `decimal total_amount` → ✅ `NUMERIC total_amount`
  - **Parentheses in type definitions cause parse errors**: Mermaid expects bare type names:
    - ❌ `varchar(32) phone` → ✅ `VARCHAR phone`
    - ❌ `decimal(10,2) price` → ✅ `NUMERIC price`
    - ❌ `varchar(100) real_name` → ✅ `VARCHAR real_name`
  - **Undefined entities in relationships**: Every entity used in a `||--o{` or `||--||` must have a corresponding `NAME { ... }` definition block, OR use the `: "label"` syntax:
    - ❌ `ORDER ||--|| PAYMENT` (PAYMENT not defined) → ✅ `ORDER ||--|| PAYMENT : "支付"` or remove the line
    - ❌ `FLIGHT ||--o{ ORDER_ITEM` (ORDER_ITEM not defined) → ✅ Remove unless ORDER_ITEM has `ORDER_ITEM { ... }`
  - **Cascading errors from truncation**: If an erDiagram entity's closing `}` gets truncated by the 36-line limit, the next entity's fields will cause `Expecting 'BLOCK_STOP', 'ATTRIBUTE_WORD'` errors. Shortest fix is to reduce total line count (remove less-important fields or undefined entity relationships)
  - **Error signatures for erDiagram**:
    | Error Message | Likely Cause |
    |---|---|
    | `Expecting 'ATTRIBUTE_WORD', got '('` | Parentheses in type: `decimal(10,2)` or `varchar(32)` |
    | `Expecting 'BLOCK_STOP', 'ATTRIBUTE_WORD'` | Missing `}` due to truncation or syntax error |
    | `Expecting 'COLON', 'STYLE_SEP'` | Undefined entity in relationship |
    | `Expecting 'SEMI', 'NEWLINE', 'SPACE', 'EOF', 'subgr'` | CodeMirror truncation (36-line limit) |
  - **Compact erDiagram template** (32 lines, fits under limit):
    ```
    erDiagram
        USER ||--o{ ORDER : "下单"
        USER {
            bigint id PK
            VARCHAR phone
            VARCHAR email
            ...
        }
        ORDER {
            bigint id PK
            NUMERIC total_amount
            ...
        }
        FLIGHT {
            VARCHAR flight_no PK
            ...
        }
        PRICE_HISTORY ||--o{ FLIGHT : "记录"
        PRICE_HISTORY {
            bigint id PK
            NUMERIC price
        }
    ```

## Cross-Page Bug Propagation (Critical Pattern)

**When a user says 'still broken' after a Mermaid fix, the bug may not be in the page you just fixed — it is replicated across multiple pages in the same book.**

This is the single most common time-waster in BookStack Mermaid troubleshooting. The same broken diagram code (copy-pasted `usecaseDiagram`) lives on 3-5+ pages, but you keep re-fixing the same page, or the user is looking at a different page.

### Phase 1: Discovery — Find ALL Affected Pages

Before re-examining the page you just fixed, always search the entire book for the bug pattern:

```python
import pymysql

conn = pymysql.connect(host='127.0.0.1', port=3307, user='bookstack', password='bookstack_pass', database='bookstack')
cursor = conn.cursor()

# Search 1: Find all pages with usecaseDiagram (or other broken pattern)
cursor.execute('''
    SELECT e.id, e.name, e.book_id
    FROM entities e
    JOIN entity_page_data p ON e.id = p.page_id
    WHERE e.type = 'page'
      AND p.html LIKE '%usecaseDiagram%'
    ORDER BY e.book_id, e.id
''')
pages = cursor.fetchall()
for pid, pname, book_id in pages:
    print(f'  [{pid}] {pname} (book={book_id})')

# Search 2: Also check for related deprecated patterns
cursor.execute('''
    SELECT e.id, e.name
    FROM entities e
    JOIN entity_page_data p ON e.id = p.page_id
    WHERE e.type = 'page'
      AND (p.html LIKE '%actor % as %' 
           OR p.html LIKE '%usecase % as %'
           OR p.html LIKE '%package %{%')
      AND p.html NOT LIKE '%flowchart%'
    ORDER BY e.id
''')
```

### Phase 2: Batch Fix — Fix ALL Affected Pages in One Pass

```python
import pymysql, datetime

conn = pymysql.connect(host='127.0.0.1', port=3307, user='bookstack', password='bookstack_pass', database='bookstack')
cursor = conn.cursor()
now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')

# Find all usecaseDiagram pages
cursor.execute('''
    SELECT e.id, e.name
    FROM entities e
    JOIN entity_page_data p ON e.id = p.page_id
    WHERE e.type = 'page' AND p.html LIKE '%usecaseDiagram%'
''')
affected = cursor.fetchall()

for page_id, page_name in affected:
    cursor.execute('SELECT p.html FROM entity_page_data p WHERE p.page_id = %s', (page_id,))
    row = cursor.fetchone()
    if not row: continue
    html = row[0]
    
    # --- Conversion logic here (see usecaseDiagram->flowchart TD section above) ---
    # ...
    
    # Update DB
    cursor.execute('''
        UPDATE entity_page_data 
        SET html = %s, text = LEFT(%s, 50000), markdown = '', 
            editor = 'wysiwyg', revision_count = revision_count + 1
        WHERE page_id = %s
    ''', (new_html, new_html, page_id))
    cursor.execute('UPDATE entities SET updated_at = %s WHERE id = %s', (now, page_id))
    cursor.execute('''
        INSERT INTO page_revisions (page_id, name, html, text, created_by, created_at, updated_at, slug, book_slug, type, markdown, summary, revision_number)
        VALUES (%s, %s, %s, LEFT(%s, 50000), 1, %s, %s, %s, 'XX', 'wysiwyg', '', 'Batch Mermaid fix: usecaseDiagram->flowchart TD',
        (SELECT COALESCE(MAX(revision_number),0)+1 FROM page_revisions WHERE page_id = %s))
    ''', (page_id, page_name[:255], new_html, new_html, now, now, f'page-{page_id}', page_id))

conn.commit()
conn.close()

print(f'Fixed {len(affected)} pages in batch')
```

### Phase 3: Verify — Check Each Fixed Page

```python
cursor.execute('''
    SELECT e.id, e.name
    FROM entities e
    JOIN entity_page_data p ON e.id = p.page_id
    WHERE e.type = 'page' AND p.html LIKE '%usecaseDiagram%'
''')
remaining = cursor.fetchall()
if remaining:
    print(f'Warning: {len(remaining)} pages still have usecaseDiagram:')
    for pid, pname in remaining:
        print(f'  [{pid}] {pname}')
else:
    print('Zero usecaseDiagram remaining — all pages converted')
```

### Counted Line Anti-Patterns (Timeline of Real Bugs)

#### Anti-Pattern 1: `<pre>\n{code}\n</pre>` Wrapper Newline Trap

When building replacement `<pre class="mermaid">` blocks programmatically, the `\n` before and after the code **count toward the 35-line limit**:

```python
# BROKEN: \n before and after adds 2 wrapper lines
new_block = f'<pre{pre_attrs}>\n{new_code}\n</pre>'
# Content between > and </pre> = \n + 33lines + \n = 35 lines ✅ but ACTUALLY 37!

# FIXED: No wrapper newlines — content directly inside
new_block = f'<pre{pre_attrs}>{new_code}</pre>'
# Content between > and </pre> = 33lines = 33 lines ✅
```

**Rule:** To fit ≤35 lines in CodeMirror, inner content must be ≤33 lines when using wrapper newlines, or ≤35 lines without wrappers.

#### Anti-Pattern 3: Space-Separated Arrow Chains Cause Parse Errors

**Multiple arrow segments on the same line separated by SPACES (not by chain syntax) are INVALID Mermaid syntax:**

```mermaid
❌ BROKEN:  F1 -.-> F5  F5 -.-> F9  F9 -.-> F13  F13 -.-> F12
→ Parse error on line 33: Expecting 'SEMI', 'NEWLINE'
    Caret points at space between 'F5' and the next arrow
```

**Mermaid supports THREE distinct syntax patterns for connecting multiple nodes:**

| Pattern | Syntax | Example | Valid? |
|---------|--------|---------|--------|
| **Chain** | `A --> B --> C` (arrow as separator) | `F1 -.-> F5 -.-> F9` | ✅ Valid chain — single source flows through intermediate nodes |
| **Fan-out** | `A --> B & C` (ampersand as separator) | `User --> UC1 & UC2` | ✅ Valid — same source to multiple targets |
| **Fan-in** | `A & B & C --> D` (ampersand joins sources) | `A1 & A2 & A3 & A4 --> B1` | ✅ Valid — multiple sources to same target |
| **Hybrid** | `A & B --> C & D` | `A1 & A2 --> C1 & C2` | ✅ Valid — combines fan-in and fan-out |
| **Space-separated** | `A --> B  B --> C` (space as separator) | `F1 -.-> F5  F5 -.-> F9` | ❌ **INVALID** — Mermaid cannot parse this |

**Detection:** In a mermaid block, look for lines containing TWO or more arrow operators (`-->`, `-.->`, `==>`) that are NOT joined by chain syntax or `&`:
- Pattern: `\bNODE\s*--[.\-]>\s*\w+\s{2,}\w+\s*--[.\-]>`
- The `\s{2,}` (two or more spaces) between node identifier and next arrow is the tell

**Fix strategies (in order of preference):**

1. **Chain syntax** (when connections form a linear flow): Replace spaces between arrows with chain arrows:
   ```
   ❌ F1 -.-> F5  F5 -.-> F9  F9 -.-> F13  F13 -.-> F12
   ✅ F1 -.-> F5 -.-> F9 -.-> F13 -.-> F12
   ```

2. **Split into individual lines** (when connections branch from different sources):
   ```
   ❌ F3 -.-> F4  F5 -.-> F17  F17 -.-> F9
   ✅ F3 -.-> F4
      F5 -.-> F17 -.-> F9
   ```

3. **Fan-out with `&`** (same source to multiple targets):
   ```
   ✅ A --> B & C & D
   ```

4. **Fan-in with `&`** (multiple sources to same target):
   ```
   ✅ A & B & C --> D
   ```

5. **Merge trailing connections with `;`** (when all connections are between subgraph nodes at the bottom):
   ```
   ❌ A1 --> B1\n      A2 --> B1\n      A3 --> B1\n      A4 --> B1
   ✅ A1; A2; A3; A4 --> B1    (fan-in, preferred)
   Or:
   ✅ A1 --> B1; A2 --> B1; A3 --> B1; A4 --> B1  (semicolons, fallback)
   ```
   
   Using `;` merging works for **any** collection of trailing arrow statements — it's useful when connections can't be elegantly grouped into fan-out/fan-in patterns:
   ```
   ❌ C1 --> C2\n      C1 --> D1\n      C1 --> D2\n      C3 --> D5\n      C4 --> D3\n      C2 --> D1
   ✅ C1 --> C2; C1 --> D1; C1 --> D2; C3 --> D5; C4 --> D3; C2 --> D1
   ```

**Line count compensation:** Splitting chains adds lines. To stay under 35-line limit:
- Remove unreferenced nodes (declared in subgraph but never connected)
- Use `&` fan-out syntax where applicable
- Remove all blank lines (they count toward CodeMirror line count)

**Diagnostic tree for "Parse error on line N" where N < 36:**

```
Parse error on line N (where N < 36)
├── Error points at node brackets:  F1[注册] F2[登录]
│   → Anti-Pattern 2: Bare multi-node declarations
├── Error points at space between arrows:  F5  F5
│   → Anti-Pattern 3: Space-separated arrow chains
├── Error at line 37 or higher: ... Expecting 'subgr'
│   → CodeMirror 36-line truncation (Anti-Pattern 1 context)
└── Error mentions 'SEMI', 'NEWLINE' at text between arrows
    → Could be either Anti-Pattern 2 or 3 — check error position
```

**Multiple node declarations on the same line without arrow connectors are INVALID Mermaid syntax when separated by spaces — but ARE valid when separated by `;` (semicolon):**

```
❌ BROKEN (spaces):  F1[注册]  F2[登录]  F3[个人中心]  F4[历史订单]
→ Parse error on line 4: Expecting 'SEMI', 'NEWLINE'

✅ FIXED (semicolons): F1[注册]; F2[登录]; F3[个人中心]; F4[历史订单]
✅ Also works inside subgraphs:
    subgraph "前端层"
        A1[海航App]; A2[微信小程序]; A3[Web H5]; A4[国际版App]
    end
```

**The `;` separator is Mermaid's native statement separator** — it's equivalent to a newline. This is the correct technique for reducing line count within subgraphs while keeping the diagram parseable. The `&` batch syntax ONLY works for arrow connection lines:

```
❌ BROKEN:  F1[注册]  F2[登录]  F3[个人中心]  F4[历史订单]
→ Parse error on line 4: Expecting 'SEMI', 'NEWLINE'

✅ FIXED:   F1[注册]
            F2[登录]
            F3[个人中心]
            F4[历史订单]
```

**The `&` batch syntax ONLY works for arrow connection lines**, not pure node declarations:
- ✅ `User --> UC1 & UC2 & UC3` — batch arrow is valid
- ❌ `F1[注册]  F2[登录]` — bare multi-node is invalid

**Detection:** In a compressed mermaid block, find lines with multiple `[...]` or `(...)` patterns but NO `-->`, `-.->`, `==>`, or `---` connectors. These need to be split.

**Fix sequence for a compressed block that has both bare multi-nodes AND overflow (>35 lines):**

```python
# Step 1: Un-merge bare multi-node lines
new_lines = []
for l in lines:
    s = l.strip()
    if has_bare_multi_nodes(s) and not has_arrows(s):
        # Split into individual node lines
        nodes = re.findall(r'\b[A-Za-z_][A-Za-z0-9_]*\s*(?:\[[^\]]*\]|\([^)]*\)|\{[^}]*\})', l)
        for nd in nodes:
            new_lines.append(indent + nd.strip())
    else:
        new_lines.append(l)

# Step 2: Remove ALL blank lines to compensate for splitting
cleaned = [l for l in new_lines if l.strip() != '']

# Step 3: Merge trailing connection arrows if still over 35
ends = [j for j, l in enumerate(cleaned) if l.strip() == 'end']
if ends and len(cleaned) > 35:
    conns = cleaned[ends[-1]+1:]
    if len(conns) > 3:
        merged = ['  ' + ' ; '.join(l.strip() for l in conns)]
        cleaned = cleaned[:ends[-1]+1] + merged
```

**Trigger:** User reports "Parse error on line X" where X < 36 and the error points at text between brackets (like `F1[注册] F2[登录]`). This means the compression script over-merged.

### Key Insight: The 'still broken' Diagnostic Tree

When user says the error is still visible:

```
用户说 still broken
├── 你只修改了页面 A，但错误在页面 B
│   -> 搜索整个 book 的所有页面，发现 3+ 个页面有相同问题
│   -> 批量修复所有，问题消失
├── 你修改了 DB 但没刷新浏览器缓存
│   -> 硬刷新 (Ctrl+F5) 或清除 BookStack cache: php artisan cache:clear
├── 页面有多个 Mermaid 代码块，你只修复了第一个
│   -> 搜索页面内所有 `<pre class="mermaid">` 和 `.cm-line` 块
└── 修复本身有问题（语法仍不符合 flowchart TD）
    -> 用验证清单逐条检查
```

### Checklist for Cross-Page Scans

- [ ] SQL query: `LIKE '%usecaseDiagram%'` across all pages in the book
- [ ] If 0 results, try broader: `LIKE '%actor % as %Alias%'`
- [ ] If 0 results try: `LIKE '%-->>%'` (sequenceDiagram-only arrows in graph/flowchart)
- [ ] If 0 results try: `LIKE '%package %{%'` (deprecated package syntax)
- [ ] If 0 results but user still sees error: check browser cache vs DB content match
- [ ] Batch fix all found pages in one transaction
- [ ] Post-fix SQL query to verify zero remaining
- [ ] Record all fixed page IDs + names to session memory for user confirmation

## Verification

1. Navigate to a page with Mermaid code (e.g., 🏗️ 系统架构详解)
2. Check console: `document.querySelectorAll('.mermaid svg').length` should be > 0
3. Check database has `<pre class="mermaid">` format in entity_page_data.html

## Related Reference Files

- **references/api-authoring-patterns.md** — 5 reusable Mermaid diagram templates for project reports (business flow, functional hierarchy, use case, system architecture, deployment) + Python API push pattern + Python 3.11 f-string workaround. Load this when building BookStack pages programmatically with Mermaid diagrams.
- **references/hainan-proposal-template.md** — 海南航空控股股份有限公司 立项报告12章结构模板（海航版），含角色补充规范、14张必备数据表、Mermaid图表配置、数据来源映射。Load this when generating CMMI5 立项报告 for Chinese aviation enterprise IT projects.
