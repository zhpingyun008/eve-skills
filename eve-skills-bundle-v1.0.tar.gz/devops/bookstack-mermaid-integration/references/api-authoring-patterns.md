# BookStack API + Mermaid 图表编排模式

## 应用场景

通过 BookStack PUT /api/pages/{id} 向已存在的页面注入含 Mermaid 图表的 HTML。适用于立项报告/技术方案等结构化文档。也可从脚本自动生成带图表的知识库页面。

## 核心模式

### 1. Mermaid HTML 包装

用 `<pre class="mermaid">` 标签包裹 Mermaid 代码：

```python
def mermaid(code):
    return f'<pre class="mermaid">\n{code}\n</pre>'
```

### 2. 多行节点文本

Mermaid 中节点内的多行文本（如 `[编码规则\n自动审核]`）需使用**字面量反斜杠+n** (`\\n`)，而非真实换行符。在 Python 三引号字符串中需写 `\\\\n`（4个反斜杠+n）：由 Python 的 `\\\\` 转义为 `\\`，加上 `n` 得到 `\\n`，注入 HTML 后 Mermaid JS 接收时将 `\\n` 解释为节点内换行。

```python
code = """flowchart TD
    B1[编码规则\\\\n自动审核]
    B2[机票预订\\\\n搜索比价]
"""
```

### 3. 业务流程图模板

```mermaid
flowchart TD
    subgraph 客户入口
        A1[企业注册/登录]; A2[员工出行申请]; A3[家属编码申请]
    end
    subgraph 业务处理
        B1[编码规则\\\\n自动审核]; B2[机票预订\\\\n搜索比价]
        B3[辅营产品]; B4[退改签]; B5[代金券]
    end
    subgraph 后台支撑
        C1[大客户管理]; C2[销售报表]; C3[结算对账]
    end
    A1 --> B1; A3 --> B1; A2 --> B2
    B1 --> B2; B2 --> B3; B3 --> B4; B2 --> B5; B5 --> B4
    B2 --> C2; C1 --> B1; C3 --> B3 & B5
```

### 4. 功能层次结构图模板

```mermaid
flowchart TD
    subgraph 展示层
        UI1[PC官网]; UI2[小程序]; UI3[Web H5]; UI4[管理后台]
    end
    subgraph 业务服务层
        S1[编码管理]; S2[退改签]; S3[辅营销售]
        S4[代金券]; S5[用户中心]; S6[活动运营]
    end
    subgraph 集成层
        I1[民航接口]; I2[政采]; I3[NDC]; I4[支付]
    end
    subgraph 基础设施层
        INF1[PMO]; INF2[架构]; INF3[安全]; INF4[监控]
    end
    UI1 & UI2 & UI3 & UI4 --> S1 & S2 & S3 & S4 & S5 & S6
    S1 & S2 & S3 & S4 & S5 & S6 --> I1 & I2 & I3 & I4
    S1 & S2 & S3 & S4 & S5 & S6 --> INF3
```

### 5. 用例图模板 (flowchart TD 替代 usecaseDiagram)

注意：`usecaseDiagram` 已在 Mermaid v11 中移除。改用 `flowchart TD` + `((Actor))` 双圆节点 + `[(UC)]` 数据库形节点：

```mermaid
flowchart TD
    subgraph 系统名称
        UC1[(企业注册/\\\\n信息管理)]
        UC2[(家属编码\\\\n申请/审批)]
        UC3[(机票搜索/\\\\n预订/支付)]
        UC4[(辅营产品\\\\n选座/行李)]
    end
    User((企业客户)); Emp((企业员工)); Admin((管理员))
    User --> UC1; Emp --> UC2 & UC3 & UC4; Admin --> UC2 & UC1
```

### 6. 系统架构图模板

```mermaid
flowchart TD
    subgraph 接入层
        GW[API Gateway\\\\nSpring Cloud Gateway]; LB[负载均衡\\\\nSLB/Nginx]
    end
    subgraph 服务层
        MS[业务微服务集群\\\\n编码/预订/辅营/退改/报表]
    end
    subgraph 中间件层
        MQ[RocketMQ]; RD[Redis Cluster]; SR[Nacos]
    end
    subgraph 数据层
        DB[(MySQL Percona\\\\n分库分表4×64)]; ES[(Elasticsearch)]
    end
    subgraph 可观测层
        PM[Prometheus]; GR[Grafana]; SK[SkyWalking]
    end
    LB --> GW; GW --> MS; MS --> MQ & RD & SR; MS --> DB & ES; MS --> PM & GR & SK
```

### 7. 部署架构图模板 (用 flowchart LR 横向布局)

```mermaid
flowchart LR
    subgraph CI/CD流水线
        GIT[GitLab]; CI[GitLab CI]; REG[镜像仓库\\\\nHarbor]; CD[ArgoCD]
    end
    subgraph 北京主[主数据中心]
        POD1[服务Pod×2]; DB1[MySQL主]; RD1[Redis主]; GW1[Gateway主]
    end
    subgraph 上海备[灾备中心]
        POD2[服务Pod×1]; DB2[MySQL从]; RD2[Redis从]; GW2[Gateway备]
    end
    subgraph 外部
        API[民航/NDC/政采]; PAY[支付网关]
    end
    GIT --> CI --> REG --> CD
    CD --> POD1 & POD2; CD --> GW1 & GW2
    GW1 --> POD1; GW2 --> POD2
    POD1 --> DB1 & RD1; DB1 --> DB2; RD1 --> RD2
    POD1 --> API & PAY
```

### 8. Python API 推送模式

```python
import json, urllib.request

BS = "http://localhost:8080/api"
AUTH = f"Token {TOKEN}"

def api(method, path, data=None):
    body = json.dumps(data).encode() if data else None
    req = urllib.request.Request(f"{BS}{path}", data=body,
        headers={'Authorization': AUTH, 'Content-Type': 'application/json'}, method=method)
    resp = urllib.request.urlopen(req, timeout=30)
    return json.loads(resp.read().decode())

result = api('PUT', '/pages/{page_id}', {
    'name': '页面名称',
    'html': full_html,
    'tags': [{'name': 'diagrams', 'value': '5'}]
})
```

## Python 3.11 f-string 陷阱

Python 3.11 禁止在 f-string 的 `{...}` 表达式中使用反斜杠：

```python
# ❌ SyntaxError:
print(f"Mermaid: {html.count('<pre class=\\"mermaid\\"')}")

# ✅ 用变量中转:
mc = html.count('<pre class="mermaid"')
print(f"Mermaid: {mc}")
```

## 验证清单

- [ ] 每个 `pre class="mermaid"` 块 ≤ 35 行（CodeMirror 限制）
- [ ] 多行节点文本用 `\\n`（字面量反斜杠+n），非真实换行符
- [ ] 不用 `usecaseDiagram` 类型（Mermaid v11 已移除）
- [ ] 用例图用 `flowchart TD` + `((Actor))` + `[(UC)]`
- [ ] 部署图用 `flowchart LR` 横向布局
- [ ] f-string 中不用反斜杠，用变量中转
