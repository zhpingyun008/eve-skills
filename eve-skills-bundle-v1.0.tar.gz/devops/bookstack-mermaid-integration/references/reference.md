# Reference: devops/bookstack-mermaid-integration

Brief description of devops/bookstack-mermaid-integration's purpose and usage.
