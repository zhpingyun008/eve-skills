# Mermaid 故障修复检查清单

## 问题1: `usecaseDiagram` 不被识别
**症状**: ❌ No diagram type detected matching given configuration for text: usecaseDiagram...
**原因**: Mermaid v11+ 已弃用 `usecaseDiagram`，或BookStack的Mermaid加载器正则白名单不包含它。
**修复**: 转为 `flowchart TD` 流程图

### 转换规则
| 原语法 (PlantUML风格) | 目标语法 (flowchart TD) |
|---|---|
| `usecaseDiagram` | `flowchart TD` |
| `actor 名称 as Alias` | `Alias((名称))` 双圆圈节点 |
| `usecase "标签" as ID` | `ID[(标签)]` 数据库形节点 |
| `package "名称" { ... }` | `subgraph 名称 ... end` |
| `Actor --> UC1` | `Alias --> ID` |
| `UC1 ..> UC2 : <<include>>` | `ID1 -.->\|include\| ID2` |
| 独立style每节点 | `style Actor fill:#6c5ce7,color:#fff` |

**区别对待 `html` 和 `text` 列**:
- `entity_page_data.html` 列中的箭头是 `--&gt;` (HTML实体编码)
- `entity_page_data.text` 列中的箭头是 `-->` (纯文本)
- 必须准备两套查找/替换字符串，否则替换会失败
- 修复SQL见主SKILL.md中的"Revision Tracking Pattern"章节

### 压缩技巧（防36行截断）
- 合并多个UC声明到一行：`UC1[(注册)]  UC2[(搜索)]  UC3[(详情)]`
- 批量箭头：`User --> UC1 & UC2 & UC3`
- 移除不必要的独立style，只保留Actor样式

## 问题2a: 多节点同行声明
**症状**: Parse error on line 3: ... UC1[(X)] UC2[(Y)] UC3[(Z)] -------^ Expecting 'SEMI', 'NEWLINE', ...
**原因**: Mermaid `flowchart TD` 要求每行一个完整语句，`UC1[(X)] UC2[(Y)]` 多节点同行声明不被支持。
**修复**: 每个节点独占一行。
```
❌ UC1[(注册/登录)]  UC2[(搜索航班)]  UC3[(查看航班详情)]   ← 错误
✅ UC1[(注册/登录)]                                             ← 正确
   UC2[(搜索航班)]
   UC3[(查看航班详情)]
```
**注意**: 只有箭头连接可以用 `&` 批量语法（如 `User --> UC1 & UC2 & UC3`），**纯节点声明**必须分行。

## 问题2b: CodeMirror 36行截断
**症状**: Parse error on line 37: ... Expecting 'SEMI', 'NEWLINE', 'SPACE', 'EOF', 'subgr'
**原因**: BookStack CodeMirror只渲染前~36行，37行后全部丢弃
**修复**: 保持Mermaid代码 ≤35行

### 压缩方法
- 使用 `&` 批量连接语法：`A --> B & C & D`
- 使用链式语法合并连续箭头：`A --> B --> C --> D`（✅有效）❌ `A --> B  B --> C`（空格分隔无效）
- 移除冗余style行
- 缩短节点标签文字
- 删除未被连接引用的孤立节点（每删1个省1行）

## 问题2d: `;` 分隔的多节点声明同行（错误压缩模式）
**症状**: Parse error on line N: ... A1[name]; A2[name2]; A3[name3] ... -------^ Expecting 'SEMI', 'NEWLINE'
**原因**: 压缩脚本将节点声明误用 `;` 合并到同一行。在Mermaid `flowchart`/`graph` 中，**`;` 只能用于分隔完整语句**（如 `A --> B ; C --> D`），**不能用于分隔纯节点声明**（如 `A1[name]; A2[name2]`）。
| 语法 | `;` 有效？ | 示例 |
|------|-----------|------|
| 语句分隔 | ✅ | `A --> B ; C --> D` (两个完整有效语句) |
| 节点声明 | ❌ | `A1[name]; A2[name2]; A3[name3]` (无效) |
**修复**: 每个节点独占一行。
```
❌ subgraph "前端层"
       A1[海航App]; A2[微信小程序]; A3[Web H5]      ← 错误
   end
✅ subgraph "前端层"
       A1[海航App]
       A2[微信小程序]
       A3[Web H5]
   end
```
**根因**: 压缩脚本作者的常见误区——在SQL/Shell中用惯 `;` 分隔，误以为Mermaid同样支持。区分：`;` 只连接"主语→谓语→宾语"完整句子，不连接裸名词。

## 问题2e: `&` 扇出限制（仅限右侧目标）
**症状**: `A & B & C --> D` 报错或无效渲染
**原因**: Mermaid `flowchart`/`graph` 的 `&` 扇出（batch connector）**仅支持右侧多目标**：
- ✅ `A --> B & C & D` — 一个源到多个目标（有效扇出）
- ❌ `A & B & C --> D` — 多个源到一个目标（无效扇入）
- ❌ `A1[name] & A2[name2] --> B` — 声明+连接混合（无效）
**修复扇入（多源到一目标）方案：**
| 方案 | 语法 | 行数 | 适用场景 |
|------|------|------|---------|
| 单行`;`合并 | `A1 --> B ; A2 --> B` | 1 | 2-3个源扇入 |
| 独立行 | `A1 --> B` + `A2 --> B` | 2/源 | 清晰易维护 |
**`;` 扇入示例:** `A1 --> B1 ; A2 --> B1` (一条语句，两个源分别→B1 → 有效！)

## 问题2f: BeautifulSoup lxml 吞噬 `<pre>` 换行符（根因）
**症状**: Mermaid存储到BookStack后，原本换行分隔的节点被折叠到同一行（如 `F1[注册] F2[登录] F3[个人中心] F4[历史订单]`），导致解析错误。
**原因**: `BeautifulSoup(diagrams_html, 'lxml')` 使用 `lxml` 解析器时，**会折叠 `<pre>` 标签内的换行符**。`lxml` 将 `<pre>` 视为保留文本节点，但它的HTML树构造器在处理缩进/换行时，会规范化空白字符。
**修复**: 使用 `html.parser` 替代 `lxml`：
```python
# ❌ lxml 吞噬换行符
alert.insert_before(BeautifulSoup(diagrams_html, 'lxml'))
# ✅ html.parser 保留 <pre> 内换行符
alert.insert_before(BeautifulSoup(diagrams_html, 'html.parser'))
```
**验证**: 写入DB后检查 `<pre class="mermaid">` 内是否保留了真正的 `\n` 字符（非 `\\n` 字面量）。
**预防**: 所有涉及 `<pre class="mermaid">` 的HTML构建/注入代码，统一使用 `html.parser` 而非 `lxml`。

## 问题3: HTML实体转义
**症状**: Parse error on line 33: ... F1 -.-> F5 F5 -.-> F9 F9 -.-> --------^ Expecting 'SEMI', 'NEWLINE'
**原因**: Mermaid不支持空格分隔的多箭头同行 `A -.-> B  B -.-> C`。空格无法表示箭头之间的连接关系。
**修复**: 两种方案——
  (1) 链式语法：`A -.-> B -.-> C -.-> D`（✅有效，箭头之间用`-.->`连接）
  (2) 拆分为独立行：每箭头一行
  *对比*:
  | 错误 | 正确 |
  |---|---|
  | `A -.-> B  B -.-> C  C -.-> D` | `A -.-> B -.-> C -.-> D` |
  | `A --> P  Q --> R`（无关箭头） | `A --> P` + `Q --> R`（独立行） |
  | `A --> B & C` | ✅ `&`扇出语法有效（同一源） |
**行数补偿**: 拆分后超35行时，可删除未被任何连接引用的孤立节点（声明了但从未出现在箭头中的节点），每删一个省1行。

## 问题3: HTML实体转义
**症状**: Mermaid图空白/不渲染 / 箭头符号显示为文字
**原因**: `<<include>>` 被HTML编码为 `&lt;&lt;include&gt;&gt;`
**修复**: 替换为原始符号
- `&lt;&lt;include&gt;&gt;` → `<<include>>`
- `&lt;` → `<`
- `&gt;` → `>`
- `&amp;` → `&`

## 问题4: 跨页传播 — 修复后"still broken"

**症状**: 你修好了页面A的Mermaid错误，用户/浏览器刷新后依然报同样的错。

**根因**: 同一book内3+个页面都有相同的`usecaseDiagram`代码（复制粘贴传播）。你只修了其中一个。

**诊断SQL**:
```sql
-- 查找book内所有含usecaseDiagram的页面
SELECT e.id, e.name 
FROM entities e
JOIN entity_page_data p ON e.id = p.page_id
WHERE e.type = 'page' 
  AND p.html LIKE '%usecaseDiagram%'
  AND e.book_id = <你的BOOK_ID>
ORDER BY e.id;
```

**修复**: 批量修复所有命中页面，一次性commit。

## 快速修复代码模板

```python
import pymysql, datetime, re
from collections import defaultdict

conn = pymysql.connect(host='127.0.0.1', port=3307, user='bookstack', password='bookstack_pass', database='bookstack')
cursor = conn.cursor()
now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')

cursor.execute("SELECT p.html FROM entity_page_data p WHERE p.page_id = %s", (page_id,))
html = cursor.fetchone()[0]

# 找到usecaseDiagram块
pre_start = html.rfind('<pre', 0, html.find('usecaseDiagram'))
pre_end = html.find('</pre>', pre_start) + 6
old_block = html[pre_start:pre_end]

# 重建为flowchart TD
# 解析actors/ucs/relations → 构建flowchart → 替换写回

cursor.execute("UPDATE entity_page_data SET html = %s, ... WHERE page_id = %s", ...)
conn.commit()
conn.close()
```
