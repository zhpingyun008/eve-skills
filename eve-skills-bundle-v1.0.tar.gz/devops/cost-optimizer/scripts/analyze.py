#!/usr/bin/env python3
"""Cloud cost analyzer — identify waste and suggest savings.
For multi-account analysis, use delegate_task to scan accounts in parallel."""
import argparse, json

WASTE_RULES = {
    "unattached_ebs": {"desc": "Unattached EBS volumes", "cost": 0.10},
    "idle_instance": {"desc": "Instances <10% CPU avg over 7 days", "cost": 1.0},
    "old_snapshot": {"desc": "Snapshots >90 days old", "cost": 0.05},
    "unused_eip": {"desc": "Unassociated Elastic IPs", "cost": 3.60},
    "oversized_instance": {"desc": "Instances never exceeding 30% util", "cost": 0.6},
    "idle_lb": {"desc": "Load balancers with zero targets", "cost": 20.0},
}

def analyze(resources):
    findings, total = [], 0
    for rule, info in WASTE_RULES.items():
        matches = [r for r in resources if r.get("type") == rule]
        if matches:
            savings = len(matches) * info["cost"] * 30
            findings.append({"rule": rule, "desc": info["desc"], "count": len(matches), "monthly": round(savings, 2)})
            total += savings
    return {"monthly": round(total, 2), "annual": round(total * 12, 2), "findings": findings}

def main():
    ap = argparse.ArgumentParser(description="Cloud cost optimizer")
    ap.add_argument("--demo", action="store_true")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()
    demo = [
        {"type": "unattached_ebs", "id": "vol-001", "size_gb": 100},
        {"type": "unattached_ebs", "id": "vol-002", "size_gb": 50},
        {"type": "idle_instance", "id": "i-abc", "avg_cpu": 3.2, "monthly_cost": 150},
        {"type": "unused_eip", "id": "eip-xyz"},
        {"type": "old_snapshot", "id": "snap-old", "age_days": 120},
    ]
    result = analyze(demo)
    if args.json:
        print(json.dumps(result, indent=2))
    else:
        print("=== Cloud Cost Optimization ===")
        for f in result["findings"]:
            print(f"  [{f['rule']}] {f['desc']}: {f['count']} ~${f['monthly']}/mo")
        print(f"\n  Monthly savings: ${result['monthly']}")
        print(f"  Annual savings:  ${result['annual']}")

if __name__ == "__main__":
    main()
