# cost-optimizer — Reference

## Overview
Cloud cost optimization — identify idle resources, right-size instances, reserved instance planning, Savings Plans analysis. Multi-cloud (AWS/GCP/Azure).

## Integration Points
- Hermes Agent skill ecosystem
- evolution_engine.py scoring system
- self-audit verification

## Key Resources
- SKILL.md: main skill definition
- scripts/: executable code (if present)
