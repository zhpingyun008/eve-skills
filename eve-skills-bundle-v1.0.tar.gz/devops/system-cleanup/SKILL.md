---
name: system-cleanup
description: 系统清理优化checklist — 磁盘空间释放、缓存清理、日志轮转、临时文件、孤立依赖、陈旧内核清理、Docker资源回收、包管理器缓存。全面系统健康优化。
category: devops
triggers:
  - "系统清理"
  - "cleanup"
  - "清理磁盘"
  - "释放空间"
  - "磁盘空间不足"
  - "disk full"
  - "磁盘满了"
  - "优化系统"
  - "system cleanup"
  - "空间释放"
  - "cache clean"
  - "日志清理"
  - "docker清理"
  - "旧内核清理"
  - "system prune"
  - "清理缓存"
  - "disk cleanup"
  - "启动慢"
  - "slow startup"
  - "系统卡"
  - "system slow"
  - "性能诊断"
  - "performance issue"
  - "boot slow"
  - "response slow"
---

# system-cleanup — 系统清理优化Checklist

## Phase 0: Performance Bottleneck Diagnosis (pre-cleanup)

在动手清理前先定位根因，避免盲目清理。

### 1. System Resource Scan
```bash
uptime                                          # load + uptime
top -bn1 | head -5                              # CPU idle + I/O wait
cat /proc/loadavg                               # precise load
free -h                                         # memory + buffer/cache
df -h / /mnt/c/                                 # WSL + Windows C:
swapon --show
iostat -x 1 3                                   # disk IOPS (install sysstat)
```

### 2. Startup Latency Diagnosis
```bash
ps -eo pid,lstart,comm --sort=start_time        # process start sequence
crontab -l | grep '@reboot'                     # boot-triggered scripts
crontab -l | grep -c '@reboot'                  # count @reboot
crontab -l | grep -E '\*\/[0-9]+'               # high-freq cron density
```

### 3. Space Sinkhole Map
```bash
du -sh ~/.hermes/*/ | sort -rh | head -15
```

**Common hotspots**: `sessions/` (1-2G JSON files), `state-snapshots/` (4-5G single state.db), `cron/output/` (1-2G), `checkpoints/` (1-2G), `skills/.curator_backups/` (~1.6G), `os/log_store.db` (3-4G), Windows C: drive >90%.

### 4. Process Density Audit
```bash
ps aux | grep -c python3                        # python process count
ps aux --sort=-%cpu | head -10                  # top CPU consumers
```

### 5. Critical Diagnostic Signals
- **I/O wait > 5%** at idle → disk bottleneck (usually C: near full)
- **Windows C: > 90%** → P0, WSL I/O drops 10-50x
- **@reboot > 2** → boot I/O storm
- **Every-N-min cron > 5** → persistent I/O contention
- **Python processes > 15** → module-load storm
- **Session JSON files > 10K** → migrate to SQLite or auto-prune

### 6. Root-Cause Chain
Connect findings into causality, e.g.:
```
C: disk 94% full → WSL I/O 10x slower → 22 Python processes all fork at once → I/O wait 10.9% → slow startup
```

## Overview

系统化系统清理清单。覆盖Linux/WSL系统的12个清理维度，从安全保守清理(风险极低)到激进清理(需确认)。每步提供预估可回收空间、风险等级和命令模板。

### 清理维度总览

| 优先级 | 维度 | 预估回收 | 风险 | 说明 |
|--------|------|----------|------|------|
| P0 | Docker 残留 | 500MB~5GB | 低 | 停止容器/悬空镜像/构建缓存 |
| P1 | 包管理器缓存 | 200MB~2GB | 极低 | apt/pip/npm/yarn/cargo/go cache |
| P2 | 日志文件 | 100MB~10GB | 低 | journalctl/应用日志/轮转日志 |
| P3 | 临时文件 | 100MB~1GB | 极低 | /tmp /var/tmp 过期文件 |
| P4 | 陈旧内核 | 200MB~1GB | 低 | 旧内核镜像/头文件 |
| P5 | Snap/Flatpak | 500MB~3GB | 低 | 旧版本缓存 |
| P6 | Homebrew | 200MB~2GB | 低 | 旧版本/缓存 |
| P7 | 用户缓存 | 500MB~10GB | 极低 | ~/.cache/* 浏览/应用/构建缓存 |
| P8 | 孤立包 | 100MB~500MB | 中 | 自动安装不再依赖的包 |
| P9 | 大文件排查 | 变量 | 极低 | >100MB 文件定位 |
| P10 | 重复文件 | 变量 | 中 | 重复下载/备份文件 |
| P11 | 旧项目构建产物 | 1GB~20GB | 低 | node_modules/target/dist/build 目录 |
| P12 | WSL虚拟磁盘压缩 | 1GB~20GB | 低 | WSL ext4.vhdx瘦身 |

## 触发条件

- "系统清理" / "cleanup" / "磁盘满了" / "disk full"
- 磁盘使用率 > 80%
- 定期维护 (建议每月执行一次)
- WSL vhdx文件过度膨胀
- Docker构建后磁盘空间不足
- "系统优化" / "释放空间"

## 执行流程

### Phase 0: 前置摸底 (必须先执行)

每次清理前执行，记录初始状态以便确认清理效果：

```bash
#!/bin/bash
# 系统清理 — 前置摸底

echo "=== 磁盘使用概览 ==="
df -h / | tail -1

echo ""
echo "=== 目录大小排行 (Top 15) ==="
du -sh /* 2>/dev/null | sort -rh | head -15

echo ""
echo "=== 各目录详情 (仅Home下>100MB) ==="
du -sh ~/*/ 2>/dev/null | sort -rh | head -20

echo ""
echo "=== 最大的20个文件 (>50MB) ==="
find / -xdev -type f -size +50M 2>/dev/null -exec du -sh {} \; | sort -rh | head -20

echo ""
echo "=== Docker 磁盘占用 ==="
docker system df 2>/dev/null || echo "Docker not installed"

echo ""
echo "=== 日志占用 ==="
journalctl --disk-usage 2>/dev/null || echo "journalctl not available"
du -sh /var/log/ 2>/dev/null

echo ""
echo "=== WSL虚拟磁盘大小 ==="
if [ -f /proc/sys/fs/binfmt_misc/WSLInterop ]; then
    echo "WSL环境 — 磁盘文件位于Windows:"
    powershell.exe -Command "Get-ChildItem \"\$env:LOCALAPPDATA\\Packages\\*\\LocalState\\ext4.vhdx\" | Select-Object @{N='SizeGB';E={[math]::Round(\$_.Length/1GB,2)}},FullName" 2>/dev/null || echo "(无法读取WSL磁盘文件大小)"
fi
```

### Phase 1: Docker 深度清理 (P0)

```bash
#!/bin/bash
echo "=== Phase 1: Docker 清理 ==="

# 1.1 停止所有运行容器(如果安全)
read -p "停止所有容器? (y/N) " stop_containers
if [ "$stop_containers" = "y" ]; then
    docker stop $(docker ps -q) 2>/dev/null
    echo "✓ 所有容器已停止"
fi

# 1.2 安全清除
echo "--- 1.2 安全清理: 悬空资源 ---"
docker container prune -f 2>/dev/null && echo "✓ 已清理停止的容器"
docker image prune -f 2>/dev/null && echo "✓ 已清理悬空镜像(dangling)"
docker network prune -f 2>/dev/null && echo "✓ 已清理未使用的网络"
docker volume prune -f 2>/dev/null && echo "✓ 已清理悬空卷"

# 1.3 深度清理 (谨慎)
echo "--- 1.3 深度清理: 未使用资源 ---"
read -p "清除所有未使用的镜像/构建缓存? (y/N) " deep_clean
if [ "$deep_clean" = "y" ]; then
    docker system prune -a -f 2>/dev/null && echo "✓ 深度清理完成"
fi

# 1.4 构建缓存单独清理 (安全)
docker builder prune -f 2>/dev/null && echo "✓ 构建缓存已清理"

echo "--- Docker 清理后状态 ---"
docker system df 2>/dev/null
```

**Pitfall**: `docker system prune -a -f` 会删除所有没有被容器引用的镜像。如果后面需要回滚/重建旧版本，镜像必须重新拉取。建议先执行 `docker image ls` 检查是否有需要保留的镜像。

### Phase 2: 包管理器缓存 (P1)

```bash
#!/bin/bash
echo "=== Phase 2: 包管理器缓存清理 ==="

# 2.1 APT (Debian/Ubuntu/WSL-Ubuntu)
if command -v apt &>/dev/null; then
    BEFORE=$(du -sh /var/cache/apt/ 2>/dev/null | cut -f1)
    sudo apt clean
    sudo apt autoclean  # 仅删除过时的包文件
    sudo apt autoremove -y  # 删除孤立依赖
    AFTER=$(du -sh /var/cache/apt/ 2>/dev/null | cut -f1)
    echo "✓ APT: $BEFORE → $AFTER"
fi

# 2.2 PIP (Python)
if command -v pip &>/dev/null; then
    # pip cache 命令需要 pip>=20.1
    BEFORE=$(du -sh ~/.cache/pip/ 2>/dev/null | cut -f1 || echo "0")
    pip cache purge 2>/dev/null && echo "✓ PIP cache: purged" || echo "~ pip cache: n/a"
    # 或用手动删除
    rm -rf ~/.cache/pip/ 2>/dev/null && echo "✓ PIP cache: $BEFORE → 0"
fi

# 2.3 npm/yarn/pnpm
if command -v npm &>/dev/null; then
    BEFORE=$(du -sh ~/.npm/ 2>/dev/null | cut -f1)
    npm cache clean --force 2>/dev/null && echo "✓ npm: $BEFORE → cleaned"
fi
if command -v yarn &>/dev/null; then
    BEFORE=$(du -sh $(yarn cache dir 2>/dev/null) 2>/dev/null | cut -f1)
    yarn cache clean 2>/dev/null && echo "✓ yarn: $BEFORE → cleaned"
fi
if command -v pnpm &>/dev/null; then
    BEFORE=$(du -sh ~/.pnpm-store/ 2>/dev/null | cut -f1)
    pnpm store prune 2>/dev/null && echo "✓ pnpm: $BEFORE → pruned"
fi

# 2.4 Cargo (Rust)
if command -v cargo &>/dev/null; then
    BEFORE=$(du -sh ~/.cargo/registry/ 2>/dev/null | cut -f1)
    cargo cache clean 2>/dev/null || rm -rf ~/.cargo/registry/cache/ 2>/dev/null
    echo "✓ Cargo: $BEFORE → cleaned"
fi

# 2.5 Go
if command -v go &>/dev/null; then
    BEFORE=$(du -sh "$(go env GOMODCACHE)" 2>/dev/null | cut -f1)
    go clean -modcache 2>/dev/null && echo "✓ Go mod cache: $BEFORE → cleaned"
fi

# 2.6 Homebrew (macOS/Linux)
if command -v brew &>/dev/null; then
    BEFORE=$(du -sh "$(brew --cache)" 2>/dev/null | cut -f1)
    brew cleanup --prune=all 2>/dev/null && echo "✓ Homebrew: $BEFORE → pruned"
fi
```

**Pitfall**: `apt autoremove` 可能删除手动安装但被标记为"自动安装"的包。如果不确定，先用 `apt --dry-run autoremove` 预览即将删除的包列表。

```bash
# 安全预览
apt list --manual-installed 2>/dev/null | head -5
apt --dry-run autoremove 2>/dev/null | grep "REMOVED"
```

### Phase 3: 日志清理 (P2)

```bash
#!/bin/bash
echo "=== Phase 3: 日志清理 ==="

# 3.1 systemd journal (最有效)
if command -v journalctl &>/dev/null; then
    BEFORE=$(journalctl --disk-usage 2>/dev/null | awk '{print $NF}')
    # 保留最近7天日志 (安全)
    sudo journalctl --vacuum-time=7d 2>/dev/null
    AFTER=$(journalctl --disk-usage 2>/dev/null | awk '{print $NF}')
    echo "✓ journalctl: $BEFORE → $AFTER (保留7天)"
    
    # 可选: 限制journal大小 (永久)
    read -p "设置journal大小上限为100MB? (y/N) " limit_journal
    if [ "$limit_journal" = "y" ]; then
        sudo sh -c 'echo "SystemMaxUse=100M" >> /etc/systemd/journald.conf'
        sudo systemctl restart systemd-journald
        echo "✓ journal日志上限已设为100MB"
    fi
fi

# 3.2 /var/log 下旧日志
BEFORE=$(du -sh /var/log/ 2>/dev/null | cut -f1)
sudo find /var/log -name "*.gz" -o -name "*.old" -o -name "*.1" -o -name "*.2" -o -name "*.3" 2>/dev/null | while read f; do
    sudo rm -f "$f"
done
# 安全: 保留当前日志文件，只删除轮转的旧日志
AFTER=$(du -sh /var/log/ 2>/dev/null | cut -f1)
echo "✓ /var/log 轮转日志: $BEFORE → $AFTER"

# 3.3 应用日志 (仅确认大小，手动决定)
find ~/ -name "*.log" -type f 2>/dev/null -exec du -ch {} + 2>/dev/null | tail -1
read -p "清理 ~/*.log 旧日志? (y/N) " clean_app_logs
if [ "$clean_app_logs" = "y" ]; then
    find ~/ -name "*.log" -type f -mtime +7 2>/dev/null -delete
    echo "✓ 7天前的应用日志已清理"
fi
```

### Phase 4.5: Windows C盘临时文件清理（从WSL操作）

当WSL上的 `/dev/sdd` 磁盘（Linux部分）空间充足但Windows C盘（`/mnt/c/`）使用率>90%时，没有Docker或过大日志的典型原因是**Windows用户Temp目录**。

**重要：WSL的 /mnt/c/ 文件系统遍历极慢** — `du -sh /mnt/c/Users/*/AppData/Local/Temp` 可能超时60s+且CPU 100%。不要从WSL shell/Python递归遍历Windows路径。

**正确方法**：用 `cmd.exe /c "cd /d C:\ && ..."` 调用Windows原生命令：

```bash
# 1. 查清当前使用量和可回收空间
cmd.exe /c "cd /d C:\ && wmic logicaldisk where caption='C:' get freespace /format:value"

# 2. 清理用户Temp （~11GB常见）
cmd.exe /c "cd /d C:\ && del /s /q Users\Administrator\AppData\Local\Temp\*.* >nul 2>nul"

# 3. 清理Windows Temp（通常较小但也要清）
cmd.exe /c "cd /d C:\ && del /s /q Windows\Temp\*.* >nul 2>nul"

# 4. 如果用batch文件for循环删除子目录，写成.bat文件再执行
# 先写bat文件到Windows Temp：
write_file /mnt/c/Windows/Temp/clean_temp.bat:
  @echo off
  cd /d C:\
  echo Cleaning User Temp...
  del /s /q "Users\Administrator\AppData\Local\Temp\*.*" >nul 2>nul
  for /d %%d in ("Users\Administrator\AppData\Local\Temp\*") do rmdir /s /q "%%d" >nul 2>nul
  echo Done.

# 再执行：
cmd.exe /c "cd /d C:\ && Windows\Temp\clean_temp.bat"

# 5. 验证释放效果
cmd.exe /c "cd /d C:\ && wmic logicaldisk where caption='C:' get freespace /format:value"
```

**⚠️ PowerShell从WSL调用的陷阱**：`powershell.exe -Command "Get-ChildItem $_.FullName"` 中的 `$_` 会被WSL bash解释为shell变量（扩展为 `/home/yestin`）。必须用 `$$` 转义或写入 .ps1 文件再执行。

**释放效果参考**：用户Temp目录通常可回收 8-15 GB。2026-06-24实测：C盘从12.8GB可用(94%) → 22.2GB可用(87%)，释放约9.4GB。

### Phase 4: 临时文件清理 (P3)

```bash
#!/bin/bash
echo "=== Phase 4: 临时文件清理 ==="

# 4.1 /tmp 过期文件 (保留最近24小时)
BEFORE=$(du -sh /tmp/ 2>/dev/null | cut -f1)
sudo find /tmp -type f -atime +1 -delete 2>/dev/null
sudo find /tmp -type d -empty -delete 2>/dev/null
AFTER=$(du -sh /tmp/ 2>/dev/null | cut -f1)
echo "✓ /tmp: $BEFORE → $AFTER (保留24小时内访问的文件)"

# 4.2 /var/tmp 过期文件 (保留最近7天)
sudo find /var/tmp -type f -atime +7 -delete 2>/dev/null

# 4.3 用户临时文件
BEFORE=$(du -sh ~/tmp/ ~/Temp/ 2>/dev/null | tail -1 | cut -f1)
[ -n "$BEFORE" ] && rm -rf ~/tmp/* ~/Temp/* 2>/dev/null && echo "✓ ~/tmp: $BEFORE → 0"
```

### Phase 5: 陈旧内核清理 (P4)

```bash
#!/bin/bash
echo "=== Phase 5: 陈旧内核清理 ==="

# 仅 Ubuntu/Debian 系统
if command -v dpkg &>/dev/null; then
    CURRENT=$(uname -r)
    echo "当前内核: $CURRENT"
    
    # 列出已安装内核
    echo "已安装内核:"
    dpkg --list | grep -E 'linux-image|linux-headers' | awk '{print $2, $3}'
    
    # 建议删除的非当前内核
    OLD_KERNELS=$(dpkg --list | grep -E 'linux-image-[0-9]+' | awk '{print $2}' | grep -v "$(uname -r | sed 's/-generic//')" || true)
    
    if [ -n "$OLD_KERNELS" ]; then
        echo ""
        echo "可删除的旧内核:"
        echo "$OLD_KERNELS"
        read -p "删除以上旧内核? (y/N) " remove_kernels
        if [ "$remove_kernels" = "y" ]; then
            echo "$OLD_KERNELS" | xargs sudo apt purge -y
            sudo update-grub 2>/dev/null
            echo "✓ 旧内核已清理"
        fi
    else
        echo "✓ 无多余内核"
    fi
fi
```

**Pitfall**: 永远保留至少一个已知可引导的旧内核作为 fallback。`uname -r` 显示的是当前运行的内核，删除所有其他内核是安全的，但保留当前+最近一个旧内核更稳妥。

```bash
# 安全做法: 保留最近2个内核
sudo apt remove --purge $(dpkg -l 'linux-image-*' | awk '$1=="ii"{print $2}' | grep -v $(uname -r) | tail -n +3) -y
```

### Phase 6: 大文件与重复文件排查 (P9/P10)

```bash
#!/bin/bash
echo "=== Phase 6: 大文件与重复文件排查 ==="

# 6.1 最占用空间的文件
echo "--- 最大的30个文件 (>100MB) ---"
find /home -xdev -type f -size +100M 2>/dev/null -exec du -sh {} \; | sort -rh | head -30

# 6.2 最大的目录 (排除系统目录)
echo ""
echo "--- 最占空间的目录 ---"
du -sh ~/projects/*/ ~/.local/*/ ~/.config/*/ 2>/dev/null | sort -rh | head -20

# 6.3 重复文件检测 (相同名称和大小的文件)
echo ""
echo "--- 可能存在重复的大文件 ---"
find ~/ -type f -size +50M 2>/dev/null | while read f; do
    basename "$f"
done | sort | uniq -c | sort -rn | head -20 | while read count name; do
    if [ "$count" -gt 1 ]; then
        echo "  重复 $count 次: $name"
    fi
done
```

### Phase 7: 旧项目构建产物 (P11)

```bash
#!/bin/bash
echo "=== Phase 7: 旧项目构建产物 ==="

# 7.1 扫描 node_modules
echo "--- node_modules 统计 ---"
find ~/projects/ ~/dev/ ~/work/ -maxdepth 4 -name "node_modules" -type d 2>/dev/null | while read dir; do
    size=$(du -sh "$dir" 2>/dev/null | cut -f1)
    echo "  $size  $(dirname $dir | xargs basename)"
done | sort -rh | head -15

# 7.2 扫描 target (Rust)
echo ""
echo "--- target (Rust) 统计 ---"
find ~/projects/ ~/dev/ ~/work/ -maxdepth 4 -name "target" -type d 2>/dev/null | while read dir; do
    size=$(du -sh "$dir" 2>/dev/null | cut -f1)
    echo "  $size  $(dirname $dir | xargs basename)"
done | sort -rh | head -10

# 7.3 扫描 dist/build
echo ""
echo "--- dist/build 目录统计 ---"
find ~/projects/ ~/dev/ ~/work/ -maxdepth 4 \( -name "dist" -o -name "build" -o -name ".next" \) -type d 2>/dev/null | while read dir; do
    size=$(du -sh "$dir" 2>/dev/null | cut -f1)
    echo "  $size  $(dirname $dir | xargs basename)"
done | sort -rh | head -10

# 7.4 扫描 .venv/__pycache__
echo ""
echo "--- Python 相关缓存 ---"
find ~/projects/ ~/dev/ ~/work/ -maxdepth 3 -name ".venv" -type d 2>/dev/null | while read dir; do
    size=$(du -sh "$dir" 2>/dev/null | cut -f1)
    echo "  $size  .venv: $(dirname $dir | xargs basename)"
done | sort -rh | head -10
```

### Phase 8: WSL 虚拟磁盘瘦身 (P12)

WSL 的 ext4.vhdx 文件不会自动缩小 — 即使你在 WSL 内删除了文件，Windows 上的 vhdx 文件大小不变。必须执行压缩：

```bash
#!/bin/bash
echo "=== Phase 8: WSL 虚拟磁盘压缩 ==="

if [ ! -f /proc/sys/fs/binfmt_misc/WSLInterop ]; then
    echo "✗ 非WSL环境，跳过"
    return
fi

echo "⚠ WSL用户注意: Linux内部删除文件不会自动回收Windows上的磁盘空间"

read -p "执行WSL虚拟磁盘压缩? (需要管理员权限, y/N) " compress_wsl
if [ "$compress_wsl" = "y" ]; then
    # 1. 在WSL内部释放未使用空间
    echo "--- 步骤1: 在WSL内部用fstrim标记空闲空间 ---"
    sudo fstrim / 2>/dev/null && echo "✓ fstrim 完成" || echo "⚠ fstrim 失败 (可能需要 util-linux)"

    # 2. 退出WSL并在Windows上压缩vhdx
    echo ""
    echo "--- 步骤2: 在Windows PowerShell中压缩vhdx ---"
    echo "请在Windows中打开 PowerShell (管理员) 并执行:"
    echo ""
    echo '  # 停止WSL'
    echo '  wsl --shutdown'
    echo ''
    echo '  # 找到vhdx路径 (通常如下)'
    echo '  $vhdx = Get-ChildItem "$env:LOCALAPPDATA\Packages\*\LocalState\ext4.vhdx" | Select-Object -First 1'
    echo '  Write-Host "压缩前: $([math]::Round((Get-Item $vhdx.FullName).Length/1GB,2)) GB"'
    echo ''
    echo '  # 压缩 (需要Windows 10 1903+)'
    echo "  Optimize-VHD -Path \$vhdx.FullName -Mode Full"
    echo ''
    echo '  # 验证'
    echo '  Write-Host "压缩后: $([math]::Round((Get-Item $vhdx.FullName).Length/1GB,2)) GB"'
    echo ''
    echo "  # 或使用 diskpart 方法 (备选)"
    echo '  # diskpart'
    echo '  # select vdisk file="C:\Users\%USERNAME%\AppData\Local\Packages\...\LocalState\ext4.vhdx"'
    echo '  # attach vdisk readonly'
    echo '  # compact vdisk'
    echo '  # detach vdisk'
    echo '  # exit'
    echo ""
    read -p "执行完成后按Enter继续..."
fi
```

**Pitfall**: `Optimize-VHD` 需要 Hyper-V PowerShell 模块。如果该命令不可用，可使用 diskpart 作为备选。另外，WSL 必须完全关闭 (`wsl --shutdown`) 后才能操作 vhdx 文件。压缩前确保已运行 `sudo fstrim /` 释放 WSL 内的未使用块。

### Phase 9: Snap/Flatpak 缓存 (P5)

```bash
#!/bin/bash
echo "=== Phase 9: Snap/Flatpak 清理 ==="

# 9.1 Snap
if command -v snap &>/dev/null; then
    # 保留最近2个版本
    BEFORE=$(du -sh /var/lib/snapd/cache/ 2>/dev/null | cut -f1)
    sudo snap set system refresh.retain=2
    # 清理旧版本
    snap list --all | awk '/disabled/{print $1, $3}' | while read snap_name rev; do
        sudo snap remove "$snap_name" --revision="$rev" 2>/dev/null
    done
    echo "✓ Snap: 旧版本已清理 (保留最近2个)"
fi

# 9.2 Flatpak
if command -v flatpak &>/dev/null; then
    BEFORE=$(du -sh /var/lib/flatpak/repo/ 2>/dev/null | cut -f1)
    flatpak uninstall --unused -y 2>/dev/null
    echo "✓ Flatpak: 未使用的运行时已清理"
fi
```

### Phase 10: 用户缓存目录 (P7)

```bash
#!/bin/bash
echo "=== Phase 10: 用户缓存清理 ==="

# 安全: 只清理明确安全的缓存
CLEANABLE_CACHES=(
    ".cache/thumbnails/*"
    ".cache/mozilla/firefox/*/cache2/*"
    ".cache/google-chrome/*/Cache/*"
    ".cache/pip/*"
    ".cache/vscode-cpptools/*"
    ".cache/JetBrains/*/caches/*"
    ".cache/composer/*"
    ".cache/yarn/*"
    ".npm/*"
    ".cargo/registry/cache/*"
    ".gradle/caches/*"
    ".ivy2/cache/*"
    ".sbt/*"
    ".cmake/*"
)

echo "可清理的缓存目录 (~/.cache/ 下):"
for cache in "${CLEANABLE_CACHES[@]}"; do
    size=$(du -sh "$HOME/$cache" 2>/dev/null | cut -f1)
    [ -n "$size" ] && echo "  $size  ~/$cache"
done

read -p "清理以上所有缓存? (y/N) " clean_cache
if [ "$clean_cache" = "y" ]; then
    for cache in "${CLEANABLE_CACHES[@]}"; do
        rm -rf "$HOME/$cache" 2>/dev/null
    done
    echo "✓ 用户缓存已清理"
fi

# 浏览器缓存单独确认
echo ""
echo "--- 浏览器缓存 (单独确认) ---"
for browser_cache in ".cache/google-chrome" ".cache/mozilla/firefox" ".cache/chromium" ".cache/microsoft-edge"; do
    size=$(du -sh "$HOME/$browser_cache" 2>/dev/null | cut -f1)
    [ -n "$size" ] && echo "  $size  ~/$browser_cache"
done
read -p "清理浏览器缓存? (会清除登录状态, y/N) " clean_browser
[ "$clean_browser" = "y" ] && rm -rf "$HOME/.cache/google-chrome" "$HOME/.cache/mozilla" "$HOME/.cache/chromium" 2>/dev/null && echo "✓ 浏览器缓存已清理"
```

### Phase 11: 最终状态报告

```bash
#!/bin/bash
echo ""
echo "========================================================================"
echo "  系统清理报告"
echo "========================================================================"
echo ""

echo "=== 最终磁盘使用率 ==="
df -h / | tail -1

echo ""
echo "=== 预计回收空间 ==="
echo "  请在清理前记录初始状态，以下为各阶段累计效果"
echo ""
echo "  常见回收总量参考:"
echo "    - 首次深度清理:   5-20 GB"
echo "    - 月度维护清理:   1-5 GB"
echo "    - Docker活跃用户: 额外 2-10 GB"
echo "    - WSL vhdx压缩:   额外 5-30 GB"
echo ""

echo "=== 下次清理建议 ==="
echo "  • 日常: pip/npm/cargo缓存清理 (每月)"
echo "  • 月度: 日志/tmp/Docker/包管理器 (每月)"
echo "  • 季度: 旧内核/Snap/用户缓存 (每3月)"
echo "  • 按需: WSL vhdx压缩 / 项目构建产物 (当空间不足)"
echo ""

echo "=== 持久优化建议 ==="
echo "  1. journal日志上限设置: SystemMaxUse=100M"
echo "  2. Snap retain 设为 2"
echo "  3. 定期 crontab: 0 3 1 * * ~/.hermes/skills/devops/system-cleanup/scripts/cleanup.sh --auto"
echo "  4. .dockerignore 减少构建上下文"
echo "  5. 旧项目归档: 将不活跃项目移至外部存储"
```

## 避坑指南

### 1. Docker prune -a 的后果

`docker system prune -a -f` + `docker builder prune -a -f` 会删除所有未被容器引用的镜像和全部构建缓存。如果CI/CD系统依赖本地构建缓存，下次构建会从零开始。

**对策**: 先用 `docker system df -v` 查看详细的镜像/缓存占用，确认没有需要保留的层。

### 2. apt autoremove 可能误删

`apt autoremove` 删除所有被标记为"自动安装"且不再被任何包依赖的包。但某些手动安装的库可能被错误标记。

**对策**: 执行前用 `apt --dry-run autoremove` 预览，检查是否有认识的包。

### 3. WSL fstrim 与 vhdx

- WSL1 不支持 fstrim
- 压缩 vhdx 前必须 `wsl --shutdown`
- `Optimize-VHD` 需要管理员 PowerShell + Hyper-V 模块
- 旧版 Windows 10 (< 1903) 只能通过 diskpart 压缩

### 4. 浏览器缓存清理影响

删除浏览器缓存会:
- 清除所有网站登录状态
- 清除浏览历史 (如果未同步)
- 清除扩展数据 (部分扩展)
- 次日首次加载速度变慢 (重新下载资源)

**对策**: 清理前确保浏览器同步已开启。

### 5. 日志清理后无法回溯

删除早期 journal 日志后，无法回溯超过保留时间的系统问题。

**对策**: 至少保留 7 天日志，生产环境至少保留 30 天。

### 6. 清理后的系统性能

清理后访问 `/tmp`、浏览器等缓存目录的应用首次使用会变慢（重新创建缓存），这是正常现象。

### 7. 磁盘空间立即释放 vs 文件系统延迟

Linux 删除大文件后，如果该文件正被进程打开，空间不会立即释放。需要重启该进程或使用 `lsof | grep deleted` 定位。

```bash
# 查找"已删除但仍在占用空间"的文件
lsof +L1 2>/dev/null | head -20
```

## 自动清理脚本 (cron 集成)

```bash
#!/bin/bash
# ~/.hermes/skills/devops/system-cleanup/scripts/auto_cleanup.sh
# 每月自动清理 (安全模式)

set -euo pipefail

LOG_FILE="$HOME/.system_cleanup_$(date +%Y%m).log"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" | tee -a "$LOG_FILE"
}

log "=== 月度自动清理开始 ==="

# 仅执行 P0-P3 (低风险)
log "Docker 安全清理..."
docker container prune -f 2>/dev/null && log "✓ docker containers pruned"
docker image prune -f 2>/dev/null && log "✓ docker dangling images pruned"
docker builder prune -f 2>/dev/null && log "✓ docker build cache pruned"

log "APT 清理..."
sudo apt clean 2>/dev/null
sudo apt autoclean 2>/dev/null

log "PIP 缓存..."
pip cache purge 2>/dev/null || true

log "Journal 日志 (保留7天)..."
sudo journalctl --vacuum-time=7d 2>/dev/null

log "tmp 过期文件..."
sudo find /tmp -type f -atime +1 -delete 2>/dev/null

log "=== 月度自动清理完成 ==="
df -h / | tail -1 | tee -a "$LOG_FILE"
```

## Verification

### 验证1: 前置摸底完整性

```bash
# 确认摸底命令可执行
bash -c "
    df -h /
    du -sh /* 2>/dev/null | sort -rh | head -5
    find / -xdev -type f -size +100M 2>/dev/null | head -5
    docker system df 2>/dev/null && echo '✓ Docker df works' || echo '~ Docker not available'
"
```

### 验证2: Docker 清理确认

```bash
# 确认清理命令存在且可安全执行
docker container prune --force 2>&1 | head -1
docker image prune --force 2>&1 | head -1
docker system df 2>&1 | head -5
```

### 验证3: 日志清理效果确认

```bash
# 清理前后对比
journalctl --disk-usage
sudo journalctl --vacuum-time=7d
journalctl --disk-usage
```

### 验证4: 磁盘空间恢复确认

```bash
# 比较清理前后的 / 使用率
echo "清理前: $(df -h / | tail -1 | awk '{print $4, $5}')"
# ...执行清理...
echo "清理后: $(df -h / | tail -1 | awk '{print $4, $5}')"
```

### 验证5: fstrim 支持检查

```bash
# 检查 WSL 或实际磁盘是否支持 fstrim
lsblk -D 2>/dev/null | head -5
# 如果 DISC-GRAN (discard granularity) 列不为 0，支持
sudo fstrim -v / 2>/dev/null && echo "✓ fstrim works" || echo "⚠ fstrim not supported"
```

## Feedback Engine Patches
*自动生成于 2026-07-16 02:02:04*

## Tool Recommendations (from trajectory feedback)

### patch
Trajectory analysis shows **patch** strongly correlates with high session scores.
- Use `patch` for targeted find-and-replace edits instead of sed/awk.
- Supports fuzzy matching with 9 strategies for robust edits.
- Auto-runs syntax checks after modification.
- Preferred for surgical code changes over full file rewrites.

### Guardrails
- Ensure `old_string` is unique in the file unless `replace_all=True`.
- Include enough surrounding context to guarantee uniqueness.
- Use `mode='patch'` for V4A multi-file patches.

### Efficiency Tips
- Combine multiple edits into a single V4A patch when possible.
- Use `replace_all=True` for bulk replacements of the same pattern.
- Preview changes with `--dry-run` mode before applying.

---
## Feedback Engine Patches
*自动生成于 2026-07-17 02:02:37*

## Tool Recommendations (from trajectory feedback)

### patch
Trajectory analysis shows **patch** strongly correlates with high session scores.
- Use `patch` for targeted find-and-replace edits instead of sed/awk.
- Supports fuzzy matching with 9 strategies for robust edits.
- Auto-runs syntax checks after modification.
- Preferred for surgical code changes over full file rewrites.

### Guardrails
- Ensure `old_string` is unique in the file unless `replace_all=True`.
- Include enough surrounding context to guarantee uniqueness.
- Use `mode='patch'` for V4A multi-file patches.

### Efficiency Tips
- Combine multiple edits into a single V4A patch when possible.
- Use `replace_all=True` for bulk replacements of the same pattern.
- Preview changes with `--dry-run` mode before applying.

---
## Feedback Engine Patches
*自动生成于 2026-07-21 08:58:12*

## Tool Recommendations (from trajectory feedback)

### write_file
Trajectory analysis shows **write_file** strongly correlates with high session scores.
- Use `write_file` to create new files or overwrite existing ones.
- Preferred over terminal heredoc for structured file creation.
- Automatically creates parent directories.

### Guardrails
- Always use absolute paths to avoid ambiguity.
- Creates parent directories — verify the intended path before writing.
- Overwrites entire file content — if you need targeted edits, use `patch` instead.

### Efficiency Tips
- Batch content creation: write whole files at once instead of appending line-by-line.
- For large files, consider splitting into multiple smaller files.
- Use `patch` for incremental updates to avoid full rewrites.

---
## Feedback Engine Patches
*自动生成于 2026-07-22 12:19:48*

## Tool Recommendations (from trajectory feedback)

### patch
Trajectory analysis shows **patch** strongly correlates with high session scores.
- Use `patch` for targeted find-and-replace edits instead of sed/awk.
- Supports fuzzy matching with 9 strategies for robust edits.
- Auto-runs syntax checks after modification.
- Preferred for surgical code changes over full file rewrites.

### Guardrails
- Ensure `old_string` is unique in the file unless `replace_all=True`.
- Include enough surrounding context to guarantee uniqueness.
- Use `mode='patch'` for V4A multi-file patches.

### Efficiency Tips
- Combine multiple edits into a single V4A patch when possible.
- Use `replace_all=True` for bulk replacements of the same pattern.
- Preview changes with `--dry-run` mode before applying.
