# Performance Diagnostic Pattern — Reference

## Session Example: "Why is startup slow?"

### Parallel Data Gathering (execute in 1-2 rounds)

| Probe | Command | Signal |
|---|---|---|
| Uptime + Load | `uptime; cat /proc/loadavg` | Load > 2.0 at idle = bottleneck |
| CPU/Wait | `top -bn1 \| head -5` | I/O wait > 5% = disk-bound |
| Memory | `free -h` | Available < 20% = pressure |
| Disk | `df -h / /mnt/c/` | C: > 90% = P0 |
| Cron density | `crontab -l \| grep -c '@reboot'` | > 2 = boot storm |
| Process density | `ps aux \| grep -c python3` | > 15 = module-load storm |
| Boot timeline | `ps -eo pid,lstart,comm --sort=start_time \| head -30` | Mass-launch within 2s = strorm |
| Space sinks | `du -sh ~/.hermes/*/ \| sort -rh \| head -15` | Identify largest dirs |
| Session count | `ls ~/.hermes/sessions/ \| wc -l` | >10K files = cleanup needed |
| Process timing gap | Compare `lstart` of keepalive-started vs. normal services | Delay > 30s = keepalive bottleneck |

### Root Cause Chain Construction

Chain: `C: 94% full → WSL I/O 10x slower → 22 Python forks simultaneously → I/O wait 10.9% → user perceives slow boot`

### Priority Triage

| Priority | Action | Impact |
|---|---|---|
| P0 | Free Windows C: space (>90%) | Restores WSL I/O to normal |
| P1 | Clean ~/.hermes/ bloat | Reclaims 15-20G |
| P2 | Stagger @reboot scripts + reduce keepalive freq | Eliminates I/O storm |
| P3 | Session DB → SQLite (long-term) | Eliminates JSON file I/O |

### Key Diagnostic Commands Reference

```bash
# All processes sorted by start time
ps -eo pid,lstart,comm --sort=start_time

# Largest files in .hermes
find ~/.hermes -type f -size +50M -exec ls -lh {} \; | sort -k5 -rh | head -20

# Python process count
ps aux | grep python3 | grep -v grep | wc -l

# Every-minute cron for keepalive density
crontab -l | grep -E '^\* \*|^\\*/[0-9]'

# Count crons by frequency pattern
crontab -l | grep -oP '\*/[0-9]+' | sort | uniq -c | sort -k2
```

### Keepalive Optimization

Keepalive scripts often run every 60s and become a hidden I/O tax. Patterns found in the wild:

```bash
# BAD: every minute, 6 netcat port checks → 24MB log in ~8 hours, 349K lines
* * * * * bash /home/yestin/company/scripts/keepalive.sh

# BETTER: every 2 minutes, halves the I/O overhead
*/2 * * * * bash /home/yestin/company/scripts/keepalive.sh
```

Keepalive scripts should have log rotation built in or suppress success output (only log when a service is actually restarted). Truncate accumulated logs with redirect:
```bash
> /home/yestin/company/logs/keepalive.log    # truncate, no fork
# instead of:
# rm /home/yestin/company/logs/keepalive.log && touch keepalive.log
```

### .hermes Specific Cleanup Targets

| Target | Typical Size | Action | Risk |
|--------|-------------|--------|------|
| `state-snapshots/` | 4.6G (single state.db) | `rm -rf` | Low — auto-generated, can be recreated |
| `cron/output/` | 1.2G (166 files) | `rm -rf` | Low — old cron run outputs |
| `os/log_store.db` | 3.6G (SQLite log DB) | `mv -> .bak` + create new empty | Low — OS Portal logs, non-critical |
| `checkpoints/legacy-*` | 1.2G | `rm -rf` | Low — old git-like checkpoints |
| `skills/.curator_backups/` | 1.6G (3 tar.gz) | Keep latest, delete old | Low |
| `sessions/` (main) | 1.9G (33K files) | Delete by month pattern | Medium — session history lost |
| `profiles/*/sessions/` | 1.8G each (58K files) | Delete by date pattern | Low — old dev sessions |

**Session cleanup commands:**
```bash
# Main profile sessions — delete by month
find ~/.hermes/sessions/ -name 'session_202605*' -delete
# Or delete by age (requires mtime — works if files aren't touched)
find ~/.hermes/sessions/ -name '*.json' -mtime +14 -delete
```

**Log store DB rebuild pattern:**
```bash
# Don't delete — backup first, let OS recreate it
mv /path/to/log_store.db /path/to/log_store.db.bak
sqlite3 /path/to/log_store.db "CREATE TABLE IF NOT EXISTS logs (...);"
```

### Success Criteria
- I/O wait < 5% at idle (check with `top -bn1 | grep 'Cpu' | awk '{print $8}'`)
- C: disk usage < 85%
- @reboot scripts ≤ 2
- Every-N-min crons ≤ 5
- Python processes < 15
- Session files < 10,000 (prefer SQLite)
- `.hermes/` total size < 30G (clean baseline)
