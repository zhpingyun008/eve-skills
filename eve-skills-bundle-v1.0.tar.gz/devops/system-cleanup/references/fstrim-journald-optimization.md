# fstrim + journald 日志上限优化

## 问题

WSL环境下，`/var/log` 长期积累journal日志可达1GB+。`journalctl` 默认无日志大小上限，存档日志持续增长。

## 优化步骤

### 1. Journal日志清理

```bash
# 清理3天前的日志（保留最近3天）
sudo journalctl --vacuum-time=3d

# 或清理到指定大小
sudo journalctl --vacuum-size=200M
```

### 2. 设置永久日志上限

```bash
# 写入200M上限（写入+/etc/systemd/journald.conf）
sudo sh -c 'grep -q "SystemMaxUse" /etc/systemd/journald.conf && \
  sed -i "s/^#*SystemMaxUse=.*/SystemMaxUse=200M/" /etc/systemd/journald.conf || \
  echo "SystemMaxUse=200M" >> /etc/systemd/journald.conf'

# 重启journald生效
sudo systemctl restart systemd-journald
```

### 3. WSL fstrim（释放已删空间回Windows）

```bash
# 在WSL内部释放未使用空间
sudo fstrim /
```

### 效果参考

- **清理前**: /var/log 966MB
- **清理后**: /var/log 370MB (journal 196.8MB)
- **fstrim**: 释放已删文件占用的vhdx空间回Windows C盘
- **永久生效**: SystemMaxUse=200M 防止未来日志无限制增长

## 注意事项

- `journalctl --vacuum-time=` 影响所有用户日志，生产环境至少保留7天
- 设置SystemMaxUse后无需定期手动清理 — journald自动遵守上限
- fstrim只在DISC-GRAN不为0的磁盘上生效 — `lsblk -D` 检查支持情况
- WSL1不支持fstrim
- 不建议删除 `/var/log/*.log` 当前日志文件 — 可能被正在运行的进程写入
