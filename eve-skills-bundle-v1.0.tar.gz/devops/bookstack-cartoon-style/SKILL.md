---
name: bookstack-cartoon-style
description: BookStack页面风格化模板 — 卡通动漫风格样式库。含完整图标/字体颜色/字体大小/布局/卡通动漫效果的样式定义与生成器。
category: devops
triggers:
  - "卡通风格 / cartoon style / 动漫风格 / anime style"
  - "BookStack样式 / BookStack styling / 页面美化"
  - "文档模板风格化 / template styling / style template"
  - "样式提取 / style extraction / pattern extraction"
  - "默认样式 / default style / 项目文档样式"
  - "海南APP对标携程 / 海航AI购票助手文档样式"
---

# BookStack 卡通动漫风格样式库

## 一、样式核心定义

BookStack卡通动漫风格的完整样式体系，包含图标、字体、颜色、布局、特效五个维度。

### 1.1 色彩系统

| 用途 | 色值 | 色样 | 说明 |
|------|------|:----:|------|
| 英雄卡背景 | `#fff8f0` | 🟡 暖白 | 卡片式封面背景 |
| 英雄卡边框 | `#333` | ⚫ 深黑 | 粗边框3px |
| 英雄卡阴影 | `6px 6px 0 #333` | ⚫ 投影 | 硬阴影（卡通标志） |
| **主色(紫)** | `#6c5ce7` | 🟣 紫 | 标题左边框、表头背景、H3文字 |
| **主色(绿)** | `#00b894` | 🟢 绿 | 二级标题边框、成功提示 | 
| **主色(蓝)** | `#0984e3` | 🔵 蓝 | 信息提示、链接 |
| **主色(橙)** | `#e17055` | 🟠 橙 | 警告/高风险 |
| **主色(黄)** | `#fdcb6e` | 🟡 黄 | 示例值卡片、提示 |
| 正文色 | `#2d3436` | ⬛ 深灰 | 正文、H2标题 |
| 分割线色 | `#b2bec3` | ⬜ 浅灰 | 装饰分割线 |
| 表行边框 | `#dfe6e9` | ⬜ 浅灰 | 表格行下边框 |
| 代码背景 | `#2d3436` | ⬛ 深色 | 代码块深色终端 |
| 代码文字 | `#dfe6e9` | ⬜ 浅灰 | 代码块文字 |
| 偶数行背景 | `#f8f9fc` | ⬜ 极浅灰 | 表格斑马纹 |

### 1.2 图标系统（Emoji）

| 用途 | Emoji | 说明 |
|------|:-----:|------|
| 项目章程 | 📄 | 文档类封面 |
| WBS/工作分解 | 📊 | 图表类 |
| 里程碑 | 🗺️ | 路线图类 |
| 风险 | ⚠️ | 警示类 |
| 工作汇报 | 📋 | 报告类 |
| 立项建设 | 🎯 | 目标类 |
| 架构 | 🏗️ | 技术类 |
| 评估/分析 | 📐 | 分析类 |
| 竞品分析 | 📊 | 竞品类 |
| 成功 | ✅ | 完成/通过 |
| 警告 | ⚠️ | 高风险 |
| 信息 | ℹ️ | 说明 |
| 提示 | 💡 | 建议 |
| 编写指引 | ✏️ | 填写说明 |
| 装饰分割线 | ✦ | 卡通装饰 |

### 1.3 字体系统

| 元素 | 字体族 | 大小 | 粗细 | 说明 |
|------|--------|:----:|:----:|------|
| 英雄卡标题 | 系统无衬线 | 1.8em | 800(bold) | 封面大标题 |
| 英雄卡emoji | 系统 | 48px | — | 封面图标 |
| 标签(badge) | 系统无衬线 | 0.85em | bold | 分类标签 |
| H2章节标题 | 系统无衬线 | ~1.3em | bold | 一级标题 |
| H3章节标题 | 系统无衬线 | ~1.1em | 600 | 二级标题 |
| 表格题头 | 系统无衬线 | 0.9em | bold | 表头文字 |
| 表格内容 | 系统无衬线 | 0.9em | normal | 表体文字 |
| 正文段落 | 系统无衬线 | 1em | normal | 一般段落 |
| 代码块 | 等宽字体 | 0.9em | normal | 代码/预格式化 |

### 1.4 布局系统

| 元素 | 内边距 | 外边距 | 圆角 | 说明 |
|------|:------:|:------:|:----:|------|
| 英雄卡 | 30px 20px | 下:24px | 16px | 封面 |
| H2标题 | 左:12px | 上:24px | — | 左边框5px |
| H3标题 | 左:12px | 上:18px | — | 左边框4px |
| 表格 | — | 上下:12px | 12px(溢出隐藏) | 圆角表 |
| 表头 | 8px 12px | — | — | 紫色背景 |
| 表体 | 8px 12px | — | — | 下边框 |
| 代码块 | 12px | — | 8px | 深色背景 |
| 段落 | — | 上下:6px | — | 行高1.6 |
| 卡片 | 16px | 上下:12px | 16px | 内容块 |
| 提示框 | 14px 18px | 上下:12px | 12px | 信息/警告/成功 |

### 1.5 卡通动漫特效

| 特效 | 实现方式 | 说明 |
|------|----------|------|
| **硬阴影** | `box-shadow:6px 6px 0 #333` | 卡通标志性阴影，无模糊 |
| **粗边框** | `border:3px solid #333` | 英雄卡粗黑边框 |
| **圆角** | `border-radius:16px` | 大圆角卡通感 |
| **装饰分割线** | `✦ ✦ ✦` | 星星装饰分隔 |
| **彩色标签** | `background:#d4b8ff` | 圆角药丸标签 |
| **斑马纹表格** | `tr:nth-child(even)` | 隔行变色 |
| **章节标题** | `border-left:5px solid purple` | 左边框装饰 |
| **emoji图标** | 48px emoji | 大号emoji作为封面图标 |
| **代码深色终端** | `background:#2d3436` | 代码块暗色主题 |

---

## 二、样式生成器（Python代码）

### 2.1 内联样式常量

```python
# 英雄卡片封面
STYLE_HERO = "text-align:center;padding:30px 20px;background:#fff8f0;" \
             "border:3px solid #333;border-radius:16px;" \
             "margin-bottom:24px;"
# NOTE: box-shadow deliberately omitted — BookStack strips it

# 标签（紫色药丸）
STYLE_BADGE_PURPLE = "display:inline-block;padding:4px 14px;border-radius:20px;" \
                     "font-weight:bold;font-size:0.85em;border:2px solid #333;" \
                     "background:#d4b8ff;"

# 标签（绿色）
STYLE_BADGE_GREEN = "display:inline-block;padding:4px 14px;border-radius:20px;" \
                    "font-weight:bold;font-size:0.85em;border:2px solid #333;" \
                    "background:#b5e7a0;"

# 标签（蓝色）
STYLE_BADGE_BLUE = "display:inline-block;padding:4px 14px;border-radius:20px;" \
                   "font-weight:bold;font-size:0.85em;border:2px solid #333;" \
                   "background:#a8d8ff;"

# H2标题（紫色左边框）
STYLE_H2 = "border-left:5px solid #6c5ce7;padding-left:12px;" \
           "color:#2d3436;margin-top:24px;font-size:1.3em;font-weight:bold;"

# H3标题（紫色文字）
STYLE_H3 = "color:#6c5ce7;margin-top:18px;font-size:1.1em;font-weight:600;" \
           "border-left:4px solid #00b894;padding-left:12px;"

# 装饰分割线
STYLE_DIVIDER = "text-align:center;font-size:1.2em;color:#b2bec3;" \
                "margin:20px 0;letter-spacing:8px;"

# 表格容器
STYLE_TABLE = "width:100%;border-collapse:collapse;margin:12px 0;" \
              "border-radius:12px;overflow:hidden;"

# 表头（紫色背景+白色文字）
STYLE_TH = "background:#6c5ce7;color:#fff;padding:8px 12px;" \
           "text-align:left;font-weight:bold;"

# 表行（浅色下边框）
STYLE_TD = "padding:8px 12px;border-bottom:1px solid #dfe6e9;"

# 代码块（深色终端）
STYLE_PRE = "background:#2d3436;color:#dfe6e9;border-radius:8px;" \
            "padding:12px;overflow-x:auto;font-size:0.9em;"

# 段落
STYLE_P = "line-height:1.6;margin:6px 0;"
```

### 2.2 文档映射（Emoji + 分类）

```python
DOC_STYLE = {
    "项目章程":           {"emoji": "📄", "badge": "项目立项"},
    "项目立项报告":        {"emoji": "📋", "badge": "项目立项"},
    "立项建设思路":        {"emoji": "🎯", "badge": "项目立项"},
    "WBS工作分解结构":     {"emoji": "📊", "badge": "项目管理"},
    "里程碑计划":          {"emoji": "🗺️", "badge": "项目管理"},
    "风险登记册":          {"emoji": "⚠️", "badge": "风险管理"},
    "携程APP深度对标分析":  {"emoji": "📊", "badge": "竞品分析"},
    "架构全景图":          {"emoji": "🏗️", "badge": "架构设计"},
    "可行性评估":          {"emoji": "📐", "badge": "竞品分析"},
    "模板":               {"emoji": "📄", "badge": "模板"},
    "会议纪要":            {"emoji": "📝", "badge": "会议"},
    "API接口":             {"emoji": "🔌", "badge": "技术"},
    "数据库":              {"emoji": "🗄️", "badge": "技术"},
    "部署":               {"emoji": "🚀", "badge": "运维"},
    "监控":               {"emoji": "📈", "badge": "运维"},
    "周报":               {"emoji": "📊", "badge": "汇报"},
    "复盘":               {"emoji": "🔄", "badge": "汇报"},
    "SRS需求规格":         {"emoji": "📋", "badge": "需求"},
    "ER模型":             {"emoji": "🔗", "badge": "设计"},
    "测试计划":            {"emoji": "🧪", "badge": "测试"},
    "测试报告":            {"emoji": "✅", "badge": "测试"},
}
```

### 2.3 英雄卡片生成器

```python
def make_hero_card(title, emoji="📄", badges=None, project="海南APP对标携程项目V1.0"):
    """生成卡通风格封面卡片HTML"""
    if badges is None:
        badges = ["海南APP对标携程"]
    tag_html = "".join(
        f'<span style="{STYLE_BADGE_PURPLE}">{b}</span> ' for b in badges
    )
    return f'''<div style="{STYLE_HERO}">
  <div style="font-size:48px;margin-bottom:10px;">{emoji}</div>
  <h1 style="font-size:1.8em;font-weight:800;margin:8px 0;">{title}</h1>
  <div>{tag_html}</div>
  <p style="margin-top:12px;font-size:0.9em;">
    <strong>📌 项目</strong>: {project} | <strong>🔖 版本</strong>: v1.0
  </p>
</div>
<div style="{STYLE_DIVIDER}">✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦</div>'''
```

### 2.4 表格生成器

```python
def make_table(headers, rows, highlight_row=None):
    """生成卡通风格表格"""
    thead = "<tr>" + "".join(f"<th style='{STYLE_TH}'>{h}</th>" for h in headers) + "</tr>"
    tbody = ""
    for i, row in enumerate(rows):
        row_style = ' style="background:#fff3e0;"' if highlight_row is not None and i == highlight_row else ""
        tbody += f"<tr{row_style}>" + "".join(f"<td style='{STYLE_TD}'>{c}</td>" for c in row) + "</tr>"
    return f"<table style='{STYLE_TABLE}'><thead>{thead}</thead><tbody>{tbody}</tbody></table>"
```

### 2.5 完整文档生成器

```python
def generate_cartoon_doc(md_content, title, emoji="📄", badges=None):
    """将Markdown内容转为卡通风格HTML（BookStack兼容，内联样式）"""
    style = {
        "hero": STYLE_HERO, "badge": STYLE_BADGE_PURPLE,
        "h2": STYLE_H2, "h3": STYLE_H3, "divider": STYLE_DIVIDER,
        "table": STYLE_TABLE, "th": STYLE_TH, "td": STYLE_TD,
        "pre": STYLE_PRE, "p": STYLE_P,
    }
    
    parts = [make_hero_card(title, emoji, badges)]
    
    first_h1 = ""
    for line in md_content.split("\n"):
        if line.startswith("# "):
            first_h1 = line[2:].strip()
            break
    
    in_table = False
    in_code = False
    code_lines = []
    
    for line in md_content.split("\n"):
        stripped = line.strip()
        
        if line.startswith("# ") and stripped == f"# {first_h1}":
            continue
        if stripped.startswith("```"):
            if in_code:
                parts.append(f"<pre style='{style['pre']}'>{''.join(code_lines)}</pre>")
                code_lines = []
                in_code = False
            else:
                in_code = True
            continue
        if in_code:
            code_lines.append(line + "\n")
            continue
        if line.startswith("## "):
            parts.append(f"<h2 style='{style['h2']}'>{line[3:].strip()}</h2>")
            continue
        if line.startswith("### "):
            parts.append(f"<h3 style='{style['h3']}'>{line[4:].strip()}</h3>")
            continue
        if line.startswith("#### "):
            parts.append(f"<h4 style='color:#2d3436;'>{line[5:].strip()}</h4>")
            continue
        if stripped == "---":
            parts.append(f"<div style='{style['divider']}'>✦ ✦ ✦</div>")
            continue
        if line.startswith("|"):
            if "|--" in line or "|:-" in line:
                continue
            cells = [c.strip() for c in line.split("|")[1:-1]]
            if not in_table:
                parts.append(f"<table style='{style['table']}'>")
                in_table = True
            parts.append("<tr>" + "".join(f"<td style='{style['td']}'>{c}</td>" for c in cells) + "</tr>")
            continue
        else:
            if in_table:
                parts.append("</table>")
                in_table = False
        if stripped.startswith("- ") or stripped.startswith("* "):
            parts.append(f"<li style='margin:4px 0;'>{stripped[2:]}</li>")
            continue
        if not stripped:
            parts.append("<br>")
            continue
        parts.append(f"<p style='{style['p']}'>{line}</p>")
    
    if in_table:
        parts.append("</table>")
    if in_code:
        parts.append(f"<pre style='{style['pre']}'>{''.join(code_lines)}</pre>")
    
    return "\n".join(parts)
```

---

## 三、BookStack兼容性

### 3.1 关键规则

| 规则 | 说明 |
|------|------|
| ❌ **禁止`<style>`标签** | BookStack安全过滤器会剥离所有`<style>`标签 |
| ✅ **使用内联style属性** | 所有样式写在元素的`style="..."`中 |
| ✅ **sync_bookstack.py pass-through** | `.cartoon.html`文件绕过`md_to_html()`直接写入 |
| ✅ **HTML片段格式** | 只有body内容（无`<!DOCTYPE>`/`<html>`/`<head>`包装） |

### 3.2 BookStack安全过滤（详见 `references/bookstack-security-filtering.md`）

BookStack会从页面HTML中剥离某些CSS属性和元素。**关键规则**：

| 过滤项 | 处理方式 |
|--------|----------|
| `box-shadow` | 被剥离，用 `border` + 背景对比色替代 |
| `<style>` 标签 | 被剥离，全部使用内联 `style="..."` |
| `<!DOCTYPE>` / `<html>` / `<head>` | 被渲染为文本，只发送body片段 |
| 书架URL | 使用slug而非数字ID：`/shelves/appv10` ✅ |

### 3.3 验证方法

```python
# API验证样式是否正常
def verify_style(page_id):
    conn = http.client.HTTPConnection("localhost", 8080, timeout=5)
    conn.request("GET", f"/api/pages/{page_id}", headers={"Authorization": f"Token {TOKEN}"})
    html = json.loads(conn.getresponse().read().decode()).get("html", "")
    
    checks = {
        "no_style_tag": "<style>" not in html,
        "has_inline_style": 'style="' in html,
        "has_hero_bg": "#fff8f0" in html,
        "has_h2_border": "6c5ce7" in html,
        "has_divider": "b2bec3" in html,
        "has_th_bg": "background:#6c5ce7" in html,
        "has_pre_bg": "#2d3436" in html,
    }
    return all(checks.values()), checks
```

---

## 四、模板页面风格化

### 4.1 文档模板对比

| 模板类型 | 当前样式 | 目标样式 |
|----------|:--------:|:--------:|
| 项目章程模板 | `<pre>`纯文本 | 🎨 卡通英雄卡+内联样式 |
| WBS模板 | `<pre>`纯文本 | 🎨 卡通英雄卡+内联样式 |
| 甘特图模板 | `<pre>`纯文本 | 🎨 Mermaid甘特图+卡通卡 |
| 风险管理模板 | `<pre>`纯文本 | 🎨 卡通表格+彩色标签 |
| SRS模板 | `<pre>`纯文本 | 🎨 卡通英雄卡+H2/H3 |
| 会议纪要模板 | `<pre>`纯文本 | 🎨 卡通卡片+行动项表格 |
| API文档模板 | `<pre>`纯文本 | 🎨 卡通代码块+端点表格 |
| 周报模板 | `<pre>`纯文本 | 🎨 卡通统计卡片+进度条 |

### 4.2 模板风格化流程

1. 读取模板Markdown内容
2. 调用`generate_cartoon_doc()`生成卡通HTML
3. 用`sync_bookstack.py`同步到BookStack
4. API验证样式（verify_style）

---

## 五、同步脚本集成模式

当需要将卡通风格应用到大规模知识库(如Eve公司Shelf 2787, 64+页面)时，推荐在同步脚本中内联风格代码而非后处理。

### 5.1 架构选择

```
方案A: 独立生成器 (generate_cartoon_doc)   方案B: 同步脚本内联 (推荐)
  ┌──────────┐    ┌──────────┐              ┌──────────────────────┐
  │ Markdown  │───▶│ 生成器   │───▶ HTML    │ 同步脚本             │
  └──────────┘    └──────────┘              │  md_to_html()已含风格 │
        ▲                                   │  sync_file()含英雄卡  │
        │                                   └──────────────────────┘
  适用于单个文档                          适用于批量知识库同步
```

方案B优势：零额外步骤，每次同步自动应用风格，新文件自动获得卡通样式。

### 5.2 英雄卡 + 标签嵌入模式

在同步脚本的 `sync_file()` 函数中，为每个页面生成英雄卡：

```python
# 自动匹配emoji和标签（基于文件名关键词）
def resolve_emoji_badge(name):
    mapping = {
        "合同": ("📝", "合同"), "商业模式": ("💰", "商业模式"),
        "项目": ("📦", "项目"), "脚本": ("⚙️", "脚本"),
        "品牌": ("🎨", "品牌"), "组织": ("🏛️", "组织"),
        "线索": ("🔍", "线索"), "报价": ("💰", "报价"),
        "财务": ("💹", "财务"), "管道": ("📊", "管道"),
        "内容": ("📝", "内容"), "讨论": ("💬", "讨论"),
        "SOP": ("📋", "SOP"), "模板": ("📄", "模板"),
        "员工": ("🤖", "AI员工"), "沟通": ("💬", "沟通"),
    }
    for key, (emoji, badge) in mapping.items():
        if key in name:
            return emoji, badge
    return "📄", "文档"
```

标签颜色根据所属Book自动切换（财务/商业模式→绿色，运营/销售→蓝色，其他→紫色）。

### 5.3 内联样式覆盖所有元素

`md_to_html`函数中，每个HTML元素都用内联style：

| Markdown | 渲染 | 内联样式 |
|----------|------|----------|
| `## 标题` | H2 | `border-left:5px solid #6c5ce7;color:#2d3436;font-size:1.3em` |
| `### 标题` | H3 | `color:#6c5ce7;border-left:4px solid #00b894` |
| `\| A \| B \|` | Table | 紫色表头 `background:#6c5ce7;color:#fff` |
| `\\`\\`code\\`\\`` | Pre | 深色终端 `background:#2d3436;color:#dfe6e9` |
| `---` | 分割线 | `✦ ✦ ✦` 星号装饰, `color:#b2bec3` |

### 5.4 验证清单

使用BookStack API验证样式是否生效：

```python
checks = {
    "hero_card": "#fff8f0" in html,              # 暖白英雄卡
    "thick_border": "border:3px solid #333" in html,  # 粗边框
    "inline_style": 'style="' in html,            # 内联样式
    "purple_headers": "#6c5ce7" in html,          # 紫色H2
    "star_divider": "✦" in html,                  # 星号分割线
    "eve_badge": "Eve(伊芙科技)" in html,          # 品牌标签
    "no_style_tag": "<style>" not in html,          # 无style标签
}
```

验证通过标准：新创建页面(高ID)通过率高于旧页面。

---

## 六、项目工作量清单模板样式（13列表格）

BookStack Book 1902 的「XX项目需求工作量清单模板」使用13列详细表格，适用于大型航空/企业IT项目。

### 6.1 13列表头定义

| 列 | 名称 | 样式 | 说明 |
|----|------|------|------|
| 1 | 序号 | `text-align:center;width:35px` | 按模块分组自增 |
| 2 | 功能/模块 | `font-weight:bold` | 同模块首行填写，后续行留空 |
| 3 | 子功能 | `font-size:11px` | 每个独立功能点 |
| 4 | 需求功能概述 | `font-size:11px` | 简要描述 |
| 5 | 合计(人天) | `font-weight:bold;background:#f8f9fa` | 各角色汇总 |
| 6-10 | 项目经理/需求/研发/架构师/测试 | `text-align:center` | 按角色预估 |
| 11 | 备注 | `font-size:11px` | 复杂度标注：核心/中等/简单 |
| 12 | 类型 | `text-align:center` | 新增/★补充 |
| 13 | 说明 | `font-size:11px` | 对应模块章节 |

### 6.2 角色分配算法 (Keyword-based)

当原始数据只有总人天时，使用关键词匹配按角色拆分：

```python
def distribute_pd(total_pd, keyword_text):
    """Keyword-based PM/REQ/DEV/ARCH/TEST split"""
    pm=req=dev=arch=test=0.0
    if any(w in keyword_text for w in ['需求分析','文档梳理','需求详细设计']):
        req=total_pd*0.6; pm=total_pd*0.4
    elif any(w in keyword_text for w in ['原型','UI设计']):
        req=total_pd*0.7; arch=total_pd*0.3
    elif any(w in keyword_text for w in ['实施方案','上线计划','业务流程']):
        pm=total_pd*0.5; req=total_pd*0.3; arch=total_pd*0.2
    elif any(w in keyword_text for w in ['接口','功能开发','逻辑处理','开发','代码']):
        dev=total_pd*0.7; arch=total_pd*0.2; req=total_pd*0.1
    elif '测试用例' in keyword_text:
        test=total_pd*0.6; req=total_pd*0.4
    elif any(w in keyword_text for w in ['SIT','UAT','验收测试','环境测试','性能测试']):
        test=total_pd*0.7; dev=total_pd*0.3
    elif '部署上线' in keyword_text:
        dev=total_pd*0.5; test=total_pd*0.3; pm=total_pd*0.2
    elif any(w in keyword_text for w in ['变更脚本','审核','基线']):
        dev=total_pd*0.6; arch=total_pd*0.2; test=total_pd*0.2
    elif any(w in keyword_text for w in ['同步','对接','推送']):
        dev=total_pd*0.6; arch=total_pd*0.2; test=total_pd*0.2
    elif any(w in keyword_text for w in ['监控','告警','巡检']):
        dev=total_pd*0.5; test=total_pd*0.3; arch=total_pd*0.2
    else:  # generic
        dev=total_pd*0.5; test=total_pd*0.2; req=total_pd*0.15; arch=total_pd*0.1; pm=total_pd*0.05
    s=pm+req+dev+arch+test
    if abs(s-total_pd)>0.5 and s>0: f=total_pd/s; pm*=f; req*=f; dev*=f; arch*=f; test*=f
    return round(pm,1),round(req,1),round(dev,1),round(arch,1),round(test,1)
```

### 6.3 大型表格生成要点

- **补充条目高亮**：`style="background:#fff3e0;"` 橘色背景标记补充/新增条目
- **模块首行合并**：同模块子功能只有第一行显示模块名，其余留空 `<td></td>`
- **复杂度标注**：`pd>=20 → 核心功能` / `pd>=10 → 中等` / `<10 → 简单`
- **入库检查**：更新BookStack后必须验证 `<th>` 数量（13）、`★补充` 出现次数、`#6c5ce7` 紫色表头、无 `<style>` 标签
- **数据量限制**：50万字符以内的HTML可单次PUT更新；更大的文档需分批提交（BookStack API限制约100万字符）

### 6.4 验证清单（模板特有）

```python
checks = {
    "table_headers": html.count('<th') == 13,      # 13列表头
    "role_columns": all(r in html for r in ['项目经理','需求','研发','架构师','测试']),
    "supplement_marker": "★补充" in html,            # 补充条目标记
    "complexity_tags": any(t in html for t in ['核心功能','中等','简单']),
    "summary_section": "工作量汇总" in html,
    "fill_instructions": "填写说明" in html,
    "no_style_tag": "<style>" not in html,
}
```

### 6.5 已知陷阱

- **BookStack表格ID自动生成**：`<table>` 会被添加 `id="bkmrk-..."`，不影响样式
- **中文URL问题**：BookStack API搜索含中文的query会触发 `UnicodeEncodeError`，必须 `urllib.parse.quote` 编码
- **角色分配误差**：关键词匹配算法是近似值。当各角色人天之和与原始总数偏差超过0.5时自动归一化。核心功能（≥20人天）建议人工复核
- **模块数据文件**：超过200条的数据建议写入独立 `.py` 文件并 `import`，避免单脚本过大

参考实现：`references/workload-template-aviation-case.md`（航空大客户V2.0项目实战案例）

### 5.5 陷阱

- **Box-shadow被BookStack剥离**：使用 `border` + 背景对比色替代阴影效果
- **`<style>`标签被剥离**：所有样式必须内联到元素上（style属性）
- **BookStack编辑器会改写HTML**：`<table>`会被添加 `id` 属性和包装元素，不影响样式效果
- **大型JSON页面可能无H2**：纯数据页面只有 `<pre><code>`，英雄卡+星号分割线仍然正常展示
