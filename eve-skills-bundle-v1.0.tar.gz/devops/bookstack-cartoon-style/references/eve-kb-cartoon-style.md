# Eve(伊芙科技) 知识库卡通风格切换 — 实战参考

## 背景

2026-05-31 使用 `bookstack-eve-sync.py` (自动同步引擎) 将 Eve 公司全部64个文件重渲为卡通风格。

## 实现方式

在同步引擎的 `sync_file()` 函数中分两步应用样式：

### Step 1: Hero Card（页面顶部）

```python
full_html = f'''<div style="text-align:center;padding:30px 20px;
    background:#fff8f0;border:3px solid #333;border-radius:16px;
    margin-bottom:24px;">
  <div style="font-size:48px;margin-bottom:10px;">{emoji}</div>
  <h1 style="font-size:1.8em;font-weight:800;margin:8px 0;color:#2d3436;">
    {page_name}</h1>
  <div>
    <span style="display:inline-block;padding:4px 14px;border-radius:20px;
        font-weight:bold;font-size:0.85em;border:2px solid #333;
        background:{badge_color};">{badge}</span>
    <span style="display:inline-block;padding:4px 14px;border-radius:20px;
        font-weight:bold;font-size:0.85em;border:2px solid #333;
        background:#b5e7a0;margin-left:6px;">Eve(伊芙科技)</span>
  </div>
  <p style="margin-top:12px;font-size:0.85em;color:#636e72;">
    <strong>📁</strong> {file_path} | <strong>🔄</strong> {timestamp}
  </p>
</div>
<div style="text-align:center;font-size:1.2em;color:#b2bec3;
    margin:20px 0;letter-spacing:8px;">
    ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦</div>
{body_html}
<div style="text-align:center;font-size:1.2em;color:#b2bec3;
    margin:20px 0;letter-spacing:8px;">
    ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦</div>'''
```

### Step 2: 正文内联样式（md_to_html函数）

```python
H2_STYLE  = "border-left:5px solid #6c5ce7;padding-left:12px;..."
H3_STYLE  = "color:#6c5ce7;margin-top:18px;font-size:1.1em;font-weight:600;border-left:4px solid #00b894;padding-left:12px;"
TABLE_STYLE = "width:100%;border-collapse:collapse;margin:12px 0;border-radius:12px;overflow:hidden;"
TH_STYLE  = "background:#6c5ce7;color:#fff;padding:8px 12px;text-align:left;font-weight:bold;"
TD_STYLE  = "padding:8px 12px;border-bottom:1px solid #dfe6e9;"
PRE_STYLE = "background:#2d3436;color:#dfe6e9;border-radius:8px;padding:12px;overflow-x:auto;font-size:0.9em;"
P_STYLE   = "line-height:1.6;margin:6px 0;color:#2d3436;"
```

### Step 3: Emoji自动映射

根据页面标题自动匹配emoji和badge标签。映射逻辑在 `sync_file()` 函数中通过关键字匹配实现（约18种类型：合同/商业模式/项目/脚本/品牌/线索/报价/财务等）。

徽章颜色按书籍类型区分：财务/商业用绿色(#b5e7a0)，运营/销售用蓝色(#a8d8ff)，其他用紫色(#d4b8ff)。

## 验证检查点

| 检查项 | 验证方法 |
|--------|---------|
| 暖白背景 | `#fff8f0` in html |
| 粗黑边框 | `border:3px solid #333` in html |
| 紫色H2 | `#6c5ce7` in html |
| 星星分割 | `✦` in html |
| 无style标签 | `<style>` not in html |
| 内联样式 | `style="` in html |
| Eve品牌标签 | `Eve(伊芙科技)` in html |

## BookStack兼容性

- ✅ 所有样式使用内联 `style=""` 属性
- ✅ 使用 `border` 替代被剥离的 `box-shadow`
- ✅ 无 `<!DOCTYPE>`/`<html>`/`<head>` 包装
- ⚠️ 某些CSS属性（如 `box-shadow`）会被BookStack安全过滤器剥离
