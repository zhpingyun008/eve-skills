# 航空大客户V2.0项目 — 需求工作量清单模板实战案例

> 用于 BookStack bookstack-cartoon-style 技能参考
> 2026-06-01 | 25模块 | 680条 | 4,023人天

## 项目背景

航空股份新大客户系统V2.0项目，初始需求清单21模块/641条/3,602人天。
审查发现编号跳跃8处+4个行业标准模块缺失，补充后25模块/680条/4,023人天。

## 模板应用流程

### 1. 原清单分析
- 扫描所有需求条目的编号连续性 → 记录跳跃点
- 识别未编号条目（"- "开头）→ 核对是否计入总数
- 标记每个子功能的工作类型关键词 → 用于角色分配

### 2. 缺失模块补全
行业标准检查清单：
- ✅ 项目管理条款（PMO）：大项目必须的专职项目管理
- ✅ 架构评审：跨模块技术方案需要总体把控
- ✅ 性能压测：核心交易链路必须做容量规划
- ✅ 上线护航：航空系统上线需灰度+7×24小时支持

### 3. 模板数据结构

每条需求转换为13列数据：
```python
# 数据格式: [模块名, 总人天, [(子功能, 概述, 人天, 是否补充)]]
MODULES_DATA = [
    ("1. 模块名称", 139, [
        ("子功能名称", "功能概述", 5, False),   # is_supplement=False
        ("★补充功能名称", "补充条目", 7, True), # is_supplement=True → 橘色高亮
    ]),
]
```

### 4. 大型数据生成策略

680条 × 13列 → ~470KB HTML → 单次PUT更新BookStack

性能关键点：
- Python字符串拼接（非列表join）会导致大文档生成慢
- 使用 `parts = []` + `'\n'.join(parts)` 模式
- 模块数据分离到独立文件 `from modules_data import MODULES_DATA`
- 模块名仅首行显示（后续行留空 `<td></td>`）

### 5. 验证清单

```python
page = api('GET', '/pages/{id}')
html = page.get('html', '')
assert "<style>" not in html, "No style tags allowed"
assert html.count('<th') == 13, "Must have exactly 13 columns"
assert "#6c5ce7" in html, "Purple header color required"
assert "★补充" in html, "Supplement marker must be present"
assert "合计(人天)" in html, "Template header format required"
```

## 文件引用

- 模块数据文件：`~/company/航空大客户V2.0_模块数据.py` → `modules_data.py`
- 补充清单：`~/company/航空大客户V2.0_需求补充清单.md`
- 合并清单：`~/company/航空大客户V2.0_完整合并清单.md`
- BookStack页面：Book 1902 → Page 3131 → 大客户销售系统V2.0 完整需求清单

## 复用提示

当遇到新的项目需求工作量清单时：
1. 确认是否有模板页面（BookStack Book 1902 或 项目管理模板书架）
2. 提取模块数据按上述格式结构化
3. 运行角色分配算法
4. 生成卡通风HTML并PUT到BookStack
5. 同步到CMMI5更新日志（页285）
