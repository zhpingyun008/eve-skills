# Inline-Style Cartoon Pattern for BookStack

**Problem**: BookStack filters `<style>` tags from page HTML for security. CSS classes defined in `<style>` blocks don't apply.

**Solution**: Use inline `style` attributes on every element instead of CSS classes.

## Pattern

Replace ALL CSS classes with inline styles:

```html
<!-- ❌ Will NOT render correctly (BookStack strips <style>) -->
<style>
.kb-hero-card{text-align:center;padding:30px 20px;background:#fff8f0;border:3px solid #333;border-radius:16px;box-shadow:6px 6px 0 #333;}
</style>
<div class="kb-hero-card">
  <h1>Title</h1>
</div>

<!-- ✅ Will render correctly (inline styles preserved by BookStack) -->
<div style="text-align:center;padding:30px 20px;background:#fff8f0;border:3px solid #333;border-radius:16px;box-shadow:6px 6px 0 #333;margin-bottom:24px;">
  <h1 style="font-size:1.8em;font-weight:800;margin:8px 0;">Title</h1>
</div>
```

## Sync Script Gotcha

When using `sync_bookstack.py` to sync `.cartoon.html` files to BookStack, the `sync_book()` function must detect HTML files and **pass them through without `md_to_html()` conversion**. The `md_to_html()` function treats all input as markdown and escapes HTML tags (e.g., `<style>` becomes `&lt;style&gt;`).

**Fix** in `sync_bookstack.py`:
```python
def sync_book(book_id, pages):
    for page_name, file_path in pages:
        content = file_path.read_text(encoding='utf-8')
        # HTML files pass through directly; .md files get markdown conversion
        if file_path.suffix == '.html':
            full_html = f"<div class='page-content'>{content}</div>"
        else:
            html = md_to_html(content)
            full_html = f"<div class='page-content'>{html}</div>"
        create_page(book_id, page_name, full_html)
```

## Cartoon Style Constants (for inline style generation)

```python
# Reusable inline style constants
STYLE_HERO = "text-align:center;padding:30px 20px;background:#fff8f0;border:3px solid #333;border-radius:16px;box-shadow:6px 6px 0 #333;margin-bottom:24px;"
STYLE_BADGE = "display:inline-block;padding:4px 14px;border-radius:20px;font-weight:bold;font-size:0.85em;border:2px solid #333;background:#d4b8ff;"
STYLE_H2 = "border-left:5px solid #6c5ce7;padding-left:12px;color:#2d3436;margin-top:24px;"
STYLE_H3 = "color:#6c5ce7;"
STYLE_DIVIDER = "text-align:center;font-size:1.2em;color:#b2bec3;margin:20px 0;letter-spacing:8px;"
STYLE_TABLE = "width:100%;border-collapse:collapse;margin:12px 0;"
STYLE_TH = "background:#6c5ce7;color:#fff;padding:8px 12px;text-align:left;"
STYLE_TD = "padding:8px 12px;border-bottom:1px solid #dfe6e9;"
STYLE_PRE = "background:#2d3436;color:#dfe6e9;border-radius:8px;padding:12px;overflow-x:auto;"
STYLE_P = "line-height:1.6;margin:6px 0;"
```

**Verification**: After syncing, check via API that `"<style>" not in html` and `"style=" in html` both hold true:
```python
ok = 'style="' in html and '<style>' not in html
```
