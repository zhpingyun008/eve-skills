# BookStack API Security Filtering Reference

**Context**: BookStack (PHP/Laravel) applies server-side security filtering to page HTML content submitted via API.

## Filtered CSS Properties

| Property | Filtered? | Notes |
|----------|:---------:|-------|
| `box-shadow` | ✅ Yes | Stripped from inline styles. Use `border` + background contrast instead. |
| `filter` / `transform` / `opacity` | ✅ Yes | CSS visual effects removed. |
| `background-image` | ✅ Yes | No external URL backgrounds. Solid colors only. |
| `position: absolute/fixed` / `z-index` | ✅ Yes | Positioning removed. |
| `animation` / `transition` | ✅ Yes | Animations stripped. |
| `border` / `background`(solid) / `color` | ❌ No | Preserved when using inline styles. |
| `padding` / `margin` / `border-radius` | ❌ No | Spacing and rounding preserved. |
| `font-size` / `font-weight` | ❌ No | Font properties preserved. |
| `display` | ❌ No | Display properties preserved. |
| `overflow-x: auto` | ⚠️ Partial | Tested working. Other overflow values may be stripped. |

## Filtered HTML Elements

| Element | Filtered? | Workaround |
|---------|:---------:|------------|
| `<style>` | ✅ Yes | **Never use `<style>`**. Always use inline `style="..."` attributes. |
| `<script>` / `<iframe>` / `<link>` | ✅ Yes | JS and external content blocked. |
| `<!DOCTYPE>` / `<html>` / `<head>` | ⚠️ Renders as text | Only send body-content HTML fragment. |

## BookStack URL Routing

Shelves/Books use **slugs** not numeric IDs: `/shelves/appv10` works, `/shelves/1317` = "Not found". Find slug via `GET /api/shelves/{id}` → extract `slug` field.

## Book-Shelf Assignment Pitfall

Creating a book with `shelf_id` does NOT assign it. Must UPDATE shelf with complete book list:

```python
# ✅ Must include ALL books:
api("PUT", f"/api/shelves/{shelf_id}", {"name": "...", "books": [2438, 2439, 2440]})
# WARNING: PUT replaces the entire book list!
```

## Data Integrity: DELETE then CREATE

When restyling pages: always DELETE old pages by known ID first, then CREATE new ones. PUT to overwrite existing HTML causes BookStack to add `id="bkmrk-xxx"` attributes, corrupting subsequent text replacement.
