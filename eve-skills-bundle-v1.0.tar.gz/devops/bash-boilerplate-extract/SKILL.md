---
name: bash-boilerplate-extract
description: Systematic extraction of shared Bash library from duplicated shell script boilerplate (logging, error handling, log rotation). Audits 3+ scripts → designs lib API → refactors → verifies.
category: devops
triggers:
  - "3+ shell/cron scripts with identical boilerplate (log dir creation, timestamp filenames, redirect patterns)"
  - "Need to add log rotation or retention policy to existing Bash scripts"
  - "Scripts using bare `set -e` without `-u` (undefined var protection) or `-o pipefail`"
  - "Cron/automation scripts with ad-hoc logging that needs standardization"
  - "User asks: 'standardize these shell scripts' / 'unify logging' / 'add log cleanup'"
  - "Reviewing a ~/.scripts directory and finding pattern repetition"
---

# Bash Boilerplate Extraction Skill


## Overview

Bash Boilerplate Extraction Skill skill - auto-validated.
## The Pattern

When you see 3+ shell scripts with the same boilerplate at the top (creating log dirs, generating timestamp log filenames, redirecting stdout/stderr), the optimal fix is to extract a shared `.sh` library that all scripts source.

## Workflow

### Phase 1: Audit

```bash
# 1. Collect the boilerplate from each script
for f in scripts/*.sh cron/*.sh; do
    echo "=== $f ==="
    head -20 "$f"  # Identical preamble = extraction candidate
done

# 2. Check for common issues
for f in scripts/*.sh; do
    # Missing set -euo pipefail?
    head -1 "$f" | grep -q 'set -euo pipefail' || echo "MISSING pipefail: $f"
    
    # Hardcoded LOG_DIR?
    grep -q 'LOG_DIR=' "$f" || echo "NO LOG_DIR: $f"
    
    # Any undefined variable references? (grep for $VAR where VAR undef)
    sed 's/#.*//' "$f" | grep -oP '\$\{[A-Z_]*\}|\$[A-Z_][A-Z_]*' | sort -u | while read var; do
        var_clean=$(echo "$var" | sed 's/[$@{}]//g')
        grep -q "^${var_clean}=" "$f" || grep -q "export ${var_clean}" "$f" || echo "POSSIBLE UNDEF: $var_clean in $f"
    done
done
```

### Phase 2: Design Shared Library API

The library should expose a minimal, composable API:

| Function | Purpose |
|----------|---------|
| `cron_init <script_name>` | Create log dir, generate timestamped log file, redirect stdout/stderr, purge old logs (>retention days) |
| `cron_log <message>` | Write `[HH:MM:SS] message` to log |
| `cron_warn <message>` | Write warning to both log and stderr |
| `cron_finish [exit_code]` | Restore stdout/stderr, write footer |

**Key design decisions:**
- Use `exec 3>&1; exec 4>&2` to save original stdout/stderr file descriptors — this lets scripts use cron_log/cron_warn and still have the option to restore
- Detect script name automatically with `basename "$0" .sh` for log filenames
- Make retention configurable via env var `LOG_RETENTION_DAYS` (default: 30)
- Use `find + date -d` for efficient log purging

### Phase 3: Implement Library

```bash
# cron_lib.sh — write to ~/.your-project/scripts/lib/cron_lib.sh
cat > lib/cron_lib.sh << 'LIBEOF'
#!/bin/bash
LOG_DIR="${LOG_DIR:-$HOME/.hermes/logs/cron}"
LOG_RETENTION_DAYS="${LOG_RETENTION_DAYS:-30}"
LOG_FILE=""

cron_init() {
    local script_name="${1:-$(basename "$0" .sh)}"
    mkdir -p "$LOG_DIR"
    local ts=$(date +%Y%m%d_%H%M%S)
    LOG_FILE="$LOG_DIR/${script_name}_${ts}.log"
    exec 3>&1 4>&2
    exec >> "$LOG_FILE" 2>&1
    echo "=== $script_name $(date) ==="
    # Purge old logs
    local cutoff=$(date -d "-${LOG_RETENTION_DAYS} days" +%Y%m%d 2>/dev/null)
    [ -n "$cutoff" ] && find "$LOG_DIR" -maxdepth 1 -name "${script_name}_*.log" -type f | while read f; do
        local fdate=$(basename "$f" | grep -oP '\d{8}(?=_|$)')
        [ -n "$fdate" ] && [ "$fdate" -lt "$cutoff" ] 2>/dev/null && rm -f "$f"
    done
}

cron_log() { echo "[$(date '+%H:%M:%S')] $*"; }
cron_warn() { echo "[WARN][$(date '+%H:%M:%S')] $*" | tee /dev/fd/4; }

cron_finish() {
    local ec=${1:-$?}
    echo "=== DONE $(date) exit=$ec ==="
    exec 1>&3 2>&4
    return "$ec"
}
LIBEOF
```

### Phase 4: Refactor Each Script

**Before (17 lines of boilerplate per script):**
```bash
#!/bin/bash
set -e

LOG_DIR="$HOME/.hermes/logs/cron"
mkdir -p "$LOG_DIR"

TS=$(date +%Y%m%d_%H%M%S)
LOG="$LOG_DIR/my_script_${TS}.log"

{
    echo "=== My Script $(date) ==="
    # ... actual work ...
    echo "DONE $(date)"
} >> "$LOG" 2>&1
exit 0
```

**After (3 lines):**
```bash
#!/bin/bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
source "$SCRIPT_DIR/cron_lib.sh"
cron_init "my_script"

# ... actual work ...

cron_finish
```

### Phase 5: Verification

```bash
# Syntax check all scripts
for f in scripts/*.sh; do
    bash -n "$f" && echo "OK: $(basename $f)" || echo "FAIL: $(basename $f)"
done

# Runtime smoke test (run one to verify log creation)
bash path/to/script.sh 2>&1
ls -la ~/.hermes/logs/cron/ | tail -3
```

## Pitfalls to Avoid

- ❌ **Don't source with relative paths** — use `SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)` for portability
- ❌ **Don't use `set -e` alone** — always use `set -euo pipefail` to catch undefined vars and pipe errors
- ❌ **Don't forget to restore file descriptors** — `exec 1>&3 2>&4` in the finish function prevents log pollution for callers
- ❌ **Don't hardcode LOG_DIR** — make it configurable via env var with a sensible default
- ❌ **Don't assume `date -d` works on all platforms** — macOS `date` is different; use `gdate` or check with `date --version 2>/dev/null`
- ⚠️ **Log purge with string comparison**: Pad the cutoff to 8 digits before comparing (e.g., `printf "%08d" "$fdate"`) to avoid comparing `203` vs `20260504` which would sort wrong
- ⚠️ **`grep -c || echo 0` double-value trap**: `grep -c` prints `0` on no match AND exits code 1. `|| echo 0` kicks in, so `var=$(cmd || echo 0)` captures a double line. Next line `[ "$var" -lt 3 ]` fails with integer expression expected. **Fix**: Use `|| true` instead — `count=$(grep -c 'pattern' file || true)`. Or assign after: `count=${count:-0}`. Same trap applies to `wc -l || echo 0`. Rule: `|| echo` is for default values on variable expansion (`${var:-default}`), not for `$()` exit code fallback.
- ⚠️ **Bash redirect order matters**: `>> file 2>&1` works correctly; `2>&1 >> file` does NOT. In the second form, stderr is first bound to stdout (still pointing at the terminal), and THEN stdout is redirected to the file — so stderr leaks out unlogged. Always use `>> file 2>&1` (redirect stdout first, then point stderr at the same fd). When verifying a redirect worked, check three signals: exit code 0, file size/mtime changed, and line count increased — do NOT rely solely on `tail` output, because scripts that embed internal timestamps (e.g., from a cached state DB) may appear unchanged on re-run.

## Real-World Example

This skill was created from a successful refactor of Hermes Agent's cron script directory:
- **Before**: 7 scripts × ~15 lines boilerplate each = ~105 lines duplicated
- **After**: 1 shared library (42 lines) + 7 scripts × 3 lines each = 63 lines total
- **Bug found**: `cost_tracker.sh` was referencing undefined variable `$MONTHLY`
- **Safety upgrade**: All scripts upgraded from `set -e` to `set -euo pipefail`
