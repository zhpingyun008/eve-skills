---
name: cloud-cost-optimizer
description: 云成本分析与优化 — 分析AWS/GCP/Azure账单、识别优化机会（闲置资源/预留实例/存储分层）、生成成本优化报告。触发词："cost optimize"/"cloud cost"/"费用优化"/"aws cost"/"gcp billing"/"成本分析"/"finops"。
depends_on: []
related_skills:
  - k8s-resource-manager
  - terraform-generator
  - cost-optimizer
category: devops
triggers:
  - "cost optimize"
  - "cloud cost"
  - "费用优化"
  - "aws cost"
  - "gcp billing"
  - "成本分析"
  - "finops"
  - "cost reduction"
  - "账单分析"
---

# Cloud Cost Optimizer — 云成本分析与优化


## Overview

Brief description of this skill's purpose and capabilities.
分析云账单，识别成本优化机会，生成可执行的降本方案。

## Trigger Conditions

Load this skill when:
- User asks about cloud cost optimization
- Monthly billing review
- Resource rightsizing analysis
- Reserved instance planning
- FinOps cost governance
- Budget alert / overspend

## Workflow

### 1. Cost Data Collection

```bash
# AWS Cost Explorer CLI
aws ce get-cost-and-usage \
  --time-period Start=$(date -d "-30 days" +%Y-%m-%d),End=$(date +%Y-%m-%d) \
  --granularity DAILY \
  --metrics "BlendedCost" "UnblendedCost" "UsageQuantity" \
  --group-by Type=DIMENSION,Key=SERVICE \
  --output json > aws-cost-30d.json

# GCP Billing
# Export billing to BigQuery first, then:
bq query --format json \
  "SELECT service.description, SUM(cost) as total_cost
   FROM \`project.dataset.gcp_billing_export\`
   WHERE DATE(_PARTITIONTIME) >= DATE_SUB(CURRENT_DATE(), INTERVAL 30 DAY)
   GROUP BY service.description
   ORDER BY total_cost DESC"

# Azure Cost Management
az consumption usage list \
  --billing-period-name $(date -d "-1 month" +%Y%m) \
  --output json > azure-cost-monthly.json
```

### 2. Cost Analysis

```bash
# Parse and categorize costs
python3 -c "
import json

with open('aws-cost-30d.json') as f:
    data = json.load(f)

results = data.get('ResultsByTime', [{}])
if results:
    groups = results[-1].get('Groups', [])
    total = 0
    for g in sorted(groups, key=lambda x: float(x['Metrics']['UnblendedCost']['Amount']), reverse=True):
        service = g['Keys'][0]
        cost = float(g['Metrics']['UnblendedCost']['Amount'])
        total += cost
        print(f'  {service}: \${cost:.2f}')
    print(f'  --- Total: \${total:.2f} ---')
"
```

### 3. Optimization Opportunities

| Category | Typical Saving | Action |
|----------|---------------|--------|
| Idle Compute | 30-50% | Stop/terminate idle instances |
| Rightsizing | 20-40% | Downsize over-provisioned instances |
| Reserved Instances | 40-60% | 1yr/3yr commitment for stable workloads |
| Storage Tiering | 50-70% | Move cold data to S3 Glacier / GCS Archive |
| Spot Instances | 60-90% | Use spot for fault-tolerant workloads |
| Unused EBS | 100% | Delete unattached volumes |
| Elastic IP | 100% | Release unused IPs |
| NAT Gateway | 30-50% | Replace with VPC endpoints |

### 4. Rightsizing Analysis

```bash
# AWS Rightsizing Recommendations
aws ce get-rightsizing-recommendation \
  --service EC2 \
  --time-period Start=$(date -d "-30 days" +%Y-%m-%d),End=$(date +%Y-%m-%d) \
  --configuration NumberOfRecommendationsToShow=20

# Check underutilized instances
aws cloudwatch get-metric-statistics \
  --namespace AWS/EC2 \
  --metric-name CPUUtilization \
  --dimensions Name=InstanceId,Value=i-12345 \
  --start-time $(date -d "-14 days" +%Y-%m-%dT00:00:00) \
  --end-time $(date +%Y-%m-%dT23:59:59) \
  --period 3600 \
  --statistics Average \
  --output json
```

### 5. Reserved Instance Planning

```bash
# Get RI recommendations
aws ce get-reservation-purchase-recommendation \
  --service EC2 \
  --lookback-period-in-days LAST_30_DAYS \
  --payment-option NO_UPFRONT \
  --term-in-years 1
```

### 6. Generate Optimization Report

```markdown
# Cloud Cost Optimization Report
**Period**: Last 30 days
**Total Spend**: $X,XXX.XX

## Top 5 Savings Opportunities

1. **Rightsize prod-web-01** (t3.xlarge → t3.large): Save $YY/月
2. **Delete unattached EBS volumes** (3 volumes): Save $ZZ/月
3. **Reserved Instance for RDS** (db.r5.large × 2): Save $AA/月
4. **Move S3 cold data to Glacier**: Save $BB/月
5. **Stop idle dev environment on weekends**: Save $CC/月

**Total Potential Savings**: $DDD/月 (XX% of current spend)

## Action Items
- [ ] Review and terminate instances with <5% CPU for 14+ days
- [ ] Purchase RI for stable production workloads
- [ ] Implement auto-stop for dev/staging environments (9am-6pm only)
- [ ] Configure S3 lifecycle policies for log data
```

## Pitfalls

1. **Cost data delay**: AWS billing data has 24-48h delay. Use AWS Cost Explorer API v2 for near-real-time data.
2. **RI commitment risk**: Reserved instances lock you into specific instance families. Start with 1-year partial upfront to limit risk.
3. **Rightsizing ≠ always cheaper**: Larger instances may have better price/performance ratios. Consider compute-optimized vs general-purpose trade-offs.
4. **Spot interruption**: Spot instances can be terminated on 2-minute notice. Only use for fault-tolerant, stateless workloads.
5. **Storage tier transition**: Retrieving data from Glacier takes hours. Ensure cold data truly doesn't need quick access.
6. **Cross-service cost attribution**: Shared resources (NAT Gateway, VPN) need allocation across teams. Implement tag-based cost allocation.
7. **Free tier gotchas**: Many services have limited free tiers that expire after 12 months. Set budget alerts before expiry.

## Verification

```bash
# Test AWS Cost Explorer access
aws ce get-cost-and-usage \
  --time-period Start=$(date -d "-3 days" +%Y-%m-%d),End=$(date -d "-1 days" +%Y-%m-%d) \
  --granularity DAILY \
  --metrics BlendedCost \
  --output json 2>/dev/null | python3 -c "import json,sys; d=json.load(sys.stdin); print(f'✓ Access OK, got {len(d.get(\"ResultsByTime\",[]))} days')" || echo "⚠️  Requires AWS Cost Explorer access (ce:GetCostAndUsage)"
```

## Integration

- **terraform-manager**: Tag resources for cost allocation
- **incident-commander**: Anomalous cost spike as incident trigger
- **health-dashboard**: Cost metrics dashboard
- **ops-monitor**: Cost monitoring alongside performance
