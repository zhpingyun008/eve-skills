# cloud-cost-optimizer — Reference

## Overview
云成本分析与优化 — 分析AWS/GCP/Azure账单、识别优化机会（闲置资源/预留实例/存储分层）、生成成本优化报告。触发词："cost optimize"/"cloud cost"/"费用优化"/"aws cost"/"gcp billing"/"成本分析"/"finops"。

## Integration Points
- Hermes Agent skill ecosystem
- evolution_engine.py scoring system
- self-audit verification

## Key Resources
- SKILL.md: main skill definition
- scripts/: executable code (if present)
