# Maestro Orchestrator Reference

## State Model
- .maestro/ on-disk shared state
- Missions: milestones + features + assertions + handoffs
- Tasks: daily blocker graph (tasks.jsonl)

## CLI Quick Ref
- maestro init
- maestro mission create
- maestro task ready/claim/update