---
name: maestro-orchestrator
description: 多Agent工程指挥 — 本地优先的共享状态层，Mission(里程碑+断言+检查点+交接启动) + Task(日常阻塞器队列)。对标 ReinaMacCredy/maestro。触发词："maestro"/"编排"/"指挥"/"多agent"/"mission"/"handoff"。
depends_on: []
related_skills:
  - incident-commander
  - k8s-deployer
  - chaos-engineer
category: devops
triggers:
  - "maestro"
  - "编排"
  - "指挥"
  - "多agent"
  - "mission"
  - "handoff"
  - "共享状态"
---

# Maestro — 多Agent工程指挥


## Overview

Brief description of this skill's purpose and capabilities.
本地优先的多Agent软件工程指挥者。共享状态在 `.maestro/` 磁盘上，无需服务器/数据库/守护进程。

## 核心概念

| 概念 | 用途 |
|------|------|
| **Mission** | 顶层工作单元，生命周期：draft→approved→executing |
| **Milestone** | Mission中的阶段，作为工作阶段或验证门 |
| **Feature** | 分配给Agent类型的具体工作，含验证步骤 |
| **Assertion** | 绑定Feature的验证目标，状态：passed/failed/blocked/waived |
| **Handoff** | 持久化启动记录+Markdown简报，启动新Agent会话 |
| **Task** | 轻量级阻塞器图，日常队列 `.maestro/tasks/tasks.jsonl` |
| **Reply** | Agent对Feature的结构化结果记录 |
| **Memory** | 修正/学习/编译指引，反馈到未来Agent提示词 |
| **Checkpoint** | 时间戳Mission快照，可保存和恢复 |

## 两种工作模式

| Mission模式 | Task模式 |
|------------|---------|
| 计划的多步骤工作，含里程碑/断言/检查点/交接 | 轻量阻塞器图，日常队列 |
| 耐久Agent简报 | 快速ready/claim/update/阻塞管理 |
| `.maestro/missions/<id>/` 下的可审查产物 | `.maestro/tasks/tasks.jsonl` 仓库追踪 |

## Hermes集成

在Hermes上下文中使用Maestro模式：

### 初始化
```bash
mkdir -p .maestro/missions .maestro/tasks
```

### 创建Mission
在Hermes中定义Mission → 生成结构化计划 → 写入 `.maestro/missions/<id>/mission.json`

### 执行循环
1. 定义工作(Mission/Feature)
2. 检查Feature简报(可选)
3. `delegate_task` 启动新Handoff
4. 更新进度
5. 验证结果(Assertion)
6. 检查点保存 → 封存Milestone

### Task日常队列
- `ready` — 标记就绪
- `claim` — Agent认领
- `update` — 更新进度
- 阻塞管理

## 安装(如需CLI)

```bash
curl -fsSL https://raw.githubusercontent.com/ReinaMacCredy/maestro/main/scripts/install.sh | bash
```

要求: Bun + Git

## 集成点

- delegate_task: Handoff启动子Agent
- task-dag: 依赖关系可视化
- virtual-team: 角色分配与Agent类型
- plan-first: 计划先于执行
- hook-engine: 里程碑钩子

## 来源

ReinaMacCredy/maestro — MIT License
