# Hermes v0.16.0 → v0.17.0 升级追踪 (2026-06-28)

## 版本信息
- From: v0.16.0 (2026.6.5)
- To: v0.17.0 (2026.6.19) — "The Reach Release"
- Commits since: ~1,475 · ~800 PRs · 1,693 files changed · 235K insertions

## 关键新特性
1. **Background subagents**: `delegate_task(background=true)` — 异步执行子Agent
2. **Memory tool upgrade**: 外部记忆提供者插件(honcho/mem0/hindsight等)
3. **Automation Blueprints**: 可视化Cron创建
4. **Desktop app**: 键盘快捷键/OS通知/watch-window/主题
5. **iMessage Photon**: 新频道(不相关)
6. **Raft network**: 新频道(不相关)
7. **Image-to-image**: image_generate支持图编辑

## 升级过程记录

### 备份
- 全量tar超时(30s) → 转为配置级备份
- Config backup: 12MB (config.yaml + .env + scripts/)
- Profile configs: 17个分别备份到 ~/backups/profile-configs/

### 依赖变更
```
更新: websockets 16.0→15.0.1, urllib3 2.6.3→2.7.0, PyJWT 2.12.1→2.13.0
      pydantic-core 2.23.4→2.46.4, packaging 26.2→26.0, jinja2 3.1.4→3.1.6
      certifi 2026.4.22→2026.5.20, pydantic 2.9.2→2.13.4
新增: hermes-agent 0.16.0→0.17.0
```

### 配置迁移
- 主配置: 27→30
- 14个profile: 22→30 (逐个运行 `hermes --profile <name> config migrate`)
- 新增字段: curator.consolidate: false, model_catalog.ttl_hours: 1
- Curator在profile级默认启用 → 需批量禁用

### 验证结果
- 版本: v0.17.0 ✅
- pip检查: 0冲突 ✅
- 技能: 280完整 ✅
- Cron: 140枚/0错误 ✅
- 产品服务: 6/6在线 ✅
- 核心端点: 全部200 ✅
- WebUI: 需手动重启(因Gateway重启波及)
- 进化引擎: 100/100 ✅
