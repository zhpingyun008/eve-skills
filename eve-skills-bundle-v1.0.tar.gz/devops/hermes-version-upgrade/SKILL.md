---
name: hermes-version-upgrade
description: Full lifecycle for upgrading Hermes Agent between versions — including post-upgrade feature enablement (Feishu native WS, Kanban, Curator and Proxy assessment, backup automation) and system diagnostics.
triggers:
  - User asks to upgrade Hermes Agent
  - User asks to check latest Hermes version
  - User reports "upgrade Hermes" or "update hermes"
  - Changelog review between Hermes versions
  - Security advisory mandates Hermes update
  - Post-upgrade Feishu or Kanban or backup setup needed
  - Post-upgrade feature enablement after version upgrade
  - User says "切换自主模式" / "auto mode" / "autonomous mode"
  - User requests multi-agent autonomous operation setup
  - Post-upgrade autonomous mode activation (Phase 5)
category: devops
---

# Hermes Agent 版本升级流程

## 1. 影响评估 (Impact Assessment)

### 1.1 确认版本差距
```bash
# 当前版本 (输出已含"Update available"提示)
hermes --version
pip3 show hermes-agent

# 最新版本 (PyPI)
pip3 index versions hermes-agent

# 查看release notes
# ⚠ GitHub release tag名 ≠ pip版本号
#    pip: 0.17.0  →  GitHub: v2026.6.19
#    不要直接用pip版本拼GitHub API tag路径 — 会返回空
#    正确方式: 遍历releases列表查找
curl -s "https://api.github.com/repos/NousResearch/hermes-agent/releases?per_page=5" \
  | python3 -c "
import sys,json
releases = json.load(sys.stdin)
if isinstance(releases, list):
    for r in releases[:5]:
        body = (r.get('body') or '')[:2000]
        print(f'=== {r[\"tag_name\"]} ({r[\"published_at\"][:10]}) ===')
        print(body[:600])
        print()
else:
    print('API returned:', str(releases)[:200])
"

# 如果只需要找特定版本, 用per_page=20确保覆盖
curl -s "https://api.github.com/repos/NousResearch/hermes-agent/releases?per_page=20" \
  | python3 -c "
import sys,json
releases = json.load(sys.stdin)
target = 'v0.17.0'  # pip版本→转GitHub tag格式
for r in releases:
    body = (r.get('body') or '')
    print(f'{r[\"tag_name\"]} ({r[\"published_at\"][:10]}): {body[:3000]}...')
    print('---')
"
```

**陷阱**: GitHub API分页限制 — `?per_page=10`可能漏掉目标版本。如`v0.17.0`不在前10个release中，需增加到`per_page=20`或使用标签查找API(但标签名需要知道确切格式)。推荐先用`per_page=20`获取全部最近release。

### 1.2 关键检查点
| 检查项 | 风险等级 | 说明 |
|--------|---------|------|
| Curator自动修剪 | 🔴高 | 新版本可能默认启用Curator，会修剪自定义技能 |
| feishu.py适配器 | 🔴高 | 旧版stub可能被完整版替换，或接口变更 |
| config.yaml格式变更 | 🟡中 | 配置迁移可能覆盖自定义字段 |
| Redaction默认开启 | 🟡中 | v0.13+ security默认开启，影响secret读取 |
| Gateway重启 | 🟡中 | 升级后旧Gateway进程需重拉 |
| 依赖变更 | 🟢低 | lark-oapi/pydantic版本变更 |
| 外部脚本 | 🟢低 | feishu-ws-daemon/router独立于Hermes |

### 1.3 读取关键版本变化
```bash
# 检查feishu.py是否变更
ls -la ~/.hermes/.venv/lib/python*/site-packages/gateway/platforms/feishu.py

# 检查新版config格式变化
# 重点关注: auxiliary.curator, security, platform adapters
```

## 2. 升级前保护 (Pre-upgrade Protection)

### 2.1 全量备份
```bash
mkdir -p ~/backups

# ⚠ profiles/ 和 skills/ 常见 5-10GB，tar全量超时会失败
# 策略：排除大型数据目录，只备份可恢复的核心配置
BACKUP_FILE=~/backups/hermes-critical-$(date +%Y%m%d).tar.gz
tar -czf "$BACKUP_FILE" \
  --exclude='profiles/*/skills' \
  --exclude='profiles/*/kanban' \
  --exclude='profiles/*/memory' \
  --exclude='profiles/*/state.db' \
  --exclude='state/*.db-wal' \
  --exclude='state/*.db-shm' \
  -C ~ \
  .hermes/config.yaml \
  .hermes/.env \
  .hermes/profiles/ \
  .hermes/scripts/ \
  .hermes/state/ \
  .hermes/memory/ \
  ./scripts/
echo "Backup: $BACKUP_FILE ($(ls -lh "$BACKUP_FILE" | awk '{print $5}'))"

# 如果上述tar仍超时（15-30秒无响应），fallback到config-only备份：
if [ $? -ne 0 ] || [ ! -f "$BACKUP_FILE" ]; then
  echo "Full tar timed out, switching to config-only backup..."
  BACKUP_FILE2=~/backups/hermes-config-$(date +%Y%m%d).tar.gz
  tar -czf "$BACKUP_FILE2" \
    -C ~ \
    .hermes/config.yaml \
    .hermes/.env \
    .hermes/scripts/
  echo "Config backup: $BACKUP_FILE2 ($(ls -lh "$BACKUP_FILE2" | awk '{print $5}'))"
  
  # 单独备份profile config.yaml
  mkdir -p ~/backups/profile-configs
  for cfg in ~/.hermes/profiles/*/config.yaml; do
    [ -f "$cfg" ] && cp "$cfg" ~/backups/profile-configs/$(basename $(dirname "$cfg")).yaml
  done
  echo "Profile configs: $(ls ~/backups/profile-configs/ | wc -l) files saved"
fi
```

### 2.2 禁用Curator（阻止技能被自动修剪）
```yaml
# 在 config.yaml 中添加（分两处以确保覆盖）
auxiliary:
  curator:
    enabled: false    # 新版auxiliary路径
curator:
  enabled: false      # 旧版/新版top-level路径
```

### 2.3 保存feishu.py stub（防止完整版覆盖后不兼容）
```bash
cp ~/.hermes/.venv/lib/python*/site-packages/gateway/platforms/feishu.py ~/scripts/feishu-stub-$(date +%Y%m%d).py
echo "Stub saved: $(wc -c < ~/scripts/feishu-stub-*.py) bytes"
```

### 2.4 停止受影响服务
```bash
# Gateway在升级过程中会保持运行（pip upgrade不影响运行中进程）
# 但建议记录当前gateway进程数用于升级后对比
ps aux | grep "gateway run" | grep -v grep | wc -l
```

## 3. 执行升级 (Execution)

```bash
# 方式A: 直接pip升级 (推荐 — 安全策略兼容)
pip3 install --upgrade hermes-agent

# 或指定版本
pip3 install hermes-agent==<target_version>

# 方式B: hermes update CLI (可能被安全策略拦截)
# hermes update 命令在某些安全配置下会被拒绝执行
# 若被blocked: 使用方式A pip升级替代

# 验证版本
hermes --version
python3 -c "from hermes_cli import __version__; print(__version__)"

# 检查依赖冲突（pip可能不阻塞不兼容的包版本）
pip3 check 2>&1
# 返回值: 0=无冲突, 非0=有冲突
# 注意: pip install 阶段的依赖冲突警告可能被安装器自动解决
#       最终以 pip3 check 退出码为准，install日志的冲突不一定是持久状态
# 常见：litellm需要旧版pydantic而hermes升级了pydantic —— 不影响hermes核心功能
```

**陷阱**: `hermes update` 可能因安全策略(security scan→pipe to interpreter)被拦截。此命令会执行下载+安装，在受控环境中可能被禁止。优先使用 `pip3 install --upgrade hermes-agent`。<br>
**预检**: `hermes --version` 输出尾部已包含"Update available"提示，可用于快速判断是否需要升级而不调用任何网络请求。

## 4. 升级后验证 (Post-upgrade Verification)

### 4.1 配置迁移

#### 4.1a 主配置迁移
```bash
# 运行配置迁移（新版可能添加默认配置段）
hermes config migrate 2>&1

# 检查迁移后自定义字段是否被保留
grep -n "curator\|custom\|leadership\|sdl" ~/.hermes/config.yaml
```

#### 4.1b Profile配置批量迁移
升级后所有profile也需独立迁移(v22→v30等)。逐一运行:
```bash
for p in arch cm dev doc eve-closer eve-scout eve-scribe pm qa req sec spi tester yestin; do
  echo -n "=== $p: "
  hermes --profile $p config migrate 2>&1 | grep "version:"
done
```

注意: 迁移后profile curator默认启用(参见4.2b)。

### 4.2 Curator状态验证

#### 4.2a 主配置验证
```bash
grep -A2 "curator:" ~/.hermes/config.yaml
# 确认 enabled: false
```

#### 4.2b Profile级批量Curator禁用 (关键步骤)
`hermes config migrate` 运行后，**所有profile的config.yaml会默认启用curator**(enabled: true)。必须批量禁用，否则280+自定义技能可能在下次curator运行时被修剪。

```bash
# 1. 检查所有profile的curator状态
for p in arch cm dev doc pm qa req sec spi tester yestin eve-closer eve-scout eve-scribe; do
  enabled=$(grep -A3 "curator:" ~/.hermes/profiles/$p/config.yaml 2>/dev/null | grep "enabled" | head -1 | awk '{print $2}')
  echo "$p: curator.enabled=$enabled"
done

# 2. 批量禁用 — 用skill_manage(action='patch') 逐文件修改
# 对每个 profile/config.yaml 运行:
# skill_manage(action='patch', name='hermes-version-upgrade',
#   old_string='curator:\n  enabled: true',
#   new_string='curator:\n  enabled: false')

# 注意: 部分profile可能有2个curator段(top-level + auxiliary)
# 需检查两个段并确保全部 enabled: false

# 3. 验证
grep -r "curator:" ~/.hermes/profiles/*/config.yaml | grep "enabled" | grep -c "true"
# 期望返回 0
```

**陷阱**: 迁移后profile curator默认启用，这是已知行为。如不手动禁用，curator下次运行时(默认24h)可能开始修剪agent-created skills。

### 4.3 feishu适配器验证
```bash
# 检查feishu.py版本（完整版或stub）
wc -c ~/.hermes/.venv/lib/python*/site-packages/gateway/platforms/feishu.py
head -5 ~/.hermes/.venv/lib/python*/site-packages/gateway/platforms/feishu.py
```

### 4.4 Gateway健康检查
```bash
# 路由脚本验证（如果使用）
python3 ~/scripts/feishu-agent-router.py --check

# 或直接curl所有profile端口
for port in $(grep -r "port:" ~/.hermes/profiles/ | awk '{print $2}'); do
  curl -sf "http://localhost:$port/health" >/dev/null && echo "✅ $port" || echo "❌ $port"
done
```

### 4.5 飞书群聊E2E测试
```bash
python3 ~/scripts/feishu-agent-router.py --message "@PM Hermes升级验证" --send
```

### 4.6 Cron验证
```bash
hermes cron list 2>&1 | head -10
crontab -l | grep feishu-daemon
```

### 4.7 进程数对比
```bash
echo "Before: <记录的数字>"
echo "After: $(ps aux | grep 'gateway run' | grep -v grep | wc -l)"
```

### 4.8 Profile完整性验证
```bash
# 确认所有Profile完好、模型分配正确
hermes profile list

# 重点关注：profile数量与升级前一致，模型名无异常
```

### 4.9 技能库完整性验证
```bash
# 确认升级未误删/误修剪技能
hermes skills list 2>&1 | head -5
echo "---"
echo "Total skills: $(hermes skills list 2>&1 | grep -c '│')"

# 验证关键自定义技能存在
for skill in cmmi5-pipeline pm-daily-report srs-auto-generator zhixiang-zhizao code-review; do
  hermes skills list 2>&1 | grep -q "$skill" && echo "✅ $skill" || echo "❌ $skill MISSING"
done
```

## 5. 回滚预案 (Rollback)

```bash
# 备份恢复
tar -xzf ~/backups/hermes-critical-*.tar.gz -C ~

# 降级回旧版本
pip3 install hermes-agent==<old_version>

# 如果有venv隔离
# rm -rf .venv && uv sync

# 重启所有gateway
for pid in $(ps aux | grep 'gateway run' | grep -v grep | awk '{print $2}'); do
  kill $pid
done
# 手动重新拉起或等待auto-heal
```

## 6. 已知陷阱 (Pitfalls)

### Config迁移添加重复curator段
迁移可能添加新的top-level `curator:` 段（enabled: true），与已有 `auxiliary.curator:` 冲突。
**解决**: 找到两个curator段，确保两者都设为 `enabled: false`。

### feishu.py stub被完整版替换
升级后旧stub(554B)会被pip替换为新完整版(200KB+)。新完整版支持原生WebSocket但行为可能不同。
**解决**: 升级前备份stub，升级后对比行为，如需回切则恢复stub。

### Gateway重启后WebUI离线

Gateway restart (`systemctl --user restart hermes-gateway.service`) 可能导致独立运行的WebUI进程(hermes-web-ui)下线。WebUI作为node子进程独立运行，不依赖Gateway存活，但Gateway重启时的SIGTERM可能传播到同进程组的WebUI。

**诊断**: WebUI端点(:8648)返回000但日志文件仍在更新
```bash
curl -s -o /dev/null -w "%{http_code}" http://localhost:8648/  # → 000
tail -3 ~/.hermes-web-ui/logs/server.log  # 确认日志时间戳是否停滞
```

**修复**: 
```bash
# 1. 停止旧进程
pkill -f "hermes-web-ui" 2>/dev/null; sleep 1

# 2. 重新启动 (使用正确的node路径)
cd /home/yestin/.hermes
/home/yestin/.hermes/node-v23/bin/node \
  /home/yestin/.hermes/node-v23/lib/node_modules/hermes-web-ui/dist/server/index.js

# 3. 验证 (等待5-6秒启动)
curl -s -o /dev/null -w "%{http_code}" http://localhost:8648/
# 期望 200

# 4. 确认Agent连接 (检查日志)
tail -5 ~/.hermes-web-ui/logs/server.log | grep "AgentClients"
# 期望看到 11个CMMI5 Agent全部Connected
```

**注意**: node路径可能随版本变化。检查 `ls /home/yestin/.hermes/node*/bin/node` 选择实际存在的版本。优先用 `latest` 或最高版本号。

### 依赖冲突（非致命）
升级后 `pip3 check` 可能报告包版本不兼容（如 litellm 需要 pydantic==2.12.5 但 Hermes v0.16.0 升级到 pydantic 2.13.4）。Hermes核心不依赖litellm，此类冲突无害。
**解决**: 运行 `pip3 check` 阅读具体冲突 —— 若冲突包非Hermes直接依赖（如 litellm, langchain），忽略即可。若提示 Hermes 自身依赖冲突，需降级或等待修复版。

### Curator在config migrate时的自动插入
`hermes config migrate` 会自动插入curator默认配置段（enabled: true）。
**v0.17.0+ 新增**: migrate还会自动添加 `curator.consolidate: false`（LLM合并功能改为opt-in，修剪保留）。
**解决**: 升级后立即检查并修改 curator.enabled = false。验证两处curator段均设为disabled。

## 7. 升级后特性启用 (Post-Upgrade Feature Enablement)

### 7.1 Phase 1 — Feishu原生WebSocket迁移（v0.14+）
升级后Feishu适配器从stub(554B)变为完整版(200KB+)，支持原生WebSocket长连：

```bash
# 1. 为所有profile启用Feishu原生WS
for profile_dir in ~/.hermes/profiles/*/; do
  profile=$(basename "$profile_dir")
  yq eval -i '.platforms.feishu.enabled = true' "$profile_dir/config.yaml" 2>/dev/null || \
    echo "  ⚠ 跳过 $profile (无config.yaml或yq不可用)"
done

# 2. 设置群消息策略为open (@mention自动回复)
for profile_dir in ~/.hermes/profiles/*/; do
  yq eval -i '.platforms.feishu.group_message_policy = "open"' "$profile_dir/config.yaml" 2>/dev/null
done

# 3. 清理外部feishu-ws-daemon.py脚本
#    停止进程 + 移除@reboot条目
pkill -f feishu-ws-daemon 2>/dev/null || true
crontab -l 2>/dev/null | grep -v "feishu-daemon\|feishu-ws" | crontab -

# 4. 验证WS连接状态
for port in $(grep -r "port:" ~/.hermes/profiles/ | awk '{print $2}' | sort -n); do
  curl -sf "http://localhost:$port/health" 2>/dev/null | python3 -c "import sys,json; d=json.load(sys.stdin); print(f'✅ :$port feishu={\"🟢\" if d.get(\"feishu\",{}).get(\"websocket\",\"\")==\"connected\" else \"🔴\"}')" 2>/dev/null || echo "❌ :$port (unreachable)"
done
```

**陷阱**: 外部feishu-daemon脚本的@reboot需要手动清理，否则重启后与Gateway WS冲突。

### 7.2 Phase 2 — Kanban看板+Gateway调度器 (v0.14+)
```bash
# 1. 创建看板
hermes kanban boards create cmmi5-sprint \
  --name "CMMI5 Sprint" \
  --description "Post-upgrade sprint board" \
  --switch

# 2. 创建初始任务
hermes kanban create "初始种子任务" --body "描述" --priority P1

# 3. 确保kanban-worker技能在所有profile下可用
#    关键: 内置kanban-worker技能不存在于文件系统中，需手动创建
SKILL_CONTENT="""---
name: kanban-worker
description: Built-in kanban worker skill for dispatched tasks
---
# Kanban Worker Skill
Standard patterns for task completion.
"""
for profile_dir in ~/.hermes/profiles/*/; do
  mkdir -p "$profile_dir/skills/kanban-worker"
  echo "$SKILL_CONTENT" > "$profile_dir/skills/kanban-worker/SKILL.md"
done

# 4. 验证Gateway dispatcher已在配置中启用
grep -r "dispatch_in_gateway\|dispatch_interval_seconds" ~/.hermes/config.yaml
# 期望: dispatch_in_gateway: true, dispatch_interval_seconds: 60

# 5. 测试kanban完整生命周期
hermes kanban create "验证测试" --body "自动分发测试" --assignee yestin
sleep 75  # 等待dispatcher轮询
hermes kanban list  # 确认任务已自动完成
```

**陷阱**: profile-scoped HERMES_HOME (如 `~/.hermes/profiles/yestin/`) 改变SKILLS_DIR路径，全局skills目录的技能不会被profile scoped子进程发现。需在每个profile的skills目录下分别放置kanban-worker SKILL.md。

### 7.3 Phase 3 — Curator/Proxy评估
```bash
# Curator评估: 仅管理agent-created技能，手动编写的不受影响
hermes curator run --dry-run
# 如果无agent-created skills, 输出: "0 candidate skills"

# Pin关键技能防止意外修剪
for skill in cmmi5-chat-router cmmi5-fullstack-orchestrator cmmi5-pipeline; do
  hermes curator pin "$skill"
done

# Proxy评估: 用于OAuth转发，如使用API Key直连则不需要
hermes proxy status 2>&1 || echo "Proxy模块未安装，无需启用"
```

### 7.4 Phase 4 — 备份自动化+系统诊断
```bash
# 1. 初始备份
hermes backup --quick -l "post-upgrade"

# 2. 创建自动备份cron (每周)
hermes cron create "every 10080m" \
  "执行 hermes backup --quick -l 'auto-weekly'" \
  --name "Weekly Auto-Backup" \
  --deliver local

# 3. 运行系统诊断
hermes doctor  # 检查问题
hermes doctor --fix  # 自动修复(wal checkpoint等)

# 4. WAL文件维护cron (state.db WAL增长到500MB+需定期checkpoint)
crontab -l 2>/dev/null; echo "0 3 * * 0 cd \$HOME/.hermes && sqlite3 state.db 'PRAGMA wal_checkpoint(TRUNCATE);' 2>/dev/null && echo 'WAL checkpoint done'" | crontab -
```

## 8. 验证清单 (Verification Checklist)

- [ ] hermes --version 显示目标版本
- [ ] pip3 check 无依赖冲突（或已知无害冲突已确认）
- [ ] config.yaml 迁移成功，自定义字段保留
- [ ] curator disabled（两个段）/ 或 dry-run确认无影响
- [ ] feishu适配器正常工作，11个profile WS已连接
- [ ] 所有profile Gateway 健康 (E2E测试通过)
- [ ] hermes profile list 显示全部profile，模型分配正确
- [ ] hermes skills list 技能总数正常，关键技能无缺失
- [ ] 飞书群聊@PM 回复正常
- [ ] kanban看板已创建，dispatcher正常运行
- [ ] kanban-worker技能在11个profile下可用
- [ ] cron jobs 正常运行 (+ 备份cron)
- [ ] @reboot自启动正常 (无外部feishu-daemon残留)
- [ ] 备份文件可恢复
- [ ] WAL checkpoint已执行
- [ ] 7层自主回路激活（Sprint→Dispatch→Supplier→Heal→Health→AntiDegrade→Evolve）
- [ ] 看板任务自动分发到各Agent
- [ ] autonomous_mode.sh每30分钟执行
- [ ] 所有Agent飞书群聊独立应答可用

## 9. 自主多Agent模式激活 (Phase 5 — Autonomous Mode)

完成Phase 1-4后，将各组件集成至全自主多Agent回路。使每个Agent通过Kanban+Gateway调度器独立接收和完成任务。

### 9.1 架构概览 — 7层自主回路

```
Layer 1  Sprint Orchestrator   ⏰ 每小时   Backlog→执行→归档
Layer 2  Kanban Dispatch       ⏰ 每60秒   网关级Agent任务分发
Layer 3  Autonomous Supplier   ⏰ 每30分钟  看板任务补充与解阻塞
Layer 4  Gateway AutoHeal      ⏰ 每2分钟  进程级故障自愈
Layer 5  Health Check          ⏰ 每5分钟  端口/服务健康巡检
Layer 6  Anti-Degradation      ⏰ 每15分钟  性能退化防御
Layer 7  Meta-Evolution        ⏰ 每周     技能/记忆自我进化
```

### 9.2 前置条件

- Phase 1-4 全部完成（Feishu WS/ Kanban / Curator评估 / 备份自动化）
- 所有profile的Gateway已在运行
- kanban-worker技能已复制到所有profile（参见7.2节）
- Kanban看板已创建且dispatcher已启用

### 9.3 创建自主模式供应脚本

```bash
mkdir -p ~/scripts
cat > ~/scripts/autonomous_mode.sh << 'SCRIPT'
#!/bin/bash
# 自主模式循环 — 每30分钟执行
# 功能: 补充看板任务、解阻塞任务、确保各Agent持续有工作

LOGFILE="$HOME/.hermes/logs/cron/autonomous_mode.log"
KANBAN_BOARD="${KANBAN_BOARD:-cmmi5-sprint}"
BUDGET_FILE="$HOME/.hermes/kanban/budgets/cmmi5-sprint.json"

mkdir -p "$(dirname "$LOGFILE")"
echo "[$(date '+%Y-%m-%d %H:%M:%S')] === Autonomous Mode Cycle Start ===" >> "$LOGFILE"

# Step 1: 检查看板是否需要补充任务 (ready < 3)
HERMES="$HOME/.hermes/.venv/bin/hermes"
READY_COUNT=$($HERMES kanban list 2>/dev/null | grep -c 'ready' || echo 0)
echo "  Ready tasks: $READY_COUNT" >> "$LOGFILE"

if [ "$READY_COUNT" -lt 3 ]; then
  # 从backlog补充任务
  if [ -f "$HOME/.hermes/backlog/backlog.json" ]; then
    for i in $(seq 1 $((3 - READY_COUNT))); do
      TASK_NAME=$(jq -r ".pending[0].title // \"Auto task $i\"" "$HOME/.hermes/backlog/backlog.json" 2>/dev/null)
      $HERMES kanban create "🤖 $TASK_NAME" --body "Auto-generated by autonomous_mode.sh" --priority P2 2>>"$LOGFILE"
      echo "  Created: $TASK_NAME" >> "$LOGFILE"
    done
  else
    $HERMES kanban create "🤖 自主维护: 系统健康检查" --body "日常巡检各Agent状态" --priority P2 2>>"$LOGFILE"
    $HERMES kanban create "🤖 自主维护: 知识库同步" --body "检查BookStack同步状态" --priority P3 2>>"$LOGFILE"
  fi
fi

# Step 2: 解阻塞 - 查找blocked任务并恢复
BLOCKED_TASKS=$($HERMES kanban list 2>/dev/null | grep 'blocked' | awk '{print $1}')
for tid in $BLOCKED_TASKS; do
  echo "  Found blocked: $tid" >> "$LOGFILE"
  # 检查是否超时阻塞 (阻塞超过2小时视为stale)
  $HERMES kanban unblock "$tid" 2>>"$LOGFILE"
done

# Step 3: 验证分发
AGENT_COUNT=$(ps aux | grep 'gateway run' | grep -v grep | wc -l)
echo "  Active gateways: $AGENT_COUNT" >> "$LOGFILE"
echo "[$(date '+%Y-%m-%d %H:%M:%S')] === Cycle Complete ===" >> "$LOGFILE"
SCRIPT
chmod +x ~/scripts/autonomous_mode.sh
```

### 9.4 注册自动供应Cron

```bash
# 添加到系统crontab (每30分钟)
crontab -l 2>/dev/null > /tmp/crontab.tmp
if ! grep -q "autonomous_mode.sh" /tmp/crontab.tmp; then
  echo "*/30 * * * * bash $HOME/scripts/autonomous_mode.sh >/dev/null 2>&1" >> /tmp/crontab.tmp
  crontab /tmp/crontab.tmp
fi

# 立即执行第一轮
bash ~/scripts/autonomous_mode.sh

# 创建日志目录
mkdir -p ~/.hermes/logs/cron/
```

### 9.5 配置Gateway调度器

确保 `~/.hermes/config.yaml` 中已启用Kanban调度器：

```yaml
kanban:
  boards:
    cmmi5-sprint:
      display_name: "CMMI5 Sprint"
      description: "Continuous autonomous sprint"
      dispatch_in_gateway: true        # 启用Gateway内调度
      dispatch_interval_seconds: 60     # 每60秒分发一次
      max_dispatched_per_agent: 1       # 每Agent同时最多1个任务
```

### 9.6 验证自主模式

```bash
# 1. 确认脚本可执行且cron已注册
crontab -l | grep autonomous_mode

# 2. 看板有足够任务
hermes kanban list

# 3. 验证分发 — 等待90秒后检查任务是否被Agent领取
sleep 90
hermes kanban list | grep -E "in_progress|done"

# 4. 飞书群聊测试 — @任意Agent应独立回复
python3 ~/scripts/feishu-agent-router.py --message "@ARCH 系统状态" 2>/dev/null || \
  echo "请手动在飞书群中@各Agent验证"

# 5. 确认所有组件健康
echo "=== 自主模式验证 ==="
for layer in "Sprint" "Dispatch" "Supplier" "Heal" "Health" "AntiDegrade" "Evolve"; do
  echo "  Layer $layer: ⏳ (由cron自动驱动)"
done
echo "  Gateways: $(ps aux | grep 'gateway run' | grep -v grep | wc -l) processes"
echo "  Cron: $(crontab -l | grep -c 'autonomous\\|hermes cron') jobs"
echo "  Feishu: 各Agent独立WS直连"
```

### 9.7 运维要点

| 组件 | 文件/路径 | 监控方式 |
|------|-----------|----------|
| 自主模式脚本 | `~/scripts/autonomous_mode.sh` | `tail -f ~/.hermes/logs/cron/autonomous_mode.log` |
| 看板数据库 | `~/.hermes/kanban/boards/` | `hermes kanban list` |
| 调度日志 | Gateway日志 | `tail -f ~/.hermes/logs/gateway-*.log` |
| Sprint日志 | `~/.hermes/logs/cron/sprint-*` | `hermes cron list` |

### 9.8 已知陷阱

**Kanban Worker被分配任务后因iteration budget限制未完成**
- 问题: `hermes kanban` dispatcher启动的worker session有5次迭代限制
- 影响: 复杂任务不会completion，会stuck在in_progress
- 解决: 
  - 短期: Sprint Orchestrator（完整Agent session）接管复杂任务
  - 长期: 增加 `max_iterations` 配置（如需要改源码或升级）

**GitHub API速率限制**
- 问题: backlog/ssue创建查GitHub时遇API限流
- 解决: 配置GitHub Token或使用本地backlog JSON文件

**WAL文件增长**
- 问题: state.db的WAL文件可达500MB+，影响备份速度
- 解决: 每周cron执行 `PRAGMA wal_checkpoint(TRUNCATE)`

**profile-scoped技能查找**
- 问题: `hermes kanban` dispatcher使用profile-scoped HERMES_HOME，
        全局skills目录的技能不被worker子进程发现
- 解决: 在每个profile的skills/下复制kanban-worker SKILL.md
        （详见7.2节陷阱说明）

## Feedback Engine Patches
*自动生成于 2026-07-16 02:02:04*

## Tool Recommendations (from trajectory feedback)

### patch
Trajectory analysis shows **patch** strongly correlates with high session scores.
- Use `patch` for targeted find-and-replace edits instead of sed/awk.
- Supports fuzzy matching with 9 strategies for robust edits.
- Auto-runs syntax checks after modification.
- Preferred for surgical code changes over full file rewrites.

### Guardrails
- Ensure `old_string` is unique in the file unless `replace_all=True`.
- Include enough surrounding context to guarantee uniqueness.
- Use `mode='patch'` for V4A multi-file patches.

### Efficiency Tips
- Combine multiple edits into a single V4A patch when possible.
- Use `replace_all=True` for bulk replacements of the same pattern.
- Preview changes with `--dry-run` mode before applying.

---
## Feedback Engine Patches
*自动生成于 2026-07-17 02:02:37*

## Tool Recommendations (from trajectory feedback)

### patch
Trajectory analysis shows **patch** strongly correlates with high session scores.
- Use `patch` for targeted find-and-replace edits instead of sed/awk.
- Supports fuzzy matching with 9 strategies for robust edits.
- Auto-runs syntax checks after modification.
- Preferred for surgical code changes over full file rewrites.

### Guardrails
- Ensure `old_string` is unique in the file unless `replace_all=True`.
- Include enough surrounding context to guarantee uniqueness.
- Use `mode='patch'` for V4A multi-file patches.

### Efficiency Tips
- Combine multiple edits into a single V4A patch when possible.
- Use `replace_all=True` for bulk replacements of the same pattern.
- Preview changes with `--dry-run` mode before applying.

---
## Feedback Engine Patches
*自动生成于 2026-07-22 12:19:48*

## Tool Recommendations (from trajectory feedback)

### patch
Trajectory analysis shows **patch** strongly correlates with high session scores.
- Use `patch` for targeted find-and-replace edits instead of sed/awk.
- Supports fuzzy matching with 9 strategies for robust edits.
- Auto-runs syntax checks after modification.
- Preferred for surgical code changes over full file rewrites.

### Guardrails
- Ensure `old_string` is unique in the file unless `replace_all=True`.
- Include enough surrounding context to guarantee uniqueness.
- Use `mode='patch'` for V4A multi-file patches.

### Efficiency Tips
- Combine multiple edits into a single V4A patch when possible.
- Use `replace_all=True` for bulk replacements of the same pattern.
- Preview changes with `--dry-run` mode before applying.
