---
name: prompt-toolchain-deploy
description: 三插件Prompt工具链部署+增强 — PromptHub REST API + Dashboard集成 + PromptSync同步。全CMMI5合规。
category: devops
triggers:
  - "prompt工具链"
  - "PromptHub"
  - "PromptSync"
  - "prompt优化"
  - "提示词仓库"
  - "Prompt toolchain REST API"
  - "prompt管理页面"
  - "添加REST API到Flask"
  - "Dashboard集成新服务"
  - "prompt chain dashboard卡片"
  - "prompt工具链面板"
---

# Prompt Toolchain Deploy & Enhance

## Overview

Three-component prompt management toolchain with REST API and Dashboard monitoring:

| Layer | Component | Port | Tech |
|-------|-----------|------|------|
| **Storage** | PromptHub | `:3871` | Flask + SQLite + Bootstrap |
| **Optimization** | Prompt Optimizer | `:8082` | Flask + DeepSeek API |
| **Sync** | PromptSync | cron | Python CLI + REST API |
| **Monitoring** | Hermes Dashboard | `:5000` | Flask + HTMX + Bootstrap |
| **Launcher** | start-prompt-toolchain.sh | — | Bash |

## Quick Start

```bash
# Full restart
bash ~/projects/start-prompt-toolchain.sh restart

# Or combined with all services
bash ~/scripts/start-all.sh start

# Run sync
python3 ~/prompts/promptsync.py

# Access points
# PromptHub:     http://localhost:3871
# Prompt API:    http://localhost:3871/api/prompts
# Optimizer:     http://localhost:8082
# Dashboard:     http://localhost:5000/prompts
```

## REST API (PromptHub v2.0)

Added 9 REST endpoints to PromptHub for programmable access. All return JSON.

| Endpoint | Method | Description | Query Params |
|----------|--------|-------------|-------------|
| `/api/stats` | GET | Statistics overview | — |
| `/api/prompts` | GET | List prompts | `?category=X&q=Y&favorite=1` |
| `/api/prompts` | POST | Create prompt | Body: `{title, content, category, tags}` |
| `/api/prompts/{id}` | GET | Single prompt + versions | — |
| `/api/prompts/{id}` | PUT | Update prompt | Body: `{title?, content?, category?, tags?}` |
| `/api/prompts/{id}` | DELETE | Delete prompt | — |
| `/api/prompts/{id}/favorite` | POST | Toggle favorite | — |
| `/api/categories` | GET | Category list + counts | — |

### How to add REST API to PromptHub

1. Add `from flask import jsonify` import
2. Create `json_error()` helper returning `(jsonify({...}), code)`
3. Define endpoints before existing HTML routes (order matters for method dispatch)
4. Use same DB helpers (`get_db()`, `serialize_prompt()`, `save_version()`)
5. Support filters via `request.args.get()` with dynamic SQL
6. POST/PUT use `request.get_json(silent=True)` with validation

### Add REST API to similar Flask services

```python
# Pattern for adding JSON API to Flask HTML services
from flask import jsonify

def json_error(msg, code=400):
    return jsonify({"error": msg}), code

@app.route('/api/items')
def api_list():
    # GET /api/items?param=value
    items = []  # query from DB
    return jsonify(items)

@app.route('/api/items', methods=['POST'])
def api_create():
    data = request.get_json(silent=True)
    if not data:
        return json_error("Request body required")
    # validate + insert
    return jsonify({"id": new_id, "message": "Created"}), 201
```

## Dashboard Integration

Prompt toolchain is monitored via the Hermes Dashboard (`~/projects/hermes-dashboard/`).

### Backend Module (`backend/prompt_chain.py`)
- Collects stats from PromptHub REST API (`/api/stats`, `/api/prompts`)
- Checks Optimizer health via HTTP GET
- Reads sync state from `~/prompts/promptsync_state.json`
- Returns unified dict: `{prompthub, optimizer, sync, services_up, services_total}`

### API Endpoint (`frontend/routes.py`)
```python
from backend import prompt_chain

@bp.route("/api/promptchain")
def api_promptchain():
    return jsonify(prompt_chain.get_prompt_chain())

# Also inject into /api/all for unified HTMX polling
```

### Frontend Card (`frontend/templates/index.html`)
- HTMX card showing: Hub/Opt status (UP/DOWN), prompt count, sync %, versions
- Click to `/prompts` management page
- Overall status includes promptchain degradation

### Prompt Management Page (`frontend/templates/prompts.html`)
- Search with 300ms debounce
- Category filter dropdown (auto-loaded from API)
- Table with title/category/tags/date/favorite star
- Detail modal with version history
- Favorite toggle via REST API
- Auto-refresh every 30s

### Pattern: Add new subsystem to Dashboard
1. Create `backend/<name>.py` — module with `get_<name>()` returning dict
2. Add route in `frontend/routes.py` — `/api/<name>` + inject into `/api/all`
3. Add card in `frontend/templates/index.html` — subsystem-card with HTMX placeholders
4. Add JS in `<script>` block — DOM references + update logic in `updateDashboard()`

## Component Architecture

### PromptHub Server
Single Flask file: `~/projects/prompthub-server/app.py` (936+ lines)
- SQLite DB: `~/projects/prompthub-server/prompts.db` (WAL mode)
- REST API inserted before HTML routes (order matters)

### PromptSync (v2.0 — REST API)
v1 used direct SQLite. v2 uses REST API:
```python
url = "http://localhost:3871/api/prompts"
req = urllib.request.Request(url)
with urllib.request.urlopen(req) as r:
    prompts = json.loads(r.read().decode())
```
- Version count via `GET /api/prompts/{id}` (detail includes versions array)
- State file: `~/prompts/promptsync_state.json`

## Pitfalls

1. **Jinja2 3.1.x InlineLoader crash** — `return source, None, True` must be `lambda: True`. Pin `jinja2==3.1.5`.
2. **Jinja2 version conflict** — litellm needs `>=3.1.6`, PromptHub needs `==3.1.5`. Startup script: `pip install jinja2==3.1.5 -q 2>/dev/null || true`
3. **REST route order** — REST endpoints MUST be defined BEFORE HTML routes in the same Flask file.
4. **Dashboard port conflict** — Kill old PID before starting new one. `ss -tlnp | grep 5000` to identify.
5. **HTTP timeouts** — Use `timeout=5` on `urllib.request.urlopen` for Dashboard polling.
6. **Docker unavailable in WSL** → Use Flask native.
7. **BookStack auth** — `Authorization: Token {id}:{secret}` directly.
8. **f-string nested quotes** — Extract CONFIG[key] to variable first.
9. **Terminal masks API keys** — Read raw file with Python open().

## CMMI5 Compliance

| PA | Artifact |
|----|----------|
| PPQA | ~/prompts/promptsync.log |
| CM | ~/prompts/promptsync_state.json |
| MA | ~/prompts/templates/*.md |
| VER | ~/prompts/verification-report-*.txt |
| TS | ~/projects/hermes-dashboard/backend/prompt_chain.py |

## Verification

```bash
# REST API tests
curl http://localhost:3871/api/stats
curl http://localhost:3871/api/prompts | python3 -c "import sys,json; d=json.load(sys.stdin); print(len(d))"
curl http://localhost:3871/api/categories

# Dashboard integration
curl http://localhost:5000/api/promptchain
curl http://localhost:5000/prompts | grep "Prompt Manager"

# Full health
for p in 3871 8082 5000; do curl -s -o /dev/null -w "Port $p: HTTP %{http_code}\n" http://localhost:$p/; done
```

## Feedback Engine Patches
*自动生成于 2026-07-16 02:02:04*

## Tool Recommendations (from trajectory feedback)

### patch
Trajectory analysis shows **patch** strongly correlates with high session scores.
- Use `patch` for targeted find-and-replace edits instead of sed/awk.
- Supports fuzzy matching with 9 strategies for robust edits.
- Auto-runs syntax checks after modification.
- Preferred for surgical code changes over full file rewrites.

### Guardrails
- Ensure `old_string` is unique in the file unless `replace_all=True`.
- Include enough surrounding context to guarantee uniqueness.
- Use `mode='patch'` for V4A multi-file patches.

### Efficiency Tips
- Combine multiple edits into a single V4A patch when possible.
- Use `replace_all=True` for bulk replacements of the same pattern.
- Preview changes with `--dry-run` mode before applying.

---
## Feedback Engine Patches
*自动生成于 2026-07-17 02:02:37*

## Tool Recommendations (from trajectory feedback)

### patch
Trajectory analysis shows **patch** strongly correlates with high session scores.
- Use `patch` for targeted find-and-replace edits instead of sed/awk.
- Supports fuzzy matching with 9 strategies for robust edits.
- Auto-runs syntax checks after modification.
- Preferred for surgical code changes over full file rewrites.

### Guardrails
- Ensure `old_string` is unique in the file unless `replace_all=True`.
- Include enough surrounding context to guarantee uniqueness.
- Use `mode='patch'` for V4A multi-file patches.

### Efficiency Tips
- Combine multiple edits into a single V4A patch when possible.
- Use `replace_all=True` for bulk replacements of the same pattern.
- Preview changes with `--dry-run` mode before applying.

---
## Feedback Engine Patches
*自动生成于 2026-07-22 12:19:48*

## Tool Recommendations (from trajectory feedback)

### patch
Trajectory analysis shows **patch** strongly correlates with high session scores.
- Use `patch` for targeted find-and-replace edits instead of sed/awk.
- Supports fuzzy matching with 9 strategies for robust edits.
- Auto-runs syntax checks after modification.
- Preferred for surgical code changes over full file rewrites.

### Guardrails
- Ensure `old_string` is unique in the file unless `replace_all=True`.
- Include enough surrounding context to guarantee uniqueness.
- Use `mode='patch'` for V4A multi-file patches.

### Efficiency Tips
- Combine multiple edits into a single V4A patch when possible.
- Use `replace_all=True` for bulk replacements of the same pattern.
- Preview changes with `--dry-run` mode before applying.
