# BookStack API Integration Notes

> Reference for `obsidian-bridge` BookStack sync channel. Captures API quirks discovered during v2.0 development.

## Authentication

BookStack uses a `token_id:secret` pair format. The API expects:
```
Authorization: Token {token_id}:{plaintext_secret}
```

Token is stored in the `api_tokens` DB table with bcrypt-hashed secret — plaintext is only shown at creation time. If unknown, extract from existing scripts:
- `~/.hermes/scripts/sync_skills_to_bookstack.py` — `TOKEN=` pattern
- `~/.hermes/scripts/skill_bookstack_sync_batch.py` — `AUTH_HEADER=` pattern

## API Endpoints Tested

| Endpoint | Purpose | Returns |
|----------|---------|---------|
| `GET /api/shelves?count=N` | List shelves | `{data: [{id, name, ...}], total: N}` |
| `GET /api/shelves/{id}?count=N` | Shelf detail with books | `{id, name, books: [{id, name, ...}]}` |
| `GET /api/books/{id}?count=N` | Book detail with pages | `{id, name, contents: [{id, name, type, ...}]}` |
| `GET /api/pages/{id}` | Page detail with HTML body | `{id, name, html: "...", ...}` |

## Critical Quirks

### `contents` NOT `pages`
BookStack `/api/books/{id}` returns `contents` key, NOT `pages`. Each content item has:
```json
{"id": 19, "name": "Team Rules", "slug": "...", "type": "page", ...}
```
Using `book_detail.get("pages", [])` silently returns empty list with no error.
The `type` field distinguishes pages from chapters.

### Shelf to Books Relationship
`GET /api/shelves/{id}` includes a `books` array. Each book has `id` and `name`. Use this to enumerate books without a separate API call.

### Book to Contents Relationship
`GET /api/books/{id}?count=N` returns contents. The `count` parameter controls how many content items are returned (default 100). Contents include both pages and chapters.

### Pagination
All list endpoints support `offset` and `count` query parameters. BookStack defaults to 100 items per page for most endpoints.

## HTML to Markdown Conversion

Page detail returns HTML body. The sync script uses a simple tag-stripping approach:
```python
text = re.sub(r'<[^>]+>', '', html)
text = re.sub(r'\n{3,}', '\n\n', text)
```
This is lossy (loses tables, lists, code blocks). Upgrade to an HTML-to-MD converter (html2text or similar) if fidelity matters.
