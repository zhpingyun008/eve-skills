---
name: obsidian-bridge
description: "v2.0 bidirectional sync: Hermes knowledge/memory/projects/company/BookStack/reports to Obsidian Vault. Zero-token cron every 15min."
category: devops
triggers:
  - "Obsidian / obsidian / 黑曜石"
  - "打通Obsidian / Obsidian集成 / Obsidian同步"
  - "知识库双向同步 / bidirectional sync / vault sync"
  - "笔记同步 / note sync / Obsidian vault"
  - "Hermes to Obsidian / WSL Obsidian / Windows Obsidian"
  - "知识/记忆/输出成果自动记录"
  - "全量同步 / full sync / 自动归档"
  - "记忆引擎同步 / memory sync / memories to obsidian"
related_skills:
  - kb-auto-engine
  - bookstack-update-sync
  - bookstack-kb-architecture
  - memory-engine
  - project-asset-archiver
---

# Obsidian Bridge v2.0 — 知识/记忆/输出成果 全量自动同步

## Overview

将 Hermes 全部知识资产自动同步到 Windows Obsidian Vault。六路 Push + 一路 Pull，覆盖知识/记忆/项目文档/公司资产/BookStack/报告。

## Architecture

```
Hermes / WSL                              Windows Obsidian
────────────────────                      ────────────────
 ~/projects/llm-wiki/wiki/     ──Push──►  vault/wiki/         (12篇)
 ~/.hermes/memory/memory.db    ──Push──►  vault/memories/     (66条全量)
 ~/projects/*/                 ──Push──►  vault/projects/     (93篇文档)
 ~/company/                    ──Push──►  vault/company/      (63篇资产)
 BookStack API                 ──Push──►  vault/bookstack/    (145页)
 ~/company/reports/            ──Push──►  vault/reports/      (50篇)

 vault/user/**/*.md  (用户笔记)  ◀─Pull──  Memory Engine       (17条注入)
```

## Push Channels

| # | 源 | 目标 | 文件数 | 说明 |
|---|-----|------|--------|------|
| 1 | `~/projects/llm-wiki/wiki/` | `vault/wiki/` | 12 | 编译后知识库 |
| 2 | `~/.hermes/memory/memory.db` | `vault/memories/{type}/` | 66 | 全量记忆(按type分目录) |
| 3 | `~/projects/*/` (.md文档) | `vault/projects/{proj}/` | 93 | SRS/设计/部署/手册 |
| 4 | `~/company/` (.md资产) | `vault/company/` | 63 | SOP/组织架构/工作流/报价 |
| 5 | BookStack API (13书架) | `vault/bookstack/{shelf}/` | 145 | 关键页面快照 |
| 6 | `~/company/reports/` | `vault/reports/` | 50 | 最近50篇运营报告 |

## Pull Channel

- 监测 `vault/**/*.md` (排除自动同步目录)
- 新增/修改 → 自动注入 Memory Engine (type=convention)
- 删除 → 自动清理跟踪状态

## Vault Directory Structure (439篇)

```
/mnt/c/Users/Administrator/Documents/Obsidian Vault/
├── wiki/                  # 知识库 (12)
├── memories/              # 记忆引擎全量 (66)
│   ├── convention/        #   约定 (46)
│   ├── evolution/         #   进化 (7)
│   ├── lesson/            #   经验教训 (7)
│   ├── decision/          #   决策 (3)
│   ├── preference/        #   偏好 (2)
│   ├── environment/       #   环境 (1)
│   └── README.md          #   索引页
├── projects/              # 项目文档 (93)
├── company/               # 公司资产 (63)
│   ├── workflows/         #   工作流
│   ├── processes/         #   流程
│   └── templates/         #   模板
├── bookstack/             # BookStack快照 (145)
├── reports/               # 运营报告 (50)
├── decisions/             # 决策记录 (3)
├── Hermes-Codex 首页.md    # 入口页 (自动维护)
└── .obsidian/             # 插件配置
```

## CLI

```bash
python3 scripts/obsidian_sync.py sync    # 双向同步 (默认)
python3 scripts/obsidian_sync.py push    # 仅推送 WSL→Obsidian
python3 scripts/obsidian_sync.py pull    # 仅拉取 Obsidian→Hermes
python3 scripts/obsidian_sync.py init    # 初始化 vault 结构
python3 scripts/obsidian_sync.py status  # 查看同步状态
```

## Cron

| 任务 | 频率 | 模式 | Token消耗 |
|------|------|------|-----------|
| 双向同步 | every 15min | no_agent | 0 (纯脚本) |
| 路径: `~/.hermes/scripts/obsidian-bridge/sync.sh` | | | |

## Pitfalls

- **BookStack API contents key**: `/api/books/{id}` returns `contents` (not `pages`). See `references/bookstack-api.md` for full API quirks including pagination, authentication, and HTML conversion.
- **Memory type constraint**: Memory Engine CHECK constraint only allows `preference|convention|fact|lesson|evolution|decision|environment|command`. Obsidian notes use `convention`.
- **BookStack token extraction**: Auto-extracted from existing scripts via regex. Two patterns tried: `TOKEN=*** ` from `sync_skills_to_bookstack.py`, then `AUTH_HEADER=*** value` from `skill_bookstack_sync_batch.py`.
- **Cron script path**: Resolves relative to `~/.hermes/scripts/`. `obsidian-bridge/sync.sh` resolves correctly. Do NOT prefix with `scripts/`.
- **WSL file permissions**: Use `write_text()` directly on `/mnt/c/`. Never chmod Windows files.
- **Reports cap**: Last 50 by mtime. Other channels have no limit.
- **Memory dedup**: Uses `summary` UNIQUE constraint. Idempotent updates.
- **Status exit code**: `cmd_status` returns None. Exit handler must check `if result is None: sys.exit(0)` to avoid TypeError.
