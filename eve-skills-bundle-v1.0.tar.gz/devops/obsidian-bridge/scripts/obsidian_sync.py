#!/usr/bin/env python3
"""
obsidian_sync.py — Hermes ↔ Obsidian 双向同步引擎 v2.0
===========================================================
Commands: sync | push | pull | init | status

全面打通: 知识/记忆/输出成果 自动同步到 Obsidian Vault

Direction A (Push):  WSL知识 → Obsidian Vault
  - wiki知识库                          → vault/wiki/
  - 公司报告(最近50篇)                   → vault/reports/
  - 记忆引擎全量(63条,按type分类)        → vault/memories/
  - 项目文档(SRS/设计/部署/手册等)       → vault/projects/
  - 公司资产(SOP/组织架构/报价单等)      → vault/company/
  - 工作流/流程文档                     → vault/workflows/
  - BookStack关键页面                   → vault/bookstack/

Direction B (Pull):  Obsidian笔记变更 → Hermes 记忆引擎
  - vault 用户笔记自动注入 Memory Engine
"""

import os, sys, shutil, json, hashlib, re, time
from pathlib import Path
from datetime import datetime, timezone
from collections import defaultdict

# ============================================================
# CONFIG
# ============================================================
VAULT = Path("/mnt/c/Users/Administrator/Documents/Obsidian Vault")
LLM_WIKI = Path.home() / "projects" / "llm-wiki" / "wiki"
REPORTS = Path.home() / "company" / "reports"
COMPANY = Path.home() / "company"
PROJECTS = Path.home() / "projects"
MEMORY_DB = Path.home() / ".hermes" / "memory" / "memory.db"
STATE_FILE = Path.home() / ".hermes" / "skills" / "devops" / "obsidian-bridge" / "sync-state.json"
HERMES_SKILLS = Path.home() / ".hermes" / "skills"

# Memory type → display label mapping
MEMORY_TYPE_LABEL = {
    "preference": "偏好",
    "convention": "约定",
    "fact": "事实",
    "lesson": "经验教训",
    "evolution": "进化",
    "decision": "决策",
    "environment": "环境",
    "command": "命令",
}

MEMORY_TYPES_ALLOWED = ("preference","convention","fact","lesson","evolution","decision","environment","command")

# Sync state
SYNC_STATE = {
    "last_sync": None,
    "stats": {"pushed": 0, "pulled": 0, "skipped": 0, "errors": 0},
    "file_hashes": {}
}


def log(msg):
    ts = datetime.now().strftime("%H:%M:%S")
    print(f"[{ts}] {msg}")


def file_md5(path):
    try:
        with open(path, "rb") as f:
            return hashlib.md5(f.read()).hexdigest()[:16]
    except Exception:
        return None


def str_md5(content):
    return hashlib.md5(content.encode()).hexdigest()[:16]


def ensure_dir(path):
    path.mkdir(parents=True, exist_ok=True)


def load_state():
    global SYNC_STATE
    if STATE_FILE.exists():
        try:
            SYNC_STATE = json.loads(STATE_FILE.read_text())
        except Exception:
            SYNC_STATE = {"last_sync": None, "stats": {"pushed": 0, "pulled": 0, "skipped": 0, "errors": 0}, "file_hashes": {}}


def save_state():
    SYNC_STATE["last_sync"] = datetime.now().isoformat()
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    STATE_FILE.write_text(json.dumps(SYNC_STATE, indent=2, ensure_ascii=False))


def write_md(target_path, content, track_key):
    """Write markdown file with change detection."""
    h = str_md5(content)
    tracked = SYNC_STATE["file_hashes"].get(track_key)
    if tracked == h:
        return 0  # unchanged
    ensure_dir(target_path.parent)
    target_path.write_text(content, encoding="utf-8")
    SYNC_STATE["file_hashes"][track_key] = h
    return 1


def add_frontmatter_if_missing(content, title, source, tags=""):
    """Ensure markdown file has YAML frontmatter."""
    if content.startswith("---"):
        return content
    return f"---\ntitle: \"{title}\"\nsource: \"{source}\"\ntags: \"{tags}\"\nsynced: \"{datetime.now().isoformat()}\"\n---\n\n{content}"


# ============================================================
# PUSH: Wiki Knowledge
# ============================================================
def push_wiki():
    src = LLM_WIKI
    dst = VAULT / "wiki"
    ensure_dir(dst)
    count = 0

    if not src.exists():
        log("  ⚠ wiki source not found")
        return 0

    for md_file in sorted(src.rglob("*.md")):
        rel = md_file.relative_to(src)
        target = dst / rel
        content = md_file.read_text(encoding="utf-8", errors="replace")
        content = add_frontmatter_if_missing(content, md_file.stem, "llm-wiki", "知识库")
        count += write_md(target, content, f"wiki/{rel}")

    return count


# ============================================================
# PUSH: Reports (last 50)
# ============================================================
def push_reports():
    src = REPORTS
    dst = VAULT / "reports"
    ensure_dir(dst)
    count = 0

    if not src.exists():
        return 0

    files = sorted(src.glob("*.md"), key=lambda f: f.stat().st_mtime, reverse=True)[:50]
    for f in files:
        content = f.read_text(encoding="utf-8", errors="replace")
        content = add_frontmatter_if_missing(content, f.stem, "reports", "报告")
        count += write_md(dst / f.name, content, f"reports/{f.name}")

    return count


# ============================================================
# PUSH: Memory Engine — 全量记忆 (全部63条,按type分类)
# ============================================================
def push_memories():
    """Sync ALL memory engine entries to vault/memories/{type}/ organized by type."""
    dst_root = VAULT / "memories"
    ensure_dir(dst_root)
    count = 0

    if not MEMORY_DB.exists():
        log("  ⚠ memory.db not found")
        return 0

    try:
        import sqlite3
        db = sqlite3.connect(str(MEMORY_DB))
        # Get all memories, grouped by type
        cur = db.execute(
            "SELECT type, summary, detail, tags, importance, created_at, last_access "
            "FROM memories ORDER BY type, last_access DESC"
        )
        rows = cur.fetchall()
        db.close()

        type_counts = defaultdict(int)
        for typ, summary, detail, tags, importance, created, last_access in rows:
            if typ not in MEMORY_TYPES_ALLOWED:
                typ = "convention"  # fallback

            label = MEMORY_TYPE_LABEL.get(typ, typ)
            type_dir = dst_root / typ
            ensure_dir(type_dir)

            # Create safe filename from summary
            safe_name = re.sub(r'[\\/:*?"<>|]', '_', summary[:60]) or f"{typ}-{type_counts[typ]}"
            target = type_dir / f"{safe_name}.md"

            importance_badge = {"critical": "🔴", "high": "🟠", "medium": "🟡", "low": "⚪"}.get(importance, "⚪")

            content = f"""---
title: "{summary}"
type: "{typ}"
importance: "{importance}"
tags: "{tags}"
source: "memory-engine"
created: "{created or 'unknown'}"
last_access: "{last_access or 'unknown'}"
---

# {importance_badge} {summary}

{detail or ''}

---
*来源: Hermes 记忆引擎 · 类型: {label} · 重要性: {importance}*
"""

            track_key = f"memories/{typ}/{safe_name}"
            count += write_md(target, content, track_key)
            type_counts[typ] += 1

        # Generate memories index page
        index_lines = [
            "---",
            f"title: \"记忆引擎索引\"",
            f"updated: \"{datetime.now().isoformat()}\"",
            "---",
            "",
            "# 🧠 记忆引擎 — 全量索引",
            "",
            f"> Hermes Memory Engine 全部 {len(rows)} 条记忆 · 按类型分类",
            "",
        ]
        for typ in sorted(type_counts.keys()):
            label = MEMORY_TYPE_LABEL.get(typ, typ)
            index_lines.append(f"- [[memories/{typ}/|📂 {label}]] — {type_counts[typ]} 条")
        index_lines += [
            "",
            "---",
            "*由 Obsidian Bridge v2.0 自动同步*",
        ]
        write_md(dst_root / "README.md", "\n".join(index_lines), "memories/README")

        log(f"  memories: {count} changed / {len(rows)} total ({', '.join(f'{k}={v}' for k,v in sorted(type_counts.items()))})")
        return count

    except Exception as e:
        log(f"  ⚠ memories sync error: {e}")
        return 0


# ============================================================
# PUSH: Project Documentation
# ============================================================
def push_projects():
    """Sync project documentation files (*.md) from ~/projects/"""
    dst = VAULT / "projects"
    ensure_dir(dst)
    count = 0

    if not PROJECTS.exists():
        return 0

    # Collect key project .md files (exclude node_modules, .git, BookStack code)
    for proj_dir in sorted(PROJECTS.iterdir()):
        if not proj_dir.is_dir():
            continue
        # Skip non-doc directories
        name = proj_dir.name
        if name in ("BookStack", "node_modules", ".git", "__pycache__", "hermes-wiki"):
            continue
        if name.startswith("."):
            continue

        # Look for key doc files
        doc_files = list(proj_dir.glob("*.md"))
        doc_files += list(proj_dir.glob("docs/*.md"))
        doc_files += list(proj_dir.glob("documentation/*.md"))
        doc_files += list(proj_dir.glob("doc/*.md"))

        if not doc_files:
            continue

        proj_dst = dst / name
        ensure_dir(proj_dst)

        for f in doc_files:
            rel = f.relative_to(proj_dir)
            content = f.read_text(encoding="utf-8", errors="replace")
            if len(content) < 50:  # skip stub files
                continue
            content = add_frontmatter_if_missing(content, f.stem, f"project:{name}", f"项目,{name}")
            count += write_md(proj_dst / rel.name, content, f"projects/{name}/{rel.name}")

    return count


# ============================================================
# PUSH: Company Assets
# ============================================================
def push_company_assets():
    """Sync company root .md files (SOP, org charts, quotes, etc.)"""
    dst = VAULT / "company"
    ensure_dir(dst)
    count = 0

    if not COMPANY.exists():
        return 0

    # Root-level .md files
    for f in sorted(COMPANY.glob("*.md")):
        content = f.read_text(encoding="utf-8", errors="replace")
        content = add_frontmatter_if_missing(content, f.stem, "company", "公司资产")
        count += write_md(dst / f.name, content, f"company/{f.name}")

    # workflows/
    wf_src = COMPANY / "workflows"
    if wf_src.exists():
        wf_dst = dst / "workflows"
        ensure_dir(wf_dst)
        for f in sorted(wf_src.glob("*.md")):
            content = f.read_text(encoding="utf-8", errors="replace")
            content = add_frontmatter_if_missing(content, f.stem, "workflows", "工作流")
            count += write_md(wf_dst / f.name, content, f"company/workflows/{f.name}")

    # processes/
    proc_src = COMPANY / "processes"
    if proc_src.exists():
        proc_dst = dst / "processes"
        ensure_dir(proc_dst)
        for f in sorted(proc_src.glob("*.md")):
            content = f.read_text(encoding="utf-8", errors="replace")
            content = add_frontmatter_if_missing(content, f.stem, "processes", "流程")
            count += write_md(proc_dst / f.name, content, f"company/processes/{f.name}")

    # templates/
    tpl_src = COMPANY / "templates"
    if tpl_src.exists():
        tpl_dst = dst / "templates"
        ensure_dir(tpl_dst)
        for f in sorted(tpl_src.glob("*.md")):
            content = f.read_text(encoding="utf-8", errors="replace")
            content = add_frontmatter_if_missing(content, f.stem, "templates", "模板")
            count += write_md(tpl_dst / f.name, content, f"company/templates/{f.name}")

    return count


# ============================================================
# PUSH: BookStack Key Pages
# ============================================================
def push_bookstack():
    """Fetch key BookStack pages via API and sync to vault."""
    dst = VAULT / "bookstack"
    ensure_dir(dst)
    count = 0

    bs_host = "http://127.0.0.1:8080"
    api_token = None

    # Read token from existing BookStack sync script
    for src in [
        Path.home() / ".hermes" / "scripts" / "sync_skills_to_bookstack.py",
        Path.home() / ".hermes" / "scripts" / "skill_bookstack_sync_batch.py",
    ]:
        if src.exists():
            src_text = src.read_text()
            # Pattern 1: TOKEN = "value"
            m = re.search(r'TOKEN\s*=\s*["\']([^"\']+)["\']', src_text)
            if m:
                api_token = m.group(1).strip()
                break
            # Pattern 2: AUTH_HEADER = "Token value" or f"Token {value}"
            m = re.search(r'AUTH_HEADER\s*=\s*(?:f?)?["\'](?:Token\s+)?([^"\'{]+)["\']', src_text)
            if m:
                api_token = m.group(1).strip()
                break
        if api_token:
            break

    if not api_token:
        log("  ⚠ BookStack API token not found, skipping")
        return 0

    try:
        import urllib.request, urllib.error

        headers = {
            "Authorization": f"Token {api_token}",
            "Content-Type": "application/json",
        }

        # Fetch shelves (books)
        req = urllib.request.Request(f"{bs_host}/api/shelves?count=50", headers=headers)
        try:
            resp = urllib.request.urlopen(req, timeout=10)
            shelves = json.loads(resp.read().decode())
        except Exception:
            log("  ⚠ BookStack API unavailable")
            return 0

        for shelf in shelves.get("data", [])[:10]:  # max 10 shelves
            shelf_name = shelf["name"]
            shelf_dst = dst / re.sub(r'[\\/:*?"<>|]', '_', shelf_name[:30])
            ensure_dir(shelf_dst)

            # Get books in this shelf
            shelf_id = shelf["id"]
            req2 = urllib.request.Request(f"{bs_host}/api/shelves/{shelf_id}?count=50", headers=headers)
            try:
                resp2 = urllib.request.urlopen(req2, timeout=10)
                shelf_detail = json.loads(resp2.read().decode())
            except Exception:
                continue

            for book in shelf_detail.get("books", [])[:5]:  # max 5 books per shelf
                book_id = book["id"]
                book_name = book["name"]

                # Get pages in this book
                req3 = urllib.request.Request(f"{bs_host}/api/books/{book_id}?count=20", headers=headers)
                try:
                    resp3 = urllib.request.urlopen(req3, timeout=10)
                    book_detail = json.loads(resp3.read().decode())
                except Exception:
                    continue

                for page in book_detail.get("contents", [])[:10]:  # max 10 pages per book
                    page_id = page["id"]
                    req4 = urllib.request.Request(f"{bs_host}/api/pages/{page_id}", headers=headers)
                    try:
                        resp4 = urllib.request.urlopen(req4, timeout=10)
                        page_detail = json.loads(resp4.read().decode())
                    except Exception:
                        continue

                    # Extract HTML body, convert to basic markdown
                    html = page_detail.get("html", "")
                    # Strip HTML tags for plain text
                    text = re.sub(r'<[^>]+>', '', html)
                    text = re.sub(r'\n{3,}', '\n\n', text)

                    page_title = page_detail.get("name", f"page-{page_id}")
                    safe_page = re.sub(r'[\\/:*?"<>|]', '_', page_title[:50])

                    content = f"""---
title: "{page_title}"
source: "bookstack"
book: "{book_name}"
shelf: "{shelf_name}"
bs_page_id: {page_id}
synced: "{datetime.now().isoformat()}"
---

# {page_title}

> 来源: BookStack · {shelf_name} → {book_name}

{text}

---
*由 Obsidian Bridge v2.0 从 BookStack 自动同步*
"""
                    count += write_md(shelf_dst / f"{safe_page}.md", content, f"bookstack/{shelf_name}/{safe_page}")
        log(f"  bookstack: {count} pages synced")
    except Exception as e:
        log(f"  ⚠ bookstack sync error: {e}")

    return count


# ============================================================
# PUSH: Output Index Page (vault homepage)
# ============================================================
def push_index_page():
    """Update vault index page with comprehensive stats."""
    vault_files = list(VAULT.rglob("*.md"))
    total = len(vault_files)

    # Count by top-level directory
    by_dir = defaultdict(int)
    for f in vault_files:
        rel = f.relative_to(VAULT)
        top = str(rel.parent).split("/")[0] if rel.parent != Path(".") else "root"
        by_dir[top] += 1

    # Count by source
    by_source = defaultdict(int)
    for f in vault_files:
        try:
            content = f.read_text(encoding="utf-8", errors="replace")
            m = re.search(r'^source:\s*"([^"]+)"', content, re.MULTILINE)
            if m:
                by_source[m.group(1)] += 1
        except Exception:
            pass

    # Recent files
    recent = sorted(vault_files, key=lambda f: f.stat().st_mtime, reverse=True)[:15]

    lines = [
        "---",
        "title: \"Hermes-Codex 首页\"",
        f"updated: \"{datetime.now().isoformat()}\"",
        "---",
        "",
        "# 🏠 Hermes-Codex 知识库",
        "",
        f"> 自动同步 · {datetime.now().strftime('%Y-%m-%d %H:%M')}",
        "",
        "## 📊 总览",
        "",
        f"- 总笔记数: **{total}**",
    ]
    for d, c in sorted(by_dir.items(), key=lambda x: -x[1]):
        if d == "root":
            lines.append(f"- 📄 根目录: {c} 篇")
        else:
            icon = {"wiki": "📚", "reports": "📋", "memories": "🧠", "projects": "📁", "company": "🏢", "bookstack": "📖", "decisions": "⚡", "templates": "📝"}.get(d, "📄")
            lines.append(f"- {icon} `{d}/`: {c} 篇")
    lines += [
        "",
        "## 📂 目录导航",
        "",
        "### 知识",
        "- [[wiki/README|📚 知识库 (wiki)]] — Agent 编译的结构化知识",
        "- [[bookstack/|📖 BookStack 同步]] — BookStack 关键页面快照",
        "",
        "### 记忆",
        "- [[memories/README|🧠 记忆引擎 (memories)]] — Hermes 全部记忆（按类型分类）",
        "- [[decisions/|⚡ 决策记录 (decisions)]] — Agent 关键决策",
        "",
        "### 输出成果",
        "- [[reports/|📋 报告 (reports)]] — 每日运营/分析报告",
        "- [[projects/|📁 项目文档 (projects)]] — SRS/设计/部署文档",
        "- [[company/|🏢 公司资产 (company)]] — SOP/组织架构/工作流/模板",
        "",
        "### 用户笔记",
        "- 在 Obsidian 中创建/编辑的笔记会自动被 Hermes 读取",
        "",
    ]

    if recent:
        lines += ["## 🕐 最近更新", ""]
        for f in recent:
            rel = f.relative_to(VAULT)
            mod = datetime.fromtimestamp(f.stat().st_mtime).strftime("%m-%d %H:%M")
            lines.append(f"- `{mod}` [[{rel}]]")
        lines.append("")

    lines += [
        "---",
        "*由 Obsidian Bridge v2.0 自动维护 | Eve（伊芙科技）*",
    ]

    count = write_md(VAULT / "Hermes-Codex 首页.md", "\n".join(lines), "index/Hermes-Codex 首页")
    return count


# ============================================================
# PUSH: Master
# ============================================================
def cmd_push():
    log("═══ PUSH: WSL → Obsidian ═══")
    load_state()

    c1 = push_wiki()
    c2 = push_reports()
    c3 = push_memories()
    c4 = push_projects()
    c5 = push_company_assets()
    c6 = push_bookstack()
    c7 = push_index_page()

    total = c1 + c2 + c3 + c4 + c5 + c6 + c7
    SYNC_STATE["stats"]["pushed"] += total
    save_state()

    log(f"  wiki={c1} reports={c2} memories={c3} projects={c4} company={c5} bookstack={c6} index={c7}")
    log(f"✓ Push done: {total} changes")
    return total


# ============================================================
# PULL: Obsidian → Hermes (注入记忆)
# ============================================================
def pull_vault_changes():
    """Detect new/changed user notes in vault."""
    load_state()
    vault_files = list(VAULT.rglob("*.md"))
    changes = []

    for f in vault_files:
        rel = str(f.relative_to(VAULT))
        if rel.startswith(".obsidian"):
            continue
        # Skip auto-synced files (push sources)
        auto_prefixes = ("wiki/", "reports/", "memories/", "decisions/",
                         "projects/", "company/", "bookstack/", "templates/")
        if rel.startswith(auto_prefixes):
            continue

        h = file_md5(f)
        tracked = SYNC_STATE["file_hashes"].get(f"user/{rel}")

        if tracked is None:
            changes.append(("NEW", rel, f))
        elif tracked != h:
            changes.append(("MOD", rel, f))

        SYNC_STATE["file_hashes"][f"user/{rel}"] = h

    # Detect deletions
    tracked_user_keys = {k for k in SYNC_STATE["file_hashes"] if k.startswith("user/")}
    existing_user_keys = {f"user/{str(f.relative_to(VAULT))}" for f in vault_files}
    for k in tracked_user_keys - existing_user_keys:
        changes.append(("DEL", k[5:], None))
        del SYNC_STATE["file_hashes"][k]

    save_state()

    if changes:
        log(f"  vault changes: {len(changes)}")
        for action, rel, _ in changes[:5]:
            log(f"    {action}: {rel}")
        if len(changes) > 5:
            log(f"    ... and {len(changes)-5} more")
    else:
        log("  no vault changes")

    return changes


def inject_to_memory(changes):
    """Inject user Obsidian notes into Memory Engine."""
    if not changes:
        return 0

    try:
        import sqlite3
        if not MEMORY_DB.exists():
            return 0

        db = sqlite3.connect(str(MEMORY_DB))
        now = datetime.now().isoformat()
        count = 0

        for action, rel, fpath in changes:
            if action == "DEL" or not fpath:
                continue

            content = fpath.read_text(encoding="utf-8", errors="replace")
            title_match = re.search(r'^---\s*title:\s*"([^"]+)"', content, re.MULTILINE)
            title = title_match.group(1) if title_match else fpath.stem

            existing = db.execute(
                "SELECT id FROM memories WHERE summary=?",
                (f"[Obsidian] {title}",)
            ).fetchone()

            if existing:
                db.execute(
                    "UPDATE memories SET detail=?, last_access=?, access_count=access_count+1 WHERE id=?",
                    (content[:2000], now, existing[0])
                )
            else:
                db.execute(
                    "INSERT INTO memories (type, summary, detail, tags, importance, access_count, created_at, last_access, source_session) VALUES (?,?,?,?,?,?,?,?,?)",
                    ("convention", f"[Obsidian] {title}", content[:2000], "obsidian,笔记", "medium", 1, now, now, "obsidian-bridge")
                )
            count += 1

        db.commit()
        db.close()
        log(f"  injected {count} notes into memory")
        return count

    except Exception as e:
        log(f"  ⚠ memory injection error: {e}")
        return 0


def cmd_pull():
    log("═══ PULL: Obsidian → Hermes ═══")
    changes = pull_vault_changes()
    injected = inject_to_memory(changes)
    SYNC_STATE["stats"]["pulled"] += injected
    save_state()
    log(f"✓ Pull done: {len(changes)} changes, {injected} injected")
    return len(changes)


# ============================================================
# INIT
# ============================================================
def cmd_init():
    log("═══ INIT: 建立 Obsidian Vault 结构 ═══")
    ensure_dir(VAULT)
    obsidian_dir = VAULT / ".obsidian"
    ensure_dir(obsidian_dir)

    # .obsidian config
    (obsidian_dir / "app.json").write_text(json.dumps({
        "alwaysUpdateLinks": True, "showFrontmatter": True,
        "showLineNumber": True, "spellcheck": True,
        "useMarkdownLinks": True, "newLinkFormat": "relative",
        "baseFontSize": 16,
    }, indent=2))

    (obsidian_dir / "core-plugins.json").write_text(json.dumps({
        "file-explorer": True, "global-search": True, "switcher": True,
        "graph": True, "backlink": True, "canvas": True,
        "outgoing-link": True, "tag-pane": True, "page-preview": True,
        "daily-notes": True, "templates": True, "note-composer": True,
        "command-palette": True, "outline": True, "word-count": True,
        "workspaces": True, "file-recovery": True,
    }, indent=2))

    (obsidian_dir / "community-plugins.json").write_text(json.dumps(
        ["dataview", "obsidian-tasks-plugin", "templater-obsidian",
         "obsidian-advanced-tables", "recent-files-obsidian",
         "omnisearch", "calendar"]
    ))

    (obsidian_dir / "types.json").write_text(json.dumps({
        "Note": {"color": "hsl(210, 20%, 80%)", "weight": 7},
        "Report": {"color": "hsl(45, 70%, 70%)", "weight": 5},
        "Decision": {"color": "hsl(0, 70%, 70%)", "weight": 8},
    }, indent=2))

    # Directory structure
    for sub in ["wiki", "reports", "memories", "decisions", "projects",
                "company", "company/workflows", "company/processes",
                "company/templates", "bookstack", "templates"]:
        ensure_dir(VAULT / sub)

    log("✓ Vault structure initialized")
    return cmd_push()


# ============================================================
# STATUS
# ============================================================
def cmd_status():
    load_state()
    vault_files = list(VAULT.rglob("*.md"))
    total = len(vault_files)

    by_dir = defaultdict(int)
    for f in vault_files:
        rel = f.relative_to(VAULT)
        top = str(rel.parent).split("/")[0] if rel.parent != Path(".") else "root"
        by_dir[top] += 1

    print(f"""
═══ Obsidian Vault Status ═══
  Vault: {VAULT}
  Total .md files: {total}""")
    for d, c in sorted(by_dir.items(), key=lambda x: -x[1]):
        print(f"    {d}/: {c}")
    print(f"""
  Last sync: {SYNC_STATE['last_sync'] or 'never'}
  Pushed:    {SYNC_STATE['stats']['pushed']}
  Pulled:    {SYNC_STATE['stats']['pulled']}
  Errors:    {SYNC_STATE['stats']['errors']}
═══════════════════════════════""")


# ============================================================
# SYNC (双向)
# ============================================================
def cmd_sync():
    log("═══ SYNC: 双向同步 v2.0 ═══")
    load_state()
    n_pushed = cmd_push()
    n_pulled = cmd_pull()
    SYNC_STATE["stats"]["pushed"] += n_pushed
    SYNC_STATE["stats"]["pulled"] += n_pulled
    save_state()
    log(f"✓ Sync complete: pushed={n_pushed}, pulled={n_pulled}")
    return n_pushed, n_pulled


# ============================================================
# MAIN
# ============================================================
if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: obsidian_sync.py {sync|push|pull|init|status}")
        sys.exit(1)

    cmd = sys.argv[1]
    if cmd != "init" and not VAULT.exists():
        print(f"❌ Vault not found: {VAULT}")
        print("   Run 'obsidian_sync.py init' first")
        sys.exit(1)

    commands = {"sync": cmd_sync, "push": cmd_push, "pull": cmd_pull,
                "init": cmd_init, "status": cmd_status}

    if cmd not in commands:
        print(f"❌ Unknown command: {cmd}")
        print("   Available: sync, push, pull, init, status")
        sys.exit(1)

    result = commands[cmd]()
    if result is None:
        sys.exit(0)
    elif isinstance(result, tuple):
        sys.exit(0 if result[0] + result[1] >= 0 else 1)
    else:
        sys.exit(0 if result >= 0 else 1)
