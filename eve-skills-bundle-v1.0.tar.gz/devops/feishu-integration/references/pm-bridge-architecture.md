# Feishu PM Bridge Architecture

> 基于实际项目验证 (2026-06-17), 产品: PM Bridge (:8769)
> 飞书App: cli_a961211c0178dbef

## 架构概览

```
飞书多维表格 (UI/操作层)  ←→  PM Bridge (:8769)  ←→  Eve Autopilot
                                  │
                          飞书Bot (消息通知)
```

## 飞书API权限清单

### ✅ 已确认可用的权限
| 权限 | 端点 | 用途 |
|------|------|------|
| wiki:space | `wiki/v2/spaces` | 获取空间列表 |
| im:message | `im/v1/messages` | Bot发送消息 |

### ❌ 需要手动开启的权限
| 权限 | 端点 | 用途 | 申请链接 |
|------|------|------|---------|
| drive:drive | `drive/v1/files` | 创建多维表格 | `https://open.feishu.cn/app/{APP_ID}/auth?q=drive:drive` |
| bitable:app | `bitable/v1/apps/{token}/tables` | 管理多维表格表/字段/记录 | 同上 |

## 权限开通步骤
1. 打开 `https://open.feishu.cn/app/{APP_ID}/auth`
2. 添加 `drive:drive` 和 `bitable:app` 权限
3. 管理员审批通过
4. 重新获取tenant_access_token（旧的会失效）

## 核心API调用模式

### 获取Token
```python
resp = requests.post("https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal",
    json={"app_id": APP_ID, "app_secret": APP_SECRET}, timeout=10)
token = resp.json()["tenant_access_token"]
```

### 检查API权限
```python
# 如果返回 code: 99991672, msg: "Access denied. One of the following scopes is required: [...]"
# 说明该API未授权，需要去开发者控制台添加权限
```

### Bot发送消息
```python
# 支持text和interactive两种msg_type
payload = {
    "receive_id": chat_id,
    "msg_type": "interactive",
    "content": json.dumps({
        "config": {"wide_screen_mode": True},
        "header": {"title": {"tag": "plain_text", "content": "标题"}, "template": "blue"},
        "elements": [{"tag": "markdown", "content": "消息内容"}]
    })
}
```

## 常见错误码
| Code | 含义 | 处理 |
|------|------|------|
| 0 | 成功 | - |
| 99991672 | 权限不足 | 需在开发者控制台添加scope |
| 1254001 | 资源已存在 | 忽略或更新 |
| 1254006 | 字段已存在 | 忽略 |
| 230001 | 无效参数 | 检查receive_id/msg_type |

## PM Bridge数据库Schema
参见 `~/company/scripts/pm_bridge.py` 中的SQLite schema定义，包含5张表:
- projects — 项目信息+盈利状态
- requirements — 需求+优先级+工作量评估
- tasks — 任务+工时+完成度
- sprints — 迭代规划
- work_logs — 员工工时登记
