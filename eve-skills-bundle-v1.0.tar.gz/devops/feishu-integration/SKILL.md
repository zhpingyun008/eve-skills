---
name: feishu-integration
description: 飞书API全栈集成 — Bitable多维表格CRUD、Bot消息通知、Webhook接收、OAuth认证、PM Bridge同步架构。覆盖权限配置、API调用、桥接设计。
category: devops
triggers:
  - "feishu"
  - "飞书"
  - "bitable"
  - "多维表格"
  - "lark"
  - "飞书集成"
  - "飞书机器人"
  - "飞书API"
  - "飞书多维"
  - "飞书通知"
  - "飞书项目"
---

# 飞书集成 (Feishu Integration)

## 概述
飞书(Feishu/Lark) API全栈集成，包括多维表格操作、Bot消息推送、Webhook接收、与Eve自主运营系统的桥接。

## 架构模式

```
┌──────────────┐    REST API    ┌──────────────┐
│  飞书多维表格  │ ←──────────→ │  PM Bridge    │
│  (用户操作层)  │  Webhook     │  (:8769)      │
└──────────────┘               └──────┬───────┘
                                      │
                               ┌──────▼───────┐
                               │  Eve Autopilot│
                               │  (自动化层)    │
                               └──────────────┘
```

## 飞书API权限清单

### 必需权限 (需在开发者控制台开通)
| 权限Scope | 用途 | API端点 |
|-----------|------|---------|
| `drive:drive` | 创建/管理多维表格文件 | `/open-apis/drive/v1/files` |
| `bitable:app` | 多维表格内表/字段/记录CRUD | `/open-apis/bitable/v1/apps/{token}` |
| `bitable:app:readonly` | 只读读取多维表格数据 | 同上(GET) |
| `im:message` | 发送Bot消息 | `/open-apis/im/v1/messages` |
| `im:resource` | 上传消息附件 | `/open-apis/im/v1/files` |

### 权限检查方法
```python
# 检查drive权限
resp = requests.get("https://open.feishu.cn/open-apis/drive/v1/files?page_size=1",
    headers={"Authorization": f"Bearer {token}"})
# HTTP 400 + code 99991672 = 缺少drive:drive权限

# 检查bitable权限
resp = requests.get(f"https://open.feishu.cn/open-apis/bitable/v1/apps/{app_token}/tables/{table_id}",
    headers={"Authorization": f"Bearer {token}"})
# HTTP 400 + code 99991672 = 缺少bitable:app权限

# 检查messaging权限
resp = requests.post("https://open.feishu.cn/open-apis/im/v1/messages",
    headers={"Authorization": f"Bearer {token}"},
    json={"receive_id": "oc_test", "msg_type": "text", "content": '{"text":"test"}'})
# HTTP 400 + code 230001 = invalid receive_id (bot连上了但发的chat_id不对)
```

### 权限申请链接
```
https://open.feishu.cn/app/{APP_ID}/auth?q={PERMISSION_SCOPE}
```

## 认证

### 获取tenant_access_token
```python
import requests
resp = requests.post(
    "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal",
    json={"app_id": APP_ID, "app_secret": APP_SECRET},
    timeout=10
)
token = resp.json()["tenant_access_token"]  # 有效期2小时
```

### 缓存策略
```python
# 缓存到文件避免每次重新获取
TOKEN_FILE = "~/.hermes/.feishu_token"
# 提前60秒刷新(expire-60)
```

## Bitable多维表格操作

### 创建多维表格
```python
resp = requests.post(
    "https://open.feishu.cn/open-apis/drive/v1/files",
    headers=HDR,
    json={"file_name": "名称", "file_type": "bitable"}
)
# 需要 drive:drive 权限
# 返回: {"data": {"file_token": "...", "url": "..."}}
```

### 添加表
```python
resp = requests.post(
    f"https://open.feishu.cn/open-apis/bitable/v1/apps/{app_token}/tables",
    headers=HDR,
    json={"table_name": "项目表"}
)
# 需要 bitable:app 权限
# 返回: {"data": {"table_id": "tblXXX"}}
```

### 添加字段
```python
payload = {
    "field_name": "状态",
    "type": 3,  # 单选
    "property": {
        "options": [
            {"name": "进行中", "color": 1},
            {"name": "已完成", "color": 2},
        ]
    }
}
resp = requests.post(
    f"https://open.feishu.cn/open-apis/bitable/v1/apps/{app_token}/tables/{table_id}/fields",
    headers=HDR, json=payload
)
```

### 字段类型映射
| type | 含义 |
|:----:|:-----|
| 1 | 文本 |
| 3 | 单选 |
| 5 | 日期 |
| 7 | 数字 |
| 11 | 人员 |
| 100 | 百分比 |
| 13 | 创建时间(自动) |

### 已知API错误码
| code | 含义 |
|:----:|:------|
| 1254001 | 表已存在 |
| 1254006 | 字段已存在 |
| 99991672 | 缺少权限scope |

## Bot消息通知

### 发送消息
```python
# 1. 获取token
resp = requests.post("https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal",
    json={"app_id": APP_ID, "app_secret": APP_SECRET}, timeout=10)
token = resp.json()["tenant_access_token"]

# 2. 发送交互式卡片消息
payload = {
    "receive_id": chat_id,
    "msg_type": "interactive",
    "content": json.dumps({
        "config": {"wide_screen_mode": True},
        "header": {"title": {"tag": "plain_text", "content": "标题"},
                   "template": "blue"},
        "elements": [
            {"tag": "markdown", "content": "消息内容"}
        ]
    })
}
requests.post(
    "https://open.feishu.cn/open-apis/im/v1/messages?receive_id_type=chat_id",
    headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
    json=payload
)
```

### 已知错误码
| code | 含义 | 排查 |
|:----:|:------|:-----|
| 230001 | invalid receive_id | chat_id格式错误，需以`oc_`开头 |
| 99991663 | bot未加入群聊 | 需手动把bot拉入目标群 |

## PM Bridge架构（飞书不可用时替代方案）

当飞书API权限不足时，使用自建PM Bridge作为替代：

### 项目位置
`~/company/scripts/pm_bridge.py`

### 技术栈
- FastAPI + SQLite + 可选飞书Bot通知
- Port 8769

### 数据模型
5张表: projects / requirements / tasks / sprints / work_logs
对应设计文档: `~/feishu-pm-evaluation.md`

### API端点
| 路径 | 方法 | 用途 |
|:-----|:----:|:-----|
| `/api/projects` | GET/POST | 项目列表/创建 |
| `/api/projects/{id}` | GET/PUT | 项目详情/更新 |
| `/api/projects/{id}/tasks` | GET/POST | 任务列表/创建 |
| `/api/tasks/{id}` | PUT | 任务更新 |
| `/api/work-logs` | GET/POST | 工作量登记/查询 |
| `/api/dashboard` | GET | 全系统概览 |
| `/api/seed` | POST | 导入示范数据 |

### Web UI
- 响应式管理面板
- 项目列表+状态标签+收入展示
- 自动从API加载数据

### 升级路径
1. PM Bridge作主系统（立即可用）
2. 开通飞书API权限后加Bitable双向同步层
3. 最终: 飞书多维表格作UI, PM Bridge作API网关

## 坑 (Pitfalls)
1. **权限是第一道坎**: 飞书API最常见的失败原因是缺少权限scope。先测试几个简单端点确认哪些权限可用。
2. **tenant_access_token 2小时过期**: 必须缓存并刷新，不要每次请求都获取。
3. **drive API 404**: 可能是API端点变更或权限问题。404+非JSON响应通常是端点路径不对。
4. **不能通过API创建多维表格**: 需要`drive:drive`权限。如果没有，用户手动在飞书创建后，再用`bitable:app`权限操作。
5. **Bot消息必须指定正确的receive_id**: 群聊用`oc_`开头的chat_id，单聊用`ou_`开头的open_id。
6. **Webhook不稳定**: 飞书Webhook不保证100%送达，不适合关键数据同步。PM Bridge的SQLite作为持久层兜底。
