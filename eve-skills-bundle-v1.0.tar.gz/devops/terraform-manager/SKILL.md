---
name: terraform-manager
description: Terraform基础设施管理 — 状态管理、plan/review、apply/rollback、模块管理、远程状态后端配置、workspace管理。触发词："terraform"/"tf"/"infra as code"/"terraform plan"/"terraform apply"/"state管理"。
depends_on:
  - cloud-cost-optimizer
related_skills:
  - k8s-resource-manager
  - iac-security-scanner
  - cloud-cost-optimizer
category: devops
triggers:
  - "terraform"
  - "tf"
  - "infra as code"
  - "terraform plan"
  - "terraform apply"
  - "terraform state"
  - "基础设施管理"
  - "terraform workspace"
  - "terraform module"
  - "生成Terraform"
  - "IaC"
  - "infrastructure as code"
  - "云资源配置"
---

# Terraform Manager — Terraform基础设施管理


## Overview

Brief description of this skill's purpose and capabilities.
Terraform基础设施全生命周期管理：编写、审查、部署、状态管理、迁移。

## Trigger Conditions

Load this skill when:
- User asks to manage Terraform infrastructure
- Terraform plan/apply workflow
- State management (migration, locking)
- Module design and refactoring
- Workspace management
- Infrastructure review

## Workflow

### 1. Project Structure

```
terraform/
├── main.tf           # Main resources
├── variables.tf      # Input variables
├── outputs.tf        # Output values
├── versions.tf       # Provider/Terraform version constraints
├── terraform.tfvars   # Variable values (gitignored!)
├── modules/
│   ├── networking/
│   ├── compute/
│   └── database/
├── environments/
│   ├── dev/
│   ├── staging/
│   └── prod/
└── backend.tf        # Remote state config
```

### 2. State Management

```bash
# Initialize with backend
terraform init -reconfigure -backend-config="key=project/env/terraform.tfstate"

# List state resources
terraform state list

# Show specific resource
terraform state show aws_instance.web

# Move resource in state (for refactoring)
terraform state mv aws_instance.old aws_instance.new

# Remove from state (without destroying)
terraform state rm aws_instance.imported

# Pull state to local file
terraform state pull > terraform.tfstate.backup

# Push state (careful!)
terraform state push terraform.tfstate.backup
```

### 3. Plan & Apply Workflow

```bash
# Format and validate
terraform fmt -recursive
terraform validate

# Plan with variable file
terraform plan -var-file="environments/prod/terraform.tfvars" -out=tfplan

# Detailed plan review
terraform show tfplan | head -100  # Check adds/changes/destroys

# Apply with backup
terraform apply tfplan -auto-approve

# Destroy
terraform destroy -var-file="environments/prod/terraform.tfvars"
```

### 4. Resource Import

```bash
# Import existing resource
terraform import aws_s3_bucket.my_bucket my-existing-bucket-name

# Generate config for imported resource
terraform plan -generate-config-out=generated.tf

# Import with state operation
terraform state rm aws_instance.old_import
terraform import aws_instance.new_import i-1234567890abcdef0
```

### 5. Module Management

```hcl
# modules/compute/main.tf
variable "instance_count" {
  type    = number
  default = 1
}

variable "instance_type" {
  type    = string
  default = "t3.micro"
}

resource "aws_instance" "this" {
  count         = var.instance_count
  ami           = data.aws_ami.ubuntu.id
  instance_type = var.instance_type
  tags = {
    Name = "${var.name}-${count.index + 1}"
  }
}

# Usage in main.tf
module "web_servers" {
  source         = "./modules/compute"
  instance_count = 3
  instance_type  = "t3.small"
  name           = "web-server"
}
```

### 6. Workspaces (Environment Isolation)

```bash
# List workspaces
terraform workspace list

# Create workspace
terraform workspace new production

# Switch workspace
terraform workspace select staging

# Apply in specific workspace
terraform workspace select production && terraform apply -auto-approve
```

### 7. CI/CD Integration

```yaml
# .github/workflows/terraform.yml
name: Terraform
on: [pull_request, push]
jobs:
  plan:
    runs-on: ubuntu-latest
    steps:
      - uses: hashicorp/setup-terraform@v3
      - run: terraform fmt -check
      - run: terraform init
      - run: terraform validate
      - run: terraform plan -out=tfplan
      - uses: actions/upload-artifact@v4
        with:
          name: tfplan
          path: tfplan

  apply:
    if: github.ref == 'refs/heads/main'
    needs: plan
    runs-on: ubuntu-latest
    steps:
      - uses: actions/download-artifact@v4
      - run: terraform apply tfplan
```

## 合并来源 (Batch A Merge)

### 来自 terraform-generator (已归档到 _archive/)
- **IaC生成**: 为AWS/GCP/Azure生成Terraform/OpenTofu配置，自动检测现有基础设施
- **工作流**: 需求分析(4步)→配置生成→安全加固(SG/IAM/加密)→验证(fmt/validate/tflint/checkov)
- **常用模式**: Greenfield(从架构图生成) / Brownfield(terraformer导入→生成.tf) / Module library
- **安全性**: 最小权限SG/范围化IAM策略/静态加密(EBS/RDS/S3)
- **Pitfalls**: State文件是单一真相源，用S3+DynamoDB锁保护；不提交密钥到.tf文件；用tags非names保持灵活性

### 新增相关技能关联
- terraform-generator已归档，其相关技能(terraform-manager, iac-security-scanner, cloud-cost-optimizer)已在当前列表中

## Pitfalls

1. **State file exposure**: Terraform state contains secrets (plaintext). Use encrypted remote backend (S3+KMS, Terraform Cloud).
2. **State locking**: Without locking, concurrent applies corrupt state. S3+DynamoDB for locking or Terraform Cloud.
3. **Sensitive variables**: `terraform.tfvars` files are often committed by accident. Add to `.gitignore`, use Vault/SSM for secrets.
4. **Destroy danger**: `terraform destroy` removes ALL resources. Use `-target` for selective destruction or `prevent_destroy = true` lifecycle.
5. **Provider version drift**: Team members with different provider versions produce different plans. Pin versions in `versions.tf`.
6. **State migration**: Moving state between backends requires careful planning. Always backup state before migration.

## Verification

```bash
# Verify Terraform setup
terraform version
terraform fmt -check -recursive 2>/dev/null && echo "✓ All files formatted" || echo "⚠️  Format check: run terraform fmt"
```

## Integration

- **iac-security-scanner**: Run Checkov/TFsec before `terraform apply`
- **k8s-resource-manager**: Terraform + K8s provider for cluster management
- **secrets-vault-manager**: Manage Terraform secrets with Vault/SOPS
- **cicd-builder**: Terraform pipeline in CI/CD
