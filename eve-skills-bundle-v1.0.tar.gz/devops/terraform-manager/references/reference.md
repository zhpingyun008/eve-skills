# terraform-manager — Reference

## Overview
Terraform基础设施管理 — 状态管理、plan/review、apply/rollback、模块管理、远程状态后端配置、workspace管理。触发词："terraform"/"tf"/"infra as code"/"terraform plan"/"terraform apply"/"state管理"。

## Integration Points
- Hermes Agent skill ecosystem
- evolution_engine.py scoring system
- self-audit verification

## Key Resources
- SKILL.md: main skill definition
- scripts/: executable code (if present)
