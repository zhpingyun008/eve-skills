# PromptHub Server — 完整扫描示例（Flask 单文件 + 无 Git 项目）

> 扫描日期: 2026-07-22
> 项目路径: `/home/yestin/projects/prompthub-server/`
> 展示技能: 无 Git 项目扫描、单文件 Flask 审计、SQLite 内容审计、运行中服务检测

## 项目元信息

| 属性 | 值 |
|------|------|
| **项目** | PromptHub Server v2 — Prompt 管理 Web 服务 |
| **技术栈** | Python Flask + SQLite + Bootstrap 5 Dark Theme |
| **代码量** | 1480 行 app.py + 31 行 start.sh |
| **端口** | 3871 (127.0.0.1) |
| **运行状态** | ✅ 正在运行 (PID 447) |
| **版本控制** | ❌ 无 Git 仓库 |

## 文件结构

```
prompthub-server/
├── app.py          (61 KB, 1480 行)  → 单体应用，路由+模板+逻辑全在
├── prompts.db      (28 KB)           → SQLite 数据库
├── start.sh        (755 B)           → 启动脚本
└── __pycache__/    
    └── app.cpython-311.pyc
```

## 数据库

**表**: `prompts` (11 行) + `versions` (19 行)  
**完整性检查**: ✅ `PRAGMA integrity_check` → ok  
**索引**: prompts 有 category/favorite 索引，versions 有 prompt_id 索引

### 数据内容信号

| 信号 | 发现 | 解读 |
|------|------|------|
| XSS 测试用例 | `id=14: title="XSS Test", category="Uncategorized"` | 项目有人在做安全测试 |
| 中英混杂分类 | `Testing` / `Development` / `AI` / `测试` / `test` | 多用户或多语言场景 |
| 收藏率 | 2/11 (18%) | 功能有使用但非核心 |
| 版本历史 | 19 个版本 vs 11 条提示词 | 版本快照功能正常使用中 |

## 关键发现

### 🔴 无版本控制
项目完全没有 Git 仓库，无法追踪变更、回滚或协作。这是最严重的问题。

### 🟡 虚拟环境与系统 Python 不匹配
- Flask 3.1.3 安装在 `/home/yestin/.hermes/.venv/`
- `start.sh` 使用裸 `python3`，未激活 venv
- 当前运行时（PID 447）能工作是因为 Hermes 会话已激活 venv，但直接运行 `start.sh` 可能会失败

### 🟡 硬编码密钥
```python
app.secret_key = 'prompthub-secret-key-change-in-production'
```
应迁移至环境变量 `os.getenv('SECRET_KEY', default)`。

### 🟡 无认证/鉴权
所有 API 完全开放。`Flask-JWT-Extended` 和 `Flask-Login` 已安装但未启用。

### 🟡 已安装未使用的依赖
| 包 | 版本 |
|---|------|
| flask-cors | 6.0.2 — 未在 app.py 中导入或配置 |
| Flask-JWT-Extended | 4.7.4 — 未在 app.py 中导入或配置 |
| Flask-Login | 0.6.3 — 未在 app.py 中导入或配置 |
| Flask-SocketIO | 5.6.1 — 未在 app.py 中导入或配置 |

### 🟡 单体超大文件
1480 行单文件，CSS/JS/HTML 模板/Python 业务逻辑全部混在一起，难以维护。

### ✅ 代码质量亮点
- 全部使用参数化查询，无 SQL 注入风险
- AST 扫描未发现 eval/exec
- 数据库 WAL 模式 + 外键约束
- 版本历史功能实现完整

## 扫描命令速查

```bash
# 运行中服务检测
ss -tlnp | grep <port>
# 或
curl -s http://localhost:<port>/ | head -5

# 虚拟环境 vs 系统 Python 检测
which python3
source /path/to/.venv/bin/activate && python3 -c "import flask; print(flask.__version__)"
python3 -c "import flask" 2>&1  # 系统 Python 能否找到

# AST 导入提取（发现已安装未使用的包）
python3 -c "
import ast
tree = ast.parse(open('app.py').read())
imports = set()
for n in ast.walk(tree):
    if isinstance(n, ast.Import):
        for alias in n.names:
            imports.add(alias.name.split('.')[0])
    elif isinstance(n, ast.ImportFrom) and n.module:
        imports.add(n.module.split('.')[0])
print('\n'.join(sorted(imports)))
"

# AST 安全扫描
python3 -c "
import ast
tree = ast.parse(open('app.py').read())
for n in ast.walk(tree):
    if isinstance(n, ast.Call) and hasattr(n.func, 'id') and n.func.id in ('eval', 'exec'):
        print(f'WARNING: {n.func.id} at line {n.lineno}')
"

# SQLite 数据库内容审计
python3 -c "
import sqlite3
conn = sqlite3.connect('prompts.db')
# 完整性
print(conn.execute('PRAGMA integrity_check').fetchone()[0])
# 表结构
for row in conn.execute(\"SELECT name FROM sqlite_master WHERE type='table'\"):
    print(f'Table: {row[0]}')
    for col in conn.execute(f'PRAGMA table_info({row[0]})'):
        print(f'  {col[1]:20s} {col[2]:15s}')
    print(f'  [Rows: {conn.execute(f\"SELECT COUNT(*) FROM {row[0]}\").fetchone()[0]}]')
conn.close()
"
```
