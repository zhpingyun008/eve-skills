# 海航AI购票助手 — 完整项目状态扫描示例

> 这是一次完整扫描的输出示例，作为 `project-status-scan` 技能的参考。展示了 7 个必查维度的报告格式。

## 项目元信息

| 项目 | 状态 |
|------|------|
| **项目路径** | `/home/yestin/projects/haihang-ticketing/` |
| **项目规模** | 539MB (含 .venv, node_modules) |
| **最后 Commit** | `d363c58` — 8周前 |
| **总提交数** | 49 commits |
| **活跃开发天数** | 8天 |
| **版本标签** | 17个 (v1.0.0 ~ v1.3.0) |
| **远程仓库** | ❌ 未配置远程 |

## 架构总览

```
haihang-ticketing/
├── backend/          # FastAPI (Python 3.11)
│   ├── api/          # 5个路由模块
│   ├── models/       # ORM 数据模型
│   ├── services/     # 4个业务服务层
│   └── migrations/   # Alembic 迁移
├── frontend/         # React 19 + Vite 8 + Tailwind CSS 4
│   ├── src/          # 14个页面/组件
│   └── dist/         # ✅ 428KB (已构建)
├── docs/             # 30+ CMMI5 文档
├── tests/            # 18个 pytest 文件
├── k8s/              # 9个 K8s 清单
└── .github/workflows/ # CI/CD
```

## 前端状态

| 项目 | 数据 |
|------|------|
| 框架 | React 19 + TypeScript 6 + Vite 8 |
| 构建 | ✅ 成功 (283ms, 92 modules) |
| JS Bundle | 362.5KB (gzip 108KB) |
| CSS Bundle | 40KB (gzip 7.8KB) |
| 未提交修改 | 7文件修改中 (UI重构中) |

## 后端状态

| 项目 | 数据 |
|------|------|
| 框架 | FastAPI 0.110 + Uvicorn 0.27 |
| 数据库 | SQLite (80KB) / PostgreSQL (配置就绪) |
| 认证 | JWT + API Key 双模式 |
| AI | DeepSeek Chat API |
| 监控 | Prometheus metrics 端点 |
| 缓存 | Redis 配置就绪 |

## 测试状态

| 类别 | 结果 |
|------|------|
| pytest | 🟡 290 passed, **24 failed** |
| 失败分布 | booking(2), chat(4), payment(12) |
| 覆盖率 | 94.3%+ (历史数据) |

## ⚠️ 关键问题

1. **24个测试失败** — 可能与未提交的本地修改相关
2. **无远程仓库** — 仅本地 Git
3. **项目停滞** — 最后 commit 在8周前
4. **pg-migration 分支未合并** — `feature/pg-migration` 未合入 main
