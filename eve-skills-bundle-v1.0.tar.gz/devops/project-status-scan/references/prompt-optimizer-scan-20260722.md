# Prompt Optimizer 项目扫描参考 (2026-07-22)

## 项目背景

Prompt Optimizer 是一个多平台 AI 提示词优化工具（Web + Desktop + Chrome Extension + Docker + MCP Server），采用 pnpm monorepo 结构。

## 扫描要点

### Git 状态

- 当前分支: `develop`，落后远程 **43 commits**
- `docker-compose.yml` 被本地修改（端口 28081→8082，环境变量大幅删减，硬编码密码）
- 最新提交: `f96ed83a docs: add prompt garden image workflow tutorial`
- 远程: `github.com/linshenkx/prompt-optimizer.git`

### 子包概览

| 子包 | 包名 | 版本 | 构建产物 |
|------|------|------|---------|
| core | @prompt-optimizer/core | 0.0.0 | ❌ dist/ 不存在 |
| ui | @prompt-optimizer/ui | (workspace) | ❌ dist/ 不存在 |
| web | @prompt-optimizer/web | (workspace) | ❌ dist/ 不存在 |
| desktop | @prompt-optimizer/desktop | 2.10.1 | ❌ dist/ 不存在 |
| extension | @prompt-optimizer/extension | 0.0.0 | ❌ dist/ 不存在 |
| mcp-server | @prompt-optimizer/mcp-server | 0.1.0 | ❌ dist/ 不存在 |

### 磁盘占用

- 总计: 924M
- node_modules (root): 829M (90%)
- 源代码 (不含 node_modules): 95M
- 子包 node_modules 几乎为空（pnpm 全局 store）

### 依赖特点

- pnpm 10.6.1, Node ^22.x
- core 包依赖: Anthropic SDK, Google Gemini, OpenAI, Dexie (IndexedDB), Zod
- desktop 包依赖: Electron 41, electron-builder 26, electron-updater, electron-log
- pnpm-workspace.yaml 有 `ignoredBuiltDependencies`: electron, electron-winstaller, esbuild, vue-demi

### 完整技术栈

- **前端**: Vue 3 + TypeScript + Vite 8
- **测试**: Vitest 4 (unit/integration) + Playwright (E2E)
- **桌面**: Electron 41
- **扩展**: WXT (Chrome Extension)
- **后端/API**: MCP Server (Node.js)
- **部署**: Vercel (web) + Docker (Nginx+Node) + GitHub Actions
- **文档**: MkDocs (双语 + Material theme)

### 发现的典型模式

1. **多平台一致性问题**: 桌面版有独立版本号 (2.10.1)，而 core/extension 标记为 0.0.0（通过 workspace:* 实际使用 root 版本）
2. **Docker Compose 本地化**: 典型的团队模式——成员拉取仓库后改端口和密码但不提交，导致脏工作区
3. **进度偏差**: 落后远程 43 commits 说明本地工作不是基于最新代码
4. **构建依赖声明**: `onlyBuiltDependencies: ["electron"]` 安全策略，阻止 pnpm 执行任意 install scripts
