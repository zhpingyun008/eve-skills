# tracellm (LLM Call Tracker) — 扫描参考

## 基本信息

| 项目 | 值 |
|------|-----|
| **扫描日期** | 2026-07-22 |
| **路径** | `/home/yestin/llm-call-tracker` |
| **指定路径** | `/home/yestin/projects/llm-call-tracker` (不存在，通过 `find ~ -name "*call*track*"` 发现) |
| **包名** | `tracellm` (与目录名不同 — 需建立别名映射) |
| **版本** | 0.1.0 (alpha) |
| **许可证** | MIT |
| **远端** | `https://github.com/zhpingyun008/tracellm.git` |
| **提交数** | 1 |
| **Python** | >= 3.9 |

## 关键发现

### 1. 元数据占位符未更新
- `pyproject.toml` 中 URL 仍指向 `yourusername/tracellm`，但实际 remote 已是 `zhpingyun008/tracellm`
- 🔴 影响：pip 发布时描述页面指向错误地址

### 2. 依赖声明缺失 (Dashboard)
- `dashboard/server.py` 依赖 `fastapi` 和 `uvicorn`，但 pyproject.toml 中 `[project.dependencies]` 为空
- 安装方式：全局 pip（非项目管理），可能在另一环境中无法运行
- 建议：将 dashboard 依赖放在 `[project.optional-dependencies]` 中

### 3. 无 .gitignore
- `__pycache__/`、`*.pyc`、`.old` 文件未被忽略，已进入 git 追踪（通过 pycache 修改检测到）
- 需添加 `.gitignore` 后 `git rm --cached` 清理

### 4. `dashboard/` 目录未追踪
- Dashboard 是新开发的功能，完全在 git 之外
- 5 个未暂存修改 + 1 个未追踪目录

### 5. `timeout` 参数已声明但未使用
- `decorator.py` 中 `track_llm_call()` 接受 `timeout` 参数（默认 30s）
- 但实际传递给 kwargs 后由原函数处理，无 `asyncio.wait_for` 或 `concurrent.futures` 超时保障
- 属于"半实现"功能——API 已暴露但行为不符合文档承诺

### 6. 无测试文件
- 仅有 `example.py` 作为集成测试（5 断言全部通过）
- 无独立 `tests/` 目录，无法执行 `pytest`

### 7. 代码注释标记系统
- 代码中使用 `#[1-3]`, `#[4-5]`, `#[8]`, `#[9]`, `#[11]`, `#[12]`, `#[14]`, `#[15]`, `#[16]`, `#[17]`, `#[18]`, `#[20]` 等标记跟踪"技术债务"或"修改追溯"
- 这是开发阶段的跟踪模式——注意这些标记会在未来合并 PR 时产生 lint 噪音

## 发现路径

```
用户指定: /home/yestin/projects/llm-call-tracker/ (不存在)
→ ls -la /home/yestin/projects/ (列出项目目录, 看到 23 个目录, 无 llm-call-tracker)
→ find ~ -type d -name "*call-tracker*" (返回 /home/yestin/llm-call-tracker)
→ 发现: 项目直接在 ~/ 下, 而非 ~/projects/ 下
```

## 触发 Patches

- **project-status-scan**: 新增"项目元数据完整性审计"(11b) 维度，涵盖包名/目录名一致性、占位符 URL 检测、依赖声明完整性、可选依赖声明检查
