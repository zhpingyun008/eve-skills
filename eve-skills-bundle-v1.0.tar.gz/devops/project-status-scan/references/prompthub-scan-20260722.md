# PromptHub — 完整项目状态扫描示例（pnpm Monorepo 扫描实操）

> 扫描日期: 2026-07-22
> 项目路径: `/home/yestin/projects/prompthub/`
> 展示技能: monorepo 扫描、数据库 Schema 分析、CI/CD 流水线分析、Docker 审计

## 项目元信息

| 属性 | 值 |
|------|------|
| **项目** | PromptHub — AI Prompt 与 Skill 管理平台 |
| **版本** | v0.5.5 (HEAD tagged) |
| **许可证** | AGPL-3.0 |
| **包管理器** | pnpm 9.15.0 (monorepo) |
| **代码总量** | ~35,613 行 TypeScript/TSX |
| **分支** | 仅 `main` 分支，worktree 干净 |
| **远程** | `origin` → `https://github.com/legeling/PromptHub.git` |

## Monorepo 架构

```
prompthub/
├── apps/
│   ├── web/           # 自托管版 - Hono + React (812 KB src)
│   └── desktop/       # Electron 桌面版 (4.7 MB src)
├── packages/
│   ├── shared/        # 共享类型与常量 (184 KB)
│   └── db/            # 数据库层 (140 KB)
├── website/           # 官网 - Astro 静态站 (9.6 MB)
├── docs/              # 多语言文档 (9.9 MB)
├── spec/              # 内部 SSD/Spec 系统 (OpenSpec)
├── .agents/           # AI Agent 配置
└── .github/workflows/ # CI/CD 流水线
```

### 子包版本映射

| 包 | 版本 | 备注 |
|---|------|------|
| `@prompthub/desktop` | **0.5.5** | 主版本，与 Git tag 对齐 |
| `@prompthub/web` | 0.1.0 | 早期阶段，远低于 desktop 版本 |
| `@prompthub/shared` | 0.1.0 | 许可证 MIT |
| `@prompthub/db` | 0.1.0 | 依赖 node-sqlite3-wasm |
| `prompthub-website` | 0.0.1 | Astro 官网 |

> ⚠️ `shamefullyHoist: true` 在 `pnpm-workspace.yaml` 中开启，依赖可能被意外提升。

## Git 特点

- 仅 `main` 单分支
- 工作区 100% 干净（无未提交/未跟踪文件）
- 60+ 语义化标签（v0.1.4 ~ v0.5.5 + beta/rebuild/yolo）
- v0.5.6 的 commit 不在 main 上——可能仅 tag 未合并

## 数据库 Schema

**引擎**: SQLite (WASM via `node-sqlite3-wasm`)  
**位置**: `apps/web/data/prompthub.db` (233 KB)

| 表 | 说明 |
|----|------|
| `prompts` | Prompt 主表，FTS5 全文搜索 |
| `prompt_versions` | 版本历史 (UNIQUE prompt_id+version) |
| `folders` | 嵌套文件夹 |
| `skills` | Skill 管理（MCP 配置，版本追踪） |
| `skill_versions` | Skill 版本历史 |
| `users` | 用户 (admin/user 角色) |
| `refresh_tokens` | JWT 刷新令牌，含过期时间 |
| `settings` | 全局键值设置 |
| `user_settings` | 用户级设置 (PRIMARY KEY user_id+key) |

特点: UUID 主键、FTS5 全文搜索触发器和增量索引、软删除通过 `visibility` 列控制。

## CI/CD 分析

### Release Pipeline (`release.yml`)
- 推送 `v*` tag 触发
- 矩阵构建: macOS x64/arm64 + Windows x64/arm64 + Linux x64
- 更新清单处理: 分架构 `latest-*.yml`，然后合并为统一 `latest-mac.yml`
- Manifest 哈希修复: 用 `fix-manifest-hashes.js` 确保实际二进制与元数据一致
- Release 默认 Draft，需手动 promote
- 条件 Homebrew Cask 发布

### Quality Gate (`quality.yml`)
- PR 触发: Install → Lint → Typecheck → Unit Tests → Integration Tests → Perf Budget → Build

## Docker 部署

- 多阶段构建: `node:22-bookworm-slim`
- 端口 3000（docker-compose 对外 3871, 可配置 `PROMPTHUB_WEB_PORT`）
- 健康检查: 每 30s 请求 `/health`
- 卷挂载: `./data` `./config` `./logs`

## 构建状态摘要

| 维度 | 结果 |
|------|------|
| CLI 构建 | ✅ 存在 (196 KB `out/cli/prompthub.cjs`) |
| Web dist | ⚠️ 未构建 (`apps/web/dist/` 不存在) |
| Desktop Electron dist | ⚠️ 未构建 (`apps/desktop/dist/` 不存在) |
| pnpm 依赖 | ✅ 已安装 (node_modules/.pnpm) |
| SQLite 数据库 | ✅ 已初始化 (233 KB) |

## 测试覆盖

| 类型 | 数量 |
|------|------|
| Desktop 单元测试 | 30+ 文件 (services/stores/ui) |
| Web 单元测试 | 路由 + 服务层 + 客户端组件测试 |
| E2E | Playwright (smoke/full suite) |
| 性能 | 大数据预算检查 (`check-large-data-budgets.mts`) |
| i18n | 多语言回归测试 |
