---
name: project-status-scan
description: 全维度项目状态扫描与健康报告生成 — 并行探查git/构建/测试/依赖/配置/文档/部署多维度，输出结构化综合报告。适用于接手陌生项目、交付前审计、定期健康检查。
category: devops
triggers:
  - "全面扫描"
  - "项目状态"
  - "扫描项目"
  - "health scan"
  - "project audit"
  - "项目现状"
  - "项目健康"
  - "扫描状态"
  - "status report"
  - "全面检查"
  - "综合报告"
  - "项目盘点"
  - "逐项排查"
  - "项目摸底"
  - "全面审计项目"
---

# Project Status Scan — 全维度项目状态扫描

## 概述

系统化扫描一个项目的全方位健康状态，生成结构化报告。适用于：

- **接手陌生项目** — 快速摸底代码库、构建状态、测试健康度
- **交付前审计** — 确认所有维度达标
- **定期巡检** — 发现退化信号
- **团队交接** — 生成标准化项目快照

## Phase 0: 路径发现（当指定路径不存在时）

ユーザーから与えられたパスが存在しない場合、すぐに失敗報告せずに以下の手順で発見する：

```yaml
step 1: 指定パス確認
  - terminal(ls -la <指定パス> 2>&1)
  - 存在しない場合 → 下記へ

step 2: 親ディレクトリの内容確認
  - terminal(ls -la <指定パスの親>/)
  - search_files(target='files', pattern='<プロジェクト名>*', path=<親>)
  - 例: `projects/freelancer-tool/` がない → `ls -la projects/` で全プロジェクト一覧を見る

step 3: システム全体で検索
  - search_files(target='files', pattern='<関連キーワード>*', path=<HOME>)
  - PIDファイル: `cat ~/company/var/run/<関連>.pid`
  - ログファイル: `ls ~/company/logs/*<関連>*`

step 4: 自動化スクリプトからパスを逆引き
  - デーモン/ウェブフック/保活用シェルスクリプトから起動パスを特定:
    - cat  ~/company/scripts/keepalive.sh    # 保活cron
    - cat  ~/company/cron/*                  # その他cron
    - grep -rli '<キーワード>' ~/company/scripts/
  - 保活スクリプト内の `cd <path>` に実際のプロジェクトパスが書かれている

step 5: 関連ビジネス文書の確認
  - プロジェクト憲章 / 企画書:
    - search_files(target='files', pattern='*<キーワード>*', path=~/project_charters/)
  - 製品カタログ: ls ~/company/products/ で製品ラインナップ確認

結論: 実際のパスがわかったら「発見経路」を報告に含める。
  例: 「指定パス /projects/freelancer-tool/ は存在しません。
        keepalive.sh から /home/yestin/freelancer-tool/ を発見しました。」
```

## スキャン次元（11個の必須次元 + 3個のオプション次元）

### 1. 目录结构与文件清单
```yaml
工具: search_files(target='files', pattern='*')
命令: ls -la <project-root>, du -sh <project-root>
产出: 项目总大小、关键目录速览
```

### 2. Git 状态
```yaml
工具: 
  - terminal(git status, git log, git diff --stat, git branch -a, git remote -v, git tag -l)
  - terminal(git rev-list --count HEAD, git rev-list --count origin/<branch>)  # divergence
  - terminal(git log --oneline HEAD..origin/<branch> | wc -l)  # behind count
产出: 分支现状、与远程的偏离程度(落后N commits / 超前N commits)、未提交修改、提交历史(最近20条)、commit总数、标签列表、远程仓库
```
> **Git divergence（分支偏离度）** 是项目状态的关键指标。落后远程超过几十个 commits 意味着本地代码严重过时，扫描报告应在顶部突出显示。

### 2b. 无 Git 仓库处理
`git status` 可能失败（返回非零）——这本身是一个 🔴 级别的发现。
- 先检查 `.git/` 目录是否存在：`ls -la <root>/.git/`
- 如果不存在 Git 仓库：
  - 跳过所有 Git 依赖的检查（branch/remote/tag/divergence）
  - **必须在报告顶部突出标注「无版本控制」**为严重问题
  - 其他维度（代码语法、依赖、数据库、运行时）依然正常检查
  - 快速修复建议：`cd <root> && git init && git add . && git commit -m "Initial baseline"`

### 3. 依赖配置审计
```yaml
工具: read_file(package.json, requirements.txt, pyproject.toml, Cargo.toml, go.mod, etc.)
产出: 技术栈版本、依赖完整性、过时/缺失依赖
```

### 4. 构建状态
```yaml
前置检查: terminal(ls -d packages/*/dist 2>/dev/null; ls -d apps/*/dist 2>/dev/null)
  说明: 先检查各子包 dist/ 产物是否存在，报告中列出哪些子包已构建、哪些缺失
构建: terminal(npm run build) 或 pnpm build 或 yarn build
后端: terminal(pip install -r requirements.txt; python -m compileall 等)
Docker: terminal(docker compose build 2>&1 | tail -5)
产出: 构建产物是否存在(逐包)、构建通过/失败、产物大小、构建耗时
```

### 5. 测试状态
```yaml
后端: terminal(pytest --tb=short -q 2>&1 | tail -20)
前端: terminal(npm test 2>&1 | tail -20)
产出: 通过/失败/跳过计数、失败详情、覆盖率、E2E状态
```

### 6. 配置与安全审查
```yaml
工具: 
  - read_file(.env, .env.example, config.*, alembic.ini, Dockerfile, docker-compose.yml)
  - terminal(git diff docker-compose.yml)  # 本地个性化 vs 仓库版本
产出: 生产密钥是否占位符、DEBUG模式、CORS配置、数据库连接串、安全风险、docker-compose.yml本地改动详情
```

### 7. 文档与部署清单
```yaml
工具: search_files(target='files') 遍历 docs/, k8s/, deploy/, .github/workflows/
产出: 文档体系完整度、K8s清单、CI/CD流水线
```

### 8. Monorepo 多包扫描（新增）
```yaml
适用: pnpm/npm/yarn workspaces, turborepo, nx, lerna
工具: 
  - read_file(pnpm-workspace.yaml, nx.json, lerna.json, turbo.json)
  - read_file(packages/*/package.json, apps/*/package.json)
  - read_file(pnpm-lock.yaml 头部, package-lock.json 头部)
产出: 
  - 包管理器版本 (pnpm@9.15.0, yarn@4.x, npm@10.x)
  - 工作区模式 (shamefullyHoist/hooks/onlyBuiltDependencies)
  - 每个子包版本对比 (桌面版 vs Web版 vs 共享包 版本号)
  - 包大小速览 du -sh packages/* apps/*
  - 子包间依赖拓扑 (workspace:* 链接)
  - 检查 wasm/electron/esbuild 等 native 构建依赖是否单独声明
```

### 9. 数据库 Schema 分析（新增）
```yaml
时机: 读到 schema.ts / schema.sql / migrations/ 时
工具:
  - read_file(packages/db/src/schema.ts, prisma/schema.prisma, migrations/*.sql)
  - terminal(sqlite3 data/*.db ".tables" && "SELECT COUNT(*) FROM <each_table>")
  - grep table创建语句和FOREIGN KEY关系
产出:
  - 表清单与用途描述
  - 索引/全文搜索(FTS)配置
  - 主键/外键关系拓扑
  - 数据量统计 (每表行数)
  - 迁移历史 (Alembic/Prisma/Knex)
  - 关键设计决策: UUID vs auto-increment, 软删除策略, 版本号方案
```

### 10. CI/CD 流水线分析（新增）
```yaml
工具:
  - read_file(.github/workflows/*.yml, .gitlab-ci.yml, Jenkinsfile, .circleci/config.yml)
  - 关注点: 触发条件(on push/tag/PR), 矩阵构建, 产物上传, release流程
产出:
  - 构建矩阵 (OS/arch覆盖)
  - 发布流程 (draft/promote/auto-update/manifest处理)
  - 质量门禁 (lint/typecheck/test/perf budget)
  - 更新机制 (electron-updater manifests, Homebrew, Docker Hub)
  - 产物清单 (每个平台的安装包/更新清单/签名)
```

### 11. 运行时状态深入分析
```yaml
# A. PID 文件 vs 实际进程验证
step 1: PIDファイルが存在する場合
  - cat <pidfile>.pid → PID を取得
  - ps -p <PID> -o pid,stat,comm 2>/dev/null || echo "PID <PID> NOT RUNNING"
  # 注意: PIDファイルが存在してもプロセスが生きているとは限らない

# B. ポートバインディング確認
step 2:
  - ss -tlnp | grep <port> || echo "Port <port> NOT LISTENING"
  レース状態に注意: ポートが表示されないのは以下を示す
    (a) サービスが実行されていない
    (b) 異なるポートで実行されている（keepaliveスクリプトと実際の設定が一致しない）

# C. ヘルスチェック（HTTPサービスの場合）
step 3:
  - curl -s http://localhost:<port>/ | head -20 || echo "NO RESPONSE"
  - curl -s http://localhost:<port>/api/usage 2>/dev/null || echo "API unreachable"
  使用量データの確認（usage.jsonなど）
    → 過去の使用量がわかれば、実際に機能したことがあるか確認できる

# D. キープアライブ/自動化設定の解析
step 4: cron/保活スクリプトの確認
  - cat ~/company/scripts/keepalive.sh 2>/dev/null
    # プロジェクトの起動コマンドとポートを特定
  - crontab -l 2>/dev/null | grep <関連キーワード>
    # cronでの起動スケジュールを確認（毎分？毎時？手動？）
    # cronエントリがない場合：手動起動のみ
  - grep -rli '<キーワード>' ~/company/cron/ 2>/dev/null

  # 保活スクリプトのバグ特定
  - 注意: nohup で cd コマンドを使うバグ（cdはシェルビルトイン）
    # ❌ 間違い: nohup cd /path && python3 main.py &
    # ✅ 正解: nohup bash -c "cd /path && python3 main.py" &
  - SSHトンネル設定（serveo/localtunnel/cloudflared）
    # どのトンネルサービスを使っているか
    # トンネルが破損しているか（エラーログがないか）

step 5: 停止理由の推定
  以下に基づいて推定:
  (a) PIDファイルが残っているがプロセスが死んでいる → クラッシュ/OOM/手動停止
  (b) 保活スクリプト cd バグ → 起動できないまま
  (c) 依存ライブラリ不足 → 起動時のcrash
  (d) APIキー未設定 → 環境変数不足

step 6: ヘルスチェックエンドポイントの明示
  各プロジェクトのヘルスチェックエンドポイントパスを明示的に確認する：
  - curl -s http://localhost:<port>/docs     # FastAPI/Swagger
  - curl -s http://localhost:<port>/api/health
  - curl -s http://localhost:<port>/ping
  「デフォルトのヘルスチェック」と思い込まずにルート一覧で確認する

step 7: プロジェクト間依存関係の確認
  プロジェクトが他のサービスに依存している場合、そのサービスが動作しているかも確認する：
  ```yaml
  依存関係の種類:
    1. データ依存: PostgreSQL / MySQL / SQLite が存在しアクセス可能か
    2. API依存: 外部API(DeepSeek, OpenAIなど)のキーが設定されているか
    3. サービス依存: ゲートウェイ/認証サービスが稼働しているか
    4. トンネル依存: 公網アクセスが必要な場合、cloudflared/SSHトンネルが動作しているか
  ```
  確認方法:
  - cat .env または startup スクリプトで依存サービスのURLリストを取得
  - curl/sqlite3で各依存先の接続確認

step 8: ログファイルの最終行から直近の稼働状況を確認
  - tail -5 ~/company/logs/*<関連キーワード>* 2>/dev/null
  - tail -5 ~/company/logs/keepalive.log.*<関連>* 2>/dev/null
  # ログに有効な行がない（空行/たった1行のエラー）→ サービスが長期停止している
```

> **虚拟环境 vs 系统 Python 检测**：不要假设当前激活的 venv 就是生产运行环境。
> 1. 获取 `which python3` 和已激活 venv 路径
> 2. 检查 `start.sh` / `run.sh` / 部署脚本中使用的 Python 解释器路径
> 3. 分别检测：`python3 -c "import flask"`（系统） vs `source .venv/bin/activate && python3 -c "import flask"`（venv）
> 4. 如果脚本用裸 `python3` 而依赖只在 venv 中，标为 🟡 问题

### 11b. 项目元数据完整性审计（新增）

检查项目元数据文件（`pyproject.toml`, `package.json`, `Cargo.toml`, `setup.py`）与实际情况的一致性。元数据问题通常被忽略，但会影响搜索、发布和团队交接。

```yaml
# A. 包名 vs 目录名一致性
# 项目目录名可能与内部包名不同（如目录 llm-call-tracker, 包名 tracellm）
# 本身不是缺陷，但应在报告中注明差异，方便后续搜索时建立别名映射
工具:
  - read_file(pyproject.toml) → [project].name
  - read_file(package.json) → name
  - basename <project_root>
产出: 「项目目录名 vs 内部包名」对比表
  例: 目录=llm-call-tracker, 包名=tracellm → ⚠️ 别名映射

# B. 占位符 URL 检测
# 模板生成的项目元数据常见占位符: yourusername, YOUR_USERNAME, example.com, your-org, CHANGE_ME
工具:
  - grep -n 'yourusername\\|YOUR_USERNAME\\|example\\.com\\|your-org\\|CHANGE_ME\\|<your-' pyproject.toml package.json README.md 2>/dev/null
产出: 「检出占位符 → 需更新为实际 GitHub/文档链接」清单

# C. 依赖声明完整性 (pyproject.toml)
# 代码中 import 了但 pyproject.toml [project.dependencies] 未声明的包
# 注意: 函数体内的延迟导入 (def foo(): import weasyprint) 尤其容易被漏掉
# 注意: dashboard/server.py 可能依赖 fastapi/uvicorn 但只有系统级安装，未列在 pyproject.toml
工具:
  - grep -rhE '^import |^from ' dashboard/ tracellm/ 2>/dev/null | sed 's/^import //; s/^from //' | cut -d' ' -f1 | cut -d'.' -f1 | sort -u
  - cat pyproject.toml | grep -E '^[a-z]'  # 大致看 dependencies 段落
  - python3 -c "import toml; print(toml.load('pyproject.toml').get('project',{}).get('dependencies',[]))" 2>/dev/null
产出: 「已用未声明」「声明未使用」「声明已安装」三类清单

# D. 依赖声明完整性 (package.json)
# 类似检查
工具:
  - node -e "const p=require('./package.json'); console.log('deps:', Object.keys(p.dependencies||{}).join(' ')); console.log('devDeps:', Object.keys(p.devDependencies||{}).join(' '))"
  - 对比 src/ 中的 import/require 语句
产出: 同 C

# E. pyproject.toml 缺少 [project.optional-dependencies]
# 当项目有分离的功能模块（如核心库 vs dashboard）时，应将 dashboard 依赖放在
# optional-dependencies 中以便用户按需安装
工具:
  - 检查 pyproject.toml 是否有 [project.optional-dependencies] 段落
  - 搜索 scripts/example.py 或模块 import 判断哪些是可选功能
产出: 是否将额外功能（dashboard/CLI/导出）声明为可选依赖

# F. pyproject.toml classifiers 准确性
# Development Status 应与实际提交数/功能完整性匹配
# README 中声明的 features 应在 classifiers 中有对应条目
工具:
  - read_file(pyproject.toml) → [project].classifiers
  - git rev-list --count HEAD  # 实际提交数
产出: 🟡 Alpha 标签+1次提交 → 匹配，但 10+ 次提交后应升级 Beta
```

### 12. 生态系统上下文分析

プロジェクトが独立して存在する場合と、Eve社のようなマルチサービスエコシステムの一部として存在する場合がある。

```yaml
step 1: サービス一覧の確認
  - ls ~/company/ または companyエコシステムのサービスマップを確認
  - 製品ラインナップ: ls ~/company/products/
  - プロジェクト憲章: ls ~/project_charters/

step 2: 周辺サービスとのポート重複チェック
  # keepalive.sh から全サービスのポート割り当てを取得
  - cat ~/company/scripts/keepalive.sh 2>/dev/null | grep "check_and_start"
  # 以下の観点で分析:
  # (a) ポート衝突の可能性はないか
  # (b) 依存するサービスは動作しているか
  # (c) このサービスの停止がエコシステム全体に与える影響

step 3: プロジェクトのライフサイクル段階を推定
  以下の証跡からプロジェクトの成熟度を推定:
  - 初期フェーズ: 1 commitのみ、requirements.txtなし、READMEと実態に乖離
  - 成長フェーズ: 複数コミット、CI/CDあり、テンプレート化された起動設定
  - メンテナンスフェーズ: 多数の未コミット変更、スタブファイル、プロジェクト憲章との乖離
  
step 4: 自動化チェーンの全容把握
  該当プロジェクトが cron→keepalive→tunnel の自動化チェーンのどの位置にいるか:
  ```
  Cron → keepalive.sh → 起動コマンド → サービス起動 → トンネル → 公網公開
  ```
  各リンクの断絶ポイントを特定する:
  - cron エントリなし → 手動起動のみ
  - keepalive にエントリなし → cronからチェックされていない
  - 起動コマンドの cd バグ → nohupから起動できず永続的に停止
  - トンネルスクリプトのみ存在 → サービス起動が前提
```
Python 项目中，`pip list` 只能验证已声明的依赖是否安装，无法发现「已安装但未使用」的包。

```yaml
工具:
  # 提取所有 import 语句的顶层包名
  - python3 -c "
import ast
tree = ast.parse(open('app.py').read())
imports = set()
for n in ast.walk(tree):
    if isinstance(n, ast.Import):
        for alias in n.names:
            imports.add(alias.name.split('.')[0])
    elif isinstance(n, ast.ImportFrom) and n.module:
        imports.add(n.module.split('.')[0])
print('\n'.join(sorted(imports)))
"
  # 交叉比对 pip list 结果
  - pip list --format=freeze | cut -d= -f1 | sort -u
产出: 「已安装但未导入」的包列表——这些是潜在的冗余依赖，可精简或说明意图
```
```yaml
工具: ruff check, mypy, bandit, eslint
产出: Lint错误数、类型错误数、安全告警
```

## 变体：多项目组合扫描（Portfolio Scan）

当用户要求扫描**多个项目**（如 `/company/projects/` 下一组交付项目）时，采用以下扩展流程：

### 适用场景
- 「全面扫描company/projects目录下所有交付项目状态」
- 「盘点所有在运行项目」
- 「出个项目组合周报」

### 扩展扫描维度

```yaml
# 除标准 11 维度外，还需额外检查：

step A: 统一目录发现
  - ls -la <projects-root>
  - 每个项目并行: find . -type f | head -30; du -sh .

step B: 批量 Git 状态
  - 对每个项目: cd <项目> && git status 2>&1 || echo "NOT_A_GIT_REPO"
  - 统计: 有Git数 / 无Git数
  - 在报告顶部统一标注「N个项目无版本控制」为 🔴 共性问题

step C: 文件修改时间分析（活动性检测）
  目的: 检测项目是否活跃/停滞
  工具:
    - stat --format='%n | last modified: %y | size: %s' <项目目录>
    - find <项目> -type f -exec stat --format='%n|%y' {} \; | sort -t'|' -k2 -r | head -5
  解读:
    - 最近修改 ≥ 1个月前 → 🟡 可能停滞
    - 最近修改 ≥ 2个月前 → 🔴 已停滞/僵尸项目
    - 同时检查 Kanban 最后更新时间是否与文件修改时间匹配

step D: 关键状态文档优先读取
  每个项目读取最能反映状态的 2-3 个文件:
    1. README.md / 项目章程 — 项目目标和规模
    2. Kanban / Jira / tracking.json — 进度数据
    3. 预启动状态 / Check-list — 商务/启动状态

step E: Kanban/看板解析（结构化进度提取）
  工具:
    - Python re 模块按 `###` 分割模块段落
    - 从每个段落提取: 状态 / 人天 / 优先级 / 需求数
    - collections.Counter 按状态汇总
    - grep -c '\[x\]' 看板.md 和 grep -c '\[ \]' 看板.md 得到子任务完成率

step F: 商务条件检查（交付项目特有）
  - tracking.json 中的: contract_amount, downpayment, payment_received, start_date, end_date
  - 对比: 当前日期 vs 约定交付日 → 是否已过交付日?
  - 对比: 首付款应到账日 vs 实际到账 → 项目是否因款未到冻结?

step G: 跨项目对比报告生成
  格式:
    # 项目总览表（顶部）
    | 项目 | 大小 | Git | 最后修改 | 文件数 | 状态 |
    |------|------|-----|---------|-------|------|
    | 项目A | 116K | ❌ | 06-05 | 4 | 立项 |
    | 项目B | 76K | ❌ | 06-03 | 6 | 冻结 |
    | 项目C | 928K | ❌ | 07-01 | 82 | 开发中 |

    # 各项目详细状态（各有独立章节）

    # 总体诊断（结尾）
    **共性问题：**
    - ❌ 全部无Git版本控制
    - ❌ BookStack同步未验证
    - ⚠️ 某项目已过交付日

    **各项目风险：**
    - 🟡/🔴/🟢 健康度标签
```

### 多项目扫描独有的 Pitfalls

- **项目命名冲突参考文件**：扫描同名项目时，参考文件用更具体的名称区分（`haihang-scan` vs `dolphin-scan` vs `airline-v2-scan`）
- **跨项目状态标签不一致**：不同项目可能用不同的状态标签体系（`pre-launch` vs `ready_to_start` vs `pending` vs `待审批`）。应在报告中统一映射到 🟢🟡🔴 三级
- **超时风险**：多个项目并行扫描时，每个项目的构建/测试可能触发大量调用。建议先做信息采集（文件+Git+修改时间），再做深度检查（构建+测试）
- **冻结项目不要跳过**：即使项目未启动，也需要在报告中明确标注冻结原因（如「首付款未到账」），这本身是有价值的发现
- **合同交付日 vs 实际状态**：`tracking.json` 中的 `end_date` 可能已过——这是 🔴 级别的合同风险

### 参考示例

见 `references/multi-project-portfolio-scan-20260722.md` — 3个交付项目的完整组合扫描实战记录。
见 `references/zhixiang-zhizao-scan-20260722.md` — 无Git + SOP治理型项目（VERSION文件替代git log、备份频率分析、治理文档体系健康度、空占位目录检测、安全报告整合）。

## 工作流

### Phase 1: 并行信息采集（同时发起所有独立探测）
```yaml
step: 同时发送
  - terminal(git status + log + branch + remote + tag)
  - search_files(target='files', pattern='*') 
  - read_file(package.json, pyproject.toml, requirements.txt)
  - terminal(ls -la && du -sh)
```

### Phase 2: 依赖聚焦（基于 Phase 1 发现的技术栈）
```yaml
step: 按语言读取关键配置文件
  Python: pyproject.toml, requirements.txt, setup.py
  Node:   package.json, pnpm-lock.yaml, tsconfig.json
  Go:     go.mod, go.sum
  Rust:   Cargo.toml
  Docker: Dockerfile, docker-compose.yml
  K8s:    k8s/*.yaml, deploy/*.yaml
```

### Phase 3: 构建与测试探测
```yaml
step: 检查前端构建状态
  - npm install (若 node_modules 缺失)
  - npm run build
step: 检查后端
  - pip install (若 .venv 或依赖缺失)
  - pytest (若测试目录存在)
```

### Phase 4: 报告生成
```yaml
step: 聚合所有发现 → 生成结构化报告
  格式: Markdown，含以下章节

  # 项目概要表（顶部）
  | 项目 | 值 |
  |------|-----|
  | 项目名称 | |
  | 版本 | |
  | 许可证 | |
  | 仓库 | |
  | 包管理器 | |
  | Node 要求 | |
  | 磁盘总大小 | (含/不含 node_modules 分开列) |

  # 完整章节（按顺序）
  - 目录结构与文件清单
  - Git 状态 (含 divergence)
  - 依赖配置审计
  - 构建状态 (含产物存在性)
  - 测试状态
  - 配置与安全审查
  - 文档与部署清单
  - Monorepo 多包扫描（如适用）
  - CI/CD 流水线分析

  # 健康检查汇总表（结尾）
  | 检查项 | 状态 | 详情 |
  |--------|------|------|
  | 项目文件完整性 | ✅/⚠️/❌ | |
  | Git 版本控制 | ✅/⚠️/❌ | |
  | 依赖安装 | ✅/❌ | |
  | 构建产物 | ✅/❌ | |
  | 配置完整性 | ✅/⚠️/❌ | |
  | 测试框架 | ✅/❌ | |
  | 文档 | ✅/⚠️/❌ | |
  | 部署配置 | ✅/❌ | |
  | CI/CD 流水线 | ✅/❌ | |

  # 关注事项
  - 按严重程度列出所有待处理项
  - 每项附处理建议 (git pull / pnpm build / git commit / etc.)
```

## 常用命令速查

```bash
# 项目信息
du -sh <project>              # 总大小
du -sh frontend/dist/         # 前端构建产物大小
ls -la haihang.db             # 数据库文件大小

# Git
git status                    # 当前工作区状态
git log --oneline -20         # 最近20条commit
git log --format='%aN' | sort -u  # 贡献者列表
git rev-list --count main     # 总commit数
git diff --stat HEAD          # 未提交修改概览
git tag -l                    # 所有标签

# 依赖
source .venv/bin/activate && pip list | grep -iE "<package>"
cat frontend/node_modules/.package-lock.json 2>/dev/null || cat frontend/package-lock.json

# 测试
pytest --tb=short -q          # 快速测试
pytest --cov=backend --cov-report=term   # 含覆盖率
npm test 2>&1 | tail -20      # 前端测试

# 构建
npm run build                 # 前端构建
tsc -b && vite build          # TypeScript + Vite 构建
```

## Pitfalls

- **大项目超时**: 超过500个文件的git log或大规模构建需要设置足够timeout(120s+)
- **测试依赖**: pytest前确保虚拟环境已激活；npm test前确保node_modules存在
- **数据库状态**: haihang.db等SQLite文件被.gitignore排除，但扫描时仍可见——注意区分测试数据与生产数据
- **远端缺失**: 无remote origin时，git push/checkout会有问题——报告中应注明
- **未提交修改**: 扫描时的未提交修改会影响测试结果（失败可能来自脏工作区而非主线）
- **PyCache/Build产物**: `__pycache__`, `.venv`, `node_modules` 等目录会显著增大 du 统计——这些应被.gitignore排除，但 du -sh 不关心
- **并行探测**: 独立的信息采集应并行发起（同一次回复中多个工具调用），互不依赖的检查不要串行化
- **报告格式**: 如果用户指定语言（中文），优先用该语言生成报告；报告应包含🧪/✅/🔴/⚠️等视觉标记便于快速扫描
- **Monorepo 版本裂化**: monorepo 中子包版本可能不一致（desktop @0.5.5 vs web @0.1.0），报告中应逐包列出
- **pnpm shamefullyHoist**: 设置为 true 时依赖可能被意外提升，某些包在运行时可能找不到预期版本。扫描时应检查并标注
- **CI/CD release 流程分析**: `release.yml` 可能有复杂的 Draft/Promote 机制、更新清单合并脚本、架构校验步骤——需逐步骤阅读而非跳过
- **仓库仅有单分支**: main 分支之外无 develop/release 分支时，所有 v0.5.6+ 的工作可能在 tag 上而非分支上——需检查 `git log --all`
- **Venv 与系统 Python 不匹配**: `start.sh` 可能使用裸 `python3`（系统环境）但依赖安装在 venv 中。先用 `which python3` 确认当前环境，再检查脚本中 PYTHON 的解释器路径是否一致
- **无 Git 的项目**: 不是所有项目都有版本控制。`git status` 失败后不要强行继续，而是把「无版本控制」作为 🔴 级别发现写入报告头部
- **参考文件命名冲突**: 扫描同名不同项目时（如两个 "PromptHub"），不要覆盖已有参考文件——加新文件并用更具体的名区分（`prompthub-monorepo` vs `prompthub-server`）
- **运行中服务检测**: 先检查端口是否已监听（`ss -tlnp | grep <port>`），避免因服务已运行而误判构建/启动状态
- **AST 安全扫描**: 静态分析时可以顺手扫 eval/exec，这是 $0 的安全加分项
- **docker-compose.yml 本地个性化**: 开发者本地改端口/密码/环境变量是脏工作区最常见来源。扫描时需 `git diff docker-compose.yml` 并在报告中单独标注为"本地配置覆盖"，与代码改动分开列。
- **构建产物不存在 ≠ 项目不健康**: dist/ 不存在只是意味着尚未构建。报告中应逐包列出产物状态（core: ❌ / ui: ❌ / web: ❌ / mcp-server: ❌），让 reader 知道首次构建的工作量。
- **Git divergence 易被忽略**: `git status` 默认不显示落后远程 commits 数。需单独 `git rev-list --count HEAD..origin/<branch>`。落后 40+ commits 时应标注为 ⚠️ 并建议 `git pull`。
- **Electron 子包 du 占比畸高**: desktop 子包的 electron + chromedriver 可能占项目 90%+ 总空间。扫描时对 desktop 子包单独 `du -sh` 可帮助排查磁盘占用。报告中应将 node_modules (829M) 与源代码 (95M) 分开列。
- **指定路径不存在时的路径发现**: 用户给的项目路径可能不存在。不要直接报告"项目不存在"——用 `search_files` 全局搜索、查 keepalive 脚本、查 cron、查 PID 文件、查相关业务文档来反向定位真实路径。在报告中包含完整的「发现路径」说明。
- **README 与现状的差异检查**: README 中声明的能力（如"有 requirements.txt"）与实际文件体系可能存在差距。扫描时应将 README 中提及的文件与磁盘上的实际文件逐项交叉比对，产出「文档声明 vs 实际情况」差异清单。
- **PID 文件可能过时**: 进程结束后 PID 文件不会被自动清理。`cat xxx.pid` + `ps -p <pid>` 是检查服务是否真正在运行的标准方法。不要仅凭 PID 文件的存在判断服务状态。
- **Keepalive 脚本的 cd bug**: `nohup cd /path && python3 main.py` 是错误的——`cd` 是 shell builtin，`nohup` 直接执行会失败。正确的写法是 `nohup bash -c "cd /path && python3 main.py"`。扫描时应检查 keepalive 脚本中的启动命令格式。
- **保活机制的全链路验证**: 不要只看 keepalive 脚本本身——需要检查 (a) cron 条目是否存在 (b) cron 指向的脚本路径是否正确 (c) 脚本内的启动命令是否正确 (d) 日志是否有错误输出。每个环节都可能断链。
- **单次使用量可作为功能验证信号**: 如果 `usage.json` 有使用记录（如 3 次免费额度已用完），说明该服务曾经正常运行过。结合日志时间戳可推断停止运行的大致时间。
- **项目在多服务生态系统中的定位**: 项目可能不是独立存在的——需要检查 keepalive 脚本中周围其他服务的端口分配，了解该项目在整个系统中的角色（产品线/辅助工具/实验原型）。
- **公网隧道配置检查**: 如果项目有 tunnel.py / deploy_windows.bat 等公网暴露机制，需检查：
  - 隧道服务是否可用（serveo.net 可达？cloudflared 已安装？）
  - 隧道启动命令是否有效
  - `.public_url` 文件是否存在（表示曾成功部署过）
  - 报告中注明「内网可达」还是「公网可达」<｜end▁of▁thinking｜>

<｜｜DSML｜｜tool_calls>
<｜｜DSML｜｜invoke name="skill_manage">
<｜｜DSML｜｜parameter name="name" string="true">project-status-scan

## References

| 文件 | 内容 |
|------|------|
| `references/haihang-ticketing-scan-20260722.md` | 海航AI购票助手完整扫描示例报告 |
| `references/prompthub-scan-20260722.md` | PromptHub 完整扫描示例报告（pnpm monorepo 扫描实操） |
| `references/prompthub-server-scan-20260722.md` | PromptHub Server 扫描示例（Flask 单文件 + 无 Git 项目扫描实操） |
| `references/freelancer-tool-scan-20260722.md` | Freelancer Tool 扫描示例（路径发现 + 保活机制分析 + 生态系统上下文） |
| `references/tracellm-scan-20260722.md` | tracellm 扫描示例（Python 库包: 元数据完整性、依赖声明缺失、Dashboard 未追踪、timeout 半实现） |
| `references/zhixiang-zhizao-scan-20260722.md` | 智项智造扫描示例（无Git + SOP治理型项目: VERSION文件替git log、备份频率分析、治理文档体系健康度、空占位目录、安全报告整合） |
