# secrets-vault-manager — Reference

## Overview
密钥/凭证集中管理 — HashiCorp Vault/Mozilla SOPS/SealedSecrets操作，密钥轮换策略，加密/解密工作流，访问审计。触发词："vault"/"secrets"/"sops"/"密钥管理"/"credential management"/"sealed secrets"/"密钥轮换"。

## Integration Points
- Hermes Agent skill ecosystem
- evolution_engine.py scoring system
- self-audit verification

## Key Resources
- SKILL.md: main skill definition
- scripts/: executable code (if present)
