---
name: secrets-vault-manager
description: 密钥/凭证集中管理 — HashiCorp Vault/Mozilla SOPS/SealedSecrets操作，密钥轮换策略，加密/解密工作流，访问审计。触发词："vault"/"secrets"/"sops"/"密钥管理"/"credential management"/"sealed secrets"/"密钥轮换"。
depends_on: []
related_skills:
  - secret-scanner
  - terraform-generator
  - k8s-deployer
category: devops
triggers:
  - "vault"
  - "secrets management"
  - "sops"
  - "密钥管理"
  - "credential management"
  - "sealed secrets"
  - "密钥轮换"
  - "hashicorp vault"
  - "encrypt secrets"
---

# Secrets Vault Manager — 密钥/凭证集中管理


## Overview

Brief description of this skill's purpose and capabilities.
密钥全生命周期管理：存储、加密、轮换、审计。支持 HashiCorp Vault / SOPS / SealedSecrets。

## Trigger Conditions

Load this skill when:
- User asks for secrets management
- Encrypt/decrypt configuration files
- Vault setup or operation
- Key rotation policy
- Secrets audit/review
- Secret migration

## Workflow

### 1. Choose Secrets Backend

| Backend | Scope | Best For |
|---------|-------|----------|
| HashiCorp Vault | Dynamic/static secrets, PKI, transit | Enterprise, multi-service |
| Mozilla SOPS | Encrypted files in git | GitOps, small teams |
| SealedSecrets | K8s-native encrypted secrets | Kubernetes deployments |
| envchain | macOS keychain | Personal dev machines |

### 2. SOPS Workflow (GitOps)

```bash
# Install SOPS
curl -LO https://github.com/getsops/sops/releases/latest/download/sops-linux-amd64
sudo mv sops-linux-amd64 /usr/local/bin/sops && chmod +x /usr/local/bin/sops

# Create .sops.yaml config
cat > .sops.yaml << 'EOF'
creation_rules:
  - path_regex: secrets/.*\.yaml
    kms: 'arn:aws:kms:us-east-1:ACCOUNT:key/KEY-ID'
    pgp: 'FINGERPRINT'
  - path_regex: secrets/.*\.env
    encrypted_regex: '^(.*)$'
EOF

# Encrypt file
sops --encrypt config.yaml > config.enc.yaml

# Edit encrypted file (auto-decrypts + re-encrypts)
sops config.enc.yaml

# Decrypt for use
sops --decrypt config.enc.yaml > config.yaml
```

### 3. HashiCorp Vault

```bash
# Start Vault in dev mode (development only!)
vault server -dev -dev-root-token-id=root

# Store a secret
vault kv put secret/myapp/database username=admin password=s3cret

# Read a secret
vault kv get secret/myapp/database

# List secrets
vault kv list secret/myapp/

# Dynamic secret (database credential rotation)
vault read database/creds/my-role

# Vault policy
cat > app-policy.hcl << 'EOF'
path "secret/data/myapp/*" {
  capabilities = ["read", "list"]
}
EOF
vault policy write myapp app-policy.hcl
```

### 4. SealedSecrets (K8s)

```bash
# Install controller
kubectl apply -f https://github.com/bitnami-labs/sealed-secrets/releases/latest/download/controller.yaml

# Install kubeseal CLI
go install github.com/bitnami-labs/sealed-secrets/cmd/kubeseal@latest

# Create sealed secret
kubectl create secret generic my-secret --dry-run=client --from-literal=password=mypassword -o json > secret.json
kubeseal --format yaml < secret.json > sealed-secret.yaml

# Apply to cluster
kubectl apply -f sealed-secret.yaml

# The sealed secret can be committed to git — only the controller can decrypt it
```

### 5. Key Rotation Strategy

```bash
# Audit existing secrets (find age of each)
python3 -c "
import os, time
from pathlib import Path

secrets_dir = Path('.')
for f in secrets_dir.rglob('*.enc.*'):
    age_days = (time.time() - f.stat().st_mtime) / 86400
    status = '⚠️  ROTATE' if age_days > 90 else ('⚠️  Review' if age_days > 60 else '✓ OK')
    print(f'{status}: {f} ({age_days:.0f} days)')
"

# Rotation policy recommendations:
# - API keys: Every 90 days
# - Database passwords: Every 180 days
# - TLS certificates: Every 365 days (or use LetsEncrypt 90-day auto)
# - SSH keys: Every 365 days or upon team member departure
```

### 6. Audit & Compliance

```bash
# List all secret paths (Vault)
vault kv list -detailed secret/

# Check SOPS file encryption status
for f in $(find . -name "*.enc.*" -o -name "*.sops.*"); do
    echo "$f: $(sops --decrypt $f 2>/dev/null | wc -l) lines"
done
```

## Pitfalls

1. **Vault dev mode**: `vault server -dev` stores everything in memory and resets on restart. Never use in production.
2. **SOPS key management**: If you lose the KMS key or PGP key, ALL SOPS-encrypted files are unrecoverable. Back up keys separately.
3. **Git history leaks**: Committing unencrypted secrets then encrypting later doesn't remove them from git history. Use `git filter-repo` after accidental commit.
4. **Vault auto-unseal**: Production Vault requires Unseal Key setup (Shamir's Secret Sharing). Use auto-unseal (KMS/Azure Key Vault) for convenience.
5. **SealedSecrets version drift**: The SealedSecret format is bound to controller version. On upgrade, old sealed secrets may not decrypt.
6. **Secret rotation at scale**: Rotating secrets across 50+ services requires automation. Consider Vault dynamic secrets for database credentials.

## Verification

```bash
# Verify SOPS setup
echo 'test: secret123' > /tmp/test-sops.yaml
sops --encrypt --in-place /tmp/test-sops.yaml 2>/dev/null && \
  sops --decrypt /tmp/test-sops.yaml 2>/dev/null | grep -q secret123 && \
  echo "✓ SOPS encrypt/decrypt working" || echo "✗ SOPS failed (needs KMS/PGP config)"
rm -f /tmp/test-sops.yaml
```

## Integration

- **k8s-resource-manager**: Inject secrets as K8s Secrets from Vault
- **terraform-manager**: Manage secrets via Terraform Vault provider
- **secret-scanner**: Audit for secrets that should be in Vault but are hardcoded
- **incident-commander**: Secret leak as incident trigger, auto-rotate
