# Eve(伊芙科技) 知识库实现参考

## 一、BookStack API 陷阱与技巧

### 1.1 Shelf操作：PUT会替换全部书籍

**陷阱**: `PUT /api/shelves/{id}` 的 `books` 参数会**替换**而非追加所有书籍。

```python
# ❌ 错误: 只传入新书ID, 原有书籍被删除
api('PUT', '/shelves/2787', {"books": [3000]})  
# → Shelf 只剩下 book 3000

# ✅ 正确: 先读取当前 books, 合并后再写入
shelf = api('GET', '/shelves/2787')
current_books = [b['id'] for b in shelf.get('books', [])]
all_books = list(set(current_books + new_book_ids))
api('PUT', '/shelves/2787', {"books": all_books})
```

### 1.2 页面查询：/api/books/{id}/pages 返回HTML而非JSON

**正确端点**: `GET /api/pages?count=500` 返回JSON列表

**注意**: BookStack的 `/api/pages` 的 `book_id` 查询参数**不生效**。需在客户端过滤：

```python
# ❌ book_id 参数不生效
pages = api('GET', '/pages?book_id=2788&count=100')

# ✅ 正确: 获取全部页面后在客户端过滤
pages = api('GET', '/pages?count=500')
eve_pages = [p for p in pages.get('data', []) if p.get('book_id') >= 2788]
```

### 1.3 页面创建/更新的响应格式

**创建/更新页面**返回的是扁平JSON对象，不是 `{data: page}` 包裹格式：

```python
result = api('POST', '/pages', {"name": "...", "html": "...", "book_id": 2788})
# result['id'] ✅ 直接可用
# result['data']['id'] ❌ 不存在
```

### 1.4 分页限制

`/api/pages?count=500` 每次最多返回500条。总页数超过500时需使用 offset 分页：

```python
page1 = api('GET', '/pages?count=500&offset=0')
page2 = api('GET', '/pages?count=500&offset=500')
```

### 1.5 安全限制

- BookStack会剥离 `<style>` 标签 → 全部使用 `style=""` 内联属性
- `box-shadow` CSS属性会被剥离 → 使用 `border` + 背景对比色替代
- 只发送body内容（无 `<!DOCTYPE>`/`<html>`/`<head>`包装）

## 二、卡通动漫风格应用

### 2.1 核心样式常量

```python
# 暖白英雄卡
STYLE_HERO = "text-align:center;padding:30px 20px;background:#fff8f0;border:3px solid #333;border-radius:16px;margin-bottom:24px;"

# 紫色H2标题（左边框）
STYLE_H2 = "border-left:5px solid #6c5ce7;padding-left:12px;color:#2d3436;margin-top:24px;font-size:1.3em;font-weight:bold;"

# 绿色H3标题（左边框）
STYLE_H3 = "color:#6c5ce7;margin-top:18px;font-size:1.1em;font-weight:600;border-left:4px solid #00b894;padding-left:12px;"

# 紫色表头
STYLE_TH = "background:#6c5ce7;color:#fff;padding:8px 12px;text-align:left;font-weight:bold;"

# 深色代码块
STYLE_PRE = "background:#2d3436;color:#dfe6e9;border-radius:8px;padding:12px;overflow-x:auto;font-size:0.9em;"

# 星星分割线
STYLE_DIVIDER = "text-align:center;font-size:1.2em;color:#b2bec3;margin:20px 0;letter-spacing:8px;"
```

### 2.2 Emoji自动映射

根据页面名称自动匹配emoji和标签分类：

```python
EMOJI_MAP = {
    "合同": ("📝", "合同"), "商业模式": ("💰", "商业模式"),
    "项目": ("📦", "项目"), "脚本": ("⚙️", "脚本"),
    "品牌": ("🎨", "品牌"), "组织": ("🏛️", "组织"),
    "线索": ("🔍", "线索"), "报价": ("💰", "报价"),
    "财务": ("💹", "财务"), "管道": ("📊", "管道"),
    "内容": ("📝", "内容"), "报告": ("📋", "报告"),
    "SOP": ("📋", "SOP"), "模板": ("📄", "模板"),
}
```

### 2.3 徽章颜色按书籍区分

```python
if book_id in (财务书ID, 商业书ID):
    badge_color = "#b5e7a0"  # 绿色
elif book_id in (运营书ID, 销售书ID):
    badge_color = "#a8d8ff"  # 蓝色
else:
    badge_color = "#d4b8ff"  # 紫色(默认)
```

## 三、文件→BookStack自动同步引擎

### 3.1 架构模式

```
~/company/ 文件变更
     ↓ 检测mtime
增量同步脚本 (每3h Cron)
     ↓ 匹配路径→对应Book
BookStack API 创建/更新页面
     ↓
状态文件 (~/.hermes/state/eve-kb-sync.json)
     ↓
下次运行只同步更新的文件
```

### 3.2 关键实现

```python
# 状态追踪: 记录每个文件的mtime
state = {"files": {"相对路径": mtime_timestamp}, "last_sync": "ISO时间"}

# 匹配: 关键字映射
BOOK_MAP = {
    "contracts/": 项目书ID,   # 包含路径关键词→对应Book
    "leads/": 销售书ID,
    "reports/finance": 财务书ID,
}

# 增量检测
if rel_path in state['files'] and state['files'][rel_path] >= current_mtime:
    return False  # 无变更, 跳过
```

### 3.3 文件过滤模式

```python
WATCHED_PATTERNS = [
    "*.md", "*.json",  # 通用文档
    "contracts/*.md",  # 合同
    "leads/**/*.md",   # 客户线索(递归)
    "quotes/*.md",     # 报价
    "reports/*.json",  # 报告数据
]
```

## 四、回滚经验教训

- **根本原因**: PUT shelves时未保留原有书籍ID列表
- **修复**: 用GET读取当前books, 合并新ID后再PUT
- **验证**: 每次PUT后立即GET验证书籍列表完整性
- **原则**: 对BookStack API的PUT操作, 始终先GET当前状态再修改
