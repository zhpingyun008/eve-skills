# BookStack API Shelf Pitfalls

## PUT /api/shelves/{id} — Books参数是替换而非追加

### 问题
当使用 `PUT /api/shelves/{id}` 更新书架时，`books` 参数会**完全替换**书架的书籍列表，而非追加。

### 错误示例
```python
# ❌ 这会丢失书架原有的所有书籍
api('PUT', '/shelves/2787', {
    "name": "Eve知识库",
    "books": [1417, 1418, 3000]  # 只传了新书ID
})
# 结果: 书架2787只剩这3本书，原有的8本书全部丢失
```

### 正确做法
```python
# ✅ 先读取现有书籍，再合并新书
shelf = api('GET', '/shelves/2787')
current_ids = [b['id'] for b in shelf.get('books', [])]
all_ids = list(set(current_ids + new_book_ids))  # 合并+去重

api('PUT', '/shelves/2787', {
    "name": shelf['name'],
    "description": shelf.get('description', ''),
    "books": all_ids  # 包含所有新旧书籍
})
```

### 根因
BookStack API 的 PUT 是幂等操作 — 它设定期望状态，不做增量更新。`books` 参数表达的是"这个书架应该包含这些书"，不是"给这个书架加这些书"。

### 预防措施
1. 修改书架前，先用 `GET /api/shelves/{id}` 获取当前完整状态
2. 始终在 `books` 数组中保留所有现有书籍 ID
3. 测试时先在 dry-run 模式下打印新的 books 列表再执行
4. 可以在脚本中使用 `list(set(old_ids + new_ids))` 确保幂等安全

## BookStack API Pagination

`GET /api/pages?count=N` 返回最多 N 条记录，且 N 有上限（500）。
当 total > N 时，需要通过 offset 参数翻页：
```python
pages = api('GET', '/pages?count=500&offset=500')  # 第二页
```

`book_id` 参数在 `/api/pages` 端点上不总是生效 — 返回的数据可能包含其他 book 的 page。需在客户端过滤：
```python
eve_pages = [p for p in all_pages if p.get('book_id', 0) >= 2788]
```

## BookStack API 分页数据获取

当 total > 500 时，需要多次请求：
```python
def get_all_pages():
    all_data = []
    offset = 0
    while True:
        result = api('GET', f'/pages?count=500&offset={offset}')
        data = result.get('data', [])
        if not data:
            break
        all_data.extend(data)
        offset += 500
    return all_data
```
