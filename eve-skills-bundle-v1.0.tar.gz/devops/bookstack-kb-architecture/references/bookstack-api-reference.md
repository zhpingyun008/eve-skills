# BookStack API Endpoint Reference

## Page Listing (The Trap)

**WRONG**: `GET /api/books/{id}/pages` → returns HTML, not JSON
**RIGHT**: `GET /api/pages?count=500` → returns JSON, filter by `book_id` client-side

```python
def find_page_by_name(book_id, name):
    pages = api('GET', '/pages?count=500')
    if not pages:
        return None
    for p in pages.get('data', []):
        if p.get('book_id') == book_id and p['name'] == name:
            return p
    return None
```

## Create/Update Response Format

Contrary to some other BookStack endpoints, page create/update returns the page object **directly**, not wrapped in `data`:

```python
# POST /api/pages returns:
# {'id': 123, 'name': 'My Page', 'slug': 'my-page', ...}   ✅ direct object
# NOT: {'data': {'id': 123, ...}}                            ❌ no wrapper

result = api('POST', '/pages', payload)
if result and 'id' in result:          # Check 'id' directly
    page_id = result['id']
```

## Page Name Uniqueness

Within a book, page names must be unique. Using the same name updates (overwrites) the existing page. This is useful for "sync" workflows but dangerous if you expect to create duplicates.

## Useful Endpoints

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/api/shelves` | GET | List all shelves |
| `/api/shelves/{id}` | GET | Get shelf details |
| `/api/shelves` | POST | Create shelf (name, description) |
| `/api/books` | GET | List all books (use `?shelf_id=N` to filter) |
| `/api/books` | POST | Create book (name, description, shelf_id) |
| `/api/pages?count=500` | GET | List pages (filter by book_id client-side) |
| `/api/pages` | POST | Create page (name, html, book_id, slug) |
| `/api/pages/{id}` | PUT | Update page (name, html, slug) |
| `/api/pages/{id}` | GET | Read page content (html field) |
| `/api/chapters` | POST | Create chapter (name, description, book_id) |
| `/api/chapters/{id}` | GET | Get chapter with pages |

## Bulk Sync Pattern

For syncing a local directory to BookStack:

1. Walk source directory, collect files by mtime
2. Check state file for previously-synced files
3. Skip if mtime unchanged (incremental)
4. Markdown→HTML conversion, JSON→pre/code formatting
5. Create or update page (name-based dedup)
6. Track mtime in state file
7. Cron every 3 hours, silent when no changes
