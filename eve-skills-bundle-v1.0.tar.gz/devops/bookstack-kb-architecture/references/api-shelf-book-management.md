BookStack API 端点注意：
1. **❌ `/api/books/{id}/pages` 返回HTML页面，不是JSON！** 要用 `/api/books/{id}` 获取包含 contents 数组的JSON响应。
2. Shelf创建：POST /api/shelves → PUT /api/shelves/{id} 分配books → POST /api/books → POST /api/pages
3. 创建book时shelf_id参数不会自动绑定book到shelf，需要通过PUT更新shelf的books数组。
4. 批量查询页面：使用 `/api/books/{id}` 的 contents 字段（type=page）做重复检测。
5. 创建page用 `markdown` 字段或 `html` 字段，内容用 `<pre>` 标签包裹可保留原始格式。