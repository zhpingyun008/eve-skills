# BookStack API 已知陷阱与模式

## 页面列表: book_id 过滤失效
`GET /api/pages?count=N` 返回**所有书**的页面，`book_id` 参数被忽略。
必须在客户端过滤：
```python
pages = api('GET', '/pages?count=500')
my_pages = [p for p in pages.get('data', []) if p.get('book_id') == MY_BOOK_ID]
```
`count` 最大 500，通过 `total` 判断是否需分页：
```python
data, offset = [], 0
while True:
    r = api('GET', f'/pages?count=500&offset={offset}')
    data.extend(r.get('data', []))
    if len(data) >= r.get('total', 0):
        break
    offset += 500
```

## 响应格式不统一
| 端点 | 返回格式 | 示例 |
|------|---------|------|
| `POST /api/pages` | 直接对象 | `{"id": 2919, "name": "..."}` |
| `POST /api/chapters` | 直接对象 | `{"id": 2982, "name": "..."}` |
| `GET /api/pages` | 包装在 `data` | `{"data": [...], "total": N}` |
| `GET /api/chapters` | 包装在 `data` | `{"data": [...], "total": N}` |
| `GET /api/shelves/{id}` | 直接对象 | `{"id": N, "books": [...]}` |
| `PUT /api/shelves/{id}` | 直接对象 | `{"id": N, "books": [...]}` |
| `GET /api/pages/{id}` | 直接对象 | `{"id": N, "html": "..."}` |

**判断方法**: 检查 `id` 字段在顶层还是在 `data` 层。

## 多书架交叉引用（2026-05 发现）
一个 Book 可属于多个 Shelf。`PUT /api/shelves/{id}` 的 `books` 数组接受任何 Book ID，包括其他 Shelf 的 Book：
```python
api('PUT', '/shelves/2787', {
    "books": [1417, 1418, 2788, 2789]  # 混入其他Shelf的Book
})
```
这创建了交叉引用，不改变 Book 的原属 Shelf。

## 章节与页面归属
- `POST /api/chapters`: `{"book_id": N, "name": "章节名", "description": "..."}` → `{"id": N}`
- `PUT /api/pages/{id}`: `{"chapter_id": N}` → 将页面移入章节
- 章节创建后，通过 API 获取 Book 详情时可看到 nested pages 结构

## 已知限制
1. API 无批量操作端点 — 每页面/每章节需单独 API 调用
2. `PUT /api/pages/{id}` 更新 `html` 会触发页面修订版本增加
3. 删除页面谨慎操作 — 无回收站恢复机制（通过 API 直接 DELETE）
4. Token 永不过期，但需在 `.env` 中配置 `APP_API_TOKEN` 才能生效
