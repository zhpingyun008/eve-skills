# Empty Book Detection & Systematic Filling (Phase 7)

## When To Use
- User reports "有些书是空的/有些书没有页面"
- CMMI5 project audit reveals zero-page books (e.g., 10 project phase books with 0 pages)
- After initial shelf creation, content is missing
- "BookStack内容为空 / 页面空白 / 书架不显示 / 书架显示空"

## Phase 7.1: Discover Empty Books via API

```python
import urllib.request, json

AUTH = f"Token {TOKEN_ID}:{TOKEN_SECRET}"
BASE = "http://localhost:8080/api"

def api(method, path):
    req = urllib.request.Request(f"{BASE}{path}",
        headers={'Authorization': AUTH}, method=method)
    resp = urllib.request.urlopen(req, timeout=15)
    return json.loads(resp.read().decode())

shelf = api('GET', f'/shelves/{SHELF_ID}')
books = shelf.get('contents', [])

empty_books = []
for b in books:
    book = api('GET', f'/books/{b["id"]}')
    pages = [c for c in book.get('contents', []) if c.get('type') == 'page']
    chapters = [c for c in book.get('contents', []) if c.get('type') == 'chapter']
    chapter_pages = 0
    for ch in chapters:
        ch_detail = api('GET', f'/chapters/{ch["id"]}')
        chapter_pages += len(ch_detail.get('contents', []))
    total_pages = len(pages) + chapter_pages
    if total_pages == 0:
        empty_books.append({'id': b['id'], 'name': b['name']})
```

## Phase 7.2: Categorize & Fill Empty Books

Standard page template per phase book:

```python
PHASE_TEMPLATES = {
    "00-项目立项": ["项目立项流程与可行性分析", "graph TD流程图+可行性分析表格+章程模板"],
    "01-市场调研": ["市场深度调研与竞品分析", "pie图表+mindmap用户画像+竞品分析矩阵"],
    "02-需求分析": ["用户需求与系统需求规格说明书", "graph LR用户故事+flowchart TD非功能需求"],
    "03-架构设计": ["系统架构与详细设计说明书", "flowchart TB四层架构+erDiagram ER模型"],
    "04-开发实现": ["编码实现与技术选型文档", "graph TD技术栈+sequenceDiagram流程"],
    "05-测试验证": ["全流程测试用例与测试报告", "graph TB测试金字塔+stateDiagram-v2"],
    "06-交付部署": ["部署方案与上线检查清单", "flowchart LR部署架构+CI/CD流水线"],
    "07-运维监控": ["运维手册与监控告警方案", "graph TB监控架构+故障预案流程图"],
    "08-项目管理": ["项目计划与过程管控文档", "mindmap WBS+gantt里程碑甘特图"],
    "09-合规安全": ["合规审查与安全保障方案", "graph TB合规框架+flowchart LR安全架构"],
}
```

Each page must contain:
- 2-3 Mermaid diagrams
- Structured tables (kb-table / kb-table-anime)
- Card elements (kb-card-comic / kb-card-glass)
- Badge tags (kb-badge)
- 2000-5000 chars substantive content

## Phase 7.3: Batch Creation

Split into batches of 3-4 books per script to avoid timeouts:

```python
# create_pages_batch1.py
def api_post(path, data):
    body = json.dumps(data).encode('utf-8')
    req = urllib.request.Request(f"{BASE}{path}", data=body,
        headers=HEADERS, method='POST')
    try:
        resp = urllib.request.urlopen(req, timeout=30)
        return json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        return None

pages = [
    {"book_id": 403, "name": "📋 项目立项...", "html": "<style>...</style><div class=...>"},
    # ...
]

for p in pages:
    result = api_post('/pages', p)
    time.sleep(0.3)
```

## Pitfalls
1. API rate limit ~4 req/s — add 0.25-0.3s sleep
2. Split into batches of 3-4 per script (delegate_task 600s timeout)
3. Mermaid: `--&gt;` for arrows, `\\n` for line breaks
4. Page names must be unique per book
5. Verify Book IDs before assuming (query /api/books first)
