# chaos-engineer — Reference

## Overview
Chaos engineering — inject failures (network latency, pod kill, CPU stress) to validate system resilience. Litmus/ChaosMesh patterns.

## Integration Points
- Hermes Agent skill ecosystem
- evolution_engine.py scoring system
- self-audit verification

## Key Resources
- SKILL.md: main skill definition
- scripts/: executable code (if present)
