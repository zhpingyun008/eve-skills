---
name: chaos-engineer
description: Chaos engineering — inject system-level failures (CPU, memory, disk, process) to validate resilience. Pure Python stdlib, WSL/Docker/K8s compatible.
depends_on: []
related_skills:
  - incident-commander
  - self-healer
category: devops
triggers:
  - "混沌工程"
  - "chaos engineering"
  - "故障注入"
  - "resilience testing"
  - "故障演练"
  - "system resilience"
  - "压力测试"
  - "stress testing"
---

## Overview

Validate system resilience through controlled failure injection. This skill was used to perform a weekly resilience drill, including the following steps:

1. Baseline check using `verify_resilience.py`
2. Injected CPU stress using `cpu_stress.py`
3. Healer check using `orchestrator.py --check`
4. Post-check using `verify_resilience.py`

The drill was successful, with the system recovering as expected after the stress was removed.

Auto-validated skill providing structured execution and output generation for the Hermes agent system.


# chaos-engineer — 混沌工程

Validate system resilience through controlled failure injection.  
**WSL-ready** — 无需Docker/K8s，纯Python stdlib实现。

## Scripts

| 脚本 | 功能 | CLI |
|------|------|-----|
| `cpu_stress.py` | CPU压力测试 | `--workers N --duration N --run` |
| `mem_stress.py` | 内存压力测试 | `--size MB --duration N --run` |
| `disk_stress.py` | 磁盘压力测试 | `--size MB --dir PATH --run` |
| `process_kill.py` | 进程杀灭韧性测试 | `--target PID --signal SIGTERM --run` |
| `chaos_runner.py` | 实验编排器(JSON plan) | `--plan FILE --plan-stdout JSON --run` |
| `verify_resilience.py` | 系统健康验证 | `--run` (检查进程/内存/磁盘/CPU) |
| `experiments/cpu_burn.json` | CPU燃烧实验计划(3级) | 供chaos_runner使用 |
| `experiments/mem_pressure.json` | 内存压力实验计划(3级) | 供chaos_runner使用 |

## 快速使用

```bash
# 单次实验
python3 scripts/cpu_stress.py --run --workers 4 --duration 10

# 编排实验
python3 scripts/chaos_runner.py --plan scripts/experiments/cpu_burn.json

# 验证恢复
python3 scripts/verify_resilience.py --run
```

## 实验类型

- **CPU压力**: 多worker忙循环，测试系统在CPU打满时的表现
- **内存压力**: 分配指定大小内存块，测试系统OOM行为
- **磁盘压力**: 写入临时文件到指定目录，测试磁盘满时的表现
- **进程杀灭**: 杀掉指定进程，测试自动恢复/监控触发
- **全编排**: 顺序执行多级实验(from light to heavy)，逐级验证

## 实验流程

1. **基线**: `verify_resilience.py --run` → 记录当前进程/内存/磁盘/CPU
2. **注入**: `cpu_stress.py --run` / `chaos_runner.py --plan X.json`
3. **观察**: 监控指标变化（验证脚本自动检测）
4. **恢复**: 再次运行 `verify_resilience.py --run` 对比基线
5. **报告**: 记录实验结果到知识库

## Verifying System Resilience

Run the complete experiment sequence:

```bash
# 1. Baseline
python3 scripts/verify_resilience.py --run

# 2. Inject (choose one)
python3 scripts/cpu_stress.py --run --workers 4 --duration 10
python3 scripts/mem_stress.py --run --size 200 --duration 5
python3 scripts/disk_stress.py --run --size 100
python3 scripts/process_kill.py --run

# 3. Orchestrated experiment
python3 scripts/chaos_runner.py --plan scripts/experiments/cpu_burn.json
python3 scripts/chaos_runner.py --plan scripts/experiments/mem_pressure.json

# 4. Verify recovery
python3 scripts/verify_resilience.py --run
```

## Pitfalls
- cpu_stress长时间运行会显著提高CPU温度/功耗
- disk_stress默认写入/tmp，确保有足够磁盘空间
- 所有脚本自动清理临时文件(finally保证)
- 首次运行先用默认参数测试
- 实验后务必运行verify_resilience验证系统已完全恢复
- **chaos_runner**: 传 `--plan` 必须同时隐含 `--run`（已修复：`--plan` 单独用时自动启用 `--run` 模式）
