#!/usr/bin/env python3
"""
Memory Stress Script — allocate memory to build pressure, then release.
"""

import sys
import os
import json
import time
import signal
import argparse

running = True


def sigint_handler(signum, frame):
    global running
    running = False


def main():
    global running

    parser = argparse.ArgumentParser(description="Memory stress testing tool")
    parser.add_argument("--check", action="store_true", help="Return JSON status and exit")
    parser.add_argument("--run", action="store_true", help="Run the stress test")
    parser.add_argument("--size", type=int, default=50, help="Total memory to allocate in MB (default: 50)")
    parser.add_argument("--duration", type=int, default=3, help="Hold duration in seconds (default: 3)")
    args = parser.parse_args()

    if args.check:
        print(json.dumps({"status": "ok", "skill": "mem-stress"}))
        return 0

    if not args.run:
        parser.print_help()
        return 0

    signal.signal(signal.SIGINT, sigint_handler)

    size_mb = max(1, args.size)
    duration = max(1, args.duration)

    # Allocate in 1 MB chunks to avoid overwhelming the system
    chunk_size_kb = 1024  # 1 MB per chunk
    num_chunks = size_mb

    print(f"[mem-stress] Starting memory stress: {size_mb}MB for {duration}s")
    print(f"[mem-stress] PID: {os.getpid()}")
    sys.stdout.flush()

    chunks = []
    allocated_mb = 0

    try:
        for i in range(num_chunks):
            if not running:
                break
            # Allocate a ~1 MB bytearray
            chunk = bytearray(chunk_size_kb * 1024)
            # Touch memory to ensure it's actually allocated
            for j in range(0, len(chunk), 4096):
                chunk[j] = 1
            chunks.append(chunk)
            allocated_mb += 1
            if i % 10 == 0 and i > 0:
                print(f"[mem-stress] Allocated {i} MB...")
                sys.stdout.flush()

        print(f"[mem-stress] Allocated {allocated_mb} MB. Holding for {duration}s...")
        sys.stdout.flush()

        # Hold the memory for the specified duration
        end_time = time.monotonic() + duration
        while time.monotonic() < end_time and running:
            time.sleep(0.1)

        print(f"[mem-stress] Releasing memory...")

    except MemoryError:
        print(f"[mem-stress] MemoryError: allocated {allocated_mb} MB before failure.")
    except KeyboardInterrupt:
        print(f"\n[mem-stress] Interrupted.")
    finally:
        # Release memory
        chunks.clear()
        print(f"[mem-stress] Memory released. Test complete.")

    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as e:
        print(json.dumps({"status": "error", "message": str(e)}))
        sys.exit(1)
