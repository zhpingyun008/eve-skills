#!/usr/bin/env python3
"""
Disk Stress Script — write temp files to build disk pressure, then clean up.
"""

import sys
import os
import json
import time
import signal
import argparse
import tempfile
import shutil

running = True


def sigint_handler(signum, frame):
    global running
    running = False


def main():
    global running

    parser = argparse.ArgumentParser(description="Disk stress testing tool")
    parser.add_argument("--check", action="store_true", help="Return JSON status and exit")
    parser.add_argument("--run", action="store_true", help="Run the stress test")
    parser.add_argument("--size", type=int, default=50, help="Total data to write in MB (default: 50)")
    parser.add_argument("--dir", type=str, default="/tmp/chaos_disk_test/", help="Directory for writing test files (default: /tmp/chaos_disk_test/)")
    args = parser.parse_args()

    if args.check:
        print(json.dumps({"status": "ok", "skill": "disk-stress"}))
        return 0

    if not args.run:
        parser.print_help()
        return 0

    signal.signal(signal.SIGINT, sigint_handler)

    size_mb = max(1, args.size)
    work_dir = args.dir

    print(f"[disk-stress] Starting disk stress: {size_mb}MB in {work_dir}")
    print(f"[disk-stress] PID: {os.getpid()}")
    sys.stdout.flush()

    created_files = []

    try:
        os.makedirs(work_dir, exist_ok=True)
        print(f"[disk-stress] Created directory: {work_dir}")

        # Write in 10 MB chunks
        chunk_size = 10 * 1024 * 1024  # 10 MB
        remaining = size_mb * 1024 * 1024
        file_index = 0

        while remaining > 0 and running:
            write_size = min(chunk_size, remaining)
            file_path = os.path.join(work_dir, f"chaos_disk_{file_index:04d}.dat")
            try:
                with open(file_path, "wb") as f:
                    data = bytearray(os.urandom(1024 * 1024))  # 1 MB random data
                    written = 0
                    while written < write_size:
                        chunk = min(len(data), write_size - written)
                        f.write(data[:chunk])
                        written += chunk
                created_files.append(file_path)
                remaining -= write_size
                file_index += 1
                total_written_mb = (size_mb - remaining / (1024 * 1024))
                if file_index % 5 == 0:
                    print(f"[disk-stress] Written {total_written_mb:.0f} MB...")
                    sys.stdout.flush()
            except OSError as e:
                print(f"[disk-stress] Write error: {e}")
                break

        total_written_mb = (size_mb - remaining / (1024 * 1024))
        print(f"[disk-stress] Written {total_written_mb:.0f} MB across {len(created_files)} files.")
        print(f"[disk-stress] Holding for 2s...")
        time.sleep(2)

    except KeyboardInterrupt:
        print(f"\n[disk-stress] Interrupted.")
    except Exception as e:
        print(f"[disk-stress] Error: {e}")
    finally:
        # Clean up all created files
        print(f"[disk-stress] Cleaning up {len(created_files)} files...")
        for f in created_files:
            try:
                os.remove(f)
            except OSError:
                pass
        # Try to remove the directory if empty
        try:
            os.rmdir(work_dir)
        except OSError:
            pass
        print(f"[disk-stress] Cleanup complete.")

    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as e:
        print(json.dumps({"status": "error", "message": str(e)}))
        sys.exit(1)
