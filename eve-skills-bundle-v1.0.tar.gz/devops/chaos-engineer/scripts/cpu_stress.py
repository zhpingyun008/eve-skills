#!/usr/bin/env python3
"""
CPU Stress Script — spawn workers doing busy loops to burn CPU cycles.
"""

import sys
import os
import json
import time
import signal
import argparse
import multiprocessing

running = True


def sigint_handler(signum, frame):
    global running
    running = False


def busy_worker(duration):
    """Perform a busy loop for the given duration."""
    end_time = time.monotonic() + duration
    while time.monotonic() < end_time and running:
        _ = 42 ** 10000  # Busy work
    return


def main():
    global running

    parser = argparse.ArgumentParser(description="CPU stress testing tool")
    parser.add_argument("--check", action="store_true", help="Return JSON status and exit")
    parser.add_argument("--run", action="store_true", help="Run the stress test")
    parser.add_argument("--workers", type=int, default=2, help="Number of worker processes (default: 2)")
    parser.add_argument("--duration", type=int, default=5, help="Duration in seconds (default: 5)")
    args = parser.parse_args()

    if args.check:
        print(json.dumps({"status": "ok", "skill": "cpu-stress"}))
        return 0

    if not args.run:
        parser.print_help()
        return 0

    # Register graceful shutdown
    signal.signal(signal.SIGINT, sigint_handler)

    workers = max(1, args.workers)
    duration = max(1, args.duration)
    start_time = time.monotonic()

    print(f"[cpu-stress] Starting CPU stress: {workers} workers, {duration}s duration")
    print(f"[cpu-stress] PID: {os.getpid()}")
    sys.stdout.flush()

    processes = []
    try:
        for i in range(workers):
            p = multiprocessing.Process(target=busy_worker, args=(duration,), name=f"cpu-stress-{i}")
            p.start()
            processes.append(p)

        # Wait for all workers to finish
        for p in processes:
            p.join(timeout=duration + 5)

        elapsed = time.monotonic() - start_time
        print(f"[cpu-stress] Completed. Workers: {workers}, Duration: {elapsed:.1f}s")
    except KeyboardInterrupt:
        running = False
        print(f"\n[cpu-stress] Interrupted. Waiting for workers to stop...")
        for p in processes:
            p.terminate()
            p.join(timeout=2)
        print(f"[cpu-stress] Aborted.")
    finally:
        # Ensure all processes are cleaned up
        for p in processes:
            if p.is_alive():
                p.terminate()
                p.join(timeout=1)

    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as e:
        print(json.dumps({"status": "error", "message": str(e)}))
        sys.exit(1)
