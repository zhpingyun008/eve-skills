#!/usr/bin/env python3
"""
Process Kill Script — resilience test: spawn a dummy process, kill it, measure recovery.
"""

import sys
import os
import json
import time
import signal
import argparse
import subprocess
import multiprocessing

running = True


def sigint_handler(signum, frame):
    global running
    running = False


def dummy_target(duration):
    """A dummy process that just sleeps until killed or timeout."""
    import time as _time
    end = _time.monotonic() + duration
    while _time.monotonic() < end:
        _time.sleep(0.5)
    return


def main():
    global running

    parser = argparse.ArgumentParser(description="Process kill resilience testing tool")
    parser.add_argument("--check", action="store_true", help="Return JSON status and exit")
    parser.add_argument("--run", action="store_true", help="Run the resilience test")
    parser.add_argument("--target", type=int, default=None, help="PID to kill (default: spawn and kill own test process)")
    parser.add_argument("--signal", type=str, default="SIGTERM", help="Signal to send (default: SIGTERM)")
    args = parser.parse_args()

    if args.check:
        print(json.dumps({"status": "ok", "skill": "process-kill"}))
        return 0

    if not args.run:
        parser.print_help()
        return 0

    signal.signal(signal.SIGINT, sigint_handler)

    sig_map = {
        "SIGTERM": signal.SIGTERM,
        "SIGKILL": signal.SIGKILL,
        "SIGINT": signal.SIGINT,
        "SIGHUP": signal.SIGHUP,
        "SIGQUIT": signal.SIGQUIT,
        "SIGSTOP": signal.SIGSTOP,
        "SIGCONT": signal.SIGCONT,
    }

    sig_name = args.signal.upper()
    sig_val = sig_map.get(sig_name, signal.SIGTERM)

    print(f"[process-kill] Process kill resilience test")
    print(f"[process-kill] PID: {os.getpid()}")
    sys.stdout.flush()

    target_pid = args.target

    if target_pid is not None:
        # Kill an external target process
        print(f"[process-kill] Targeting external PID: {target_pid}")
        try:
            os.kill(target_pid, sig_val)
            print(f"[process-kill] Sent {sig_name} to PID {target_pid}")
            # Check if process still exists
            time.sleep(0.5)
            try:
                os.kill(target_pid, 0)  # Signal 0 checks existence
                print(f"[process-kill] Process {target_pid} still running after kill")
            except OSError:
                print(f"[process-kill] Process {target_pid} terminated successfully")
        except ProcessLookupError:
            print(f"[process-kill] Process {target_pid} not found")
        except PermissionError:
            print(f"[process-kill] Permission denied to kill PID {target_pid}")
        return 0

    # Default: spawn a test dummy process and kill it
    print(f"[process-kill] Spawning test dummy process...")

    try:
        p = multiprocessing.Process(target=dummy_target, args=(30,), name="dummy-target")
        p.start()
        dummy_pid = p.pid
        print(f"[process-kill] Spawned dummy process PID: {dummy_pid}")

        time.sleep(1)

        # Verify it's alive
        alive_before = p.is_alive()
        print(f"[process-kill] Dummy alive before kill: {alive_before}")

        # Kill it
        print(f"[process-kill] Sending {sig_name} to PID {dummy_pid}...")
        p.terminate()  # multiprocessing terminate sends SIGTERM
        # If using actual os.kill for non-SIGTERM
        if sig_val != signal.SIGTERM and sig_val != signal.SIGKILL:
            os.kill(dummy_pid, sig_val)

        p.join(timeout=3)
        alive_after = p.is_alive()
        if alive_after:
            p.kill()
            p.join(timeout=1)
            alive_after = p.is_alive()

        print(f"[process-kill] Dummy alive after kill: {alive_after}")
        print(f"[process-kill] Recovery status: {'ok' if not alive_after else 'failed'}")

    except KeyboardInterrupt:
        print(f"\n[process-kill] Interrupted.")
    except Exception as e:
        print(f"[process-kill] Error: {e}")
    finally:
        # Ensure cleanup
        try:
            if 'p' in locals() and p.is_alive():
                p.terminate()
                p.join(timeout=2)
        except Exception:
            pass

    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as e:
        print(json.dumps({"status": "error", "message": str(e)}))
        sys.exit(1)
