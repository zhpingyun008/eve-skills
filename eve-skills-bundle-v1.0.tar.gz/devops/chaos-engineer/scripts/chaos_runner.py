#!/usr/bin/env python3
"""
Chaos Runner — orchestrator that executes chaos experiment plans defined in JSON.
"""

import sys
import os
import json
import time
import argparse
import traceback


def load_plan(plan_path):
    """Load and validate a JSON experiment plan."""
    if not os.path.exists(plan_path):
        raise FileNotFoundError(f"Plan file not found: {plan_path}")

    with open(plan_path, "r") as f:
        data = json.load(f)

    if not isinstance(data, list):
        raise ValueError("Experiment plan must be a JSON array of experiment objects")

    for exp in data:
        if not isinstance(exp, dict):
            raise ValueError(f"Each experiment must be a JSON object, got: {type(exp)}")
        if "name" not in exp:
            raise ValueError("Each experiment must have a 'name' field")
        if "type" not in exp:
            raise ValueError(f"Experiment '{exp.get('name', 'unnamed')}' must have a 'type' field")

    return data


def run_experiment(exp):
    """Execute a single experiment by type."""
    name = exp["name"]
    exp_type = exp["type"]
    params = exp.get("params", {})

    print(f"\n{'='*60}")
    print(f"[chaos-runner] Running experiment: {name}")
    print(f"[chaos-runner] Type: {exp_type}")
    print(f"[chaos-runner] Params: {json.dumps(params)}")
    print(f"{'='*60}")
    sys.stdout.flush()

    # Map experiment types to script paths
    script_map = {
        "cpu-stress": "cpu_stress.py",
        "cpu_burn": "cpu_stress.py",
        "mem-stress": "mem_stress.py",
        "mem_pressure": "mem_stress.py",
        "disk-stress": "disk_stress.py",
        "disk_stress": "disk_stress.py",
        "process-kill": "process_kill.py",
        "process_kill": "process_kill.py",
        "verify-resilience": "verify_resilience.py",
        "verify_resilience": "verify_resilience.py",
    }

    script_name = script_map.get(exp_type)
    if not script_name:
        raise ValueError(f"Unknown experiment type: {exp_type}. Supported: {', '.join(script_map.keys())}")

    scripts_dir = os.path.dirname(os.path.abspath(__file__))
    script_path = os.path.join(scripts_dir, script_name)

    if not os.path.exists(script_path):
        raise FileNotFoundError(f"Script not found: {script_path}")

    # Build command arguments from params
    cmd_parts = [sys.executable, script_path, "--run"]
    for key, value in params.items():
        cmd_parts.append(f"--{key}")
        if not isinstance(value, bool):
            cmd_parts.append(str(value))

    import subprocess
    print(f"[chaos-runner] Command: {' '.join(cmd_parts)}")
    sys.stdout.flush()

    start = time.monotonic()
    result = subprocess.run(cmd_parts, capture_output=False, timeout=300)
    elapsed = time.monotonic() - start

    status = "success" if result.returncode == 0 else "failed"
    print(f"[chaos-runner] Experiment '{name}' completed: {status} (exit={result.returncode}, duration={elapsed:.1f}s)")

    return {
        "name": name,
        "type": exp_type,
        "status": status,
        "returncode": result.returncode,
        "duration": round(elapsed, 1),
    }


def main():
    parser = argparse.ArgumentParser(description="Chaos experiment orchestrator")
    parser.add_argument("--check", action="store_true", help="Return JSON status and exit")
    parser.add_argument("--run", action="store_true", help="Run experiments from a plan")
    parser.add_argument("--plan", type=str, default=None, help="Path to JSON experiment plan file")
    parser.add_argument("--plan-stdout", type=str, default=None, help="JSON experiment plan as inline string")
    args = parser.parse_args()

    if args.check:
        print(json.dumps({"status": "ok", "skill": "chaos-runner"}))
        return 0

    if not args.run and not args.plan and not args.plan_stdout:
        parser.print_help()
        return 0

    # Load plan from file or stdin
    plan_data = None
    if args.plan_stdout:
        try:
            plan_data = json.loads(args.plan_stdout)
        except json.JSONDecodeError as e:
            print(f"[chaos-runner] Invalid JSON in --plan-stdout: {e}")
            return 1
    elif args.plan:
        try:
            plan_data = load_plan(args.plan)
        except (FileNotFoundError, ValueError, json.JSONDecodeError) as e:
            print(f"[chaos-runner] Failed to load plan: {e}")
            return 1
    else:
        print("[chaos-runner] No plan provided. Use --plan or --plan-stdout.")
        return 1

    # Normalize to list
    if isinstance(plan_data, dict):
        # Support object with 'experiments' key or single experiment
        if "experiments" in plan_data:
            plan_data = plan_data["experiments"]
        else:
            plan_data = [plan_data]

    print(f"[chaos-runner] Loaded plan with {len(plan_data)} experiment(s)")
    sys.stdout.flush()

    results = []
    all_success = True

    for i, exp in enumerate(plan_data):
        print(f"\n[chaos-runner] --- Experiment {i+1}/{len(plan_data)} ---")
        sys.stdout.flush()
        try:
            result = run_experiment(exp)
            results.append(result)
            if result["status"] != "success":
                all_success = False
        except Exception as e:
            print(f"[chaos-runner] Experiment '{exp.get('name', 'unnamed')}' failed with error: {e}")
            traceback.print_exc()
            results.append({
                "name": exp.get("name", "unnamed"),
                "type": exp.get("type", "unknown"),
                "status": "error",
                "error": str(e),
            })
            all_success = False

    # Print summary
    print(f"\n{'='*60}")
    print(f"[chaos-runner] Experiment Run Summary")
    print(f"{'='*60}")
    for r in results:
        status_icon = "✓" if r["status"] == "success" else "✗"
        print(f"  {status_icon} {r['name']}: {r['status']} ({r.get('duration', 'N/A')}s)")
    print(f"{'='*60}")
    print(f"[chaos-runner] Overall: {'ALL PASSED' if all_success else 'SOME FAILED'}")

    return 0 if all_success else 1


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print(f"\n[chaos-runner] Interrupted.")
        sys.exit(130)
    except Exception as e:
        print(json.dumps({"status": "error", "message": str(e)}))
        sys.exit(1)
