#!/usr/bin/env python3
"""
Verify Resilience — after chaos experiments, check system health metrics.
"""

import sys
import os
import json
import time
import argparse
import subprocess


def get_process_count():
    """Count running processes."""
    try:
        result = subprocess.run(
            ["ps", "-e", "--no-headers"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        count = len(result.stdout.strip().split("\n")) if result.stdout.strip() else 0
        return count, None
    except Exception as e:
        return None, str(e)


def get_memory_info():
    """Get memory available in MB."""
    try:
        with open("/proc/meminfo", "r") as f:
            for line in f:
                if line.startswith("MemAvailable:"):
                    parts = line.split()
                    kb = int(parts[1])
                    mb = kb / 1024
                    return round(mb, 1), None
        return None, "Could not find MemAvailable in /proc/meminfo"
    except Exception as e:
        return None, str(e)


def get_disk_usage(path="/"):
    """Get disk usage percentage for a given path."""
    try:
        st = os.statvfs(path)
        total = st.f_frsize * st.f_blocks
        free = st.f_frsize * st.f_bfree
        used = total - free
        pct = (used / total) * 100 if total > 0 else 0
        used_gb = used / (1024 ** 3)
        free_gb = free / (1024 ** 3)
        return round(pct, 1), round(used_gb, 1), round(free_gb, 1), None
    except Exception as e:
        return None, None, None, str(e)


def get_cpu_idle():
    """Get CPU idle percentage from /proc/stat."""
    try:
        with open("/proc/stat", "r") as f:
            first_line = f.readline()
        if not first_line.startswith("cpu "):
            return None, "Could not parse /proc/stat"
        parts = first_line.split()
        if len(parts) < 8:
            return None, "Unexpected /proc/stat format"
        # user, nice, system, idle, iowait, irq, softirq, steal
        user = int(parts[1])
        nice = int(parts[2])
        system = int(parts[3])
        idle = int(parts[4])
        iowait = int(parts[5])
        irq = int(parts[6])
        softirq = int(parts[7])
        total = user + nice + system + idle + iowait + irq + softirq
        idle_pct = (idle / total) * 100 if total > 0 else 0
        return round(idle_pct, 1), None
    except Exception as e:
        return None, str(e)


def main():
    parser = argparse.ArgumentParser(description="System resilience verification tool")
    parser.add_argument("--check", action="store_true", help="Return JSON status and exit")
    parser.add_argument("--run", action="store_true", help="Run all resilience checks")
    args = parser.parse_args()

    if args.check:
        print(json.dumps({"status": "ok", "skill": "verify-resilience"}))
        return 0

    if not args.run:
        parser.print_help()
        return 0

    print(f"[verify-resilience] System Health Check")
    print(f"[verify-resilience] PID: {os.getpid()}")
    print(f"{'='*50}")
    sys.stdout.flush()

    checks = {}
    all_passed = True

    # Check 1: Process count
    print(f"\n[1/4] Checking process count...")
    count, err = get_process_count()
    if err:
        checks["process_count"] = {"status": "error", "message": err}
        all_passed = False
        print(f"  ✗ Error: {err}")
    else:
        checks["process_count"] = {"status": "ok", "value": count}
        print(f"  ✓ {count} processes running")
        if count < 10:
            print(f"  ⚠ Warning: Very few processes running — system may be degraded")

    # Check 2: Memory available
    print(f"\n[2/4] Checking available memory...")
    mem_mb, err = get_memory_info()
    if err:
        checks["memory_available"] = {"status": "error", "message": err}
        all_passed = False
        print(f"  ✗ Error: {err}")
    else:
        checks["memory_available"] = {"status": "ok", "value_mb": mem_mb}
        print(f"  ✓ {mem_mb} MB available")
        if mem_mb < 100:
            print(f"  ⚠ Warning: Low memory available (< 100 MB)")
            all_passed = False

    # Check 3: Disk usage
    print(f"\n[3/4] Checking disk usage...")
    pct, used_gb, free_gb, err = get_disk_usage("/")
    if err:
        checks["disk_usage"] = {"status": "error", "message": err}
        all_passed = False
        print(f"  ✗ Error: {err}")
    else:
        checks["disk_usage"] = {
            "status": "ok",
            "used_pct": pct,
            "used_gb": used_gb,
            "free_gb": free_gb,
        }
        print(f"  ✓ {pct}% used ({used_gb} GB used, {free_gb} GB free)")
        if pct > 90:
            print(f"  ⚠ Warning: Disk usage > 90%")
            all_passed = False

    # Check 4: CPU idle
    print(f"\n[4/4] Checking CPU idle percentage...")
    idle_pct, err = get_cpu_idle()
    if err:
        checks["cpu_idle"] = {"status": "error", "message": err}
        all_passed = False
        print(f"  ✗ Error: {err}")
    else:
        checks["cpu_idle"] = {"status": "ok", "idle_pct": idle_pct}
        print(f"  ✓ CPU idle: {idle_pct}%")
        if idle_pct < 10:
            print(f"  ⚠ Warning: CPU is heavily loaded")
            all_passed = False

    # Summary
    print(f"\n{'='*50}")
    status_text = "ALL CHECKS PASSED" if all_passed else "SOME CHECKS ISSUES DETECTED"
    print(f"[verify-resilience] {status_text}")
    print(f"[verify-resilience] JSON output:")
    print(json.dumps({"status": "ok" if all_passed else "degraded", "checks": checks}, indent=2))

    return 0 if all_passed else 1


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as e:
        print(json.dumps({"status": "error", "message": str(e)}))
        sys.exit(1)
