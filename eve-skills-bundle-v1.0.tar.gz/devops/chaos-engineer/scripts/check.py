#!/usr/bin/env python3
"""Chaos-Engineer skill check — verify all chaos experiment scripts are functional"""
import sys, json, subprocess, os

SCRIPTS_DIR = os.path.dirname(os.path.abspath(__file__))

def main():
    results = {}
    all_ok = True
    
    for f in sorted(os.listdir(SCRIPTS_DIR)):
        if f.endswith('.py') and f != 'check.py':
            path = os.path.join(SCRIPTS_DIR, f)
            try:
                r = subprocess.run([sys.executable, path, '--check'], 
                                 capture_output=True, text=True, timeout=10)
                out = r.stdout.strip()
                if r.returncode == 0 and out:
                    data = json.loads(out)
                    results[f] = {"status": data.get("status", "unknown"), "ok": True}
                else:
                    results[f] = {"status": "error", "error": out or r.stderr[:100], "ok": False}
                    all_ok = False
            except Exception as e:
                results[f] = {"status": "error", "error": str(e), "ok": False}
                all_ok = False
    
    print(json.dumps({
        "status": "ok" if all_ok else "partial",
        "skill": "chaos-engineer",
        "scripts_checked": len(results),
        "all_pass": all_ok,
        "details": results
    }, indent=2))
    sys.exit(0 if all_ok else 1)

if __name__ == "__main__":
    main()
