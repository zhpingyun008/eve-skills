#!/usr/bin/env python3
"""Skill-to-BookStack sync — single run for changed files."""

import hashlib
import json
import os
import time
from datetime import datetime
import urllib.request

# === Config ===
SKILLS_DIR = os.path.expanduser("~/.hermes/skills")
SYNC_TS_FILE = os.path.expanduser("~/.hermes/logs/.skill_sync_last")
HASH_CACHE_FILE = os.path.expanduser("~/.hermes/logs/.skill_sync_hash.json")
TOKEN_FILE = "/tmp/.bookstack_sync_token"

BASE_URL = "http://localhost:8080/api"

BOOK_MAP = {
    "agent-skills": 2031,
    "cmmi5": 2032,
    "devops": 2033,
    "security": 2034,
    "meta": 2035,
    "engineering": 2036,
    "productivity": 2037,
    "business": 2753,
}

BOOK_NAMES = {
    2031: "Agent核心技能",
    2032: "CMMI5过程域",
    2033: "运维自动化",
    2034: "安全审计",
    2035: "元技能·进化",
    2036: "工程实践",
    2037: "生产力工具",
    2753: "商业业务",
}

# === Read token ===
if not os.path.exists(TOKEN_FILE):
    # Fallback: parse from .bashrc
    with open(os.path.expanduser("~/.bashrc")) as f:
        for line in f:
            if "BOOKSTACK_TOKEN" in line and "export" in line:
                token = line.split("=")[1].strip().strip('"')
                break
    with open(TOKEN_FILE, "w") as f:
        f.write(token)
else:
    with open(TOKEN_FILE) as f:
        token = f.read().strip()

def api_call(method, endpoint, data=None):
    url = f"{BASE_URL}/{endpoint.lstrip('/')}"
    body = json.dumps(data).encode() if data else None
    req = urllib.request.Request(url, data=body, method=method)
    req.add_header("Authorization", f"Token {token}")
    req.add_header("Content-Type", "application/json")
    try:
        resp = urllib.request.urlopen(req, timeout=30)
        return json.loads(resp.read())
    except urllib.error.HTTPError as e:
        err_body = e.read().decode()
        return {"error": True, "status": e.code, "body": err_body}

def file_hash(path):
    return hashlib.sha256(open(path, "rb").read()).hexdigest()

# === Read last sync timestamp ===
with open(SYNC_TS_FILE) as f:
    first_line = f.readline().strip()
last_ts = int(float(first_line))
print(f"Last sync: {last_ts} = {datetime.fromtimestamp(last_ts).strftime('%Y-%m-%d %H:%M:%S')}")

# === Load hash cache ===
hash_cache = {}
if os.path.exists(HASH_CACHE_FILE):
    with open(HASH_CACHE_FILE) as f:
        hash_cache = json.load(f)

# === Find changed files ===
import glob

changed_files = []
for sk_path in glob.glob(f"{SKILLS_DIR}/**/SKILL.md", recursive=True):
    rel_path = os.path.relpath(sk_path, SKILLS_DIR)
    
    # Skip archive
    if "/_archive/" in rel_path:
        continue
    
    mtime = os.path.getmtime(sk_path)
    
    # Skip if mtime <= last_ts (with 1s tolerance)
    if mtime <= last_ts + 1:
        continue
    
    # Determine category
    parts = rel_path.split(os.sep)
    if len(parts) >= 2:
        category = parts[0]
        skill_name = parts[-2]  # parent directory of SKILL.md
    else:
        category = parts[0]
        skill_name = parts[0].replace(".md", "")
    
    # Skip if category not in mapping
    if category not in BOOK_MAP:
        print(f"  ⏭  SKIP (category '{category}' not mapped): {rel_path}")
        continue
    
    # Check content hash
    cur_hash = file_hash(sk_path)
    cached_hash = hash_cache.get(rel_path)
    if cached_hash == cur_hash:
        print(f"  ⏭  SKIP (content unchanged): {rel_path}")
        continue
    
    changed_files.append({
        "path": sk_path,
        "rel_path": rel_path,
        "category": category,
        "skill_name": skill_name,
        "hash": cur_hash,
        "mtime": mtime,
    })

if not changed_files:
    print("\nNo files need syncing.")
    # Still update timestamp to prevent re-scan
    now_ts = time.time()
    with open(SYNC_TS_FILE, "w") as f:
        f.write(f"{int(now_ts)}\n{datetime.fromtimestamp(now_ts).strftime('%Y-%m-%d %H:%M:%S')}\n")
    print(f"Updated timestamp to {int(now_ts)}")
    exit(0)

print(f"\nFound {len(changed_files)} file(s) to sync:")
for f in changed_files:
    print(f"  📄 {f['rel_path']} → book {BOOK_MAP[f['category']]} ({BOOK_NAMES[BOOK_MAP[f['category']]]})")

# === Fetch existing pages for affected books ===
changed_book_ids = set()
for f in changed_files:
    changed_book_ids.add(BOOK_MAP[f['category']])

book_pages = {}
for bid in changed_book_ids:
    print(f"\nFetching existing pages for book {bid} ({BOOK_NAMES.get(bid, '?')})...")
    offset = 0
    pages = {}
    while True:
        result = api_call("GET", f"/pages?book_id={bid}&count=500&offset={offset}")
        if result.get("error"):
            print(f"  ❌ API error fetching pages: {result.get('body', str(result))}")
            break
        data = result.get("data", [])
        for p in data:
            pages[p["name"]] = p
        if not data:
            break
        offset += 500
    book_pages[bid] = pages
    print(f"  ✅ Found {len(pages)} existing pages in book {bid}")

# === Sync each changed file ===
created = 0
updated = 0
errors = 0

for f in changed_files:
    book_id = BOOK_MAP[f['category']]
    book_name = BOOK_NAMES.get(book_id, "Unknown")
    page_name = f"{book_name} › {f['skill_name']} › SKILL.md"
    
    with open(f["path"]) as fh:
        raw_content = fh.read()
    
    html_content = f"<pre>\n{raw_content}\n</pre>"
    
    existing = book_pages.get(book_id, {}).get(page_name)
    
    if existing:
        # Update existing page
        result = api_call("PUT", f"/pages/{existing['id']}", {
            "name": page_name,
            "html": html_content,
        })
        if result.get("error"):
            print(f"  ❌ UPDATE FAIL: {f['rel_path']} → {result.get('body', str(result))}")
            errors += 1
        else:
            print(f"  ✅ UPDATE: {f['rel_path']} → page {existing['id']}")
            updated += 1
    else:
        # Create new page
        result = api_call("POST", "/pages", {
            "name": page_name,
            "html": html_content,
            "book_id": book_id,
        })
        if result.get("error"):
            print(f"  ❌ CREATE FAIL: {f['rel_path']} → {result.get('body', str(result))}")
            errors += 1
        else:
            print(f"  ✅ CREATE: {f['rel_path']} → page {result.get('id', '?')}")
            created += 1

    # Update hash cache
    hash_cache[f['rel_path']] = f['hash']

# === Save hash cache ===
with open(HASH_CACHE_FILE, "w") as f:
    json.dump(hash_cache, f, indent=2)
print(f"\n✅ Hash cache updated ({len(hash_cache)} entries)")

# === Update timestamp ===
now_ts = int(time.time())
with open(SYNC_TS_FILE, "w") as f:
    f.write(f"{now_ts}\n{datetime.fromtimestamp(now_ts).strftime('%Y-%m-%d %H:%M:%S')}\n")
print(f"✅ Timestamp updated to {now_ts} ({datetime.fromtimestamp(now_ts).strftime('%Y-%m-%d %H:%M:%S')})")

# === Summary ===
print(f"\n{'='*60}")
print(f"📊 SYNC SUMMARY")
print(f"{'='*60}")
print(f"  Created:  {created}")
print(f"  Updated:  {updated}")
print(f"  Errors:   {errors}")
print(f"  Total:    {created + updated + errors}")
