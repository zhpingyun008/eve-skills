#!/usr/bin/env python3
"""
dedup_by_search.py — Search-API-based precise dedup, runs in milliseconds.

Targets specific page names by skill name (not book_id), uses BookStack's
Search API which is O(1) regardless of book size. Avoids the 180s timeout
that cleanup_duplicates.py hits on Book 2033 (18K+ pages).

Usage:
  # Dedup a specific skill name across all books:
  python3 dedup_by_search.py hermes-cron-posting

  # Dedup multiple skills:
  python3 dedup_by_search.py hermes-cron-posting skill-bookstack-sync

  # Dedup ALL skills that have duplicates (dumps search per unique name):
  python3 dedup_by_search.py --all

  # Dry run — show what would be deleted, don't actually DELETE:
  python3 dedup_by_search.py --dry-run hermes-cron-posting

Requires /tmp/.bookstack_token to exist with the API token.

Cron-safe: no pipes, no execute_code, no rm. Uses Python urllib only.
"""
import json
import urllib.request
import os
import sys

TOKEN_FILE = '/tmp/.bookstack_token'
API_BASE = 'http://localhost:8080/api'


def get_token():
    if not os.path.exists(TOKEN_FILE):
        print(f"ERROR: Token file {TOKEN_FILE} not found. Create it with:")
        print(f"  echo 'your-token' > {TOKEN_FILE}")
        sys.exit(1)
    with open(TOKEN_FILE) as f:
        return f.read().strip()


def search(token, query, count=50):
    """Search BookStack for pages matching the query."""
    url = f"{API_BASE}/search?query={query}&count={count}"
    req = urllib.request.Request(
        url,
        headers={'Authorization': f'Token {token}'}
    )
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read())


def delete_page(token, page_id, page_name):
    """DELETE a BookStack page by ID."""
    url = f"{API_BASE}/pages/{page_id}"
    req = urllib.request.Request(
        url,
        headers={'Authorization': f'Token {token}'},
        method='DELETE'
    )
    with urllib.request.urlopen(req, timeout=30) as resp:
        return resp.status == 204


def dedup_skill(token, skill_name, dry_run=False):
    """
    Find and remove duplicate BookStack pages for a given skill name.
    Uses the Search API which is fast (~500ms) regardless of book size.
    
    Always picks the page with the latest updated_at to keep.
    """
    # Search — match the page name pattern "› skill_name › SKILL.md"
    result = search(token, skill_name, count=50)
    pages = result.get('data', [])
    
    if not pages:
        print(f"  No pages found for '{skill_name}'")
        return 0
    
    # Filter: only pages whose name contains "› {skill_name} › SKILL.md"
    target_pattern = f"› {skill_name} › SKILL.md"
    relevant = [p for p in pages if target_pattern in p.get('name', '')]
    
    if len(relevant) <= 1:
        print(f"  {skill_name}: {len(relevant)} page(s) — no duplicates")
        return 0
    
    # Group by (book_id, name) — a "true duplicate" is the same name in the same book
    groups = {}
    for p in relevant:
        key = (p['book_id'], p['name'])
        if key not in groups:
            groups[key] = []
        groups[key].append(p)
    
    total_deleted = 0
    for key, members in groups.items():
        if len(members) <= 1:
            continue
        
        book_id, page_name = key
        # Sort by updated_at descending — keep the latest
        members.sort(key=lambda x: x.get('updated_at', ''), reverse=True)
        keep = members[0]
        deletes = members[1:]
        
        print(f"  {skill_name} (book={book_id}): {len(members)} copies → keeping page {keep['id']} (updated {keep.get('updated_at', '?')})")
        
        for d in deletes:
            d_id = d['id']
            d_updated = d.get('updated_at', '?')
            print(f"    DELETE page {d_id} (updated {d_updated})")
            
            if not dry_run:
                try:
                    resp_code = delete_page(token, d_id, d.get('name', ''))
                    if resp_code:
                        print(f"    ✅ Deleted")
                        total_deleted += 1
                    else:
                        print(f"    ❌ DELETE returned non-204")
                except urllib.error.HTTPError as e:
                    body = e.read().decode()
                    print(f"    ❌ HTTP {e.code}: {body[:150]}")
                except Exception as e:
                    print(f"    ❌ {e}")
    
    return total_deleted


def main():
    args = sys.argv[1:]
    dry_run = '--dry-run' in args
    do_all = '--all' in args
    
    # Remove flags from args
    targets = [a for a in args if not a.startswith('--')]
    
    if not targets and not do_all:
        print("Usage: python3 dedup_by_search.py [--dry-run] [--all] <skill_name1> [skill_name2 ...]")
        print("  --dry-run:  Show what would be deleted without actually deleting")
        print("  --all:      Scan ALL unique skill names found via search query")
        sys.exit(1)
    
    token = get_token()
    
    if do_all:
        # Search broadly, then extract unique skill names from page names
        # Pattern: "BookName › skill-name › SKILL.md"
        result = search(token, "› SKILL.md", count=500)
        pages = result.get('data', [])
        names = set()
        for p in pages:
            name = p.get('name', '')
            # Extract skill name: "BookName › skill-name › SKILL.md"
            parts = name.split(' › ')
            if len(parts) >= 3:
                names.add(parts[1])  # The skill-name part
        
        print(f"Found {len(names)} unique skill names in search results")
        targets = sorted(names)
    
    total_cleaned = 0
    for skill_name in targets:
        print(f"\n[{skill_name}]")
        deleted = dedup_skill(token, skill_name, dry_run)
        total_cleaned += deleted
    
    if dry_run:
        print(f"\n[Dry run complete] Would delete {total_cleaned} duplicate page(s)")
    else:
        print(f"\n[Done] Deleted {total_cleaned} duplicate page(s)")


if __name__ == '__main__':
    main()
