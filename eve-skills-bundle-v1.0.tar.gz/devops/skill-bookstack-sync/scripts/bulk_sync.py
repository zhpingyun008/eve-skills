#!/usr/bin/env python3
"""
Bulk sync new/modified SKILL.md files to BookStack Skill shelf (ID=2028).
"""
import hashlib
import json
import os
import sys
import time
import urllib.request
import urllib.error
from datetime import datetime, timezone

# === CONFIG ===
TOKEN = "enhanced-learn-v2:fix-token-20260525"
BASE_URL = "http://localhost:8080"
LAST_SYNC_FILE = "/home/yestin/.hermes/logs/.skill_sync_last"
SKILLS_DIR = "/home/yestin/.hermes/skills"
HASH_CACHE_FILE = "/home/yestin/.hermes/logs/.skill_sync_hash.json"

# Book mapping: directory_name -> book_id
BOOK_MAP = {
    "agent-skills": 2031,
    "cmmi5": 2032,
    "devops": 2033,
    "security": 2034,
    "meta": 2035,
    "engineering": 2036,
    "productivity": 2037,
    "business": 2753,
    "optimization": 3094,
    "evolution": 3100,
    "sdlc": 3132,
}

# Root-level skill -> book_id mapping (synced from references/book-mappings.md)
# Skills stored directly in ~/.hermes/skills/<name>/SKILL.md with no subdirectory.
ROOT_MAP = {
    "apikey-image-gen": 2031,
    "grok-image-to-video": 2036,
    "hyperframes": 2036,
    "markdown-viewer": 2036,
    "remotion": 2036,
    "mcp-server-installer": 2033,
    "agent-heartbeat": 2033,
    "agent-compliance-audit": 2032,
    "agent-self-audit": 2031,
    "agent-security-posture-audit": 2034,
    "sandbox-exec": 2033,
    "self-healer": 2035,
    "code-review": 2036,
    "mermaid-render": 2036,
    "browser-automation": 2036,
    "computer-use-linux": 2036,
    "win-desktop-control": 2036,
    "codex-ceo": 2035,
    "codex-shared": 2035,
    "rl-finetune": 2035,
    "claude-code-thirdparty": 2036,
    "ide-bridge": 2036,
    "kanban-worker": 2037,
    "hermes-os-portal-build": 2033,
    "multi-profile-platform-rollout": 2033,
    "webapp-reverse-doc": 2036,
    "gbrain": 2035,
    "ai-company-intelligence": 2035,
    "agent-workflow": 2031,
}

# Page prefix name for each book id (used in page names like "{prefix} › {skill} › SKILL.md")
BOOK_PREFIX = {
    2031: "agent-skills", 2032: "cmmi5", 2033: "devops", 2034: "security",
    2035: "meta", 2036: "engineering", 2037: "productivity", 2753: "business",
    3094: "optimization", 3100: "evolution", 3132: "sdlc", 2029: "general",
}

# Read last sync timestamp
def read_last_sync():
    try:
        with open(LAST_SYNC_FILE) as f:
            return float(f.readline().strip())
    except (FileNotFoundError, ValueError):
        return 0.0

# Update last sync timestamp
def update_last_sync(ts=None):
    if ts is None:
        ts = time.time()
    with open(LAST_SYNC_FILE, 'w') as f:
        f.write(f"{ts}\n{datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')}\n")
    return ts

# Find all SKILL.md files
def find_skill_files():
    result = []
    for root, dirs, files in os.walk(SKILLS_DIR):
        for f in files:
            if f == "SKILL.md":
                path = os.path.join(root, f)
                mtime = os.path.getmtime(path)
                result.append((mtime, path))
    result.sort(key=lambda x: x[0])
    return result

# Get category and skill name from path
def parse_skill_path(path):
    rel = os.path.relpath(path, SKILLS_DIR)
    parts = rel.replace('\\', '/').split('/')
    if len(parts) == 1:
        # Root-level skill: skills/skillname/SKILL.md
        return None, parts[0]
    elif len(parts) >= 2:
        # Categorized: skills/{category}/{skillname}/SKILL.md
        # But what about skills/{skillname}/SKILL.md?
        # If parts has 2 items: ['category', 'SKILL.md']? No...
        # Let me think: rel path is like "agent-skills/codebase-navigator/SKILL.md"
        # So parts = ['agent-skills', 'codebase-navigator', 'SKILL.md']
        # For root level: 'self-healer/SKILL.md' -> parts = ['self-healer', 'SKILL.md']
        if parts[-1] == 'SKILL.md' and len(parts) >= 2:
            skill_name = parts[-2]
            if len(parts) == 2:
                return None, skill_name  # root-level
            else:
                category = parts[0]
                return category, skill_name
    return None, None

# Get or create page in BookStack
def create_or_update_page(book_id, page_name, content):
    """Create a new page in BookStack. Returns (success, page_id)."""
    url = f"{BASE_URL}/api/pages"
    
    payload = json.dumps({
        "book_id": book_id,
        "name": page_name,
        "html": f"<pre>{content}</pre>"
    }).encode('utf-8')
    
    req = urllib.request.Request(url, data=payload, method='POST')
    req.add_header("Authorization", f"Token {TOKEN}")
    req.add_header("Content-Type", "application/json")
    
    try:
        resp = urllib.request.urlopen(req, timeout=30)
        result = json.loads(resp.read().decode())
        return True, result.get('id')
    except urllib.error.HTTPError as e:
        error_body = e.read().decode()
        status = e.code
        # If 409 conflict, try to find and update existing page
        if status == 409:
            return "conflict", None
        return False, f"HTTP {status}: {error_body[:200]}"
    except Exception as e:
        return False, str(e)

# Find existing page: try filter[name] first, fall back to search API for Unicode names (P15)
def find_page_by_name(book_id, page_name):
    from urllib.parse import quote
    # Strategy A: filter[name] — fast path for ASCII-only page names
    url = f"{BASE_URL}/api/pages?filter[name]={quote(page_name)}&count=1"
    req = urllib.request.Request(url)
    req.add_header("Authorization", f"Token {TOKEN}")
    try:
        resp = urllib.request.urlopen(req, timeout=15)
        data = json.loads(resp.read().decode())
        if data.get('data') and len(data['data']) > 0:
            return data['data'][0]['id']
    except:
        pass
    # Strategy A2 (fallback): search API handles Unicode page names reliably
    try:
        encoded = quote(f'"{page_name}"')
        url = f"{BASE_URL}/api/search?query={encoded}&count=5"
        req = urllib.request.Request(url)
        req.add_header("Authorization", f"Token {TOKEN}")
        resp = urllib.request.urlopen(req, timeout=15)
        data = json.loads(resp.read().decode())
        if data.get('data'):
            for item in data['data']:
                if item.get('name') == page_name and item.get('book_id') == book_id:
                    return item['id']
    except:
        pass
    return None

# Update existing page
def update_page(page_id, page_name, content):
    url = f"{BASE_URL}/api/pages/{page_id}"
    payload = json.dumps({
        "name": page_name,
        "html": f"<pre>{content}</pre>",
    }).encode('utf-8')
    
    req = urllib.request.Request(url, data=payload, method='PUT')
    req.add_header("Authorization", f"Token {TOKEN}")
    req.add_header("Content-Type", "application/json")
    
    try:
        resp = urllib.request.urlopen(req, timeout=30)
        result = json.loads(resp.read().decode())
        return True, result.get('id')
    except Exception as e:
        return False, str(e)

# Escape HTML for pre tag content
def escape_html(text):
    return text.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')

def file_hash(path):
    """Compute SHA256 hash of a file. Used for batch-touch detection (P1)."""
    with open(path, 'rb') as f:
        return hashlib.sha256(f.read()).hexdigest()

def main():
    import urllib.parse
    
    last_sync = read_last_sync()
    print(f"Last sync: {datetime.fromtimestamp(last_sync)} (ts={last_sync})")
    
    all_files = find_skill_files()
    
    # Filter newer files
    newer = [(m, p) for m, p in all_files if m > last_sync]
    print(f"Total SKILL.md files: {len(all_files)}")
    print(f"Newer than last sync: {len(newer)}")
    
    if not newer:
        print("No new/modified skills to sync.")
        return
    
    # Categorize
    mapped = []
    unmapped = []
    
    for mtime, path in newer:
        cat, name = parse_skill_path(path)
        if cat and cat in BOOK_MAP:
            mapped.append((mtime, path, cat, name, BOOK_MAP[cat]))
        elif cat == '_archive':
            pass  # Skip archived skills
        elif cat is None and name in ROOT_MAP:
            book_id = ROOT_MAP[name]
            prefix = BOOK_PREFIX.get(book_id, "general")
            mapped.append((mtime, path, prefix, name, book_id))
        elif cat is None:
            mapped.append((mtime, path, "general", name, 2029))
        else:
            unmapped.append((mtime, path, cat, name))
    
    print(f"\nMapped for sync: {len(mapped)}")
    print(f"Unmapped (skipped): {len(unmapped)}")
    for _, p, c, n in unmapped:
        print(f"  [SKIP] {c}/{n}")
    # Count root-level fallback to Book 2029 for reporting
    root_2029 = sum(1 for _, _, _, _, bid in mapped if bid == 2029)
    
    # Load hash cache to skip batch-touched files without content change (P1)
    hash_cache = {}
    if os.path.exists(HASH_CACHE_FILE):
        try:
            with open(HASH_CACHE_FILE) as f:
                hash_cache = json.load(f)
        except:
            hash_cache = {}
    
    # Process mapped files
    created = 0
    updated = 0
    errors = 0
    conflicts = 0
    skipped_by_hash = 0
    
    for mtime, path, cat, name, book_id in mapped:
        # Skip if content unchanged despite mtime change (batch-touch detection, P1)
        rel_path = os.path.relpath(path, SKILLS_DIR)
        current_hash = file_hash(path)
        if hash_cache.get(rel_path) == current_hash:
            skipped_by_hash += 1
            continue
        
        # Read content
        with open(path, 'r', encoding='utf-8', errors='replace') as f:
            raw_content = f.read()
        
        page_name = f"{cat} › {name} › SKILL.md"
        escaped = escape_html(raw_content)
        
        # Try create first
        success, result = create_or_update_page(book_id, page_name, escaped)
        
        if success is True:
            created += 1
            print(f"  ✓ CREATED {page_name} (page_id={result})")
        elif success == "conflict":
            # Try to find and update
            page_id = find_page_by_name(book_id, page_name)
            if page_id:
                ok, _ = update_page(page_id, page_name, escaped)
                if ok:
                    updated += 1
                    print(f"  ✓ UPDATED {page_name} (page_id={page_id})")
                else:
                    errors += 1
                    print(f"  ✗ FAILED update {page_name}")
            else:
                conflicts += 1
                print(f"  ? CONFLICT but not found: {page_name}")
        else:
            errors += 1
            print(f"  ✗ ERROR {page_name}: {result}")
        
        # Small delay to be nice to the API
        time.sleep(0.3)
    
    # Rebuild full hash cache (P1: prevents re-sync on next run from batch-touched files)
    fresh_cache = {}
    for root, _dirs, files in os.walk(SKILLS_DIR):
        if '_archive' in root.split(os.sep):
            continue
        if 'SKILL.md' in files:
            fp = os.path.join(root, 'SKILL.md')
            rel = os.path.relpath(fp, SKILLS_DIR)
            fresh_cache[rel] = hashlib.sha256(open(fp, 'rb').read()).hexdigest()
    with open(HASH_CACHE_FILE, 'w') as f:
        json.dump(fresh_cache, f, indent=2)
    
    # Update timestamp
    new_ts = time.time()
    update_last_sync(new_ts)
    
    print(f"\n===== SYNC SUMMARY =====\n")
    print(f"  Created:      {created}")
    print(f"  Updated:      {updated}")
    print(f"  Conflicts:    {conflicts}")
    print(f"  Errors:       {errors}")
    print(f"  Unmapped:     {len(unmapped)} (unknown categories)")
    print(f"  Unchanged:    {skipped_by_hash} (skipped by hash cache)")
    if root_2029:
        print(f"  Fallback2029: {root_2029} (unmapped root-level → Book 2029)")
    print(f"  New timestamp: {datetime.fromtimestamp(new_ts)}\n")
    
    # Return structured data for reporting
    return {
        "created": created,
        "updated": updated,
        "errors": errors,
        "conflicts": conflicts,
        "skipped_by_hash": skipped_by_hash,
        "skipped_unmapped": len(unmapped),
        "root_2029": root_2029,
        "total": len(mapped),
        "unmapped_skills": [n for _, _, c, n in unmapped],
    }

if __name__ == "__main__":
    result = main()
