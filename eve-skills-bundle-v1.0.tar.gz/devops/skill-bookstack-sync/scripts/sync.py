#!/usr/bin/env python3
"""
skill-bookstack-sync — Standalone sync script for SKILL.md → BookStack Skill技能库

Usage:
  python3 sync.py          # Normal sync (new/modified since last timestamp)
  python3 sync.py --dry-run  # Preview only, no API calls
  python3 sync.py --force  # Force sync all skills regardless of timestamp
"""
import html
import json
import os
import sys
import time
import urllib.request

# ── Configuration ──────────────────────────────────────────────────────────
BASE_URL = "http://localhost:8080/api"
AUTH_HEADER = "Token enhanced-learn-v2:fix-token-20260525"
SKILLS_BASE = os.path.expanduser("~/.hermes/skills")
TIMESTAMP_FILE = os.path.expanduser("~/.hermes/logs/.skill_sync_last")
SHELF_ID = 2028

# Book mapping (category_dir → (book_id, chinese_name))
# Default fallback for unmapped categories / top-level skills
TOP_LEVEL_BOOK_ID = 2029
TOP_LEVEL_BOOK_NAME = "技能库总览"

# Full book mapping — keep in sync with SKILL.md's Category→Book Mapping table
BOOK_MAP = {
    # Dedicated books
    "agent-skills": (2031, "Agent核心技能"),
    "cmmi5": (2032, "CMMI5过程域"),
    "devops": (2033, "运维自动化"),
    "security": (2034, "安全审计"),
    "meta": (2035, "元技能·进化"),
    "engineering": (2036, "工程效能"),
    "productivity": (2037, "生产力工具"),
    "business": (2753, "商业业务"),
    "optimization": (3094, "成本与性能优化"),
    "evolution": (3100, "自进化引擎"),
    "sdlc": (3132, "SDLC软件工程"),
    "collaboration": (3281, "团队协作"),
    "data": (3284, "数据工程"),
    "dev": (3288, "Dev"),
    "dev-experience": (3290, "开发体验"),
    "dev-tools": (3293, "开发工具"),
    "integration": (3299, "Integration"),
    "media-skills": (3301, "媒体技能"),
    "mlops": (3303, "MLOps"),
    "observability": (3307, "可观测性"),
    "quality": (3336, "质量保障"),
    "testing": (3349, "测试实践"),
    # Top-level skills — route to their ACTUAL target books based on
    # BookStack organization. These were previously all routed to 2029
    # (技能库总览), but that caused duplicate pages because they already
    # existed in their respective category books. Keep in sync with the
    # actual BookStack shelf state — verify periodically.
    #
    # ⚠️ NOTE: These entries are FALLBACKS used when frontmatter has no
    # `category:` field. If frontmatter HAS a category, sync.py routes
    # via BOOK_MAP[category_name], making these explicit entries dead
    # code for that skill. But keep them accurate regardless — they are
    # the ONLY routing for skills without frontmatter, and serve as
    # documentation. Verify against frontmatter when updating them.
    "_archive": (2029, "技能库总览"),  # skip — archived skills still go to 总览
    "agent-compliance-audit": (2034, "安全审计"),
    "agent-heartbeat": (2031, "Agent核心技能"),
    "agent-security-posture-audit": (2034, "安全审计"),
    "agent-self-audit": (2035, "元技能·进化"),
    "agent-workflow": (2035, "元技能·进化"),
    "apikey-image-gen": (2031, "Agent核心技能"),
    "browser-automation": (2033, "运维自动化"),
    "claude-code-thirdparty": (2031, "Agent核心技能"),
    "code-review": (2036, "工程实践"),
    "computer-use-linux": (2033, "运维自动化"),
    "gbrain": (2035, "元技能·进化"),
    "grok-image-to-video": (2031, "Agent核心技能"),
    "hermes-os-portal-build": (2033, "运维自动化"),
    "hyperframes": (2031, "Agent核心技能"),
    "ide-bridge": (2031, "Agent核心技能"),
    "kanban-worker": (2037, "生产力工具"),
    "markdown-viewer": (2031, "Agent核心技能"),
    "mcp-server-installer": (2033, "运维自动化"),
    "mermaid-render": (2037, "生产力工具"),
    "multi-profile-platform-rollout": (2033, "运维自动化"),
    "remotion": (2031, "Agent核心技能"),
    "rl-finetune": (2035, "元技能·进化"),
    "sandbox-exec": (2034, "安全审计"),
    "self-healer": (3307, "可观测性"),
    "supplier-manager": (2032, "CMMI5过程域"),
    "webapp-reverse-doc": (2033, "运维自动化"),
    "win-desktop-control": (2033, "运维自动化"),
}

CHINESE_BOOK_NAMES = {k: v for k, (_, v) in BOOK_MAP.items()}


# ── API helpers ───────────────────────────────────────────────────────────
def api_call(path, method="GET", data=None):
    """Make a BookStack API call."""
    url = f"{BASE_URL}{path}"
    headers = {
        "Authorization": AUTH_HEADER,
        "Content-Type": "application/json",
    }
    body = json.dumps(data, ensure_ascii=False).encode("utf-8") if data else None
    req = urllib.request.Request(url, data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            raw = resp.read().decode("utf-8")
            return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as e:
        err_body = e.read().decode("utf-8", errors="replace")
        print(f"  ⚠️  HTTP {e.code} on {method} {path}: {err_body[:500]}", file=sys.stderr)
        return None
    except Exception as e:
        print(f"  ⚠️  Error on {method} {path}: {e}", file=sys.stderr)
        return None


def get_yaml_category(filepath):
    """Extract `category` from YAML frontmatter if present."""
    try:
        with open(filepath) as f:
            content = f.read()
        if content.startswith("---"):
            end = content.find("---", 3)
            if end > 0:
                frontmatter = content[3:end]
                for line in frontmatter.strip().split("\n"):
                    ls = line.strip()
                    if ls.startswith("category:"):
                        val = ls.split(":", 1)[1].strip().strip("\"'")
                        if val:
                            return val
    except Exception:
        pass
    return None


def get_existing_pages(book_id):
    """Return dict {page_name: [id, ...]} for all pages in a book.

    Uses a list of IDs per name so same-name duplicates are NOT silently
    dropped. The caller (update/cleanup logic) relies on seeing all IDs
    to detect and eliminate same-name duplicates.
    """
    book = api_call(f"/books/{book_id}")
    if not book:
        return {}
    existing = {}
    for item in book.get("contents", []):
        if item.get("type") == "page":
            name = item["name"]
            existing.setdefault(name, []).append(item["id"])
    return existing


def write_timestamp(ts_str):
    """Write timestamp + human-readable date to the state file (2-line format)."""
    import datetime as _dt
    human_ts = _dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    os.makedirs(os.path.dirname(TIMESTAMP_FILE), exist_ok=True)
    with open(TIMESTAMP_FILE, "w") as f:
        f.write(f"{ts_str}\n{human_ts}\n")
    print(f"  \U0001f4be Timestamp saved: {ts_str} ({human_ts})")


def get_book_id_and_name(category):
    """Return (book_id, chinese_name) for a category."""
    if category is None:
        return TOP_LEVEL_BOOK_ID, TOP_LEVEL_BOOK_NAME
    if category in BOOK_MAP:
        return BOOK_MAP[category]
    # Unmapped category — check on BookStack
    chinese_name = CHINESE_BOOK_NAMES.get(category, f"{category.capitalize()} — {category}分类技能")
    # Search for existing book by name on shelf 2028
    shelf = api_call(f"/shelves/{SHELF_ID}")
    if shelf:
        for item in shelf.get("contents", []):
            if item.get("type") == "book" and item.get("name") == chinese_name:
                BOOK_MAP[category] = (item["id"], chinese_name)
                return item["id"], chinese_name
    # Create new book
    print(f"  📚 Creating new book '{chinese_name}' for category '{category}' on shelf {SHELF_ID}")
    new_book = api_call("/books", "POST", {
        "name": chinese_name,
        "description": f"{category}分类技能",
        "bookshelf_id": SHELF_ID,
        "tags": [{"name": "category", "value": category}]
    })
    if new_book and new_book.get("id"):
        BOOK_MAP[category] = (new_book["id"], chinese_name)
        return new_book["id"], chinese_name
    print(f"  ❌ Failed to create book for category '{category}'", file=sys.stderr)
    return None, chinese_name


# ── Main sync logic ──────────────────────────────────────────────────────
def main():
    dry_run = "--dry-run" in sys.argv
    force = "--force" in sys.argv

    # Phase 1: Read state
    if os.path.exists(TIMESTAMP_FILE):
        with open(TIMESTAMP_FILE) as f:
            raw = f.read().strip()
        # Support BOTH formats: newline-separated (2 lines, native write_timestamp)
        #   AND pipe-delimited (1 line, written by ad-hoc / external scripts).
        #   Examples:
        #     "1782292488\n2026-06-24 17:14:48"          — 2-line
        #     "1782292488|2026-06-24 17:14:48"             — 1-line pipe
        #   Split by newline first, then by pipe, take segment 0.
        first_ts_segment = raw.split("\n")[0].split("|")[0].strip()
        try:
            content_ts = int(float(first_ts_segment))
        except (ValueError, TypeError):
            content_ts = 0
        current_ts = int(time.time())
        if content_ts > current_ts + 3600:
            print(f"  ⚠️  Timestamp corruption: content={content_ts}, falling back to file mtime")
            last_sync = int(os.path.getmtime(TIMESTAMP_FILE))
        else:
            last_sync = content_ts
    else:
        last_sync = 0

    if force:
        last_sync = 0
        print("🔁 Force mode: scanning ALL skills")

    print(f"📡 Last sync: {time.ctime(last_sync)} (epoch: {last_sync})")

    # Phase 2: Scan for changes
    changed = []
    skipped_archive = 0
    for root, dirs, files in os.walk(SKILLS_BASE):
        # Skip _archive directory
        if "_archive" in root.split(os.sep):
            skipped_archive += 1
            continue
        if "SKILL.md" in files:
            filepath = os.path.join(root, "SKILL.md")
            mtime = os.path.getmtime(filepath)
            if mtime > last_sync:
                rel_path = os.path.relpath(root, SKILLS_BASE)
                parts = rel_path.split(os.sep)
                if len(parts) >= 2:
                    category = parts[0]
                    skill_name = parts[1]
                else:
                    # Top-level — check YAML for explicit category
                    yaml_cat = get_yaml_category(filepath)
                    if yaml_cat:
                        category = yaml_cat
                    else:
                        category = None
                    skill_name = parts[0]
                changed.append((category, skill_name, filepath, mtime))

    if not changed:
        print("✅ No new or modified SKILL.md files to sync.")
        return

    print(f"📝 Found {len(changed)} modified/new SKILL.md file(s):")
    for category, skill_name, filepath, mtime in sorted(changed, key=lambda x: (x[0] or 'zzz', x[1])):
        cat_display = category if category else "(top-level)"
        print(f"  [{cat_display}] {skill_name} — {time.ctime(mtime)}")

    if dry_run:
        print("\n🏁 Dry-run complete. No API calls made.")
        return

    # Phase 3: Process each changed file
    stats = {"created": 0, "updated": 0, "new_books": 0, "errors": 0}

    # Group by book to minimize API calls
    books_cache = {}

    for category, skill_name, filepath, mtime in sorted(changed, key=lambda x: (x[0] or 'zzz', x[1])):
        book_id, book_name = get_book_id_and_name(category)
        if book_id is None:
            print(f"  ❌ Cannot determine book for '{skill_name}' (category={category})")
            stats["errors"] += 1
            continue

        # Cache existing pages per book
        if book_id not in books_cache:
            print(f"  📖 Fetching existing pages for Book #{book_id} ({book_name})...")
            books_cache[book_id] = get_existing_pages(book_id)

        existing_pages = books_cache[book_id]

        # Read raw content
        with open(filepath) as f:
            raw_content = f.read()

        # Construct page name using Chinese convention (matching sync.py)
        page_name = f"{book_name} › {skill_name} › SKILL.md"
        escaped = html.escape(raw_content)
        page_html = f"<pre>{escaped}</pre>"

        payload = {
            "name": page_name,
            "html": page_html,
            "markdown": raw_content,  # 🚨 Prevents PHP HTML truncation on large files
            "book_id": book_id,
            "tags": [
                {"name": "category", "value": category or "top-level"},
                {"name": "skill", "value": skill_name}
            ]
        }

        if page_name in existing_pages:
            # UPDATE — pick the newest page (highest ID) as the survivor
            all_ids = sorted(existing_pages[page_name])
            keep_id = all_ids[-1]
            url = f"/pages/{keep_id}"
            result = api_call(url, "PUT", payload)
            if result:
                print(f"  🔄 Updated page #{keep_id}: {page_name}")
                stats["updated"] += 1
                # Duplicate cleanup: delete ALL other pages sharing the same name
                for dup_id in all_ids[:-1]:
                    api_call(f"/pages/{dup_id}", "DELETE")
                    print(f"    🗑️ Deleted same-name duplicate page #{dup_id}")
                    stats["updated"] += 1
            else:
                stats["errors"] += 1
        else:
            # Fuzzy match: check for pages with same skill_name but different prefix
            fuzzy_matches = []
            for pn, ids in existing_pages.items():
                if f"› {skill_name} ›" in pn:
                    fuzzy_matches.extend(ids)
            if fuzzy_matches:
                # Pick the newest (highest ID) to update, delete rest
                fuzzy_matches.sort()
                keep_id = fuzzy_matches[-1]
                url = f"/pages/{keep_id}"
                result = api_call(url, "PUT", payload)
                if result:
                    print(f"  🔄 Updated (fuzzy match) page #{keep_id} → {page_name}")
                    stats["updated"] += 1
                for dup_id in fuzzy_matches[:-1]:
                    api_call(f"/pages/{dup_id}", "DELETE")
                    print(f"    🗑️ Deleted duplicate page #{dup_id}")
                books_cache[book_id] = get_existing_pages(book_id)
            else:
                # CREATE
                result = api_call("/pages", "POST", payload)
                if result:
                    print(f"  🆕 Created page #{result.get('id')}: {page_name}")
                    stats["created"] += 1
                else:
                    stats["errors"] += 1

    # Phase 5: Update timestamp — use max(current_time, latest_skill_mtime) to
    # prevent drift. If sync takes a long time, a skill modified during sync
    # could have mtime > our timestamp, causing re-processing next run.
    raw_ts = int(time.time())
    latest_mtime = 0
    for root, dirs, files in os.walk(SKILLS_BASE):
        if "_archive" in root.split(os.sep):
            continue
        if "SKILL.md" in files:
            mtime = int(os.path.getmtime(os.path.join(root, "SKILL.md")))
            latest_mtime = max(latest_mtime, mtime)
    final_ts = max(raw_ts, int(latest_mtime) + 1)
    new_ts = str(final_ts)
    write_timestamp(new_ts)

    # Report
    print(f"\n{'='*60}")
    print(f"📊 Sync Summary:")
    print(f"  ✅ Created:     {stats['created']} new page(s)")
    print(f"  🔄 Updated:     {stats['updated']} page(s)")
    print(f"  ❌ Errors:      {stats['errors']}")
    print(f"  📝 Total files: {len(changed)}")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()
