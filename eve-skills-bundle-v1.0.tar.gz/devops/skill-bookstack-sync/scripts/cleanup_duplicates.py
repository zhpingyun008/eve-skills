#!/usr/bin/env python3
"""
cleanup-duplicate-pages.py
Periodically deduplicate BookStack skill pages in shelf 2028.
Keeps only the page with the latest updated_at per (book_id, page_name).

Usage: echo 'TOKEN_VALUE' > /tmp/.bookstack_token && python3 this_script.py

Cron-safe: no pipes, no execute_code. All file I/O through Python stdlib.
Tested: 15 stale pages cleaned in one pass on 2026-06-29.

WARNING: Books with 18K+ pages (Book 2033) may cause slow pagination.
Consider using Search API per target page name as a faster alternative.
"""

import json
import os
import subprocess
import sys
from collections import defaultdict
from datetime import datetime

TOKEN_PATH = '/tmp/.bookstack_token'
BASE_URL = 'http://localhost:8080/api'
SHELF_ID = 2028

def now():
    return datetime.now().strftime('%Y-%m-%d %H:%M:%S')

def curl_get(path, output_path):
    """Download a JSON endpoint to a file."""
    token = open(TOKEN_PATH).read().strip()
    url = f'{BASE_URL}{path}'
    r = subprocess.run(
        ['curl', '-s', '-H', f'Authorization: Token {token}', url],
        capture_output=True, text=True, timeout=60
    )
    with open(output_path, 'w') as f:
        f.write(r.stdout)
    return json.loads(r.stdout)

def curl_delete(page_id):
    """DELETE a page, return HTTP status code."""
    token = open(TOKEN_PATH).read().strip()
    url = f'{BASE_URL}/pages/{page_id}'
    r = subprocess.run(
        ['curl', '-s', '-o', '/dev/null', '-w', '%{http_code}',
         '-X', 'DELETE', '-H', f'Authorization: Token {token}', url],
        capture_output=True, text=True, timeout=15
    )
    return r.stdout.strip()

def main():
    print(f'[{now()}] === Skill Page Duplicate Cleanup (shelf {SHELF_ID}) ===')

    # Step 1: Get all books in the shelf
    shelf = curl_get(f'/shelves/{SHELF_ID}', '/tmp/cleanup_shelf.json')
    book_ids = [b['id'] for b in shelf.get('books', [])]
    if not book_ids:
        book_ids = [2029, 2031, 2032, 2033, 2034, 2035, 2036, 2037, 2753, 3094, 3100, 3132]
    print(f'[{now()}] Books: {book_ids}')

    # Step 2: Fetch all pages from all books
    all_pages = []
    for book_id in book_ids:
        offset = 0
        while True:
            data = curl_get(f'/pages?book_id={book_id}&count=500&offset={offset}',
                            f'/tmp/cleanup_chunk_{book_id}_{offset}.json')
            for p in data.get('data', []):
                all_pages.append({
                    'id': p['id'],
                    'name': p['name'],
                    'updated_at': p.get('updated_at', ''),
                    'book_id': p.get('book_id', book_id)
                })
            total = data.get('total', 0)
            offset += 500
            if offset >= total:
                break
        print(f'  Book {book_id}: {len([p for p in all_pages if p["book_id"] == book_id])} pages')

    # Step 3: Find duplicates
    groups = defaultdict(list)
    for p in all_pages:
        groups[(p['book_id'], p['name'])].append(p)

    to_delete = []
    for key, group in groups.items():
        if len(group) <= 1:
            continue
        sorted_p = sorted(group, key=lambda x: x.get('updated_at', ''), reverse=True)
        for stale in sorted_p[1:]:
            to_delete.append(stale)
            print(f'  DUP: book={key[0]} name={key[1]!r} stale_id={stale["id"]} updated={stale.get("updated_at", "?")}')

    with open('/tmp/cleanup_to_delete.json', 'w') as f:
        json.dump(to_delete, f, ensure_ascii=False)
    print(f'\nTotal: {len(to_delete)} stale duplicates')

    if len(to_delete) == 0:
        print(f'[{now()}] No duplicates found. Nothing to delete.')
        return

    # Step 4: Delete stale pages
    print(f'[{now()}] Deleting {len(to_delete)} stale pages...')
    ok = fail = 0
    for p in to_delete:
        code = curl_delete(p['id'])
        if code == '204':
            ok += 1
            print(f'  OK: /pages/{p["id"]}')
        else:
            fail += 1
            print(f'  FAIL: /pages/{p["id"]} -> HTTP {code}')

    print(f'\nResult: {ok} deleted, {fail} failed')
    print(f'[{now()}] === Cleanup complete ===')

if __name__ == '__main__':
    main()
