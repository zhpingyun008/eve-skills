# Cron Sync Pitfalls — Discovered 2026-06-25

## 1. PHP Built-in Server Single-Threaded Blocking

The `php -S` development server handles ONE request at a time. All others queue up and timeout.

**Symptoms**: curl TCP-connects to 127.0.0.1:8080 but receives zero bytes after 5-60s timeout. PHP process shows state `R` (running) with socket fd created when the stuck request started.

**Root causes**:
- Previous long request (rendering 300KB page) still processing
- Another script (e.g., `bookstack-eve-sync.py`) actively using the API

**Fix — Kill and restart PHP**:
```bash
# Find PID
ps aux | grep 'php8.*8080' | grep -v grep
# Kill with explicit PID
kill <PID>
# Restart in background
terminal(background=true, command="/home/yestin/opt/php/usr/bin/php8.3 -c /home/yestin/opt/php/php.ini -d memory_limit=512M -S 127.0.0.1:8080 -t /home/yestin/projects/BookStack/public /home/yestin/projects/BookStack/server.php")
# Verify
sleep 3 && curl -s -o /dev/null -w '%{http_code}' 'http://127.0.0.1:8080/'
```

## 2. MariaDB Socket File Deleted by Foreground Script

`bookstack-foreground.sh` runs `rm -f /tmp/mariadb.sock` on startup, deleting the socket of any running MariaDB instance. MariaDB does NOT recreate the socket if deleted while running.

**Symptom**: BookStack returns 500: `"SQLSTATE[HY000] [2002] No such file or directory (Connection: mysql, Socket: /tmp/mariadb.sock)"`. MariaDB process still visible in `ps`, TCP port still listening.

**Fix — Restart MariaDB**:
```bash
kill <mariadb_pid>
# Start fresh (try without LD_LIBRARY_PATH first — often works)
/home/yestin/opt/mariadb/usr/sbin/mariadbd \
  --basedir=/home/yestin/opt/mariadb/usr \
  --datadir=/home/yestin/opt/mariadb/data \
  --port=3307 --socket=/tmp/mariadb.sock --user=yestin \
  --bind-address=127.0.0.1
sleep 3
ls -la /tmp/mariadb.sock
```

## 3. Large SKILL.md (180KB+) — POST OK but GET returns 500

Creating a page with 180KB+ content via `POST /api/pages` returns HTTP 200 and stores correctly in DB. However `GET /api/pages/{id}` returns HTTP 500 because rendering the huge `<pre>` block exceeds PHP memory/processing limits.

**This is cosmetic only**. Verify via DB:
```bash
/home/yestin/opt/mariadb/usr/bin/mariadb -S/tmp/mariadb.sock \
  -ubookstack -pyestin2049 bookstack \
  -e "SELECT LENGTH(html), LENGTH(text) FROM entity_page_data WHERE page_id = <ID>;"
```

## 4. Laravel bootstrap Cache Corruption

Writing invalid content to `bootstrap/cache/config.php` breaks Laravel with `"Target [Illuminate\Contracts\Foundation\MaintenanceMode] is not instantiable"`.

**Fix**: Move the cache file to /tmp/ and restart PHP:
```bash
mv /home/yestin/projects/BookStack/bootstrap/cache/config.php /tmp/
# Restart PHP
```
