# `-newer` vs Content-Based Comparison — 2026-06-29

## Discovery

During the 2026-06-29 08:00 sync run, I first used `find -printf '%T@'` to get Unix epoch timestamps
and compared them against the content of `.skill_sync_last` (also epoch). This showed **5 files** as newer.

But when I used `find -newer ~/.hermes/logs/.skill_sync_last` (filesystem mtime comparison), only **2 files**
were flagged. The `-newer` approach is the correct one.

## Root Cause

| File | Epoch Timestamp | Human Time | `-newer` Result |
|------|----------------|------------|-----------------|
| `.skill_sync_last` (mtime) | 1782688377 | 07:12:57 | — (reference) |
| `eve-analyst/SKILL.md` | 1782686992 | 05:59:52 | ❌ older |
| `ccgp-bid-scraper/SKILL.md` | 1782685324 | 05:28:44 | ❌ older |
| `eve-customer-success/SKILL.md` | 1782684800 | 05:13:20 | ❌ older |
| `computer-use-linux/SKILL.md` | 1782688489 | 07:14:49 | ✅ newer |
| `eve-deep-consciousness/SKILL.md` | 1782690338 | 07:45:38 | ✅ newer |

The first 3 files' epochs (05:xx) were numerically larger than the content timestamp (07:12:49 content)
but smaller than the file mtime (07:12:57). Since both the content and `-printf '%T@'` use Unix epoch,
a naive comparison `epoch > content` was correct mathematically — but the content timestamp was
**8 seconds behind the file mtime** due to the write-to-filesystem latency.

## Lesson

**Always use `find -newer` against the file itself.** It is:
- Immune to write-to-filesystem latency (content vs mtime discrepancies)
- Immune to timezone drift (compares filesystem-level timestamps)
- Immune to clock skew
- Immune to future-dated content
- Simpler: one command, no epoch math
