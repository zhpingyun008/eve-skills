# 2026-07-23 Cron Sync: 3 Updates, filter[name] Unicode Failure, Cross-Book Duplicates

## Summary

- **3 files synced** (all UPDATES, no creates)
- All 3 were modifications of existing BookStack pages
- Cron mode (no user interaction, automatic delivery)
- **Key finding**: `filter[name]=` fails on Unicode page names; search API works

## Files Synced

| # | Skill | Category | Book | Page ID | File mtime |
|---|-------|----------|------|---------|------------|
| 1 | caveman-compress | productivity | 生产力工具 (2037) | 23122 | 1784796211.319 |
| 2 | loop-engineering | engineering | 工程实践 (2036) | 23128 | 1784796231.606 |
| 3 | product-charter-engine | business | 商业业务 (2753) | 23129 | 1784796249.698 |

## Finding: filter[name]= Silent Failure on Unicode

**The Problem**: Using `filter[name]={urllib.parse.quote(page_name)}` returned `{"data":[],"total":0}` for all 3 page names, even though pages existed at those names.

Page names contained `›` (Unicode RIGHT-POINTING DOUBLED ARROW, U+203A). The `filter[name]=` endpoint could not match these.

**The Workaround**: `/api/search?query="{page_name}"` worked correctly:

```python
encoded = urllib.parse.quote(f'"{page_name}"')
result = api_call("GET", f"/search?query={encoded}&count=3")
# → returned correct matches for all 3 pages
```

**Side effect**: Search API may return results from other books with same name. Must validate `item['book_id'] == expected_book_id` after search.

## Finding: Cross-Book Duplicates

`business › product-charter-engine › SKILL.md` had 3 copies:
- ID=19387 → Book 2031 (Agent核心技能) — WRONG book
- ID=23120 → Book 2753 (商业业务) — old version
- ID=23129 → Book 2753 (商业业务) — latest version (updated this run)

This likely happened because:
1. Initial creation landed in wrong book (filter[name]= matched wrong book first)
2. Manual re-creation created duplicate in correct book

**Recommendation**: Run `scripts/cleanup_duplicates.py` to detect and remove cross-book duplicates. Also add a pre-sync check: before creating a page, search ALL books in shelf 2028 for the same page name.

## Execution Context

- Cron job (no user present, automatic delivery to destination)
- Timestamp last sync: 1784790436.1749582 (2026-07-23 15:07:16)
- Used `execute_code` with Python `urllib.request` (Mode A pattern) for all API calls
- Token from `.bashrc`: `BOOKSTACK_TOKEN="enhanced-learn-v2:fix-token-20260525"`
- No `BOOKSTACK_API_TOKEN_ID` or `BOOKSTACK_API_TOKEN_SECRET` env vars exist
