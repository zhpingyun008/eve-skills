# Relpath Parts-Length Silent-Skip Bug (2026-07-15)

## Symptom
An `execute_code` sync script reported `Found 0 modified SKILL.md files` even though `os.walk` confirmed a SKILL.md with `mtime > LAST_TS` existed. The file was silently skipped.

## Root Cause
The path parsing used `relpath.split('/')` and only handled 2-part or 1-part results:

```python
relpath = os.path.relpath(path, SRC)  # e.g. "devops/skill-bookstack-sync/SKILL.md"
parts = relpath.split('/')
if len(parts) == 2:
    # ...
elif len(parts) == 1:
    # ...
else:
    continue  # <-- BUG: len=3 hits this and is silently dropped
```

### Path structure breakdown
| File location | `relpath` from SRC | `len(parts)` | Expected handling |
|---|---|---|---|
| `~/.hermes/skills/devops/<skill>/SKILL.md` | `devops/<skill>/SKILL.md` | **3** | ✅ Category-level skill |
| `~/.hermes/skills/<skill>/SKILL.md` | `<skill>/SKILL.md` | 2 | Root-level skill |
| `~/.hermes/skills/SKILL.md` (unlikely) | `SKILL.md` | 1 | Edge case |

**The `len(parts) == 2` check assumes a category dir + filename, but nested skills have 3 parts: category-dir + skill-dir + filename.**

## Fix
Use `len(parts) >= 3` for category-level skills and fall back to `len(parts) == 2` for root-level:

```python
if len(parts) >= 3:
    category = parts[0]       # e.g. "devops"
    skill_name = parts[1]     # e.g. "skill-bookstack-sync"
elif len(parts) == 2:
    category = None           # root-level
    skill_name = parts[0]     # directory name before SKILL.md
else:
    continue
```

## Verification
Run a quick `os.walk` + `mtime` check in terminal — NOT via `execute_code` — to confirm files exist before debugging script logic:

```bash
python3 -c "
import os
SRC = os.path.expanduser('~/.hermes/skills')
LAST_TS = $(head -1 ~/.hermes/logs/.skill_sync_last)
count = 0
for dirpath, dirnames, filenames in os.walk(SRC):
    if '/_archive/' in dirpath: continue
    if 'SKILL.md' in filenames:
        path = os.path.join(dirpath, 'SKILL.md')
        mtime = os.path.getmtime(path)
        if mtime > LAST_TS:
            print(f'MODIFIED: {path} (mtime={mtime}, >{LAST_TS})')
            count += 1
print(f'Total modified: {count}')
"
```

## Lesson for sync scripts
Always test file discovery independently (terminal-based) before debugging the sync/API logic. A `0 modified` result could mean:
1. No files actually changed (correct — skip timestamp update)
2. **Path parsing bug** causing silent skip (as happened here)
3. `_archive` filter too aggressive
4. Timezone/mtime comparison issue

Add a `print(f"[DEBUG] parts={parts}, len={len(parts)}, adding={len(parts) >= 3 or len(parts) == 2}")` during development to catch this early.
