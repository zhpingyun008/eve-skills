# 2026-06-20 Skill-to-BookStack Sync Run (Cron B — Single-File Update)

## Basic Info

| Field | Value |
|-------|-------|
| **Session Type** | Cron job (no user present) |
| **Model** | deepseek-v4-flash |
| **Last Sync TS** | 1781910150 (07:02:30) |
| **Current Sync TS** | 1781914136 (08:08:56) |
| **Elapsed** | ~66 min since last sync |
| **SKILL.md Scanned** | 273 (all categories + _archive + root) |
| **Modified Found** | 1 |
| **Pages Updated** | 1 |
| **Pages Renamed** | 1 (⚠️ accidental) |

## Modified Skill

### agent-skills/internet-perception/SKILL.md

| Property | Value |
|----------|-------|
| Modified at | 1781914046 (2026-06-20 08:07:26) |
| Book Mapping | agent-skills → Book ID 2031 (Agent核心技能) |
| Existing Page ID | **3113** |
| Old Page Name | `Agent核心技能 › internet-perception › SKILL.md` ✅ (Chinese) |
| New Page Name | `agent-skills › internet-perception › SKILL.md` ❌ (English) |
| Revision | 3 → 4 |
| Updated At | 2026-06-20T00:08:43.000000Z ✅ (advanced) |

## 🔥 Finding 1: PUT-Based Page Rename (Worse Than Duplicate Creation)

**New problem class discovered in this session.** Previously, the English name trap only referred to CREATING new pages with English prefixes. This session proves that PUT (update) operations also suffer from it — and the consequences are WORSE:

| Aspect | CREATE duplicate | PUT rename |
|--------|-----------------|------------|
| Detection | New page ID appears → easy to spot | `updated_at` advances → looks normal |
| Original page | Original correct-name page still exists | **Original correct name is DESTROYED** |
| Recovery | Delete the new duplicate | Must name-correct via another PUT |
| Tracking | Two pages to find | Only one page, wrong name, no trace left |

**Root cause**: The ad-hoc script used `category` (English dir name `"agent-skills"`) directly in the page name field of the PUT payload:
```python
payload = {
    "name": f"{category} › {skill_name} › SKILL.md",  # "agent-skills › …"
    "html": pre_content
}
# PUT /api/pages/3113 — this RENAMES the page, not just updates content!
```

**Fix**: Always use Chinese book names in PUT payloads too:
```python
BOOK_CN = {"agent-skills": "Agent核心技能", ...}
payload = {
    "name": f"{BOOK_CN[category]} › {skill_name} › SKILL.md",  # "Agent核心技能 › …"
    "html": pre_content
}
```

**Self-verification for PUT (new)**: After every PUT, immediately GET /api/pages/{id} and check the name field. If it changed from what it was before, the PUT renamed the page — fix with a second PUT with the correct name.

## Finding 2: Task Instruction vs. Established Convention Mismatch

The cron job task specification says:
> 页面名: "{分类} › {技能名} › SKILL.md"

Where `{分类}` is the English directory name (e.g., `agent-skills`, `devops`). This DIRECTLY contradicts the established convention of using Chinese book names (e.g., `Agent核心技能`, `运维自动化`). The task spec itself encodes the English name trap.

**Lesson**: The task definition for this cron job needs to be updated to say `CN_NAME_MAP[{分类}]` instead of `{分类}`. Until then, every ad-hoc run will reproduce the English name trap by following the instruction literally.

## Finding 3: One-File Scan Timing

The full find ... -exec stat approach timed out at 30s on 273 files. The find -newer approach using the timestamp file as reference completed instantly. This confirms the existing skill recommendation to use -newer over stat.

## Action Items

1. **Fix page 3113 name** from `agent-skills › internet-perception › SKILL.md` back to `Agent核心技能 › internet-perception › SKILL.md`
2. **Update cron task definition** to use `CN_NAME_MAP[{分類}]` instead of `{分類}` for page naming
3. **Add PUT rename variant** to skill-bookstack-sync SKILL.md pitfalls
