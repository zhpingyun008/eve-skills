# BookStack Shelf 2028 - Book Mappings (as of 2026-07-17)

## Dedicated Books (category→book_id)

| Category | Book ID | Book Name |
|----------|---------|-----------|
| `agent-skills` | 2031 | Agent核心技能 |
| `cmmi5` | 2032 | CMMI5过程域 |
| `devops` | 2033 | 运维自动化 |
| `security` | 2034 | 安全审计 |
| `meta` | 2035 | 元技能·进化 |
| `engineering` | 2036 | 工程实践 |
| `productivity` | 2037 | 生产力工具 |
| `business` | 2753 | 商业业务 |
| `optimization` | 3094 | 成本与性能优化 |
| `evolution` | 3100 | 自进化引擎 |
| `sdlc` | 3132 | SDLC软件工程 |

## Root-Level Skills (no category directory)

Skills stored directly in `~/.hermes/skills/<name>/SKILL.md` (no subdirectory) have categorical mappings based on their function:

| Skill Name | Nature | Target Book ID | Target Book Name |
|------------|--------|:--------------:|-----------------|
| `apikey-image-gen` | Hermes Web UI image generation/editing | 2031 | Agent核心技能 |
| `grok-image-to-video` | xAI Grok image-to-video animation | 2036 | 工程实践 |
| `hyperframes` | HTML/CSS/JS video composition | 2036 | 工程实践 |
| `markdown-viewer` | Markdown diagram rendering | 2036 | 工程实践 |
| `remotion` | React video projects | 2036 | 工程实践 |
| `mcp-server-installer` | MCP server tool lifecycle installation | 2033 | 运维自动化 |
| `agent-heartbeat` | Agent心跳巡检系统 | 2033 | 运维自动化 |
| `agent-compliance-audit` | CMMI5多Agent合规审计 | 2032 | CMMI5过程域 |
| `agent-self-audit` | Agent自架构审计与竞品对标 | 2031 | Agent核心技能 |
| `agent-security-posture-audit` | Hermes Agent安全态势审计 | 2034 | 安全审计 |
| `sandbox-exec` | Sandbox command execution isolation | 2033 | 运维自动化 |
| `self-healer` | 自治自愈框架 | 2035 | 元技能·进化 |
| `code-review` | 6维度代码审查引擎 | 2036 | 工程实践 |
| `mermaid-render` | Zero-install Mermaid diagram renderer | 2036 | 工程实践 |
| `browser-automation` | WSL browser control system | 2036 | 工程实践 |
| `computer-use-linux` | Linux desktop observation/control | 2036 | 工程实践 |
| `win-desktop-control` | Windows desktop control (PowerShell/.NET) | 2036 | 工程实践 |
| `codex-ceo` | Codex as CEO control layer | 2035 | 元技能·进化 |
| `codex-shared` | Access Codex skills/memories/.agent governance | 2035 | 元技能·进化 |
| `rl-finetune` | RL微调全生命周期引擎 | 2035 | 元技能·进化 |
| `claude-code-thirdparty` | Claude Code第三方模型接入 | 2036 | 工程实践 |
| `ide-bridge` | IDE integration bridge via MCP/LSP | 2036 | 工程实践 |
| `kanban-worker` | Kanban task worker patterns | 2037 | 生产力工具 |
| `hermes-os-portal-build` | Hermes OS Portal feature lifecycle | 2033 | 运维自动化 |
| `multi-profile-platform-rollout` | Batch platform feature rollout | 2033 | 运维自动化 |
| `webapp-reverse-doc` | Reverse-document live web apps via CDP | 2036 | 工程实践 |
| `gbrain` | Global Brain unified cognitive hub | 2035 | 元技能·进化 |
| `ai-company-intelligence` | AI一人公司智能运营层 | 2035 | 元技能·进化 |
| `agent-workflow` | Multi-agent workflow orchestration | 2031 | Agent核心技能 |

**Unmapped root-level skills**: Any root-level skill not listed above falls through to **Book 2029** (技能库总览). When adding a new root-level skill, evaluate its function and either:
  - Add it to this table with an appropriate dedicated book, OR
  - Let it fall through to 2029 if no category fits cleanly.

## General Book (fallback for categorized but map-less categories)

| Book ID | Book Name | Affected Categories |
|---------|-----------|---------------------|
| 2029 | 技能库总览 | collaboration/, data/, dev-experience/, dev-tools/, testing/, observability/, quality/, media-skills/, mlops/, _archive (skipped), and unmapped root-level skills |

## Notes
- `_archive/` should be **skipped** (archived skills not mirrored to BookStack)
- Shelf ID: 2028 (Skill技能库)
- API: http://localhost:8080/api
- Token: read dynamically from `~/.bashrc` via `grep 'BOOKSTACK_TOKEN' ~/.bashrc | head -1 | cut -d'"' -f2`
- Do NOT hardcode token in scripts (see P4/P9 in main SKILL.md)
