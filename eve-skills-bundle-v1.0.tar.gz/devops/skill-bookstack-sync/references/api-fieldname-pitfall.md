# API Field Name Pitfall

## HTTP 422: Wrong Content Field Name

The BookStack `/api/pages` endpoint returns `422 Unprocessable Content` when the payload uses the wrong field name.

### Error
```json
{
  "error": {
    "message": "The given data was invalid.",
    "validation": {
      "html": ["The html field is required when markdown is not present."],
      "markdown": ["The markdown field is required when html is not present."]
    },
    "code": 422
  }
}
```

### Root Cause
The payload used `content_html` or `content` instead of `html`:

```python
# ❌ WRONG — triggers 422
payload = {
    "book_id": 2029,
    "name": "技能库总览 › agent-heartbeat › SKILL.md",
    "content_html": "<pre>...</pre>",   # ← WRONG field name
}

# ✅ CORRECT
payload = {
    "book_id": 2029,
    "name": "技能库总览 › agent-heartbeat › SKILL.md",
    "html": "<pre>...</pre>",           # ← CORRECT field name
}
```

### Fix
Rename the content field from `content_html` or `content` to `html` (or use `markdown` for markdown content). Only one content field (`html` or `markdown`) should be present; sending both may also cause errors.

### Discovered
2026-06-24 — first bulk UPDATE attempt on existing pages triggered this.
