# Timestamp File Race Condition — Sibling Sync Concurrent Write

## Discovery: 2026-07-02

## Symptom

When updating `~/.hermes/logs/.skill_sync_last` via `write_file`, the tool returned:

```
_warning: /home/yestin/.hermes/logs/.skill_sync_last was modified by sibling subagent
'a198e873-e43d-4974-bfe4-a2eb180db0d7' but this agent never read it.
Read the file before writing to avoid overwriting the sibling's changes.
```

A sibling subagent (another cron-triggered skill sync instance) had also written to the same timestamp file. Since this agent never read the file before writing, the sibling's timestamp was silently overwritten.

## Root Cause

Multiple skill-bookstack-sync cron jobs (or the Eve KB sync — which uses a different state file) may run concurrently within a few seconds of each other. Each instance:

1. Reads the timestamp to find modified files
2. Syncs
3. Writes a new timestamp

If two instances overlap in Step 3, the **last writer wins** — the first writer's timestamp is lost. The next run will miss files synced by the first writer (because the saved timestamp pre-dates their mtime) or re-sync already-synced files (if the saved timestamp post-dates the second writer's run but a sibling also wrote to it).

## Impact

- **Missed files**: If Instance A syncs 3 files at T=100 and Instance B overwrites with T=101, the next run (using T=101) won't re-sync Instance A's files. But since both instances sync different files, no data is lost — files are in BookStack, just not tracked in the local timestamp.
- **Re-synced files**: If Instance A syncs at T=100 and writes T=100, then Instance B writes T=98 (an older timestamp), the next run re-syncs everything between T=98 and T=100 — a harmless but wasteful full re-sync.

## Detection

Monitor for `_warning` messages in `write_file` output when writing to `~/.hermes/logs/.skill_sync_last`. The warning names the sibling subagent ID explicitly.

## Mitigation Options

### Option A: Thread-safe timestamp update (recommended for fix)

Read before write, merging timestamps by taking the max:

```python
def update_timestamp(ts_file, new_epoch):
    current = int(open(ts_file).read().strip().split("\n")[0].split("|")[0])
    # Take the max of current and new to avoid going backwards
    latest = max(current, new_epoch)
    write_file(ts_file, f"{latest}\n{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
```

**Trade-off**: If sibling ran at T=100 and we ran at T=99, T=100 is saved — the sibling's mtime floor is preserved but some of our files might be re-synced next run (from T=99 to T=100). Harmless.

### Option B: Accept the race (current behavior, simplest)

Impact is minimal — missed files remain in BookStack, re-syncs are harmless. Accept it.

### Option C: Lock file

```python
import fcntl
LOCK_FILE = os.path.expanduser("~/.hermes/logs/.skill_sync_last.lock")
with open(LOCK_FILE, "w") as lf:
    fcntl.flock(lf, fcntl.LOCK_EX)
    try: ...
    finally: fcntl.flock(lf, fcntl.LOCK_UN)
```

**Trade-off**: Requires fcntl (POSIX-only). Blocks concurrent runs. Overkill for low-impact race.

## Recommendation

**Accept the race (Option B)** for now. Files stay in BookStack regardless. If missed files are observed across 3+ consecutive runs, implement Option A.
