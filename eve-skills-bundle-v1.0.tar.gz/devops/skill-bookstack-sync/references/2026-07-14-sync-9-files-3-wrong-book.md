# 2026-07-14 Sync: 9 Files, 3 in Wrong Book — Lesson Reinforced

## Context

The 2026-07-14 cron run scanned 286 SKILL.md files, found 9 modified since last sync (2026-07-13 06:08:20), and created 9 pages in BookStack. However, **3 business-category skills were created in the wrong Book**.

## What Went Wrong

The agent did **not** load `skill-bookstack-sync` before executing (skipped Step 0). Instead, it used a mental model of only 7 book entries:

```python
# Agent's assumed mapping (WRONG — incomplete)
BOOK_MAP = {
    "agent-skills": 2031,
    "cmmi5": 2032,
    "devops": 2033,
    "security": 2034,
    "meta": 2035,
    "engineering": 2036,
    "productivity": 2037,
}
# business and other categories → defaulted to 2031
```

The actual mapping in `references/book-mapping.md` has **21+ entries**, including `business → 2753`. The 3 business skills were created in Book 2031 (Agent核心技能) instead of Book 2753 (商业业务).

| Skill | Created In | Should Be |
|-------|-----------|-----------|
| auto-money-pipeline | Book 2031 | Book 2753 |
| cold-email-pipeline | Book 2031 | Book 2753 |
| eve-scout | Book 2031 | Book 2753 |

The 6 non-business skills were correctly assigned (diagnose→2036, top-level media skills→2031).

## Lesson

**Step 0 is not optional.** The `scripts/sync.py` script has the authoritative book mapping with 60+ entries including per-skill overrides for top-level skills. Running without loading the skill first is the single biggest source of wrong-book-creation bugs — and this session proves it.

## Fix Required

The 3 misplaced pages (BookStack IDs 22661, 22662, 22663) need to be deleted from Book 2031 and recreated in Book 2753, or moved via the API. The correct book_id=2753 should be used with PUT to relocate:

```bash
# Option A: Move via PUT (if BookStack supports book_id change on pages)
curl -s -X PUT http://localhost:8080/api/pages/22661 \
  -H "Authorization: Token ..." \
  -H "Content-Type: application/json" \
  -d '{"book_id": 2753}'

# Option B: Delete and recreate
curl -s -X DELETE http://localhost:8080/api/pages/22661 -H "Authorization: Token ..."
# Then POST with correct book_id=2753
```

BookStack `PUT /api/pages/{id}` with `book_id` is supported — the page moves to the new book. Verify after fix with `GET /api/pages/{id}` and check `book_id` field.

## Verdict

This session produced a net positive: 6 correctly-created pages + 1 actionable bug discovered (3 pages in wrong book) + 1 reinforced lesson (always load the skill first).
