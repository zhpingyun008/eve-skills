# 2026-07-16: `filter[name]=` 搜索已验证可行

## 背景
之前所有同步都依赖 `GET /api/pages?book_id=X&count=500` 批量拉取所有页面，但本 BookStack 实例的 `book_id` 过滤器完全无效（P3），每次返回整个 Shelf 的 ~6,754 条记录。批量拉取 2 个 Book 就需要 ~120 秒并经常超时。

## 新方案：`filter[name]=` 精确搜索

### 请求格式
```
GET /api/pages?filter[name]={urllib.parse.quote(页面名)}
```

### 实测结果（2026-07-16 17:11）
- 搜索目标：`运维自动化 › skill-bookstack-sync › SKILL.md`
- 耗时：~2 秒
- 返回：单个匹配结果（Page ID: 22755）
- 状态：可直接用 `result["data"][0]["id"]` 获取页面 ID

### Python 代码
```python
import urllib.request, urllib.parse, json, os

# 读取 token
token = None
with open(os.path.expanduser("~/.bashrc")) as f:
    for line in f:
        if "BOOKSTACK_TOKEN" in line and "export" in line:
            token = line.split("=")[1].strip().strip("\"'")

BASE_URL = "http://localhost:8080/api"
page_name = "运维自动化 › skill-bookstack-sync › SKILL.md"
encoded = urllib.parse.quote(page_name)

req = urllib.request.Request(f"{BASE_URL}/pages?filter[name]={encoded}")
req.add_header("Authorization", f"Token {token}")
resp = urllib.request.urlopen(req, timeout=10)
data = json.loads(resp.read())

if data.get("data"):
    page_id = data["data"][0]["id"]
    print(f"FOUND|{page_id}")
else:
    print("NOT_FOUND")
```

## 优势总结
- 每次搜索 ~2 秒，无论书中有多少页面
- 不需要分发 bulk fetch 多个 Book
- 对于小批量同步（1-10 文件），完全消除 P8 超时问题
- 不需要使用 `book_id` 参数（反正已损坏）

## 局限
- 搜索引擎按精确名称匹配，首次创建页面后才知道名称格式
- 如果 shelf 中存在名称完全相同但位于不同 Book 的重复页面，`filter[name]` 返回多条记录 → 需要额外去重逻辑（但按 `{BookName} › {skill} › SKILL.md` 命名方案理论上应唯一）
