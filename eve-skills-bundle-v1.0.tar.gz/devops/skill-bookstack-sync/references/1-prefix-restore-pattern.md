# 1| Prefix Restore Pattern (2026-06-30)

## Problem

The `.skill_sync_last` file (at `~/.hermes/logs/.skill_sync_last`) has format `1|<epoch>` but an agent wrote just `<epoch>` (without the `1|` prefix), corrupting the format.

## Symptoms

- The next sync run will read `1782781031` instead of `1|1782781031`
- When the `1|` prefix is missing, parsing logic that splits on `|` will produce `["1782781031"]` instead of `["1", "1782781031"]`
- Timestamp comparison may still work by coincidence (the epoch value is correct), but the format is non-compliant

## Fix (cron-safe)

Since `write_file` writes to `~/.hermes/logs/.skill_sync_last` are safe (dotfile, ~ path), use:

```python
import time
# CRITICAL: preserve the 1| prefix
write_file("~/.hermes/logs/.skill_sync_last", f"1|{int(time.time())}")
```

Or from terminal:

```bash
python3 -c "import time; open('/home/yestin/.hermes/logs/.skill_sync_last','w').write(f'1|{int(time.time())}')"
```

## Root Cause

The `1|` prefix looks like an optional version marker but is actually required. The file content `1782777098` looks visually similar to `1|1782777098` — the `1|` at the start is easy to overlook when reading the file. Agents reading the file see `"1|1782777098"` and mentally parse it as `"1782777098"` (the epoch), then write back just the epoch.

## Defense

Before any `write_file` call targeting this path:
1. Say out loud: "the format is 1|<epoch>"
2. Check the written value: `read_file("~/.hermes/logs/.skill_sync_last")` should start with `1|`
3. If the file starts with a raw digit (no `1|` prefix), the prefix was dropped — fix immediately
