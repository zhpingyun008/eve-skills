# Medium Batch Sync Script — 2026-07-14

## Context

Used to sync 15 modified SKILL.md files to BookStack Skill技能库 shelf in a single Python script. This pattern fills the gap between:
- **CLI script** (1-3 files) → simple, per-file curl/POST
- **delegate_task** (30+ files) → subagent isolation for long runs

## Verified Results

| Metric | Value |
|--------|-------|
| Files processed | 15 |
| Created | 10 |
| Updated | 5 |
| Skipped | 0 |
| Errors | 0 |
| Runtime | ~2s |

## Script Anatomy

The script (`/tmp/skill_sync.py`) contained these phases in one process:

### Phase 1: Read timestamp & find modified files
```python
with open(TIMESTAMP_FILE, "r") as f:
    last_ts = int(f.readline().strip().split("|")[0].strip())

for root, dirs, files in os.walk(skills_dir):
    if "/_archive" in root:
        continue
    if "SKILL.md" in files:
        mtime = os.path.getmtime(os.path.join(root, "SKILL.md"))
        if mtime > last_ts + 1:  # 1-second buffer
            # collect
```
- Uses `os.path.getmtime()` not `find -newer` — both work, Python approach keeps everything in one language
- 1-second buffer avoids race conditions with near-simultaneous writes
- Skips `_archive/` directory entirely

### Phase 2: Resolve category from frontmatter
```python
def get_category_from_file(path):
    m = re.search(r'^category:\s*(\S+)', content, re.MULTILINE)
    if m:
        fm_cat = m.group(1)
        if fm_cat == "uncategorized":
            return None, content  # Fall through to heuristics
        if fm_cat == "dev":
            return "dev-experience", content  # Ambiguity resolution
        return fm_cat, content
    return None, content
```
- `category: uncategorized` → treated as "no category", falls through to media/creative heuristic
- `category: dev` → resolved to `dev-experience` (Book 3290)

### Phase 3: Determine Book ID
```python
def resolve_book_id(category, skill_name, frontmatter_text):
    if category and category in BOOK_MAP:
        return BOOK_MAP[category]
    
    # Root-level heuristic: check if media/creative
    for kw in MEDIA_KEYWORDS:
        if kw in skill_lower:
            return 2031  # Agent核心技能
    
    # Check tags in frontmatter
    tags_match = re.search(r'tags:\s*\[(.*?)\]', frontmatter_text, re.DOTALL)
    # ...
    
    # Check description for media hints
    media_hints = ["video", "image", "animation", "diagram", "render", "screenshot"]
    
    # Fallback for flat skills
    return 2029  # 技能库总览
```
- Media/creative skills (remotion, hyperframes, markdown-viewer, apikey-image-gen, grok-image-to-video) → Book 2031
- Flat non-media skills (codex-ceo, codex-shared, hermes-os-portal-build) → Book 2029

### Phase 4: Check for existing page (avoid duplicates)
```python
def check_existing_page(book_id, page_name):
    url = f"{BASE}/pages?count=100&filter[book_id]={book_id}"
    result = api_request("GET", url)
    for page in result.get("data", []):
        if page.get("name") == page_name:
            return page["id"]
    return None
```
- Searches by exact name match within the target book
- Returns page ID if found → update; None if not found → create

### Phase 5: Create or update with HTML escaping
```python
escaped_content = escape(content)
html_content = f"<pre>\n{escaped_content}\n</pre>"
```
- `html.escape()` is MANDATORY — SKILL.md files contain angle brackets, ampersands, CJK characters
- Without escaping, BookStack WYSIWYG editor interprets `<` as HTML tags and corrupts the page

## Key Lessons
The BookStack API token was stored in `~/.bashrc` as:
```bash
export BOOKSTACK_TOKEN="enhanced-learn-v2:fix-token-20260525"
```
Cron jobs do NOT source `.bashrc`. Three mitigation strategies:
1. **Hardcode** (simplest for local single-user BookStack) — write the token directly in the script. Safe when BookStack is localhost-only.
2. **Cron env** — `HERMES_BOOKSTACK_TOKEN=*** hermes cron job ...`
3. **Dedicated env file** — `~/.hermes/.env` sourced in both interactive and cron contexts.

## Key Lessons

### Token sourcing for cron
The BookStack API token was stored in `~/.bashrc` as:
```bash
export BOOKSTACK_TOKEN="enhanced-learn-v2:fix-token-20260525"
```
Cron jobs do NOT source `.bashrc`. Three mitigation strategies:
1. **Hardcode** (simplest for local single-user BookStack) — write the token directly in the script. Safe when BookStack is localhost-only.
2. **Cron env** — `HERMES_BOOKSTACK_TOKEN=*** hermes cron job ...`
3. **Dedicated env file** — `~/.hermes/.env` sourced in both interactive and cron contexts.

**Session proof**: Script with hardcoded token succeeded on 15 files; prior attempts with env-only sourcing failed with HTTP 401. Fix: embedded token directly in the Python script's `TOKEN` variable.

### Book existence outside shelf
Books like `3336 (质量保障)` exist as standalone BookStack books but are NOT attached to Shelf 2028. The API still accepted page creation in them without errors. This is a known-good pattern — books need not be shelf members to accept pages.

### Category resolution for `uncategorized`
5 root-level skills had `category: uncategorized` in frontmatter. The resolution logic correctly routed:
- Media/creative → Book 2031 (Agent核心技能): apikey-image-gen, grok-image-to-video, hyperframes, markdown-viewer, remotion
- Non-media flat → Book 2029 (技能库总览): codex-ceo, codex-shared, hermes-os-portal-build

### Page naming convention
Used: `{book_name} › {skill_name} › SKILL.md`
- Book 2031 (agent-skills) → `agent-skills › apikey-image-gen › SKILL.md`
- Book 2029 (total) → `total › codex-shared › SKILL.md`
- Book 3336 (quality) → `quality › hermes-doc-compliance › SKILL.md`
