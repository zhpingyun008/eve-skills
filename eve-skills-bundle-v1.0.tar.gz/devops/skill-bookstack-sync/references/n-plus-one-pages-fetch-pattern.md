# N+1 Pages Fetch Antipattern — BookStack Sync Performance

## Discovered
2026-06-29 — Eve KB sync (bookstack-eve-sync.py) timed out at 60s with 134+ tracked files.

## The Pattern (broken)

```python
def find_page_by_name(book_id, name):
    pages = api('GET', "/pages?count=500")  # ← fetches ALL pages EVERY call
    for p in pages.get('data', []):
        if p.get('book_id') == book_id and p['name'] == name:
            return p
    return None

def create_or_update_page(book_id, name, content_html, filepath):
    existing = find_page_by_name(book_id, name)  # ← called per file
    # ...
```

Every call to `create_or_update_page()` triggers a full `GET /pages?count=500`. With N files to check, the sync makes N×1 API calls — each ~200–500ms on a local BookStack instance. At 134+ files, that's 67+ seconds minimum before any write happens.

## Root Cause

The sync design treats each file independently. `find_page_by_name` is written as if it's a cheap lookup, but it's actually the most expensive API call in the pipeline.

## Fixes (ordered by effectiveness)

### Fix 1: Bulk-fetch pages ONCE at start (lowest effort)
```python
# Load ALL pages into a dict once
def load_all_pages():
    all_pages = {}
    data = api('GET', "/pages?count=500")
    for p in data.get('data', []):
        key = (p['book_id'], p['name'])
        all_pages[key] = p
    return all_pages

# Then use dict lookup instead of API call
all_pages = load_all_pages()
existing = all_pages.get((book_id, name))
```

**Caveat**: `count=500` caps at 500 pages total. Books with 500+ pages need pagination with `offset`.

### Fix 2: Use Search API (matches skill-bookstack-sync pattern)
```python
def find_page_quick(book_id, name):
    # Search API is much faster than listing all pages
    query = urllib.parse.quote(name)
    result = api('GET', f"/search?query={query}&count=5")
    for p in result.get('data', []):
        if p.get('book_id') == book_id:
            return p
    return None
```

### Fix 3: Batch the entire sync
Group all files by book_id first, then for each book:
1. Fetch all pages in that book once (with pagination)
2. Build a lookup dict
3. Process all files for that book
4. Move to next book

## Symptoms
- Sync script consistently times out at 60s when backlog > ~50 files
- First few files process quickly, then each subsequent file gets slower
- `last_sync` timestamp in state file becomes stale (9h+ behind)
- All files remain unsynced on timeout (state file timestamp not updated)
- Log file not written because TimeoutExpired handler only prints, doesn't log

## References
- skill-bookstack-sync Pitfalls #4 (pagination trap — related but distinct)
- skill-bookstack-sync Step 2 (Search API as alternative to pages listing)
