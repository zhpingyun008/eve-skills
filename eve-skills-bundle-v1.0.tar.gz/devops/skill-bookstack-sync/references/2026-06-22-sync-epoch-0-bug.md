# sync.py Epoch-0 Bug — 2026-06-22

## Discovery

During the 2026-06-22 10:08 cron sync run, `scripts/sync.py` reported:

```
📡 Last sync: Thu Jan  1 08:00:00 1970 (epoch: 0)
```

This caused a **full re-scan of all 222 SKILL.md files** instead of incremental sync (only 2 files actually modified since last sync).

## Root Cause

The timestamp file `.skill_sync_last` stores TWO lines:

```
1782090361       ← Unix epoch (line 1)
2026-06-22 09:06:01  ← human-readable (line 2)
```

The sync.py read the entire file with `f.read().strip()` then tried `int(raw)` on the concatenated multi-line string `"1782090361\n2026-06-22 09:06:01"`. `int()` raised `ValueError`, caught by the except clause which set `content_ts = 0`.

**Buggy code:**
```python
with open(TIMESTAMP_FILE) as f:
    raw = f.read().strip()  # reads BOTH lines
content_ts = int(raw)  # ValueError → 0
```

## Fix Applied

**Reader** — Changed to `f.readline().strip()` to read only the first line:
```python
with open(TIMESTAMP_FILE) as f:
    first_line = f.readline().strip()  # reads only "1782090361"
content_ts = int(first_line)  # Works!
```

Also added `TypeError` to the except clause for robustness.

**Writer** — Was writing only 1 line. Changed to write 2 lines:
```python
with open(TIMESTAMP_FILE, "w") as f:
    f.write(f"{ts_str}\n{human_ts}\n")
```

## Verification

After fix, spot-checked:
- `商业业务 › eve-deep-consciousness › SKILL.md` (ID 17560) — updated 2026-06-22T02:07:36 ✅
- `运维自动化 › skill-bookstack-sync › SKILL.md` (ID 17572) — updated 2026-06-22T02:08:14 ✅

## Side Effect of the Bug

The full re-scan actually cleaned up 18 stale duplicate pages (English-prefixed names) and renamed 2 pages to correct Chinese names. So despite being unintended, the full scan was productive cleanup.
