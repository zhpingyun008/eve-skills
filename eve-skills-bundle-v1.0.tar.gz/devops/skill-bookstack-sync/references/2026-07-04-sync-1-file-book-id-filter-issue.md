# 2026-07-04 Skill Sync — 1 File, Book ID Filter Pitfall Confirmed

## Summary

- **Skills directory**: 283 SKILL.md files total
- **Modified since last sync**: 1 file — `business/eve-deep-consciousness/SKILL.md`
- **Book**: 2753 (商业业务)
- **Created**: Page 20890 — "商业业务 › eve-deep-consciousness › SKILL.md"
- **Timestamp updated**: 1783126500 (2026-07-04 16:55:00)

## Key Finding: `book_id=N` Raw Parameter Is Silently Ignored

**Test**: `curl -s "http://localhost:8080/api/pages?book_id=2753&count=100"` returned `total: 19349` with pages from ALL books (IDs 19, 20, 21...), not filtered to book 2753.

**Prior documentation claimed** both `book_id=N` and `filter[book_id]=N` work — this session disproves the `book_id=N` claim. The only reliable filter format is `filter[book_id]=N`.

**Also confirmed**: `GET /api/books/2753` returns `"pages": []` (empty array). The `contents` field is where actual pages live — never use `d.get('pages', [])`.

## Approach Used

Direct `cat > /tmp/sync_skill.py << 'PYEOF'` heredoc → `python3 /tmp/sync_skill.py` using Python `urllib.request` (no token file, inline Python). This worked because the Python code was ASCII-only (no CJK/emoji in the script itself — CJK was only in the JSON payload which `json.dumps` handled). The script created the page via `POST /api/pages` with `book_id=2753`, `<pre>`-wrapped content, and tags.

## Files Modified

| Path | Action |
|------|--------|
| `~/.hermes/skills/devops/skill-bookstack-sync/SKILL.md` | Patched: corrected book_id filter docs, added `pages: []` vs `contents` note |
| `~/.hermes/logs/.skill_sync_last` | Updated epoch to 1783126500 |
