# 2026-06-20: BookStack PHP Server Deadlock + MariaDB Recovery

## Scenario

Cron job `skill-bookstack-sync` started normally but `sync.py` timed out after 180s (3 sequential API calls all timed out). Subsequent manual API calls to the BookStack server also timed out — both `http://localhost:8080` and `http://127.0.0.1:8080` returned HTTP `000` after 10s.

## Root Cause Chain

### 1. PHP Built-in Server Deadlock

The PHP development server (`php -S`) is **single-threaded**. When a previous `sync.py` run made rapid-fire API calls (especially large-file PUTs/POSTs), the server processed them sequentially. If one request timed out from the client's perspective but was still being processed server-side, the server's single worker thread was **held hostage** — unable to accept new connections.

**Evidence**: `ps aux` showed the PHP process (PID 429) in **state R** (running) at 8.8% CPU, and `ss -tlnp` confirmed it was listening on 127.0.0.1:8080. But `curl -v http://127.0.0.1:8080/login` showed:
```
* Connected to 127.0.0.1:8080
> GET /login HTTP/1.1
> Host: 127.0.0.1:8080
...
```
The TCP connection established but the HTTP request hung forever (no response headers returned). The PHP server accepted the connection but never processed the request because its worker was stuck.

### 2. MariaDB Socket Disappearance

After killing the stuck PHP process (PID 429) and starting a new one, the new server returned HTTP 500:
```json
{"error": {"message": "SQLSTATE[HY000] [2002] No such file or directory
  (Connection: mysql, Socket: /tmp/mariadb.sock, Database: bookstack,
  SQL: select * from `api_tokens` where `token_id` = 7cf... limit 1)"}}
```

The MariaDB socket at `/tmp/mariadb.sock` was missing. Checking `ls /tmp/mariadb*` returned nothing. The MariaDB server process was also down.

### 3. MariaDB Auto-Start

After checking `ps aux | grep mariadb`, nothing was found. But **within 30 seconds** of the new PHP server trying to connect, a new `mariadbd` process (PID 217212) appeared automatically:

```
/home/yestin/opt/mariadb/usr/sbin/mariadbd
  --basedir=/home/yestin/opt/mariadb/usr
  --datadir=/home/yestin/opt/mariadb/data
  --port=3307 --socket=/tmp/mariadb.sock
  --user=yestin --bind-address=127.0.0.1
```

The MariaDB socket appeared shortly after: `/tmp/mariadb.sock` was created and the API started responding with HTTP 200 (~0.26s response time).

**Hypothesis**: MariaDB was started by a systemd user service or a cron @reboot hook that detects missing socket and auto-launches. The `--user=yestin` flag means it's a user-level process, not a system daemon.

## Recovery Sequence (Verified Working)

```bash
# Step 1: DETECT deadlock
# curl returns 000 or hangs indefinitely
curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:8080/login --connect-timeout 5 --max-time 10
# → 000 (timeout)

# Step 2: KILL the stuck PHP process
# Find it first:
ps aux | grep "php.*-S 127.0.0.1:8080" | grep -v grep
# Kill by PID:
kill <PID>
# Verify stopped:
ps -p <PID> --no-headers || echo "Process stopped"

# Step 3: START a new PHP server (background mode in Hermes)
# Use terminal(background=true) for the PHP server (long-lived process)
cd /home/yestin/projects/BookStack && \
  /home/yestin/opt/php/usr/bin/php8.3 \
  -c /home/yestin/opt/php/php.ini \
  -d memory_limit=512M \
  -S 127.0.0.1:8080 \
  -t /home/yestin/projects/BookStack/public \
  /home/yestin/projects/BookStack/server.php

# Step 4: CHECK MariaDB socket — it may auto-start within 30s
for i in 1 2 3 4 5 6; do
  if [ -S /tmp/mariadb.sock ]; then
    echo "MariaDB socket ready"
    break
  fi
  echo "Waiting for MariaDB... ($i/6)"
  sleep 5
done

# Step 5: VERIFY API health
curl -s -o /dev/null -w "%{http_code} %{time_total}s" \
  "http://127.0.0.1:8080/api/shelves/2028" \
  -H "Authorization: Token 7cf28cddb3f347844a2f720de8c7de27:reset-secret-2026" \
  --max-time 15
# Expected: 200 < 1s

# Step 6: RUN sync
python3 ~/.hermes/skills/devops/skill-bookstack-sync/scripts/sync.py
```

## Prevention / Detection

| Signal | Action |
|--------|--------|
| curl to 8080 returns 000 for >30s | Kill and restart PHP (Step 2-3) |
| sync.py timeout (exit 124) + timestamp unchanged | Check API directly; if unresponsive → Step 2-3 |
| sync.py timeout (exit 124) + timestamp advanced | Sync actually succeeded (see pitfall: timeout ≠ failure) |
| API returns HTTP 500 with SQLSTATE[HY000] | Wait 30s for MariaDB auto-start, then retry |
| API returns HTTP 500 with different SQL error | Check `/tmp/mariadb.sock` existence; if missing, check `ps aux \| grep mariadbd` |

## Key Takeaways

1. PHP built-in server WILL deadlock under concurrent request load — this is inherent to single-threaded `php -S`
2. Killing the PHP process is the ONLY reliable recovery — the server won't self-heal
3. MariaDB auto-recovers within ~30s when a new PHP process connects — do NOT manually start it
4. Always use `terminal(background=true)` to start the PHP server (not foreground with `&`)
5. After restarting PHP, ALWAYS wait for the MariaDB socket before running sync
6. The API bind address `127.0.0.1:8080` (not `0.0.0.0:8080`) — only localhost access
