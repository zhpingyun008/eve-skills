# 2026-06-22 Sync Run: HTML-Only POST Truncation Fix

## Finding

When using Python `urllib.request` to POST a page to BookStack with **only the `html` field**, large SKILL.md files (>18K chars) are silently truncated. The stored HTML was 23,405 chars for a 183,119 byte file (~12%).

## Root Cause

BookStack's PHP backend processes the `html` field through HTMLPurifier/WYSIWYG sanitization, which truncates content beyond a threshold during POST/PUT. The `markdown` field bypasses this processing entirely and stores content as-is.

## Evidence

| Field sent | Stored HTML | Stored Markdown | Ratio |
|-----------|-------------|-----------------|-------|
| `html` only | 23,405 chars | 0 chars | ~12% |
| `html` + `markdown` | 176,209 chars | 99,960 chars | ~96% (markdown) |

## Fix

Include both `html` (for WYSIWYG display with `<pre>` wrapper + `html.escape()`) and `markdown` (for raw content preservation) in every POST/PUT payload.

## Verification

After the fix was applied, `GET /api/pages/18010` confirmed:
- HTML stored: 176,209 chars (rendered with BookStack's WYSIWYG markup around `<pre>`)
- Markdown stored: 99,960 chars (raw content intact)

## Affected Code Sections in SKILL.md

- Option A (execute_code mode): payload construction — was missing `markdown` field
- Option B (cron mode write_file + terminal): payload construction — was missing `markdown` field
- Large File Handling section — header was inaccurate (stated truncation as universal; it's limited to `html`-only payloads)
- Added new Pitfall: ⚠️ HTML-Only POST Truncates Large Content
