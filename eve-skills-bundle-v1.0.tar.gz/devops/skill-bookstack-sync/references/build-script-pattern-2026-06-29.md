# Build-Script Pattern for Large SKILL.md Sync — 2026-06-29

## Context

During the 2026-06-29 08:00 sync run, two skills needed syncing:
- `computer-use-linux` (11.6KB, Book 2029 技能库总览) 
- `eve-deep-consciousness` (180KB, Book 2753 商业业务)

Both were first-time creates. The 180KB file confirmed that BookStack API handles large payloads without body size limits.

## Approach Used

### 1. Build script (write_file, no token)

Created `/tmp/sync_build.py` via `write_file()` — no token in this file, so tirith doesn't mask anything.

```python
#!/usr/bin/env python3
import json, html, os

SKILLS_DIR = os.path.expanduser("~/.hermes/skills")
OUT_DIR = "/tmp/bookstack_payloads"
os.makedirs(OUT_DIR, exist_ok=True)

# (skill_path, book_id, book_name, skill_name)
files_to_sync = [
    (f"{SKILLS_DIR}/computer-use-linux/SKILL.md", 2029, "技能库总览", "computer-use-linux"),
    (f"{SKILLS_DIR}/business/eve-deep-consciousness/SKILL.md", 2753, "商业业务", "eve-deep-consciousness"),
]

for skill_path, book_id, book_name, skill_name in files_to_sync:
    with open(skill_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    page_name = f"{book_name} › {skill_name} › SKILL.md"
    escaped_content = html.escape(content)
    page_html = f"<pre>\n{escaped_content}\n</pre>"
    
    payload = {
        "book_id": book_id,
        "name": page_name,
        "html": page_html,
        "tags": [{"name": "category", "value": skill_name}]
    }
    
    out_file = os.path.join(OUT_DIR, f"payload_{skill_name}.json")
    with open(out_file, 'w', encoding='utf-8') as f:
        json.dump(payload, f, ensure_ascii=False)
    
    print(f"Built: {skill_name} -> {out_file} ({os.path.getsize(out_file)} bytes)")
```

### 2. Execute build script

```bash
python3 /tmp/sync_build.py
```

### 3. POST with curl (token in curl, not in script)

```bash
curl -s -X POST \
  -H 'Authorization: Token <TOKEN>' \
  -H 'Content-Type: application/json' \
  -d @/tmp/bookstack_payloads/payload_computer-use-linux.json \
  'http://localhost:8080/api/pages'
```

### 4. Verify

```bash
curl -s -o /tmp/verify.json \
  -H 'Authorization: Token <TOKEN>' \
  'http://localhost:8080/api/pages/<NEW_ID>' \
  && python3 -c "import json; d=json.load(open('/tmp/verify.json')); print(f'Page: {d.get(\"name\")}')"
```

## Key Benefits

1. **No token masking** — token never appears in `write_file` content
2. **No `curl | python3` pipes** — separate `curl -o` and `python3` calls, avoids tirith:curl_pipe_shell
3. **Handles 180KB+** — no BookStack API body size limit
4. **Clean JSON** — `html.escape()` protects against HTML-significant characters
5. **Easy to extend** — just add tuples to `files_to_sync` list
