# delegate_task 并行同步模式 — 大规模批量的 tirith-safe 替代方案

## 概述

当需要同步大量 SKILL.md 文件（30+）时，传统的 Python 脚本逐文件 POST/PUT 方式在单线程下耗时较长。本模式使用 `delegate_task` 将整个同步任务委托给子 Agent，子 Agent 独立工作并返回摘要，父 Agent 可继续执行其他任务。

**适用场景**：单次同步 20+ 文件、多分类交叉同步、父 Agent 在同步期间需要做其他工作。

## 关键优势

| 维度 | Python 脚本模式 | delegate_task 模式 |
|------|----------------|-------------------|
| 并发度 | 单线程逐文件 | 子 Agent 独立运行，可并行 |
| tirith 问题 | 需处理 token 红码、`curl|python3` 拦截、dotfile 覆盖 | 子 Agent 完全隔离，tirith 规则独立评估 |
| 复杂度 | 需写入 payload JSON、处理搜索/去重逻辑 | 只需传文件列表和分类映射 |
| 状态追踪 | 需父 Agent 轮询或读取日志 | 子 Agent 自动返回摘要 |
| 适用规模 | 1-10 文件 | 10-100 文件 |

## 模式示例

### 输入：需要同步的文件列表（按分类分组）

父 Agent 将技能列表按 Book ID 分组，构造详细的 context 传给予 Agent：

```python
context = f"""
agent-skills → Book ID 2031:
- /path/to/skill1/SKILL.md
- /path/to/skill2/SKILL.md

cmmi5 → Book ID 2032:
- /path/to/skill3/SKILL.md

...

每个技能操作步骤：
1. 读取 SKILL.md 文件内容
2. POST /api/pages (book_id, name, markdown=<pre>content</pre>)
3. 返回每个技能同步结果
"""
```

### 执行：委托子 Agent

```python
delegate_task(
    goal="同步 ~/.hermes/skills/ 中已修改的 SKILL.md 到 BookStack",
    context=context,
    toolsets=["terminal", "file"]
)
```

### 输出：子 Agent 返回摘要

子 Agent 返回各分类同步结果统计，父 Agent 据此更新时间戳。

## 注意事项

1. **子 Agent 无记忆**：必须在 context 中传递所有必要信息（token、URL、文件路径、Book ID 映射）
2. **子 Agent 摘要不可尽信**：对于有副作用的操作（POST），父 Agent 应在完成后抽样验证（如搜索 API 确认页面已创建）
3. **文件读取在子 Agent 内完成**：父 Agent 不需要先读取所有 SKILL.md 内容再传——子 Agent 有自己的文件系统访问权限
4. **适合大规模一次性同步**：对于 cron 模式的增量同步（通常 1-5 文件），Python 脚本模式更轻量

## Session 证明

- 2026-07-02 cron sync: 41 文件，7 个分类，子 Agent 在 ~190 秒内完成全部同步。父 Agent 在同步期间校验了 Book 存在性和 Shelf 归属。
