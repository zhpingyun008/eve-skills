# 2026-07-11: Search API Cross-Book Ranking Caused Duplicate Creation

## Symptom

Despite implementing the "search first, then POST" pattern, a new duplicate page
was created for `商业业务 › eve-deep-consciousness › SKILL.md` in Book 2753.
The search returned `existing_id = None`, so the code fell through to POST.

## Root Cause

The BookStack Search API (`GET /api/search?query=eve+deep+consciousness&count=20`)
returns results across ALL books, ranked by relevance. On this run:

- `eve-deep-consciousness` appeared in pages across Books 2033, 2037, AND 2753
- Pages from Books 2033 (skill-bookstack-sync) and 2037 (hermes-cron-posting)
  ranked higher in the first 20 results
- All 10 existing exact-match pages from Book 2753 were pushed beyond `count=20`
- The code checked only `item.get("name") == page_name` — none of the top-20
  results matched, so `existing_id` stayed `None`

## Search Result Breakdown

```
Total: 36 results (only 20 returned due to count=20)
First 20 results included (approx.):
  - 8× skill-bookstack-sync from Book 2033
  - 6× hermes-cron-posting from Book 2037
  - 4× eve-qm from Book 2753
  - 2× business›eve-deep-consciousness from Book 2753 (old format)
  - 0× 商业业务›eve-deep-consciousness from Book 2753 (all 10 were after position 20)
```

## Fix Applied

1. **Dual-check with book_id verification**: Phase 1 → book contents (/books/{id}).
   Phase 2 → Search API with `count=50` + `item.get("book_id") == target_book_id`.

2. **Post-sync dedup**: After the duplicate was created, 11 stale pages were cleaned
   up (10 same-name duplicates + 1 old-format page `business › eve-deep-consciousness
   › SKILL.md`). The latest page (22576) was kept.

## Pages Deleted

| ID | Name |
|:--:|------|
| 20996 | 商业业务 › eve-deep-consciousness › SKILL.md |
| 21021 | 商业业务 › eve-deep-consciousness › SKILL.md |
| 22549 | 商业业务 › eve-deep-consciousness › SKILL.md |
| 22443 | 商业业务 › eve-deep-consciousness › SKILL.md |
| 21233 | 商业业务 › eve-deep-consciousness › SKILL.md |
| 21157 | 商业业务 › eve-deep-consciousness › SKILL.md |
| 21074 | 商业业务 › eve-deep-consciousness › SKILL.md |
| 21011 | 商业业务 › eve-deep-consciousness › SKILL.md |
| 21010 | 商业业务 › eve-deep-consciousness › SKILL.md |
| 21002 | 商业业务 › eve-deep-consciousness › SKILL.md |
| 22572 | business › eve-deep-consciousness › SKILL.md (old format) |

## Page Kept

| ID | Name |
|:--:|------|
| **22576** | 商业业务 › eve-deep-consciousness › SKILL.md |

## Lesson

The "search-first" pattern is not reliable with `count=20` when the skill name is
common across multiple books. Always use the dual-check (book contents → Search API
with count=50 + book_id validation), and run a post-sync dedup check for the specific
skill name after every create/modify operation.

See Pitfall #36 in the main SKILL.md for implementation.
