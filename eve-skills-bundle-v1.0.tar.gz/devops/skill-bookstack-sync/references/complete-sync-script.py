#!/usr/bin/env python3
"""
SKILL.md → BookStack Skill技能库 Complete Sync Script
Verified: 2026-07-16 02:13 run — 38 mapped files, 0 errors
"""
import urllib.request, urllib.error
import json, os, glob, time, hashlib
from datetime import datetime

BASE_URL = "http://localhost:8080/api"
SYNC_TS_FILE = os.path.expanduser("~/.hermes/logs/.skill_sync_last")
HASH_CACHE_FILE = os.path.expanduser("~/.hermes/logs/.skill_sync_hash.json")
SKILLS_DIR = os.path.expanduser("~/.hermes/skills")

# Book mapping: subdirectory -> book_id
BOOK_MAP = {
    "agent-skills": 2031, "cmmi5": 2032, "devops": 2033,
    "security": 2034, "meta": 2035, "engineering": 2036, "productivity": 2037,
}
BOOK_NAMES = {2031: "Agent Skills", 2032: "CMMI5过程域", 2033: "运维自动化",
              2034: "安全合规", 2035: "元技能", 2036: "工程效能", 2037: "生产力工具"}

# --- Token from .bashrc ---
token = None
with open(os.path.expanduser("~/.bashrc")) as f:
    for line in f:
        if 'BOOKSTACK_TOKEN' in line and 'export' in line:
            token = line.split('=')[1].strip().strip('"')
            break
if not token:
    print("ERROR: BOOKSTACK_TOKEN not in ~/.bashrc")
    exit(1)

def api(method, endpoint, data=None):
    url = f"{BASE_URL}/{endpoint.lstrip('/')}"
    body = json.dumps(data).encode() if data else None
    req = urllib.request.Request(url, data=body, method=method)
    req.add_header("Authorization", f"Token {token}")
    req.add_header("Content-Type", "application/json")
    try:
        resp = urllib.request.urlopen(req, timeout=30)
        return json.loads(resp.read())
    except urllib.error.HTTPError as e:
        return {"error": True, "status": e.code, "body": e.read().decode()}

def file_sha256(path):
    return hashlib.sha256(open(path, 'rb').read()).hexdigest()

# --- Step 1: Read last sync ---
try:
    last_ts = float(open(SYNC_TS_FILE).readline().strip())
except (FileNotFoundError, ValueError):
    last_ts = 0

print(f"Last sync: {datetime.fromtimestamp(last_ts)} (ts={last_ts})")

# --- Step 2: Find modified files ---
hash_cache = {}
if os.path.exists(HASH_CACHE_FILE):
    hash_cache = json.load(open(HASH_CACHE_FILE))

candidates = []
for sk_path in glob.glob(f"{SKILLS_DIR}/**/SKILL.md", recursive=True):
    if '/_archive/' in sk_path:
        continue
    mtime = os.path.getmtime(sk_path)
    if mtime > last_ts + 1:
        rel = os.path.relpath(sk_path, SKILLS_DIR)
        parts = rel.split(os.sep)
        cat = parts[0]
        skill = parts[-2] if len(parts) >= 2 else parts[0].replace('/SKILL.md','')
        cur_hash = file_sha256(sk_path)
        if hash_cache.get(rel) == cur_hash:
            print(f"  SKIP (same hash): {rel}")
            continue
        candidates.append({"path": sk_path, "rel": rel, "cat": cat, "skill": skill,
                           "hash": cur_hash, "mtime": mtime})

print(f"Changed files (after hash dedup): {len(candidates)}")
mapped = [c for c in candidates if c["cat"] in BOOK_MAP]
print(f"  In mapped categories: {len(mapped)}")
print(f"  Other categories (skipped): {len(candidates) - len(mapped)}")

if not mapped:
    print("Nothing to sync.")
    now = time.time()
    with open(SYNC_TS_FILE, 'w') as f:
        f.write(f"{now}\n{datetime.fromtimestamp(now)}\n")
    exit(0)

# --- Step 3: Fetch existing pages ---
print("Fetching BookStack pages...")
book_pages = {}
for cat, bid in BOOK_MAP.items():
    offset = 0
    pages = {}
    while True:
        result = api("GET", f"/pages?book_id={bid}&count=500&offset={offset}")
        if result.get("error"):
            print(f"  ERROR book {bid}: {result}")
            break
        for p in result.get("data", []):
            pages[p["name"]] = p
        if not result.get("data"):  # use data==[] as termination, NOT total
            break
        offset += 500
    book_pages[bid] = pages
    print(f"  Book {bid}: {len(pages)} pages")

# --- Step 4: Sync ---
created = 0
updated = 0
errors = []
for f in mapped:
    bid = BOOK_MAP[f["cat"]]
    pname = f"{BOOK_NAMES[bid]} › {f['skill']} › SKILL.md"
    raw = open(f["path"]).read()
    html = f"<pre>\n{raw}\n</pre>"

    existing = book_pages.get(bid, {}).get(pname)
    if existing:
        r = api("PUT", f"/pages/{existing['id']}", {"name": pname, "html": html})
        if r.get("error"):
            errors.append(f"UPDATE FAILED {f['rel']}: {r.get('body', r)}")
        else:
            updated += 1
            print(f"  UPDATE [{BOOK_NAMES[bid]}] {f['skill']} (page {existing['id']})")
    else:
        r = api("POST", "/pages", {"name": pname, "html": html, "book_id": bid})
        if r.get("error"):
            errors.append(f"CREATE FAILED {f['rel']}: {r.get('body', r)}")
        else:
            created += 1
            print(f"  CREATE [{BOOK_NAMES[bid]}] {f['skill']} (new page {r.get('id','?')})")

# --- Step 5: Update timestamps + hash cache ---
now_ts = time.time()
with open(SYNC_TS_FILE, 'w') as f:
    f.write(f"{now_ts}\n{datetime.fromtimestamp(now_ts)}\n")
for f in mapped:
    hash_cache[f["rel"]] = f["hash"]
json.dump(hash_cache, open(HASH_CACHE_FILE, 'w'), indent=2)

# --- Report ---
print(f"\n=== Sync Complete ===")
print(f"Created: {created} | Updated: {updated} | Errors: {len(errors)} | Skipped: {len(candidates)-len(mapped)}")
for e in errors:
    print(f"  ERROR: {e}")
print(f"Timestamp updated to {datetime.fromtimestamp(now_ts)}")
