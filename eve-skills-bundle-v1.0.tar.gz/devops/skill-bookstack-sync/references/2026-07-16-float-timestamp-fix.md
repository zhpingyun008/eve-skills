# 2026-07-16 — 浮点数时间戳修复 & 重复页清理

## 问题

`.skill_sync_last` 存储了 `1784149719.1111465`（浮点数），而 `sync.py` 使用 `int(first_ts_segment)` 解析：

```python
int("1784149719.1111465")  # → ValueError
```

导致 `content_ts = 0`（except 分支），进而 `last_sync = 0`，所有 235 个 SKILL.md 被判定为需要同步。

## 根源

写入 `.skill_sync_last` 的进程使用了 `time.time()`（返回 float）而非 `int(time.time())`。该文件被设计为整数格式，但无下游强制校验。

## 修复

sync.py 第 217 行：
```python
# BEFORE
content_ts = int(first_ts_segment)

# AFTER
content_ts = int(float(first_ts_segment))
```

兼容整数（`1784149719`）和浮点数（`1784149719.1111465`）两种格式。

## 同步结果

| 指标 | 值 |
|------|-----|
| 实际变更文件 | 1（skill-bookstack-sync 自身的 SKILL.md） |
| 更新 | 1 page（#22755, 运维自动化 › skill-bookstack-sync › SKILL.md） |
| 重复页清理 | 6 个同名的历史重复页面被删除 |
| 新增 | 0 |
| 错误 | 0 |

## 重复页详情

Book `2033`（运维自动化）下 `skill-bookstack-sync` 技能产生了 6 个重复副本：
- #20665, #22445, #22480, #22506, #22605, #22678

同步脚本的清理逻辑：同名的页面先按 ID 排序，保留最大 ID（最新），其余 DELETE。
