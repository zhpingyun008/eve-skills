# 2026-06-23 Sync Run: Same-Name Duplicate Blind Spot & markdown Fix

## Summary

Three bugs discovered in `scripts/sync.py` and fixed:

1. **Same-name duplicate blind spot**: `get_existing_pages()` used `dict {name: id}` → duplicate IDs silently dropped
2. **Missing `markdown` field**: Payload had only `html` → large files truncated by PHP HTMLPurifier
3. **Timestamp drift**: Written at execution start → next cron re-processed just-synced files

## Evidence

### Bug 1: Same-Name Duplicate

```json
// In Book 3132 (SDLC软件工程):
// Pages with identical Chinese names:
//   #17024: SDLC软件工程 › backend-infra-hardening › SKILL.md
//   #3133:  SDLC软件工程 › backend-infra-hardening › SKILL.md
// get_existing_pages() returned {"SDLC软件工程 › backend-infra-hardening › SKILL.md": 3133}
// ID 17024 was invisible to the cleanup loop -> had to manually DELETE via curl
```

### Bug 2: Missing markdown

```python
# BEFORE (broken — truncation risk for files >18K chars):
payload = {
    "name": page_name,
    "html": page_html,
    "book_id": book_id,
    ...
}

# AFTER (fixed):
payload = {
    "name": page_name,
    "html": page_html,
    "markdown": raw_content,  # Added!
    "book_id": book_id,
    ...
}
```

Fix was applied to ALL THREE code paths: UPDATE, fuzzy-match UPDATE, and CREATE.

### Bug 3: Timestamp Drift

```python
# BEFORE:
new_ts = str(int(time.time()))  # writes execution START time

# AFTER — scans ALL SKILL.md mtimes and takes max(now, max_mtime + 1):
raw_ts = int(time.time())
latest_mtime = 0
for root, dirs, files in os.walk(SKILLS_BASE):
    if "_archive" in root.split(os.sep): continue
    if "SKILL.md" in files:
        mtime = os.path.getmtime(os.path.join(root, "SKILL.md"))
        latest_mtime = max(latest_mtime, mtime)
final_ts = max(raw_ts, int(latest_mtime) + 1)
```

## Verification

After fixes, re-run `python3 scripts/sync.py --dry-run` to confirm no unexpected files flagged.

To clean lingering same-name duplicates accumulated by the old code, run with `--force` once:
```bash
cd ~/.hermes/skills/devops/skill-bookstack-sync
python3 scripts/sync.py --force
```
