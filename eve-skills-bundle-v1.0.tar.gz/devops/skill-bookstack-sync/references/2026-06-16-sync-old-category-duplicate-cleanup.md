# 2026-06-16: Old Category Name Duplicate Cleanup

## Discovery

During the 2026-06-16 sync run, 3 pages were found in Book ID=2033 (devops) for `eve-deep-consciousness`:

| ID | Name | Notes |
|----|------|-------|
| 10601 | `devops › eve-deep-consciousness › SKILL.md` | ✅ Current name, was UPDATE-d |
| 3679 | `运维自动化 › eve-deep-consciousness › SKILL.md` | ❌ Old category name, DELETEd |
| 9357 | `运维自动化 › eve-deep-consciousness › SKILL.md` | ❌ Old category name, DELETEd |

**Root cause**: The category mapping was changed from Chinese "运维自动化" to English "devops" at some point, but old pages were never cleaned up. BookStack does not auto-detect or auto-clean this.

## Pattern

Whenever a category name in the mapping changes:
1. Old pages with the old category prefix remain in the book
2. New pages with the new prefix are created alongside them
3. The book accumulates duplicates silently

## Detection Method

```
curl -s -o /tmp/bs_all_pages.json \
  -H "Authorization: Token TOKEN" \
  "http://localhost:8080/api/pages?count=100&filter%5Bbook_id%5D=BOOK_ID"
```

Then search the JSON for the skill name substring (case-insensitive), not just the exact page name.

## Cleanup

```
curl -s -X DELETE \
  -H "Authorization: Token TOKEN" \
  http://localhost:8080/api/pages/OLD_PAGE_ID
```

DELETE returns empty body with 200 status on success.

## Prevention

Add a Step 3.5 in the sync workflow: after identifying the correct page to update, scan the full book page list for any page with the same skill name but different category prefix, and delete those duplicates.
