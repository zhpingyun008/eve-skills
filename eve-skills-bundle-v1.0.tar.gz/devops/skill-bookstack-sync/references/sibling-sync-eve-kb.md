# Eve KB Sync — Sibling Sync Process

## Overview

The Eve KB sync (`~/company/scripts/bookstack-eve-sync.py`) is a **separate cron-triggered sync process** that mirrors `~/company/` files (quotes, contracts, leads, reports, scripts, etc.) to BookStack under shelf ID=2787 (Eve知识库). It runs via wrapper `~/.hermes/scripts/cron-eve-kb-sync.py` which checks a 2-hour cooldown before invoking the upstream script with `--quick`.

## Why This Matters to SKILL.md Sync

Both sync processes share the **same BookStack server** (`php -S 127.0.0.1:8080`). Cross-system interference:

1. **Server blockage**: A long Eve KB sync (many files, large payloads) can trigger the single-thread PHP hang, causing the SKILL.md sync to see HTTP 000.
2. **ECONNREFUSED**: If the Eve KB sync's per-file 10s alarm kills the PHP process through repeated timeouts, the SKILL.md sync sees Connection refused.
3. **API rate contention**: Both syncs doing `GET /pages?count=500` calls simultaneously compound the single-thread bottleneck.

## Eve KB Sync Architecture

| Aspect | Detail |
|---|---|
| Script | `~/company/scripts/bookstack-eve-sync.py` (446 lines) |
| Wrapper | `~/.hermes/scripts/cron-eve-kb-sync.py` (subprocess 180s timeout, 2h cooldown) |
| Mode | `--quick` = max 10 files per run, restricted dirs only |
| Per-file timeout | `signal.alarm(10)` — 10s per file (many timeouts on large quote files) |
| Page lookup | `GET /pages?count=500` — fetches only first 500 pages (pagination trap = duplicates) |
| State file | `~/.hermes/state/eve-kb-sync.json` — tracks mtime per file |
| Log | `~/company/data/logs/kb-quick-sync.log` |
| Shelf | ID=2787 (Eve知识库) |
| Books | ~7 books: 2788-2793 (组织架构, 合同, 脚本, 商业模式, 线索报价, 财务仪表板) |
| Token | Hardcoded in `bookstack-eve-sync.py` (subject to security scanner redaction) |

## Observed Failure Pattern (2026-07-01)

Earlier cron runs (after midnight) showed repeated `Connection refused` then `Timeout` errors — the server was down for several hours. By 03:06 the server was back up (HTTP 302) and the sync succeeded (10 files, 0 errors). This suggests the PHP process dies periodically under load and auto-recovery happens within 1-3 hours (possibly from a separate health-check cron).

## Consistent Soft-Timeout Patterns (2026-07-02)

Not all timeouts indicate server failure. Two file patterns **consistently** hit the 10s per-file alarm and return `[Timeout]` without killing the PHP process:

| File pattern | Root cause | Impact | Mitigation |
|---|---|---|---|
| `tmp_*.json` (e.g., `tmp_analyst_post.json`) | Large JSON payload, BookStack's single-thread PHP blocks on write >10s | File skipped, state not updated, retried next run | Non-critical — staging/debug dumps. Next cron run re-attempts. |
| `patrol_report_*.md` | Long markdown content + single-thread contention | File skipped, retried next run | Non-critical — patrol reports are informational. |

**Key observation**: Both files fail the per-file `signal.alarm(10)` timeout but the script exits with code 0 and continues processing. The wrapper's 180s subprocess timeout is never reached. This means:

- ✅ Temp/timeouts do NOT cascade into server death
- ✅ The PHP process survives individual 10s alarm kills
- ✅ Subsequent files still get sync attempts
- ✅ Next cron cycle (2h cooldown) re-attempts the timed-out files

**When to worry**: If ALL files in a run return `[Timeout]`, or a single file times out repeatedly across 3+ consecutive runs, suspect a stuck PHP process (HTTP 000) rather than normal contention. Check with the BookStack health check.
