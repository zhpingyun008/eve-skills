# BookStack Page Creation — Verification Reference

> Reference for `skill-bookstack-sync`: how to verify a page was created correctly after the API POST.

## Creation Response Fields

After a successful `POST /api/pages`, BookStack returns the full page object. Key fields:

```json
{
  "id": 19091,
  "name": "productivity › hermes-cron-posting › SKILL.md",
  "slug": "productivity-hermes-cron-posting-skillmd",
  "book_id": 2037,
  "chapter_id": null,
  "priority": 0,
  "editor": "wysiwyg",
  "html": "<pre>...</pre>",
  "markdown": "...",
  "tags": [
    {"name": "category", "value": "productivity", "order": 0},
    {"name": "skill", "value": "hermes-cron-posting", "order": 0},
    {"name": "auto-sync", "value": "true", "order": 0}
  ],
  "revision_count": 1,
  "created_at": "2026-06-25T06:02:27.000000Z",
  "updated_at": "2026-06-25T06:02:27.000000Z"
}
```

## Verification Checklist

After creating a page, confirm these invariants via `GET /api/pages/{id}`:

| Check | What to verify |
|-------|----------------|
| **ID is integer** | Page was stored, not rejected |
| **name matches** | `"{category} › {skill-name} › SKILL.md"` pattern |
| **book_id matches** | Correct category Book (2031-2037) |
| **html wraps in `<pre>`** | `.html` starts with `'<pre'` and ends with `'</pre>'` |
| **tags are set** | `category`, `skill`, `auto-sync` tags present |
| **No error field** | Response has no `error` or `message` indicating failure |

## BookStack `<pre>` Tag Quirk

BookStack's WYSIWYG editor adds an auto-generated `id` attribute to `<pre>` tags:

```html
<!-- Original -->
<pre>---\nname: hermes-cron-posting\n...</pre>

<!-- Stored by BookStack -->
<pre id="bkmrk-----name%3A-hermes-cro">---\nname: hermes-cron-posting\n...</pre>
```

The `id` is URL-encoded from the first chars of content. This is **BookStack's normal behavior** — the content is intact. Verify content completeness by checking for the YAML frontmatter `---` delimiter rather than strict `<pre>` tag equality.

## Tirith-proof Verification

The `GET /api/pages/{id}` endpoint is safe from tirith blocks (no pipe, no inline Python needed):

```bash
# Safe — no pipe:
curl -s -H "Authorization: Token ..." \
  "http://localhost:8080/api/pages/19091" \
  -o /tmp/verify.json
python3 -c "import json; d=json.load(open('/tmp/verify.json')); print('OK' if d.get('id') else 'FAIL')"
```

Do NOT use `curl | python3` — tirith blocks pipe-to-interpreter in both cron and interactive modes.

## Fallback: Python urllib When curl Times Out

In cron environments, `curl` to localhost:8080 may **time out interrmittently** even without a pipe. If `curl -o` fails, fall back to a file-based Python urllib script:

```python
# write_file /tmp/verify_page.py
import json, urllib.request

TOKEN = "YOUR_TOKEN"
AUTH = f"Token {TOKEN}"
PAGE_ID = 19647

req = urllib.request.Request(
    f"http://localhost:8080/api/pages/{PAGE_ID}",
    headers={"Authorization": AUTH}
)
with urllib.request.urlopen(req, timeout=15) as r:
    d = json.loads(r.read().decode())
    print(f"✅ Page ID={d['id']}")
    print(f"   Name: {d['name']}")
    print(f"   Book ID: {d.get('book_id','?')}")
```

Then:
```bash
python3 /tmp/verify_page.py
```

Note: `python3 -c "..."` **inline** code may also time out in the same cron environment. Always use **file-based** Python scripts (`python3 /tmp/script.py`) for verification, not inline Python.

## Verification Priority Order

1. **Primary**: `curl -o /tmp/verify.json` + `python3 /tmp/check.py` (tirith-safe, works most of the time)
2. **Fallback**: `write_file /tmp/verify.py` with Python urllib + `python3 /tmp/verify.py` (when curl times out)
3. **Never**: `curl | python3 -c` (blocked by tirith pipe-to-interpreter rule)
