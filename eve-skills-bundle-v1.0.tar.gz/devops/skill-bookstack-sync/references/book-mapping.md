# Book-to-Category Mapping Reference

Authoritative mapping from skill directory category → BookStack Book ID. Cross-referenced against `skill-bookstack-sync` cron output and BookStack shelf 2028 API.

## Current Mapping

| Category directory | Book ID | Book Name | Notes |
|---|---|---|---|
| `agent-skills` | 2031 | Agent核心技能 | Share book with `evolution` |
| `evolution` | 2031 | Agent核心技能 | Maps to same book as agent-skills |
| `cmmi5` | 2032 | CMMI5过程域 | |
| `devops` | 2033 | 运维自动化 | |
| `security` | 2034 | 安全加固 | |
| `meta` | 2035 | 元技能·进化 | |
| `engineering` | 2036 | 工程实践 | |
| `productivity` | 2037 | 效率工具 | |
| Top-level (no subdir) | 2029 | 技能库总览 | Skills directly under `skills/` root |

## Shelf Structure

- **Shelf ID**: 2028 (Skill技能库)
- **Description**: Hermes Agent技能库 — 250+ SKILL.md索引与管理
- Total pages: ~21,000+ across all books

## Book Display Names (for page title formatting)

Pages use format `"{BookName} › {SkillName} › SKILL.md"`.

| Book ID | Display Name |
|---|---|
| 2029 | 技能库总览 |
| 2031 | Agent核心技能 |
| 2032 | CMMI5过程域 |
| 2033 | 运维自动化 |
| 2034 | 安全加固 |
| 2035 | 元技能·进化 |
| 2036 | 工程实践 |
| 2037 | 效率工具 |

## Discovery Commands

```bash
# List all books in shelf
curl -s -H "Authorization: Token $TOKEN" \
  "http://localhost:8080/api/shelves/2028" | python3 -c "import json,sys; d=json.load(sys.stdin); [print(f'{b[\"id\"]}: {b[\"name\"]}') for b in d['books']]"

# Count pages per book
for bid in 2029 2031 2032 2033 2034 2035 2036 2037; do
  total=$(curl -s -H "Authorization: Token $TOKEN" \
    "http://localhost:8080/api/pages?count=1&filter[book_id]=$bid" | \
    python3 -c "import json,sys; print(json.load(sys.stdin).get('total',0))")
  echo "Book $bid: $total pages"
done

# Find a specific page by skill name
curl -s -H "Authorization: Token $TOKEN" \
  "http://localhost:8080/api/pages?count=200&filter[book_id]=2036" | \
  python3 -c "import json,sys; d=json.load(sys.stdin); [print(f'  {p[\"id\"]}: {p[\"name\"]}') for p in d['data'] if 'hermes-opencode' in p['name']]"
```
