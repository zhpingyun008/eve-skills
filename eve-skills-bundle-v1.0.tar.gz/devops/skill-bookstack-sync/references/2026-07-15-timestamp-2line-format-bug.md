# Timestamp File 2-Line Format Bug — sync.py 2026-07-15

## Symptoms

Running `skill_sync_bookstack.py` reported **288 files** to sync (all SKILL.md files)
even though only 7 had actually changed since the last sync time.

## Root Cause

The timestamp file `~/.hermes/logs/.skill_sync_last` had accumulated a 2-line format:

```
1784099421
2026-07-15 15:10:21
```

But `sync.py`'s `get_last_sync_ts()` does:

```python
line = f.read().strip()          # "1784099421\n2026-07-15 15:10:21"
dt = strptime(line[:19], ...)    # "1784099421\n2026-07-1" → VALUE ERROR
return float(line)               # float("1784099421\n2026-07-15 ...") → VALUE ERROR
return 0                         # All files appear "new"
```

The SKILL.md documented the read logic as `raw.split("\n")[0].split("|")[0].strip()`
but this code **does not exist** in the deployed `sync.py`. The actual code uses
`f.read().strip()` → `line[:19]` which splices across the newline boundary.

## How the 2-line format arrived

The timestamp file is **read** by multiple processes:
- `sync.py`'s `write_timestamp()` writes 2-line format
- The 2026-07-07 ad-hoc write used Python but may have been overwritten by 
  a sibling process or a previous ad-hoc write using `date +%s > file`

## Immediate Workaround

Write the timestamp as single-line date format:

```
2026-07-15 15:10:21
```

This format is correctly parsed by `strptime(line[:19], "%Y-%m-%d %H:%M:%S")`.

## Long-term Fix

Update `get_last_sync_ts()` in `~/.hermes/scripts/skill_sync_bookstack.py`:

```python
def get_last_sync_ts():
    if not os.path.exists(TIMESTAMP_FILE):
        return 0
    with open(TIMESTAMP_FILE, "r") as f:
        raw = f.read().strip()
    if not raw:
        return 0
    # Split by newline → first line, then by | → last segment (handles 1| prefix)
    line = raw.split("\n")[0].split("|")[-1].strip()
    # Try epoch integer first
    try:
        return float(line)
    except ValueError:
        pass
    # Try date string
    try:
        dt = datetime.datetime.strptime(line[:19], "%Y-%m-%d %H:%M:%S")
        return dt.timestamp()
    except ValueError:
        return 0
```

## Impact

Without this fix, the timestamp silently falls back to epoch=0 on every run,
re-syncing ALL 288+ SKILL.md files to BookStack. This creates duplicate pages,
wastes API quota, and masks the problem.

## Files

- Script: `~/.hermes/scripts/skill_sync_bookstack.py` (lines 37-53)
- Timestamp: `~/.hermes/logs/.skill_sync_last`
- Skill: `skill-bookstack-sync` → Step 1b section documents the bug
