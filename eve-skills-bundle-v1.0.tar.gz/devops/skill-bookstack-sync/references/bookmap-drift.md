# BOOK_MAP Drift Detection Guide

> Added 2026-06-25 after a sync session where top-level skills were routing to Book 2029 (技能库总览) instead of their actual target books.

## Problem

`sync.py`'s `BOOK_MAP` contains explicit routing for top-level skills (skills directly under `~/.hermes/skills/<name>/`). These routes **must match** where the pages actually live in BookStack. If they don't match:

1. **Duplicate pages** get created in the wrong book
2. **Wrong pages** get updated via fuzzy match (same skill_name, different book prefix)

## Detection Script

Run this periodically to verify BOOK_MAP correctness:

```python
import json, subprocess

AUTH = "Authorization: Token <token>"
API = "http://localhost:8080/api"
book_ids = [2031, 2032, 2033, 2034, 2035, 2036, 2037, 2753, 3094, 3100, 3132, 2029]

for bid in book_ids:
    r = subprocess.run(["curl", "-s", "-H", AUTH, f"{API}/books/{bid}?count=500"],
                       capture_output=True, text=True, timeout=30)
    d = json.loads(r.stdout)
    for c in d.get("contents", []):
        if c.get("type") == "page":
            print(f"[{bid}:{c['id']:>5}] {c['name']}")
```

Then cross-reference page names with BOOK_MAP entries — every top-level skill's page should be in the book that BOOK_MAP says it should be in.

## When BOOK_MAP Drifts

Causes:
- A page was manually moved to a different BookStack book
- A new top-level skill directory was created without adding its BOOK_MAP entry
- A BookStack reorganization moved multiple skills

Fix: update the `# Top-level skills` section of `BOOK_MAP` in `scripts/sync.py`.
