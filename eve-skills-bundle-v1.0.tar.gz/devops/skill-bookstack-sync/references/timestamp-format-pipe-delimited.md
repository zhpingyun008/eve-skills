# Timestamp Format: Pipe-Delimited vs 2-Line (2026-06-25)

## Background

The `write_timestamp()` function in `scripts/sync.py` writes in **2-line format**:

```
1782292488
2026-06-24 17:14:48
```

But ad-hoc cron scripts or external processes may write a **pipe-delimited single-line** format:

```
1782292488|2026-06-24 17:14:48
```

## Impact on sync.py (before 2026-06-25 fix)

The original `Phase 1: Read state` code did:

```python
first_line = f.readline().strip()
content_ts = int(first_line)  # Fails: "1782292488|..." is not an int
```

This raised `ValueError`, caught as `content_ts = 0` → **full rescan of ALL 224+ skills** instead of incremental sync.

## Fix (applied 2026-06-25)

The timestamp parser now reads the raw content and splits by newline first, then by pipe:

```python
raw = f.read().strip()
first_ts_segment = raw.split("\n")[0].split("|")[0].strip()
content_ts = int(first_ts_segment)
```

This handles both formats transparently.

## Detection

If you see `📡 Last sync: Thu Jan  1 08:00:00 1970 (epoch: 0)` in the sync.py output, check the timestamp file:

```bash
cat ~/.hermes/logs/.skill_sync_last | od -c | head -3
```

- `|` between timestamp and date → pipe-delimited (now handled)
- `\n` between them → 2-line format (native)
