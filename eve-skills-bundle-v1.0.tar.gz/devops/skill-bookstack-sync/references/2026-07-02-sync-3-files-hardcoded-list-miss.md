# 2026-07-02 同步：硬编码列表遗漏文件 + 动态发现修复

## 背景

常规 cron 同步，上次时间戳 2026-07-02 08:06:59 (epoch 1782950819)。

## 问题

`find -newer` 找到 3 个修改的 SKILL.md：

```
agent-skills/internet-perception/SKILL.md      (mtime 09:14:37)
business/eve-deep-consciousness/SKILL.md        (mtime 09:28:44)
devops/skill-bookstack-sync/SKILL.md            (mtime 09:08:09)
```

但第一版 Python 脚本使用硬编码 SYNC_FILES 列表，只包含了前 2 个：

```python
SYNC_FILES = [
    ("agent-skills", "internet-perception", "..."),
    ("devops", "skill-bookstack-sync", "..."),
    # missing: business/eve-deep-consciousness
]
```

`business/eve-deep-consciousness` 被意外遗漏。第一轮只同步了 2 个文件（2 个 PUT），然后必须额外跑一轮才捕获第 3 个。

## 修复

添加 `Pitfall #28` 到 SKILL.md，并更新 Step 1 强调程序化推导文件列表。给出了完整的 `find -> subprocess -> file list` Python 模板。

## 教训

1. 永远不要手动转录 `find -newer` 输出到 Python 列表 —— 必漏文件
2. 同步脚本应该直接通过 subprocess 运行 `find` 并解析输出
3. business 分类已有 mapping (2753)，不需要额外配置
