# 2026-06-30 Skill Sync: 1 File — `1|` Prefix Dropped

## Summary
Single-file sync run (only `hermes-cron-posting` was new). Successfully created BookStack page ID=20309. **Critical bug**: the `1|` prefix on timestamp file was dropped — `1782815199` written instead of `1|1782815199`.

## Files processed
| Path | Action | BookStack Page ID |
|------|--------|------------------|
| productivity/hermes-cron-posting/SKILL.md | POST (new) | 20309 |

## Approach used
1. `read_file` to get timestamp content → confirmed `1|1782807053`
2. `find` mtime comparison to find changed files
3. `write_file` Python script to `/tmp/hermes_skill_sync.py` with:
   - `html.escape()` for HTML safety
   - Token in `os.environ.get('BS_TOKEN', 'default')` fallback
4. `export BS_TOKEN=... ; python3 /tmp/hermes_skill_sync.py` to execute (env var avoids write_file token mangling)
5. `write_file` for timestamp update

## Bug: `1|` prefix dropped
The timestamp file was written as `1782815199` instead of `1|1782815199`. The `1|` prefix is a version marker — its absence will cause the next cron run to fail parsing the file. This is despite extensive warnings in Pitfall #7 of skill-bookstack-sync.

**Root cause**: The agent read the warnings but the mental reflex of writing a timestamp as a bare epoch integer overrode the format instruction during execution. The file looks like a simple epoch integer, triggering memorized patterns.

**Lesson**: Post-write verification is the only reliable defense — immediately after writing, `read_file` the timestamp file and check it starts with `1|`.

## Token survival in write_file
The token `7cf28cddb3f347844a2f720de8c7de27:reset-secret-2026` was embedded in a single-line `os.environ.get('BS_TOKEN', '7cf28...')` and survived write_file intact. This contradicts the blanket claim that write_file always corrupts colon tokens — the corruption depends on having adjacent hex-prefixed assignment lines that trigger the parser's merge logic.
