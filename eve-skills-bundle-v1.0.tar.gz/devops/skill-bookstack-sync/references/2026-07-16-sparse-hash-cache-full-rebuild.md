# 2026-07-16 — Sparse Hash Cache + Token Drift Full Recovery

## Problem

After the 2026-07-16 15:12:55 sync run, the hash cache at `~/.hermes/logs/.skill_sync_hash.json`
contained only **5 entries** out of **235 SKILL.md files** (~2% coverage). This caused the
next cron run to re-process all 62 files with mtime > last_sync, even though most content
had NOT changed.

**Root cause**: The old "update only processed files" pattern in sync.py's phase 5 gradually
lost entries over time (partial writes, manual cache edits, file corruption).

## Symptoms

- 62 files flagged as "new/modified" despite batch mtime (1784186004) being a meta-evolution
  touch, not content change
- Hash cache had: `skill-bookstack-sync`, `spa-api-discovery`, `meta-evolution`, `ccgp-bid-scraper`,
  `cold-email-pipeline` — only 5 entries
- Result: full API round-trips for 15 books, 151 update operations, 75+ duplicate cleanups

## Fix Applied

### 1. Token correction

`scripts/sync.py` had a stale hardcoded `AUTH_HEADER`:
```
7cf28cddb3f347844a2f720de8c7de27:reset-secret-2026
```
Actual token in `~/.bashrc` (line 143):
```
enhanced-learn-v2:fix-token-20260525
```
Patched via `patch()`.

### 2. Full hash cache rebuild

After sync completion, rebuilt full cache with:
```python
fresh_cache = {}
for root, _dirs, files in os.walk(SKILLS_BASE):
    if "_archive" in root.split(os.sep):
        continue
    if "SKILL.md" in files:
        fp = os.path.join(root, "SKILL.md")
        rel = os.path.relpath(fp, SKILLS_BASE)
        fresh_cache[rel] = hashlib.sha256(open(fp, "rb").read()).hexdigest()
json.dump(fresh_cache, open(cache_path, 'w'), indent=2)
```
Result: 235 entries, full coverage.

### 3. Duplicate cleanup

Detected and removed **75+ duplicate pages** across all books. Each update/delete pair
cleaned up stale duplicates created by previous sync runs. No errors.

## Verification

- Sync timestamp: `1784189647` (2026-07-16 16:14:07)
- API errors: 0
- Hash cache: 235/235 entries
- Next sync should process 0 files (no mtime changes since rebuild)
