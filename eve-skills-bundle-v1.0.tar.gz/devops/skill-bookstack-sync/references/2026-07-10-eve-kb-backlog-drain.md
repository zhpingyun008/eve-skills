# Eve KB Sync 积压清空 — 2026-07-10

## 现象

2026-07-10 凌晨同步积压巨大：约 **412+ 报价单页** 堆积在 `~/company/data/sync_inbox/quotes/` 未被同步到 BookStack。

## 根因

- `cron-eve-kb-sync.py` 每次调用 `bookstack-eve-sync.py --quick` 只能处理 **1-3 个文件**
- 该 wrapper 有 **2 小时静默期**（`state_file` 中 `last_sync` 检查）—— 距上次同步不足 2 小时则直接退出
- 积压累计了数天（从 2026-06-30 开始已有 863 行日志，生成的 BookStack page ID 从 ~21200 到 ~22000+）
- 单一 PHP 线程 + 每次调用只处理少量文件 = 自然积压无法在 cron 频率内消化

## 消耗

- **耗时**：手工 drain 约 30 分钟还没清完（持续 ~3 文件/20-30s = 6-9 文件/分钟）
- **412+ 页面** 在 7 小时内被创建（00:09 ~ 07:11 UTC+8）
- **后台 drain 仍在继续**（背景进程在退出前仍可继续处理）

## 结论

当积压达到 400+ 时，正常 cron 节奏无法及时消化。需要额外手段：
1. **启用后台 drain loop**（`while python3 bookstack-eve-sync.py --quick; do; done`）
2. **去除 2 小时 debounce**：修改 `cron-eve-kb-sync.py` 跳过 `last_sync` 检查
3. **增加 `--full` 模式**：`bookstack-eve-sync.py --full` 做全量扫描而非增量

当前架构的设计假设是"日常增量无积压"，积压场景没有有效的自动清空手段。需考虑：
- 是否新增一条更积极的 cron（每 5 分钟）专门用于积压 drain
- 或者修改底层脚本支持批量（一次处理 10-20 个文件）
