# Dedup Timeout Workaround — Books with 18K+ Pages

## Problem

The `cleanup_duplicates.py` script paginates through ALL pages in each book to find duplicates. Book 2033 (运维自动化) contains 18K+ pages, requiring ~37 API calls (500 pages per call). This can cause the script to exceed the 180s cron timeout.

## Symptoms

- `[Command timed out after 180s]` in terminal output
- The script is interrupted mid-pagination

## Root Cause

The pagination loop `GET /api/pages?book_id=2033&count=500&offset=N` makes ~37 sequential API calls (200-500ms each = 7-18 seconds just for Book 2033). Combined with other books, this can exceed 180s.

## Workarounds

### Option A: Skip Book 2033 (fast, covers 95% of cases)

Most duplicates accumulate in the first 500 pages. Run dedup for all books except 2033:

```bash
python3 -c "
import json, subprocess
t=open('/tmp/.bookstack_token').read().strip()
BASE='http://localhost:8080/api'
SKIP={2033}
for bid in [2029,2031,2032,2033,2034,2035,2036,2037,2753,3094,3100,3132]:
    if bid in SKIP: continue
    d=json.loads(subprocess.run(['curl','-s','-H',f'Authorization: Token {t}',
        f'{BASE}/pages?book_id={bid}&count=500'],capture_output=True,text=True,timeout=30).stdout)
    names={}
    for p in d.get('data',[]):
        if p['name'] in names:
            print(f'DUP book={bid} name={p[\"name\"]} id={p[\"id\"]} vs {names[p[\"name\"]]}')
        else: names[p['name']]=p['id']
    print(f'Book {bid}: {len(d.get(\"data\",[]))}/{d.get(\"total\",0)} pages')
"
```

### Option B: Search API per target page name (precise, ~500ms)

```python
import json, subprocess
token=open('/tmp/.bookstack_token').read().strip()
def check_dups(page_name):
    r=subprocess.run(['curl','-s','-H',f'Authorization: Token {token}',
        f'http://localhost:8080/api/search?query={page_name}&count=20'],
        capture_output=True,text=True,timeout=15)
    results=json.loads(r.stdout).get('data',[])
    if len(results)>1:
        sorted_r=sorted(results,key=lambda x: x.get('updated_at',''))
        for stale in sorted_r[:-1]:
            print(f'STALE: id={stale[\"id\"]} name={stale[\"name\"]} updated={stale.get(\"updated_at\",\"?\")}')
        keep=sorted_r[-1]
        print(f'KEEP:  id={keep[\"id\"]} name={keep[\"name\"]} updated={keep.get(\"updated_at\",\"?\")}')
    else:
        print(f'OK: {len(results)} page(s) for {page_name}')
```

### Option C: Longer timeout

```bash
python3 ~/.hermes/skills/devops/skill-bookstack-sync/scripts/cleanup_duplicates.py
# Set terminal timeout to 300s when running
```
