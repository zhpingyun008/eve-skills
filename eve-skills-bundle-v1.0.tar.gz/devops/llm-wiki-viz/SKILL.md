---
name: llm-wiki-viz
description: LLM Wiki 可视化知识库系统 v2.1 — D3.js知识图谱+marked渲染+标签云+全屏图谱+代码复制+阅读时间+最近浏览+滚动进度+面包屑+导出+图片放大+键盘快捷键。后端新增backlinks/tags/export API。
category: devops
tags: [knowledge-base, visualization, d3js, obsidian, wiki, llm, v2, frontend]
triggers:
  - "LLM Wiki可视化"
  - "知识图谱"
  - "知识库系统"
  - "wiki server"
  - "visual knowledge base"
  - "知识库可视化"
  - "知识图谱系统"
related_skills:
  - kb-auto-engine
  - bookstack-kb-architecture
---

# LLM Wiki 可视化知识库系统 v2.1

## 功能清单

| 功能 | 说明 |
|------|------|
| 🕸️ **知识图谱** | D3.js力导向图, 30节点+102边, 悬停高亮, 点击导航 |
| 🔍 **全文搜索** | 标题加权+内容检索, 高亮关键词, 片段预览+相关度 |
| 🏷️ **标签云** | 从frontmatter提取68个标签, 点击筛选 |
| 📄 **Markdown渲染** | marked.js引擎, 完整GFM: 表格/代码块/列表/引用 |
| 🔗 **反向链接** | 服务端计算, 显示引用当前页面的其他页面 |
| 🧩 **相关页面** | 图谱邻居节点推荐, 一键跳转 |
| 📋 **目录(TOC)** | 自动从h2/h3生成页内浮动导航 |
| ⬇️ **导出** | 下载页面原始Markdown文件 |
| 📖 **阅读时间** | 自动估算每页阅读时长 |
| 🖼️ **图片放大** | 点击查看原图全尺寸 |
| 📋 **代码复制** | 代码块悬停显示复制按钮 |
| 🕐 **最近浏览** | 侧栏显示最近5个页面 |
| 📊 **滚动进度** | 页面顶部紫色进度条 |
| 🍞 **面包屑** | 分类>页面名称导航 |
| ⛶ **全屏图谱** | 图谱全屏模式, 快捷键 `f` |
| ⌨️ **键盘快捷键** | `/`搜索, `j/k`导航, `Esc`关闭, `f`全屏, `Enter`打开 |
| 📱 **响应式** | 移动端自动折叠侧栏 |
| 🧰 **工具栏** | 导出/图谱/全屏/链接按钮行 |

## 键盘快捷键

| 键 | 功能 |
|:--:|:----|
| `/` | 聚焦搜索框 |
| `j` / `k` | 页面列表上下导航 |
| `Enter` | 打开选中页面 |
| `f` | 全屏/退出图谱 |
| `Esc` | 关闭页面视图 / 退出全屏 / 失焦搜索 |

## 架构

```
浏览器 ← REST API → Python http.server ← 文件系统 → Obsidian Vault
```

### 文件结构

```
~/company/scripts/
├── llm-wiki-server.py               # HTTP server (stdlib only, ~8.5 KB)
└── llm-wiki-frontend/
    └── index.html                    # SPA前端 (独立文件, ~34 KB)
```

**设计原则**: 前端独立为 `index.html` 文件，server 每次请求重新读取。修改前端无需重启 server。

## API端点

| 端点 | 返回 | 用途 |
|------|------|------|
| `GET /` | HTML | SPA前端 |
| `GET /api/stats` | JSON | 30页/123引用 |
| `GET /api/index` | JSON | 完整索引 |
| `GET /api/graph` | JSON | 30节点+102边 |
| `GET /api/page?path=` | JSON | 页面内容+元数据 |
| `GET /api/search?q=` | JSON | 全文搜索结果+片段 |
| `GET /api/backlinks?path=` | JSON | 反向链接页列表 |
| `GET /api/tags` | JSON | 标签+计数聚合 |
| `GET /api/export?path=` | MD文件 | 下载原始Markdown |

## 启动/停止

```bash
# 启动 (后台)
cd ~/company && python3 -u scripts/llm-wiki-server.py &

# 停止
kill $(pgrep -f llm-wiki-server)
```

## Pitfalls

### 🔴 read_file 行号污染 (server文件损坏)

`read_file()` 输出包含 `N|` 行号前缀（如 `265|265|        self.end_headers()`），**永远不要将其输出直接写回 Python 文件**。这会破坏语法结构。

**症状**: Python 文件包含 `|<html>`、`265|265|` 等预期外的行前缀，SyntaxError。

**根因**: `read_file` 的行号格式（line_number|content）被当作文件内容写回。

**正确做法**: 

```python
# ❌ 错误 — 会污染文件
content = read_file("/path/to/server.py").get('content', '')
write_file("/path/to/server.py", content)

# ✅ 正确 — 从零重构或使用 patch 做精确替换
from hermes_tools import patch
patch(path, old_string="...", new_string="...")

# ✅ 或直接用 terminal 的 python 脚本完整重写
from hermes_tools import write_file
write_file("/path/to/server.py", clean_code_string)
```

**恢复方法**: 如果已经污染，用完全重写替代修复：
```python
from hermes_tools import write_file
# 构建完整的干净代码字符串
clean_code = '''#!/usr/bin/env python3
... (完整重写) ...
'''
write_file("/path/to/server.py", clean_code)
```

### 🟡 YAML date 序列化

frontmatter 中的 `date` / `datetime.date` 类型在 `json.dumps()` 时抛出 `TypeError: Object of type date is not JSON serializable`。

**修复**: 解析 YAML 后遍历所有值，将 `isinstance(v, date)` 的字段转 `str(v)`。

```python
import yaml
from datetime import date
fm = yaml.safe_load(m.group(1)) or {}
for k, v in fm.items():
    if isinstance(v, date):
        fm[k] = str(v)
```

### 🟡 stdout 缓冲

长时间运行的 server 进程 stdout 会被缓冲，导致日志输出延迟或丢失。

**修复**: 用 `python3 -u` (unbuffered) 启动。

### 🟡 端口冲突

旧进程未完全释放时新进程无法绑定。必须先 kill 再启动。

```bash
kill -9 $(pgrep -f llm-wiki-server) 2>/dev/null; sleep 2
```

## 开发指南

1. 前端在 `llm-wiki-frontend/index.html`，修改后刷新浏览器即可
2. 后端在 `llm-wiki-server.py`，修改后需重启进程
3. D3.js 从 CDN 加载 (d3js.org)，marked.js 从 cdn.jsdelivr.net 加载
4. 图谱数据来自 `/api/graph`，页面内容来自 `/api/page?path=`

## Feedback Engine Patches
*自动生成于 2026-07-16 02:02:04*

## Tool Recommendations (from trajectory feedback)

### patch
Trajectory analysis shows **patch** strongly correlates with high session scores.
- Use `patch` for targeted find-and-replace edits instead of sed/awk.
- Supports fuzzy matching with 9 strategies for robust edits.
- Auto-runs syntax checks after modification.
- Preferred for surgical code changes over full file rewrites.

### Guardrails
- Ensure `old_string` is unique in the file unless `replace_all=True`.
- Include enough surrounding context to guarantee uniqueness.
- Use `mode='patch'` for V4A multi-file patches.

### Efficiency Tips
- Combine multiple edits into a single V4A patch when possible.
- Use `replace_all=True` for bulk replacements of the same pattern.
- Preview changes with `--dry-run` mode before applying.

---
## Feedback Engine Patches
*自动生成于 2026-07-17 02:02:37*

## Tool Recommendations (from trajectory feedback)

### read_file
Trajectory analysis shows **read_file** strongly correlates with high session scores.
- Preferred over cat/head/tail in terminal.
- Use this for reading text files with line numbers and pagination.
- Supports offset and limit for large file navigation.

---
## Feedback Engine Patches
*自动生成于 2026-07-17 02:02:37*

## Tool Recommendations (from trajectory feedback)

### patch
Trajectory analysis shows **patch** strongly correlates with high session scores.
- Use `patch` for targeted find-and-replace edits instead of sed/awk.
- Supports fuzzy matching with 9 strategies for robust edits.
- Auto-runs syntax checks after modification.
- Preferred for surgical code changes over full file rewrites.

### Guardrails
- Ensure `old_string` is unique in the file unless `replace_all=True`.
- Include enough surrounding context to guarantee uniqueness.
- Use `mode='patch'` for V4A multi-file patches.

### Efficiency Tips
- Combine multiple edits into a single V4A patch when possible.
- Use `replace_all=True` for bulk replacements of the same pattern.
- Preview changes with `--dry-run` mode before applying.

---
## Feedback Engine Patches
*自动生成于 2026-07-21 08:58:12*

## Tool Recommendations (from trajectory feedback)

### write_file
Trajectory analysis shows **write_file** strongly correlates with high session scores.
- Use `write_file` to create new files or overwrite existing ones.
- Preferred over terminal heredoc for structured file creation.
- Automatically creates parent directories.

### Guardrails
- Always use absolute paths to avoid ambiguity.
- Creates parent directories — verify the intended path before writing.
- Overwrites entire file content — if you need targeted edits, use `patch` instead.

### Efficiency Tips
- Batch content creation: write whole files at once instead of appending line-by-line.
- For large files, consider splitting into multiple smaller files.
- Use `patch` for incremental updates to avoid full rewrites.

---
## Feedback Engine Patches
*自动生成于 2026-07-22 12:19:48*

## Tool Recommendations (from trajectory feedback)

### patch
Trajectory analysis shows **patch** strongly correlates with high session scores.
- Use `patch` for targeted find-and-replace edits instead of sed/awk.
- Supports fuzzy matching with 9 strategies for robust edits.
- Auto-runs syntax checks after modification.
- Preferred for surgical code changes over full file rewrites.

### Guardrails
- Ensure `old_string` is unique in the file unless `replace_all=True`.
- Include enough surrounding context to guarantee uniqueness.
- Use `mode='patch'` for V4A multi-file patches.

### Efficiency Tips
- Combine multiple edits into a single V4A patch when possible.
- Use `replace_all=True` for bulk replacements of the same pattern.
- Preview changes with `--dry-run` mode before applying.

---
## Feedback Engine Patches
*自动生成于 2026-07-22 12:19:49*

## Tool Recommendations (from trajectory feedback)

### read_file
Trajectory analysis shows **read_file** strongly correlates with high session scores.
- Preferred over cat/head/tail in terminal.
- Use this for reading text files with line numbers and pagination.
- Supports offset and limit for large file navigation.
