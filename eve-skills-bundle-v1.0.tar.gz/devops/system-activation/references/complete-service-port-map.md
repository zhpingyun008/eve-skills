# Complete Eve Service Port Map

> Auto-discover ports with: `ss -tlnp 2>/dev/null | grep -E 'python|node'`
> **NEVER hardcode port assumptions** — always verify with `ss -tlnp` first.

## Layer 1: Hermes Core Infrastructure

| Service | Port | Process | PID Match Pattern | HTTP Check |
|---------|------|---------|-------------------|------------|
| Hermes Gateway | 8655/8660 | `hermes_cli.main gateway` | `-m hermes_cli.main` | :8655/health |
| Hermes Dashboard | 8050 | `dashboard/app.py` | `dashboard` | :8050/ |
| Hermes OS API | 8642 | `os/api_server.py` | `os/api_server` | :8642/health |
| Hermes WebUI (VNC) | 5900 | `web/app.py` | `web/app.py` | :5900/ |
| Hermes Wiki | 4000 | `docsify serve` | `docsify` | :4000/ |
| CC-Switch Proxy | 8787 | `cc-switch-proxy.py` | `cc-switch-proxy` | — |
| DeepSeek Proxy | 9292 | `deepseek-proxy.py` | `deepseek-proxy` | — |
| Dashboard Redirect | 8640 | `dashboard_redirect.py` | `dashboard_redirect` | — |
| Internal API (A) | 3871 | `app.py` (PID 522) | `app.py` | — |
| Internal API (B) | 8085 | `app.py` (PID 741) | `app.py` | — |

## Layer 2: Eve Company Services

| Service | Port | Entry Point | Command |
|---------|------|-------------|---------|
| Company API (FastAPI) | 8000 | `~/company-product/backend/main.py` | `python3 -m uvicorn backend.main:app --host 0.0.0.0 --port 8000` |
| Bidding Tool (Flask) | 8850 | `~/company/product/bidding-tool/app.py` | `python3 app.py` (from bidding-tool dir) — uses `socketio.run(app, port=8850)` |
| Company Website | 8765 | http.server | `python3 -m http.server 8765 --directory ~/company/website` |
| Discuss API | 8766 | `~/company/scripts/discuss-api.py` | `python3 discuss-api.py` |
| Contact API | 8767 | `~/company/scripts/contact-api.py` | `python3 contact-api.py` |
| Company Dashboard | 3888 | `~/company/scripts/dashboard.py` | `python3 dashboard.py` |
| Codex CEO Autopilot | — | `~/company/scripts/codex-ceo-autopilot.py` | CLI script, daemon loop |
| Eve Consciousness | — | `~/company/scripts/orchestrator.py` | state machine, daemon loop |

## Layer 3: Product Matrix (5 Services)

| Service | Port | Entry Point | Quirk |
|---------|------|-------------|-------|
| 智账AI | 8081 | `~/zhizhang-ai/api/server.py` | Standard FastAPI, no special needs |
| tracellm | 8082 | `~/llm-call-tracker/dashboard/server.py` | Entry point is dashboard dir, NOT tracellm package dir |
| 去重工具 | 8083 | `~/dedup-tool/api/server.py` | **Requires** `PYTHONPATH=/home/yestin/dedup-tool` |
| Listing | 8084 | `~/listing-tool/api/server.py` | No `if __name__ == "__main__"` — use inline python invocation |
| PM Bridge | 8769 | `~/company/scripts/pm_bridge.py` | Must run from `~/company/` (DB path is relative to CWD) |
| Freelancer | 9000 | `~/freelancer-tool/main.py` | Standard standalone |
| VerifyAI | 8888 | `~/verifyai/api/server.py` | Has systemd unit (verifyai.service) |

## Layer 4: Gateway Profiles (Persistent)

| Profile | Listen Port | Purpose |
|---------|-------------|---------|
| eve-scout | 9263/8726 | 市场侦察 (24/7) |
| eve-closer | 9144/8727 | 销售关单 (24/7) |
| eve-scribe | 9264/8728 | 内容营销 (24/7) |
| arch | 8660 | 架构师 (on-demand) |
| pm | 8661 | 项目管理 (on-demand) |
| qa | 8743 | 质量管理 (on-demand) |
| req | 8744 | 需求分析 (on-demand) |

## Complete Health Check Script

```bash
#!/usr/bin/env bash
# Complete system health check — covers ALL layers
echo "=== Hermes Core ==="
for p in 8050 8642 5900 4000; do
  ss -tlnp 2>/dev/null | grep -q ":$p " && echo "ALIVE :$p" || echo "DOWN  :$p"
done

echo "=== Eve Company ==="
for p in 8000 8850 8765 8766 8767 3888; do
  ss -tlnp 2>/dev/null | grep -q ":$p " && echo "ALIVE :$p" || echo "DOWN  :$p"
done

echo "=== Product Matrix ==="
for p in 8081 8082 8083 8084 8769 9000 8888; do
  ss -tlnp 2>/dev/null | grep -q ":$p " && echo "ALIVE :$p" || echo "DOWN  :$p"
done

echo "=== Gateway Profiles ==="
for p in 9263 9144 9264 8660 8661 8743 8744; do
  ss -tlnp 2>/dev/null | grep -q ":$p " && echo "ALIVE :$p" || echo "DOWN  :$p"
done
```

## Port Assumption Anti-Pattern

**WRONG** (assumes port numbers — will falsely report DOWN):
```bash
curl -s http://localhost:5000/     # Wrong! bidding-tool is on :8850
curl -s http://localhost:8648/     # Wrong! webui is on :5900
```

**RIGHT** (discovers ports first, then checks):
```bash
ss -tlnp 2>/dev/null | grep -E 'python|node' | grep -oP ':\K\d+' | sort -nu
```
