# Gateway Recovery & Heartbeat Fix (2026-06-29)

## Problem
After system reboot, all 15 Hermes profile gateways show as offline. Attempting to restart them fails with "Another local Hermes gateway is already using this Feishu app_id" because old PID files and Feishu WS locks persist. The heartbeat agent reports 0/15 healthy.

## Root Causes (multi-layered)

### Layer 1: Stale PIDs + Feishu app_id lock
- Old `gateway run --profile <name>` processes (from pre-reboot) remain in `ps aux` as defunct/zombie, still holding the Feishu WebSocket file lock
- New `--replace` fails because the lock detects PID still alive
- **Fix**: `kill -9 <old_PID>`, then restart with `--replace`

### Layer 2: Hardcoded ports in heartbeat-agent.py
- `heartbeat-agent.py` had `AGENTS = {...}` with hardcoded ports (8662, 8722-8730)
- After restart, gateways bind to DIFFERENT ports (read from each profile's config.yaml)
- Result: Heartbeat checks wrong ports → 0/15 healthy → exit code 1
- **Fix**: Replace hardcoded dict with `detect_agent_ports()` that reads `port:` from each profile's `config.yaml`

### Layer 3: "test" profile name is Hermes-reserved
- `hermes --profile test gateway run --replace` returns `Error: Profile name 'test' is reserved`
- Remove from heartbeat agent's FALLBACK_PORTS

### Layer 4: Dev profile expired API key
- `~/.hermes/profiles/dev/.env` had an independent DEEPSEEK_API_KEY that expired (last 4 chars: 9d6b)
- Cron jobs inside dev gateway failed with HTTP 401
- **Fix**: Replace dev's DEEPSEEK_API_KEY with the working key from main ~/.hermes/.env

## Recovery Procedure (Post-Reboot)

```
Step 1: Kill all stale profile gateway processes (not the main gateway PID)
  for pid in $(pgrep -f 'gateway run --profile' 2>/dev/null); do
    kill -9 $pid 2>/dev/null
  done
  # Or use the start-all-profiles.sh script

Step 2: Start all profile gateways serially (5s gap to avoid Feishu lock contention)
  for profile in arch cm dev doc eve-closer eve-scout eve-scribe pm qa req sec spi tester yestin; do
    hermes gateway run --profile $profile --replace &
    sleep 5
  done

Step 3: Verify with port-based health check (not hardcoded ports)
  for p in arch ...; do
    port=$(grep -oP 'port:\\s*\\K\\d+' ~/.hermes/profiles/$p/config.yaml | tail -1)
    curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:$port/health
  done

Step 4: Run heartbeat-agent.py to confirm 14/14 (test excluded)
  python3 ~/.hermes/scripts/heartbeat-agent.py | grep SUMMARY
```

## Files Modified
- `~/.hermes/scripts/heartbeat-agent.py` — replaced hardcoded ports with dynamic `detect_agent_ports()`, removed `test` from FALLBACK_PORTS
- `~/.hermes/profiles/dev/.env` — replaced expired DEEPSEEK_API_KEY

## Verification
```
python3 ~/.hermes/scripts/heartbeat-agent.py | grep SUMMARY
# Expected: ✅ SUMMARY: 14/14 Agents Healthy
```
