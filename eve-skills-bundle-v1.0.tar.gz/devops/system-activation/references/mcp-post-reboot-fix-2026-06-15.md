# MCP Server Post-Reboot Fix (2026-06-15)

## 症状

系统重启后，agent.log 报：
```
WARNING tools.mcp_tool: Failed to connect to MCP server 'computer-use-linux': ClientSession.__init__() got an unexpected keyword argument 'sampling_capabilities'
WARNING tools.mcp_tool: Failed to connect to MCP server 'hermes-studio': ClientSession.__init__() got an unexpected keyword argument 'sampling_capabilities'
```

Gateway日志无MCP相关记录。用户看到 `computer-use-linux (stdio) — failed` 和 `hermes-studio (stdio) — failed`。

## 根因

Hermes `mcp_tool.py` 的 `session_kwargs()` 方法传入 `sampling_capabilities` 参数给 `ClientSession()`，但已安装的 `mcp` Python SDK 版本（v1.23.3）不支持该参数。

## 修复

在 `~/.hermes/.venv/lib/python3.11/site-packages/tools/mcp_tool.py` 中将 `session_kwargs()` 改为动态检测 ClientSession 支持的参数：

```python
def session_kwargs(self) -> dict:
    import inspect
    from mcp import ClientSession as _MCPClientSession
    _valid = set(inspect.signature(_MCPClientSession).parameters)
    kwargs: dict = {}
    if "sampling_callback" in _valid:
        kwargs["sampling_callback"] = self
    if "sampling_capabilities" in _valid:
        kwargs["sampling_capabilities"] = SamplingCapability(
            tools=SamplingToolsCapability(),
        )
    return kwargs
```

## 验证

重启Gateway后检查日志：
```bash
grep "MCP" ~/.hermes/logs/agent.log | tail -3
```

期望输出：
```
MCP server 'hermes-studio' (stdio): registered 14 tool(s): mcp_hermes_studio_...
MCP server 'computer-use-linux' (stdio): registered 16 tool(s): mcp_computer_use_linux_...
MCP: registered 30 tool(s) from 2 server(s)
```

## 已知影响

- 此补丁兼容新旧 mcp SDK 版本
- `sampling_capabilities` 仅影响MCP采样协商，不影响工具注册和调用
- 无需升级 mcp Python包
