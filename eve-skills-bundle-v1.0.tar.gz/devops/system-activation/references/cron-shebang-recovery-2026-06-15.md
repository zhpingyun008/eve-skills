# Cron Shebang/Command-as-Path Recovery — 2026-06-15 Batch Repair

## Context

System restart revealed 15 cron jobs in `error` state with `Script not found`. Two variants:
- **Shebang-as-path** (13): `Script: #!/usr/bin/env bash` or `Script: #!/usr/bin/env python3`
- **Command-as-path** (2): `Script: cd ~/company && python3 scripts/money-consciousness.py --skip-search 2>&1`

All were `no_agent=True` mode crons where the `script` field stored content instead of a filename.

## Batch Recovery Summary

| Cron Jobs Affected | 15 |
|--------------------|----|
| Script files created | 15 (8 `.py` + 7 `.sh`) |
| Total script lines recovered | ~170 lines across all |
| Run time | ~5 minutes total |
| Script location | `~/.hermes/scripts/cron-*.py` and `cron-*.sh` |

## Cron Jobs Recovered

| # | Name | Type | Schedule | Script Created |
|---|------|------|----------|----------------|
| 1 | 进化快检（每12h） | bash | every 720m | `cron-evolution-quick-check.sh` |
| 2 | Template Auto-Pusher weekly sync | python | 0 3 * * 1 | `cron-template-pusher.py` |
| 3 | Eve Daily Standup - AI员工日报 | python | 0 9 * * * | `cron-eve-standup.py` |
| 4 | Eve Lead Alert - 新线索自动通知 | python | 30 7 * * * | `cron-eve-lead-alert.py` |
| 5 | Eve Content Engine - 每日内容生产 | bash | 0 14 * * * | `cron-eve-content-engine.sh` |
| 6 | Eve KB Sync - 知识库自动同步 | python | 0 */3 * * * | `cron-eve-kb-sync.py` |
| 7 | PM Auto Metric Snapshot - 每日度量快照 | python | 0 1 * * * | `cron-pm-metric-snapshot.py` |
| 8 | Eve 搞钱日报下午版 - 二次研究 | python | 0 16 * * * | `cron-eve-afternoon-report.py` |
| 9 | Auto Pricing - 定价智能分析 | python | 0 5 * * 1 | `cron-auto-pricing.py` |
| 10 | Eve Money Consciousness (每2小时) — command-as-path | bash | 0 */2 * * * | `cron-eve-money-consciousness.sh` |
| 11 | Eve每日战报-08:15 | python | 15 8 * * * | `cron-eve-daily-briefing.py` |
| 12 | Eve每小时状态帖 (#general) — command-as-path | bash | 0 * * * * | `cron-eve-hourly-status.sh` |
| 13 | Eve讨论引擎-晨会08:45 | python | 45 8 * * * | `cron-eve-meeting-morning.py` |
| 14 | Eve讨论引擎-午间脑暴12:00 | python | 0 12 * * * | `cron-eve-meeting-noon.py` |
| 15 | Eve讨论引擎-搞钱会15:00 | python | 0 15 * * * | `cron-eve-meeting-afternoon.py` |

## Recovery Pattern (Python — complete)

```python
from hermes_tools import terminal, write_file

# 1. Get cron list
result = terminal("hermes cron list 2>&1", timeout=30)
output = result['output']

# 2. Parse line-by-line for broken crons (both shebang-as-path and command-as-path)
lines = output.split('\n')
crons_to_fix = []
i = 0
while i < len(lines):
    line = lines[i]
    stripped = line.strip()
    # Detect both variants: #!/ or cd ~/
    if stripped.startswith('Script:') and ('#!/' in stripped or 'cd ~/' in stripped):
        # Extract name by looking backwards
        name = ''
        for j in range(max(0, i-10), i):
            if 'Name:' in lines[j]:
                name = lines[j].split('Name:')[1].strip()
                break
        
        # Extract job_id by looking backwards
        job_id = ''
        for j in range(max(0, i-10), i):
            s = lines[j].strip()
            if s and '[' in s and len(s.split()[0]) == 12:
                job_id = s.split()[0]
                break
        
        # Collect all script content lines (from Script: line to Mode: line)
        script_parts = [stripped.split('Script:')[1].strip()]
        i += 1
        while i < len(lines):
            s = lines[i].strip()
            if s.startswith('Mode:') or s.startswith('Last run') or s.startswith('Next run') \
               or s.startswith('Schedule') or s.startswith('Deliver') or s.startswith('Repeat'):
                break
            if s:
                script_parts.append(s)
            i += 1
        
        full_script = '\n'.join(script_parts)
        crons_to_fix.append({
            'name': name,
            'job_id': job_id,
            'content': full_script
        })
    else:
        i += 1

# 3. Create standalone scripts and update cron references
for c in crons_to_fix:
    # Determine file extension from shebang or content
    first_line = c['content'].split('\n')[0]
    if 'bash' in first_line:
        ext = '.sh'
    elif 'python' in first_line:
        ext = '.py'
    else:
        # Command-as-path variant — no shebang, just a shell command
        ext = '.sh'
    
    filename = f"cron-{c['name'].lower().replace(' ','-').replace('(','').replace(')','')[:40]}{ext}"
    
    # Write the standalone script file
    write_file(f"/home/yestin/.hermes/scripts/{filename}", c['content'])
    print(f"✅ Created: {filename} ({len(c['content'])} chars)")
    
    # Update the cron to point to the new script (relative path only!)
    # cronjob(action='update', job_id=c['job_id'], script=filename)
```

## Automated Detection & Quick-Fix

```bash
# Quick scan
echo "Broken crons:" $(hermes cron list 2>&1 | grep -c "Script:.*#!\|Script:.*cd ~")
hermes cron list 2>&1 | grep "Script:.*#!\|Script:.*cd ~" -B5 | grep "Name:"

# List all created fix scripts
ls -la ~/.hermes/scripts/cron-eve-*.py ~/.hermes/scripts/cron-eve-*.sh \
      ~/.hermes/scripts/cron-evolution-*.sh ~/.hermes/scripts/cron-template-*.py \
      ~/.hermes/scripts/cron-pm-*.py ~/.hermes/scripts/cron-auto-*.py 2>/dev/null
```

## Key Lessons

1. **Script field is PATH-only**: `script` in cron job config is a relative/absolute file path, NOT inline content. All inline content must be saved to a standalone file first.
2. **Relative paths**: Script paths are relative to `~/.hermes/scripts/`. Use just the filename (e.g., `cron-eve-standup.py`), not an absolute path.
3. **Content preserved in cron list**: Even though the `Script:` line only shows the first line (shebang), the full script content exists between `Script:` line and `Mode:` line in `hermes cron list` output.
4. **Two variants**: Shebang-as-path (`Script: #!/usr/bin/env bash`) AND command-as-path (`Script: cd ~/company && python3 ...`). Both need the same fix.
5. **Stale errors**: After fixing, `last_status` still shows `error` until the cron actually runs again at its scheduled time. Old error records are not retroactively updated.
6. **Job ID extraction**: Each cron block starts with a 12-char hex ID (e.g., `990292c21486`). Parse it from the start of each block.
