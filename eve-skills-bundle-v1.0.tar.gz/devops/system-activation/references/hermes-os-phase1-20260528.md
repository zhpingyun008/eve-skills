# Hermes OS Phase 1 Implementation — 2026-05-28

## Background

Following strategic assessment of merging Hermes Agent (CLI engine, 170k⭐), Hermes Desktop(GUI clients), and Hermes OS (concept), the decision was to upgrade existing Hermes Agent infrastructure into a true AI Agent Operating System via a 3-phase plan.

**Approved: Phase 1 (Core OS) → Phase 2 (Unified Portal) → Phase 3 (Intelligence)**

## Phase 1 Deliverables

### Day 1-2: API Server Independent + Service Registry

**API Server (:8642)**
- Standalone Python HTTP server (http.server stdlib, no FastAPI dependency)
- systemd-managed: `hermes-os-api.service`
- Endpoints:
  - `GET /health` — Health check
  - `GET /v1/models` — OpenAI-compatible model list (proxied from Gateway :8655)
  - `POST /v1/chat/completions` — OpenAI-compatible chat (proxied)
  - `GET /os/status` — System resource status (CPU/Memory/Disk via psutil)
  - `GET /os/services` — Service registry output
  - `GET /os/health-summary` — Dashboard health HTML fragment
  - `POST /os/register` — Service registration
  - `POST /os/heartbeat` — Service heartbeat

**Service Registry**
- `~/.hermes/os/registry.py` — CLI tool with 4 commands: register, heartbeat, check, list
- Storage: `~/.hermes/os/registry.json` (JSON file, not SQLite)
- Heartbeat Cron: `*/2 * * * *` (no_agent=True), sends heartbeats for 4 core services + checks timeouts (60s)
- Registered services (8 total):
  - hermes-gateway (:8655), hermes-dashboard (:8050), hermes-webui-8000 (:8000)
  - hermes-webui-8648 (:8648), hermes-os-api (:8642), hermes-promptchain (:8082)
  - hermes-wiki (:3871), computer-use-mcp (internal)

### Day 3: Log Aggregation

**Log Aggregator** (`~/.hermes/os/log_aggregator.py`)
- Aggregates 6 log sources: gateway, dashboard, heartbeat, health, errors, cron
- Zero external dependencies (Python stdlib only)
- Output: `~/.hermes/os/log_aggregator.jsonl`
- Cron: `*/5 * * * *` (no_agent=True)
- Dashboard integration: `GET /api/os/logs?limit=N&level=ERROR&source=gateway`

### Dashboard Integration

**OS Status Page** (`/os` on :8050)
- Real-time service mesh (8 services, online/offline status)
- System resource cards (CPU/Memory/Disk gauges)
- Live log stream (15-second auto-refresh)
- Each service shown with type icon, port, and status dot

**Nav Integration**
- "⚡ OS" button in Dashboard header
- CSS class `.os-nav-btn` added to `dashboard.css`
- Links to `/os` from both Dashboard and OS page nav

## Config Changes

```yaml
# Gateway API Server — CORS wide open
platforms:
  api_server:
    cors_origins: '*'
    enabled: true
    extra:
      host: 0.0.0.0
      port: 8655
```

## Key Architecture Decisions

1. **No FastAPI/uvicorn** — `http.server.HTTPServer` is sufficient for lightweight API serving. Avoids adding another heavy dependency.
2. **JSON file registry** — JSON file over SQLite for the registry. The data volume is tiny (<1KB, 8 services). SQLite overhead not justified.
3. **Gateway API stays at :8655** — The Hermes Agent's built-in API Server is tied to Gateway. Instead of decoupling it (risky), we built a separate OS API on :8642 that proxies to :8655.
4. **no_agent=True** for all OS Cron jobs — Heartbeat and Log Aggregation are pure script tasks. No LLM needed.
5. **Systemd management** — All OS components managed through systemd user services for consistency with existing Gateway/Dashboard services.

## Verification

```bash
curl -s http://localhost:8642/health       # {"status":"ok","version":"1.0.0"}
curl -s http://localhost:8642/os/services  # 8 services, all online
curl -s http://localhost:8050/os           # HTML page
curl -s http://localhost:8050/api/os       # JSON with services + resources
curl -s 'http://localhost:8050/api/os/logs?limit=5'  # Log entries
systemctl --user is-active hermes-os-api.service  # active
```
