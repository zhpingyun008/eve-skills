# Eve Product Service Layer — Startup & Recovery

## Overview

Eve operates 6 product services (the "产品矩阵") as bare Python processes — no Docker, no systemd, no PM2. All are FastAPI/uvicorn servers started manually. After any system restart (WSL reboot, power loss, etc.), all 6 go down and must be restarted individually.

## Service Registry

| Product | Port | Entry Point | Startup Command |
|---------|------|-------------|-----------------|
| 智账AI | 8081 | `~/zhizhang-ai/api/server.py` | `cd ~/zhizhang-ai && python3 api/server.py` |
| tracellm | 8082 | `~/llm-call-tracker/dashboard/server.py` | `cd ~/llm-call-tracker && python3 dashboard/server.py` |
| 去重工具 | 8083 | `~/dedup-tool/api/server.py` | `cd ~/dedup-tool && PYTHONPATH=/home/yestin/dedup-tool python3 api/server.py` |
| Listing | 8084 | `~/listing-tool/api/server.py` | `cd ~/listing-tool && python3 -c "from api.server import app; import uvicorn; uvicorn.run(app, host='0.0.0.0', port=8084)"` |
| PM Bridge | 8769 | `~/company/scripts/pm_bridge.py` | `cd ~/company && python3 scripts/pm_bridge.py` |
| freelancer | 9000 | `~/freelancer-tool/main.py` | `cd ~/freelancer-tool && python3 main.py` |
| VerifyAI | 8888 | `~/verifyai/api/server.py` | `cd ~/verifyai && python3 -m uvicorn api.server:app --host 0.0.0.0 --port 8888` |

## Known Quirks & Pitfalls

### 1. 去重工具 (:8083) — PYTHONPATH Requirement

The `~/dedup-tool/api/server.py` imports `from engine.deduper import ...` which fails with `ModuleNotFoundError: No module named 'engine'` if run without `PYTHONPATH`. The server file itself does NOT add its parent dir to `sys.path` — it expects `sys.path.insert(0, os.path.dirname(__file__) + '/..')` or explicit PYTHONPATH.

**Fix**: Always set `PYTHONPATH=/home/yestin/dedup-tool` before running.

### 2. Listing (:8084) — No `if __name__ == "__main__"` Block

The `~/listing-tool/api/server.py` defines a FastAPI `app` but has **no entry point** (`uvicorn.run(...)`). It must be started via an inline Python invocation.

**Check before running**: If `listing-tool` has been updated, verify the entry point hasn't been added to `server.py`.

### 3. PM Bridge (:8769) — Runs from `~/company/` Not Its Own Dir

PM Bridge is at `~/company/scripts/pm_bridge.py` but must be started from `~/company/` (because it creates DB/data files relative to `BASE = expanduser("~/company")`). Starting from any other directory creates orphan DB files in the wrong location.

### 4. tracellm (:8082) — No Auto-Start, Dashboard Entry Point

tracellm has **no systemd/auto-start mechanism**. Its HTTP dashboard entry point is `~/llm-call-tracker/dashboard/server.py` (a FastAPI uvicorn server), not the `tracellm/` package directory itself. The package directory (`tracellm/__init__.py`) is a Python library, not a server.

**Startup command**: `cd ~/llm-call-tracker && python3 dashboard/server.py`
**Verification**: `curl -s -o /dev/null -w '%{http_code}' http://localhost:8082/` → expect 200

**Pitfall**: Do NOT try `cd ~/llm-call-tracker/tracellm && python3 ...` — the tracellm/ directory contains library modules (`decorator.py`, `storage.py`, `__init__.py`), not a server entry point.

### 5. No Persistent Startup Mechanism

None of these services have:
- systemd service units
- Docker containers with restart=always
- Cron-based auto-heal watchers
- PM2 process management

After any system restart, ALL must be started manually via `terminal(background=true)`.

### 6. VerifyAI (:8888) — Systemd Unit Available

VerifyAI is the only product service with a proper systemd service unit (`~/verifyai/verifyai.service`). It can be started via systemd OR directly with uvicorn:

```bash
# Option A: systemd (preferred)
cp ~/verifyai/verifyai.service ~/.config/systemd/user/verifyai.service
systemctl --user daemon-reload
systemctl --user start verifyai.service

# Option B: Direct uvicorn (for non-systemd environments)
cd ~/verifyai && python3 -m uvicorn api.server:app --host 0.0.0.0 --port 8888
```

**Verification**: `curl -s -o /dev/null -w '%{http_code}' http://localhost:8888/` → expect 200

**Pitfall**: systemd user services may not auto-start after WSL reboot. If systemctl fails, fall back to direct uvicorn.

## Startup Sequence

Recommended order (fastest services first, verify each before next):

```python
# Using Hermes terminal(background=true) — all 7 services
terminal(background=True, command="cd /home/yestin/zhizhang-ai && python3 api/server.py")
terminal(background=True, command="cd /home/yestin/llm-call-tracker && python3 dashboard/server.py")
terminal(background=True, command="cd /home/yestin/dedup-tool && PYTHONPATH=/home/yestin/dedup-tool python3 api/server.py")
terminal(background=True, command="cd /home/yestin/listing-tool && python3 -c 'from api.server import app; import uvicorn; uvicorn.run(app, host=\"0.0.0.0\", port=8084)'")
terminal(background=True, command="cd /home/yestin/freelancer-tool && python3 main.py")
terminal(background=True, command="cd /home/yestin/company && python3 scripts/pm_bridge.py")
terminal(background=True, command="cd /home/yestin/verifyai && python3 -m uvicorn api.server:app --host 0.0.0.0 --port 8888")
```

After ~4s wait, verify all 7 endpoints:

```bash
for p in 8081 8082 8083 8084 8769 9000 8888; do
  curl -s -o /dev/null -w "%{http_code}" --max-time 3 http://localhost:$p/
  echo " :$p"
done
```

Expected: 200 200 200 307 200 200 200 (Listing:8084 returns 307 redirect — normal). VerifyAI:8888 returns 200.

## Long-term Improvement Candidates

1. Create systemd service units for all 7 services (`restart=always`)
2. Add healer watcher cron to auto-restart any down service
3. Or migrate to docker-compose with restart policy
4. Add reboot-time auto-start: one-shot cron that starts all 7 services after system boot
5. Add persistent gateway profiles (eve-closer/eve-scout/eve-scribe) to the startup sequence
