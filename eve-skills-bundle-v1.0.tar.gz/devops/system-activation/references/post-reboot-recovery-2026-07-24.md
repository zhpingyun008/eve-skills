# Post-Reboot Recovery Pattern — 2026-07-24

**Context**: WSL system reboot → all services down, cron jobs.json `state` field empty, evolution engine score dropped from 100 to 98.3.

## Recovery Sequence (proven order)

```
↓ 1. Dispatch subagents to restore services (parallel, max 3)
↓ 2. Git init projects (sequential, each subagent blocks)
↓ 3. Clear pending backlog items + rotate error log
↓ 4. Fix evolution engine: healer metrics → MEMORY.md compress → evolution log entries
   → score 98.3→100.0
↓ 5. Full system scan confirm
↓ 6. Deep diagnostics: cron/trajectory/skill-audit/port-audit
```

## Service Recovery

Dispatch 4 subagents in parallel (max 3 per batch) to restore services. Key pattern:

```python
# Batch 1 (3 at once)
delegate_task(tasks=[
    {"goal": "恢复LLM Gateway (9090)", "context": "项目: ~/projects/llm-gateway/, uvicorn app.main:app"},
    {"goal": "恢复Skills Market (8770)", "context": "项目: ~/projects/skills-market/, uvicorn backend.main:app"},
    {"goal": "恢复Env Vault (8771)", "context": "项目: ~/projects/env-vault/backend/, uvicorn app.main:app"},
])
# Batch 2 (1 remaining)
delegate_task(goal="恢复Freelancer Tool (9000)", context="项目: ~/freelancer-tool/, python3 main.py")
```

**Common services and their start commands:**

| Port | Service | Start Command |
|------|---------|---------------|
| 9000 | Freelancer Tool | `python3 main.py` (from ~/freelancer-tool/) |
| 9090 | LLM Gateway | `uvicorn app.main:app --port 9090` (from ~/projects/llm-gateway/) |
| 8770 | Skills Market API | `uvicorn backend.main:app --port 8770` (from ~/projects/skills-market/) |
| 8771 | Env Vault | `uvicorn app.main:app --port 8771` (from ~/projects/env-vault/backend/) |
| 8000 | Skills Market Backend | (was already running) |
| 8085 | Prompt Optimizer Server | (was already running) |
| 3871 | PromptHub Server | (was already running) |

## Cron Diagnostic Pitfall

**Never check `jobs.json` directly for `status` or `next_run`** — those field names don't exist.

Correct fields:
- `state` — NOT `status` (values: `scheduled`, `completed`, `paused`)
- `next_run_at` — NOT `next_run` or `nextRun`
- `enabled` — boolean (default true)

**Safe diagnostic** (terminal):
```bash
python3 -c "
import json
with open('/home/yestin/.hermes/cron/jobs.json') as f:
    d = json.load(f)
jobs = d.get('jobs', [])
print(f'Total: {len(jobs)}')
states = set(j.get('state') for j in jobs if j.get('state'))
print(f'States: {states}')
enabled = sum(1 for j in jobs if j.get('enabled') == True)
with_next_run = sum(1 for j in jobs if j.get('next_run_at'))
print(f'Enabled: {enabled} | With next_run_at: {with_next_run}')
"
```

If `ticker_heartbeat` and `ticker_last_success` files exist and update every few seconds in `~/.hermes/cron/`, the cron ticker IS running — don't restart it.

## Evolution Engine Post-Reboot Fix

Three predictable drops after reboot:

| Dimension | Typical Post-Reboot | Fix |
|-----------|-------------------|-----|
| `self_healing` | 97 (metrics > 2h old) | `python3 ~/.hermes/healer/orchestrator.py --check` |
| `memory_efficiency` | 90 (MEMORY.md bloated) | Clean memory.db (SQLite DELETE Obsidian bloat) → sync.py |
| `execution_velocity` | 95 (evolution entries stale) | Append 3 fresh entries to evolution_log.jsonl |

**Proven fix sequence:**
1. `orchestrator.py --check` (fixes self_healing)
2. Clean memory.db via SQLite (fixes memory_efficiency)
3. Append fresh evolution log entries (fixes execution_velocity)
4. Re-run `--analyze` → expected 100.0

## Port Security Audit (Quick Pattern)

After all services restored, do a quick 0.0.0.0 port audit:

```bash
ss -tlnp | grep "0.0.0.0:" | while read line; do
  port=$(echo "$line" | grep -oP '0.0.0.0:\K\d+')
  pid=$(echo "$line" | grep -oP 'pid=\K\d+')
  cmd=$(ps -p $pid -o args= 2>/dev/null | head -c 60)
  echo ":$port  →  $cmd"
done
```

**Categorize**: Public-facing (need 0.0.0.0 for tunnel/demo) vs Internal (should be 127.0.0.1). At Eve scale, most 0.0.0.0 services are intentional (product APIs behind tunnel).

## Git Init for Projects

On recovery, initialize Git for projects that lost .git/ (unusual — only happens if projects never had Git):

```bash
cd ~/projects/<name> && git init && git add -A && git commit -m "init: <name>"
```

## Backlog Cleanup

The backlog auto-generates `pending` entries for repeated failures. After recovery:
1. Mark them as `completed` with resolution note
2. Rotate `errors.log` (prevents stale error counts)
