# Startup Diagnostics Reference — 2026-05-30

## System State (pre-activation)

| Dimension | Status | Detail |
|-----------|--------|--------|
| Cron (system) | 5 entries | Weekly WAL, auto-mode, heartbeat, WS monitor, gateway boot |
| Cron (Hermes) | 49 active | Sprint, evolution, CMMI5, learning, perception, LLM Wiki, memory, KG |
| Dashboard | LIVE 8050 | PID 418, port auto-assigned |
| API Balance | 198.28 CNY | DeepSeek充足; 429来自第三方感知服务 |
| Gateway | 4 processes | PID 420 (main), 1201 (pm profile) + others |
| Evolution Score | 97.8/100 | skill_quality=100, memory=100, self_healing=97 |
| Disk | 1007G/29G used (3%) | 充足 |
| Memory | 7.6Gi/1.4Gi used (18%) | 健康 |

## Dashboard Port Mismatch

**Cron script** `~/.hermes/scripts/cron-16fcfff0fca8.sh`:
- Checks port **8648** via curl
- Expects app at `~/projects/hermes-dashboard/app.py`

**Actual dashboard**:
- PID 418, running from `~/projects/hermes-dashboard/app.py`
- Port **8050** (auto-assigned by uvicorn)
- App has PID lock file at `/tmp/hermes-dashboard.pid`
- Config at `~/projects/hermes-dashboard/config.py` — sets HERMES_DIR but **no port config**

**Effect**: Every 5min, cron checks 8648 → fails → tries restart → app already running (PID lock blocks) → no-op. False-positive perpetual restart.

**Fix options**:
1. Update cron script to check actual port: `s/8648/8050/`
2. Replace curl check with PID file check: `kill -0 $(cat /tmp/hermes-dashboard.pid)`
3. Remove redundant cron if systemd/healer manages dashboard

## Evolution Engine CLI

| Command | Purpose |
|---------|---------|
| `--analyze` | Full 9-dim assessment |
| `--analyze --json` | JSON output for parsing |
| `--plan` | Generate action plan (may return 0 if last few points need manual fix) |
| `--evolve --max-actions N --safe` | Execute N safe evolutions |
| `--evolve --max-actions N --safe --json` | Same with JSON output |
| `--verify` | Verify last evolution |
| `--history` | Evolution log |
| `--assess` | **DOES NOT EXIST** |

## Daily Report Fix

**Original**: Inline script in cron Script field with `#!/usr/bin/env python3` → "Script not found" error.
**Fix**: Create separate script file `~/.hermes/scripts/daily-report.py`, set `script='daily-report.py'` in cron.

Key principle: **Cron `script` field only accepts filenames** (resolved under `~/.hermes/scripts/`), not inline shebang content.

## 429 Error Diagnosis

- DeepSeek API balance: **198.28 CNY — sufficient**
- 429 errors came from **internet-perception cron jobs** using third-party services (Serper, Brave, etc.)
- Not a DeepSeek issue — don't waste time troubleshooting provider config
- Fix: recharge third-party service accounts or reduce scan frequency
