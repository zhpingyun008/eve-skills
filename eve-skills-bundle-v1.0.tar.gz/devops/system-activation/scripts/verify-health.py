#!/usr/bin/env python3
"""系统启动健康验证脚本 — 快速验证10个子系统状态"""
import json, subprocess, sys, os

def check(label, ok, detail=""):
    icon = "✅" if ok else "❌"
    print(f"  {icon} {label}" + (f"  | {detail}" if detail else ""))

def run(cmd, timeout=10):
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
        return r.stdout.strip(), r.returncode
    except subprocess.TimeoutExpired:
        return "(timeout)", -1

print("=" * 50)
print("  系统启动健康验证")
print("=" * 50)

# 1. Cron
out, rc = run("cronjob --action list 2>/dev/null || echo 'NA'")
cron_count = out.count('"job_id"')
check("Cron任务", cron_count > 50, f"{cron_count}枚已注册")

# 2. Agent进程
out, rc = run("ps aux | grep -E 'hermes|gateway' | grep -v grep | wc -l")
agent_count = int(out) if out.isdigit() else 0
check("Agent进程", agent_count >= 10, f"{agent_count}个进程运行中")

# 3. Dashboard
code, _ = run("curl -s -o /dev/null -w '%{http_code}' http://localhost:8050/")
check("Dashboard (8050)", code == "200")

# 4. WebUI
code, _ = run("curl -s -o /dev/null -w '%{http_code}' http://localhost:8648/")
check("WebUI (8648)", code == "200")

# 5. BookStack
code, _ = run("curl -s -o /dev/null -w '%{http_code}' http://localhost:8080/api/pages/285")
check("BookStack API", code == "200")

# 6. CMMI5 Pipeline
bridge_db = os.path.expanduser("~/projects/hermes-infra/agent-bridge/agent_bridge.db")
if os.path.exists(bridge_db):
    out, _ = run(f"python3 -c \"import sqlite3; db=sqlite3.connect('{bridge_db}'); cur=db.cursor(); cur.execute('SELECT status,count(*) FROM agent_tasks GROUP BY status'); print(dict(cur.fetchall())); db.close()\"")
    check("CMMI5管道", True, out)
else:
    check("CMMI5管道", False, "agent_bridge.db not found")

# 7. RL训练数据
train = os.path.expanduser("~/.hermes/training_data/train.jsonl")
eval_f = os.path.expanduser("~/.hermes/training_data/eval.jsonl")
if os.path.exists(train) and os.path.exists(eval_f):
    train_size = os.path.getsize(train) // 1024
    eval_size = os.path.getsize(eval_f) // 1024
    check("RL训练数据", True, f"train {train_size}KB / eval {eval_size}KB")
else:
    check("RL训练数据", False, "training data missing")

print("=" * 50)
print("  验证完成")
print("=" * 50)
