---
name: bookstack-model-registry
description: Full lifecycle for adding a new LLM model provider to Hermes Agent — API key setup, provider config, connectivity testing, model discovery/benchmarking, BookStack asset registry update, Feishu sync, and RAG ingestion.
category: devops
triggers:
  - "新增模型 / add model / new model provider"
  - "接入提供商 / integrate new provider / connect API"
  - "模型切换 / switch model / change model"
  - "更新模型版本 / update model version"
  - "模型路由变更 / model routing change"
  - "模型成本更新 / model cost update"
  - "更新模型资产库 / update model asset library"
  - "BookStack模型记录 / model registry"
  - "模型配置参考 / model config reference"
  - "飞书同步模型信息 / sync model info to Feishu"
  - "model asset maintenance"
  - "connect NVIDIA / connect Anthropic / connect any new LLM API"
  - "provider auth failure / provider 401 / API Key not recognized"
  - "NO env var / no-key-r...ired / provider credential not working"
  - "model not found / 找不到默认模型 / model name invalid"
  - "模型配置诊断 / diagnose model config / model name mismatch"
  - "模型名有后缀 / wrong model name / model API returned different ID"
---

# bookstack-model-registry — 模型提供商全生命周期接入 + BookStack登记


## Overview

bookstack-model-registry — 模型提供商全生命周期接入 + BookStack登记 skill - auto-validated.
**类**: DevOps / Provider Integration
**触发条件**: 需要接入一个新的LLM模型提供商（如NVIDIA、Anthropic、Gemini等），或在已有提供商下新增模型时

## 全流程概览

```
Phase 0: Provider配置    → config.yaml + .env + API Key
Phase 1: API连通性测试    → curl调用验证 + 模型列表发现
Phase 2: 模型基准测试      → 关键模型推理验证 + 能力评估
Phase 3: BookStack登记    → 模型清单表 + 路由配置 + 配置参考
Phase 4: 同步+RAG        → 飞书同步 + RAG重摄入
```

## Phase 0: 模型配置诊断（当默认模型找不到/报错时）

当 `hermes` 启动时报 "model not found" 或模型调用失败时，按以下步骤诊断修复。

### 0.1 排查当前模型配置

```bash
# 查看当前模型名
hermes config show | grep -A2 "Model:"
# 或直接看 config.yaml
grep -A2 '^model:' ~/.hermes/config.yaml
```

常见问题：`model.name` 中包含了不必要的后缀（如 `deepseek-v4-flash-默认` 中的 `-默认`），导致 API 无法识别。

### 0.2 查询提供商可用模型列表

通过提供商 API 的 `/models` 端点获取官方模型列表：

```bash
# 从 .env 加载 API Key
source ~/.hermes/.env

# 通用 OpenAI-compatible 模型列表查询
curl -s ${PROVIDER_BASE_URL}/models -H "Authorization: Bearer $PROVIDER_API_KEY" | python3 -m json.tool

# 例如 DeepSeek:
curl -s https://api.deepseek.com/models -H "Authorization: Bearer $DEEPSEEK_API_KEY" | python3 -m json.tool

# 从响应中提取模型名
curl -s https://api.deepseek.com/models -H "Authorization: Bearer $DEEPSEEK_API_KEY" \
  | python3 -c "import json,sys;d=json.load(sys.stdin);[print(m['id']) for m in d['data']]"
```

### 0.3 对比并修复模型名 + Provider

`config.yaml` 的 `model:` 段需要 **三个字段** 才能正确加载：

```yaml
model:
  model: <精确模型ID>        # ← 模型ID（必填！API实际调用的模型名）
  name: <显示名>             # ← 显示名（可选，主要用于界面展示）
  provider: <provider名>     # ← 提供商
```

- 检查 `model.name` 是否与 API 返回的模型 ID **精确一致**（大小写、连字符完全匹配）
- 检查 `model.model` 是否也设置了正确的模型 ID（**容易遗漏！**）
- 检查 `model.provider` 是否对应正确的提供商（如 `deepseek`/`zai`/`nvidia`/`openrouter`）
- 若不一致，用 `hermes config set` 显式固化（比直接改YAML更可靠，确保重启后正确加载）：

```bash
# ⚠️ 需要 THREE 条命令，缺一不可

# 1. 修复模型ID（模型实际调用名，必须精确匹配API模型ID，不能有多余后缀）
hermes config set model.model <精确模型ID>

# 2. 修复显示名（可选但建议同步）
hermes config set model.name <精确模型ID>

# 3. 修复提供商
hermes config set model.provider <provider名>
```

**陷阱：** `hermes config set model.name` **只设置 `name:` 字段**，不会自动设置 `model:` 字段。
如果只运行 `hermes config set model.name` + `model.provider` 而遗漏了 `model.model`，
config.yaml 会是：
```yaml
model:
  name: deepseek-v4-flash    # ✅ 有
  provider: deepseek         # ✅ 有
  # model: 缺失！             # ❌ Hermes 无法确认模型ID → 重启加载失败
```
因此 **必须显式执行 `hermes config set model.model`**。

### 0.4 验证修复

```bash
# 确认配置已更新（检查 model/name/provider 三个字段都齐全）
hermes config show | grep -A3 "Model:"
grep -A3 '^model:' ~/.hermes/config.yaml
# 期望输出:
# model:
#   name: deepseek-v4-flash
#   provider: deepseek
#   model: deepseek-v4-flash   ← 这一行必须有！

# 若缺少 model: 字段，立即补上：
hermes config set model.model <精确模型ID>

# 验证 API 连通性 — 必须确认模型在 provider 的可用列表中
source ~/.hermes/.env
curl -s ${PROVIDER_BASE_URL}/models -H "Authorization: Bearer $PROVIDER_API_KEY" \
  | python3 -c "import json,sys;d=json.load(sys.stdin);[print(f'  ✅ {m[\"id\"]}') for m in d.get('data',[])]"

# 例如 DeepSeek：
source ~/.hermes/.env
curl -s https://api.deepseek.com/models -H "Authorization: Bearer $DEEPSEEK_API_KEY" \
  | python3 -c "import json,sys;d=json.load(sys.stdin);[print(f'  ✅ {m[\"id\"]}') for m in d.get('data',[])]"

# 快速推理测试
curl -s -X POST https://api.deepseek.com/v1/chat/completions \
  -H "Authorization: Bearer $DEEPSEEK_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"model":"<精确模型ID>","messages":[{"role":"user","content":"ping"}],"max_tokens":10}' \
  | python3 -c "import json,sys;d=json.load(sys.stdin);print('✅ OK' if d.get('choices') else '❌ FAIL:', d)"
```

### 0.5 记录到记忆

修复后将此经验和正确的模型 ID 记录到记忆，防止重复排查：

```bash
hermes memory add "模型名配置: <provider> API 接受的模型名必须精确匹配 /models 端点返回的 id 字段，不能有额外后缀或前缀"
```

---

## Phase 1: Provider配置接入
### 0.1 获取API Key并写入.env（**必须**）

目标提供商官网注册/申请API Key（如 build.nvidia.com, console.anthropic.com, makersuite.google.com）

**关键：** Hermes的PROVIDER_REGISTRY**只从环境变量**读取API Key，config.yaml的 `providers.{name}.api_key` 字段**不被认领**。因此必须将Key写入 `.env` 文件：

```bash
echo 'PROVIDER_API_KEY=sk-...' >> ~/.hermes/.env
echo 'PROVIDER_BASE_URL=https://api.provider.com/v1' >> ~/.hermes/.env
```

如何确认env var名称？查看 `PROVIDER_REGISTRY` 中该provider的 `api_key_env_vars` 和 `base_url_env_var`：
```bash
grep -A10 '"nvidia": ProviderConfig' ~/.hermes/.venv/lib/python3.11/site-packages/hermes_cli/auth.py
```

### 0.2 添加provider到config.yaml

NVIDIA NIM (OpenAI兼容) 示例:
```yaml
providers:
  nvidia:
    api_key: nvapi-...
    base_url: https://integrate.api.nvidia.com/v1
```

使用 `~/.hermes/tools/patch` 或 `sed` 插入:
```python
from hermes_tools import patch
patch('~/.hermes/config.yaml',
    '  openrouter:',  # 插入在openrouter之后
    '  openrouter:\n    ...\n  nvidia:\n    api_key: nvapi-...\n    base_url: https://integrate.api.nvidia.com/v1')
```

也可通过环境变量引用（推荐）:
```yaml
  nvidia:
    api_key: ${NVIDIA_API_KEY}
    base_url: https://integrate.api.nvidia.com/v1
```

### 0.3 验证配置写入
```bash
grep -A3 'nvidia:' ~/.hermes/config.yaml
```

## Phase 0.5: 注册模型到Hermes模型列表

新模型添加到provider后，还需要注册到Hermes的内部模型列表才能在 `hermes model` 交互选择中可见。

### 0.5.1 检查模型是否在列表中

```python
from hermes_cli.models import provider_model_ids
nv = provider_model_ids('nvidia')
print(f'v4-flash: {any("v4-flash" in x for x in nv)}')
print(f'v4-pro:   {any("v4-pro" in x for x in nv)}')
```

### 0.5.2 更新硬编码模型列表

`hermes_cli/models.py` 中有 `_PROVIDER_MODELS` 字典，各provider的模型写死在列表中。API提供商新增模型后此处不会自动同步。

```python
# 文件: ~/.hermes/.venv/lib/python3.11/site-packages/hermes_cli/models.py
# _PROVIDER_MODELS["nvidia"] = [
#     ...
#     "deepseek-ai/deepseek-v3.2",   # 已有，旧模型
#     "deepseek-ai/deepseek-v4-flash",  # 新增 ← 补上
#     "deepseek-ai/deepseek-v4-pro",    # 新增 ← 补上
# ]
```

使用 `patch()` 工具修改:

```python
from hermes_tools import patch
patch(
    "~/.hermes/.venv/lib/python3.11/site-packages/hermes_cli/models.py",
    '"deepseek-ai/deepseek-v3.2",',
    '"deepseek-ai/deepseek-v3.2",\n        "deepseek-ai/deepseek-v4-flash",\n        "deepseek-ai/deepseek-v4-pro",'
)
```

### 0.5.3 更新模型目录缓存

`~/.hermes/cache/model_catalog.json` 是Hermes模型选择界面的缓存数据，也需要同步更新：

```python
import json, os
cache = os.path.expanduser("~/.hermes/cache/model_catalog.json")
if os.path.exists(cache):
    d = json.load(open(cache))
    nv = d.setdefault("providers", {}).setdefault("nvidia", {"models": []})
    existing = {m["id"] for m in nv.get("models", [])}
    for mid in ["deepseek-ai/deepseek-v4-flash", "deepseek-ai/deepseek-v4-pro"]:
        if mid not in existing:
            nv.setdefault("models", []).append({"id": mid, "description": "DeepSeek V4 via NVIDIA NIM"})
    json.dump(d, open(cache, "w"), indent=2)
```

**注意**: cache文件定期被官方模型目录覆盖（TTL 24h），此修复需要在上游模型目录更新前提供临时可见性。长远解决方案是设置 `model_catalog.providers.nvidia.url` 自定义目录源。

### 0.5.4 验证

```bash
# 确认模型出现在列表中
hermes chat -q "hi" --provider nvidia --model deepseek-ai/deepseek-v4-flash --quiet

# 或直接查列表
python3 -c "from hermes_cli.models import provider_model_ids; print('v4-flash:', any('v4-flash' in x for x in provider_model_ids('nvidia')))"
```

## Phase 1: API连通性测试 + 模型发现

### 1.1 列表API（发现可用模型）

通用 OpenAI-compatible 列表:
```bash
curl -s $BASE_URL/models -H "Authorization: Bearer $API_KEY" | python3 -m json.tool
```

示例 (NVIDIA):
```bash
curl -s https://integrate.api.nvidia.com/v1/models \
  -H "Authorization: Bearer $NVIDIA_API_KEY" | python3 -c "
import json,sys
data = json.load(sys.stdin)
models = data.get('data',[])
print(f'可用模型: {len(models)} 个')
for m in models:
    print(m.get('id','?'))
"
```

### 1.2 将模型按类别分类

```python
# NVIDIA NIM模型分类示例
cats = {
    '🏆 旗舰推理': ['nemotron-3-super', 'nemotron-4-340b', 'ultra'],
    '⚡ 轻量高效': ['nano-30b', 'mini-4b', 'nano-9b'],
    '🤖 推理思考': ['reasoning'],
    '👁️ 视觉语言': ['vl', 'vila', 'cosmos', 'neva'],
    '🔤 嵌入向量': ['embed', 'retriever'],
    '🛡️ 安全审核': ['safety', 'guard'],
    '🎤 语音翻译': ['riva-translate'],
}
matched = [m for m in models if any(kw in m.get('id','').lower() for kw in kws)]
```

### 1.3 API推理测试

```bash
curl -s -X POST $BASE_URL/chat/completions \
  -H "Authorization: Bearer $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"model":"PROVIDER/MODEL-NAME","messages":[{"role":"user","content":"Reply exactly: Hello from PROVIDER"}],"max_tokens":30}' | python3 -c "
import json,sys
d=json.load(sys.stdin)
c=d.get('choices',[{}])[0].get('message',{}).get('content','')
print(f'回复: {c}')
# 检查是否有reasoning字段（CoT模型）
reasoning = d.get('choices',[{}])[0].get('message',{}).get('reasoning','')
if reasoning:
    print(f'推理过程: {reasoning[:100]}...')
"
```

验证要点:
- HTTP 200 ✅
- 内容非空且有实际回复
- 响应速度可接受
- 中文支持（如需）

### 1.4 挑选关键模型

按使用场景选择3-5个代表性模型:
| 场景 | 模型选择标准 |
|------|-------------|
| 旗舰推理 | 最大参数 + 最长上下文 |
| 轻量日常 | 高效MoE / 小参数 |
| 推理思考 | 有reasoning/CoT字段的模型 |
| 视觉多模态 | 支持image输入的VL模型 |
| 嵌入向量 | 专为embedding/Search优化的模型 |

### 1.5 注意：API空响应陷阱

部分模型在 `chat/completions` 端点会返回空响应（HTTP 200但content为`""`），可能原因：
- 模型需要不同API endpoint（如嵌入模型用 `/v1/embeddings`）
- 模型仅支持自托管（如 Nemotron-4-340B）
- 模型已废弃但仍在list中

先快速验证模型是否能正常返回再投入精力测试。

---

## Phase 2: 模型基准测试 (Benchmark)

在确认API连通后，对所有候选模型进行 **3维度实测**。

### 2.1 测试问题集

```python
TESTS = {
    "算术(准确率)": "What is 15 × 37? Give only numeric answer.",
    "中文(语言理解)": "用一句话通俗解释量子计算。",
    "代码(工程能力)": "Write Python: def is_palindrome(s):  # handle empty, case, spaces",
}
```

### 2.2 测试脚本模板

```python
import json, time
from hermes_tools import terminal

def test_model(model_id, question, max_tokens=60):
    payload = json.dumps({
        "model": model_id,
        "messages": [{"role": "user", "content": question}],
        "max_tokens": max_tokens
    })
    cmd = f'''curl -s -X POST {BASE_URL}/chat/completions \
  -H "Authorization: Bearer {API_KEY}" \
  -H "Content-Type: application/json" \
  -d '{payload}' 2>/dev/null'''
    start = time.time()
    r = terminal(cmd, timeout=30)
    elapsed = time.time() - start
    resp = json.loads(r['output'])
    msg = resp.get('choices', [{}])[0].get('message', {})
    content = msg.get('content', '')
    reasoning = msg.get('reasoning', '') or msg.get('reasoning_content', '')
    usage = resp.get('usage', {})
    tokens = usage.get('total_tokens', '?')
    return (content or reasoning or '(empty)'), tokens, f"{elapsed:.1f}s"
```

### 2.3 评分标准

| 维度 | 方法 | 评分 |
|------|------|------|
| **算术** | 15×37=555是否正确？ | ✅正确 / 部分(有CoT但未给答案) / ❌错误 |
| **中文** | 比喻是否地道、语法是否流畅 | ⭐极优(地道中文比喻) / ✅好 / 中(术语化) / 差(英文回复) |
| **代码** | 函数完整性、边界处理、类型注解 | ⭐强(类型注解+边界) / 好 / 可(有代码但被稀释) |
| **速度** | 从请求到响应的时间 | 快(<1s) / 中(1-3s) / 慢(>3s) |

### 2.4 特殊特性检测

测试时额外检查响应中的特殊字段：
- **`reasoning` / `reasoning_content`** — 模型有Chain of Thought，类似DeepSeek R1。注意这种模型会消耗大量tokens进行"思考"，需要更大的max_tokens
- **中文CoT** — 有些模型会输出中文思考链，有些用英文。如果面向中文用户，中文CoT更友好
- **空响应** — HTTP 200但content为""。模型不可用，跳过

### 2.5 结果记录

对每个模型输出JSON格式记录:
```python
entry = {
    "model": model_id,
    "accuracy": "✅正确 / 部分 / ❌",
    "chinese": "⭐极优 / ✅好 / 中 / 差",
    "code": "⭐强 / 好 / 可 / 差",
    "speed": "快 / 中 / 慢",
    "has_cot": True/False,
    "pricing": {"prompt": 0.00009, "completion": 0.00045},
    "notes": "特点说明"
}
```

---

## Phase 3: 综合评估报告

在完成基准测试后，可创建独立的评估报告页面（BookStack新页面），包含：

### 3.1 报告结构
```
NVIDIA NIM 模型评估报告 (BookStack)
├── 总体概览 — 模型总数/分类/来源
├── 商家模型评估 — 分梯队（旗舰/优化/轻量）
├── 第三方模型评估 — 当前使用/其他重点
├── 模型特性深度分析
│   ├── CoT思考链特性
│   ├── 中文能力对比
│   ├── 代码能力对比
│   └── 价格效益分析
├── 注意事项 — API不可用/CoT强制/定价差异
└── 总结 — 排名+最佳用途推荐
```

### 3.2 能力排序表（示例格式）

```html
<table><thead><tr>
  <th>排名</th><th>模型</th><th>综合评分</th><th>最佳用途</th>
</tr></thead><tbody>
<tr><td>🥇</td><td>DeepSeek V4 Flash</td><td>⭐⭐⭐⭐⭐</td><td>主模型/日常Agent</td></tr>
<tr><td>🥈</td><td>Gemma 4 31B IT</td><td>⭐⭐⭐⭐⭐</td><td>性价比之王</td></tr>
</tbody></table>
```

### 3.3 注意事项总结
- 标注API不可用的模型（避免后续误用）
- 标注强制CoT的模型及建议max_tokens
- 标注免费/付费渠道

---

## 已知坑点（通用）

1. **模型命名格式——OpenRouter格式 vs 直连API格式**：各提供商对同一模型使用不同的命名格式。
   - **OpenRouter / NVIDIA NIM**: 使用 `provider/model-name` 格式，如 `deepseek-ai/deepseek-v4-flash`
   - **DeepSeek/Azure/Google直连**: 使用短名，如 `deepseek-v4-flash`
   - **后果**: 将 `deepseek-ai/deepseek-v4-flash` 发到 `api.deepseek.com` 会得到 `400 invalid_request_error` — "The supported API model names are deepseek-v4-pro or deepseek-v4-flash"
   - **排查**: curl直连接口的chat/completions，检查返回的error message中的模型名提示
   - **注意**: Cron job可以独立设置model/provider（与全局config.yaml的`model:`段不同），全局配置正确不代表所有cron正确。排查时需逐个检查cron配置。
   - **修复**: 匹配provider对应的命名格式 —— direct provider用短名，OpenRouter/NVIDIA用`provider/model-name`格式

2. **OpenAI兼容性**: 大多数新提供商使用OpenAI-compatible API格式（/v1/chat/completions），但有细微差异。检查端点路径（/v1/chat/completions vs /v1/complete）。
3. **API Key为空**: `NVIDIA_API_KEY` 可在shell中为empty string但curl能列models（无需认证的列表API）。推理一定需要有效Key，用 `echo $KEY_LENGTH` 检查长度。
3. **推理模型CoT**: 如Nemotron-3-Super等推理模型会在response中返回 `reasoning`/`reasoning_content` 字段，消耗大量tokens。max_tokens需设足够大（200+）以保证看到最终回复。
4. **免费模型**: 通过OpenRouter访问NVIDIA模型有free档（如 `nvidia/nemotron-3-nano-omni-30b-a3b-reasoning:free`），但直接NVIDIA NIM API通常需要付费Key。
5. **多Provider并发**: config.yaml中已有多个provider（baidu/openrouter/nvidia等），新增时注意缩进和YAML格式正确性。
6. **⚠️ config.yaml的api_key不生效——必须设.env环境变量**: Hermes的 `PROVIDER_REGISTRY`（在 `hermes_cli/auth.py`）为每个注册的provider硬编码了 `api_key_env_vars`，运行时**只从环境变量读取API Key**，完全无视 config.yaml 的 `providers.{name}.api_key` 字段。这意味着即使config.yaml里配了Key，Hermes仍然会用占位符 `"no-key-r...ired"` 发送请求，导致401 Unauthorized。
   - **影响范围**: 所有在 `PROVIDER_REGISTRY` 中注册的provider（NVIDIA/NIM, xAI/Grok, Mistral, Groq, Fireworks等）
   - **排查方法**: 
     a. `hermes status` 检查对应provider的API Key状态是否显示 ✓ configured
     b. 查看失败请求的dump文件（路径在错误日志中），检查 `Authorization` header是否为 `"Bearer no-key-r...ired"`
     c. 查看 `PROVIDER_REGISTRY` 中该provider的 `api_key_env_vars` 元组，确认需要设置哪些env var
     ```bash
     grep -A10 '"nvidia": ProviderConfig' ~/.hermes/.venv/lib/python3.11/site-packages/hermes_cli/auth.py
     ```
   - **修复**: 将API Key写入 `.env`，然后重启gateway
     ```bash
     echo "PROVIDER_API_KEY=sk-..." >> ~/.hermes/.env
     echo "PROVIDER_BASE_URL=https://..." >> ~/.hermes/.env
     hermes gateway restart
     ```
   - **验证**: `hermes chat -q "hi" --provider {name} --model {model} --quiet`

## 能力

维护一个完整的模型资产库页面在BookStack中，包含：

```
模型资产库 (BookStack page)
├── 1. 基础信息 (文档编号/版本/标准引用)
├── 2. 模型清单表 — 7+模型完整信息
│   ├── 模型名称 | 提供商 | 版本 | 能力指标 | 成本 | 部署方式 | 适用场景
│   └── 每行一个模型，包含deepseek-v4-flash等详细版本号
├── 3. 成本记录 — 月度成本拆解（各提供商占比）
├── 4. 模型路由配置 — 当前生效的路由表
│   ├── 主模型（CLI端/飞书端）
│   ├── Vision / Web Extract / Delegation / 上下文压缩
│   └── 备用(fallback)提供商链
├── 5. 模型配置参考 — config.yaml 可复制代码块
├── 6. 快捷命令 — 查看/切换/Provider列表/Token消耗
├── 7. 飞书端模型切换记录 — 日期/原模型/新模型/原因/执行人
└── 8. 飞书同步 → RAG重摄入
```

## Workflow

### Phase 1: 读取当前模型资产库

```python
import urllib.request, json

TOKEN = 'TOKEN_ID:RAW_SECRET'
BASE = 'http://localhost:8080/api'

def api(method, path, data=None):
    url = f"{BASE}{path}"
    body = json.dumps(data).encode() if data else None
    req = urllib.request.Request(url, data=body,
        headers={'Authorization': f'Token {TOKEN}', 'Content-Type': 'application/json'}, method=method)
    resp = urllib.request.urlopen(req, timeout=30)
    return json.loads(resp.read().decode())

# 读取当前模型资产库页面
page = api('GET', '/pages/26')  # 模型资产库固定为page 26
html = page.get('html', '')
print(f"当前内容长度: {len(html)} 字符")

# 分析现有模型列表和成本数据
import re
models = re.findall(r'<td>([^<]+(?:Flash|Pro|V[0-9]|Air|Turbo|4B|8B|70B)[^<]*)</td>', html)
cost_data = re.findall(r'2026-0[0-9].*?</tr>', html)
print(f"已有模型: {len(models)}")
print(f"已有成本记录: {len(cost_data)}")
```

### Phase 2: 更新模型清单表

HTML表格结构（7列）:

```html
<table><thead><tr>
  <th>模型名称</th><th>提供商</th><th>版本</th>
  <th>能力指标</th><th>成本(¥/M tokens)</th>
  <th>部署方式</th><th>适用场景</th>
</tr></thead><tbody>
<!-- 每行一个模型 -->
<tr>
  <td>DeepSeek V4 Flash</td>
  <td>DeepSeek</td>
  <td>deepseek-v4-flash</td>
  <td>推理99/100，代码98/100，速度95/100</td>
  <td>0.5</td>
  <td>API远程 (api.deepseek.com)</td>
  <td>主模型/代码生成/Agent日常/飞书端响应</td>
</tr>
<!-- … 更多模型行 … -->
</tbody></table>
```

**版本号格式**: 统一使用 `provider/model-name` 格式，如 `deepseek-v4-flash`, `z-ai/glm-4-flash`, `ERNIE-4.5-8K`

**标准模型字段**:
| 字段 | 说明 | 示例 |
|------|------|------|
| 模型名称 | 显示名称 | DeepSeek V4 Flash |
| 提供商 | 提供商名称+入口名 | DeepSeek / 智谱AI (ZAI) / 百度 (Baidu) |
| 版本 | 精确模型ID | deepseek-v4-flash / z-ai/glm-4-flash |
| 能力指标 | 推理/代码/速度/中文等评分 | 推理99/100，代码98/100 |
| 成本 | 每M token价格(¥) | 0.5 / 0.10 / 0 |
| 部署方式 | API入口+路径 | API远程 (api.deepseek.com) |
| 适用场景 | 主要用途 | 主模型/Cron任务/低成本批处理 |

### Phase 3: 更新成本记录

月度成本表（6列）:
```html
<table><thead><tr>
  <th>月份</th><th>总消费</th>
  <th>DeepSeek</th><th>GLM</th><th>Baidu</th><th>OpenRouter</th>
</tr></thead><tbody>
<tr><td>2026-05</td><td>¥3.23</td><td>¥1.50 (45%)</td><td>¥1.20 (37%)</td><td>¥0.30 (9%)</td><td>¥0.23 (7%)</td></tr>
<!-- 至少保留最近3个月 + 年度目标 -->
<tr><td colspan="6"><b>2026年Q2目标</b>：月均¥5以内</td></tr>
</tbody></table>
```

### Phase 4: 创建模型路由配置表

显示当前所有模型路由项的精确配置，8行表:

```html
<h2>模型路由配置（当前生效）</h2>
<table><thead><tr>
  <th>路由项</th><th>当前使用的模型</th><th>提供商/入口</th><th>配置位置</th>
</tr></thead><tbody>
<tr><td>主模型（CLI端）</td><td>deepseek-v4-flash</td><td>DeepSeek (api.deepseek.com)</td><td>config.yaml model.provider/model.name</td></tr>
<tr><td>主模型（飞书端）</td><td>deepseek-v4-flash</td><td>DeepSeek (api.deepseek.com)</td><td>config.yaml model.provider/model.name</td></tr>
<tr><td>Vision视觉</td><td>deepseek-v4-flash</td><td>DeepSeek</td><td>config.yaml auxiliary_models.vision</td></tr>
<tr><td>网页提取(Web Extract)</td><td>deepseek-v4-flash</td><td>DeepSeek</td><td>config.yaml auxiliary_models.web_extract</td></tr>
<tr><td>子任务委派(Delegation)</td><td>deepseek-v4-flash</td><td>DeepSeek</td><td>config.yaml auxiliary_models.delegation</td></tr>
<tr><td>上下文压缩</td><td>deepseek-v4-flash</td><td>DeepSeek</td><td>config.yaml context_compression</td></tr>
<tr><td>备用(fallback)</td><td>zai → baidu</td><td>智谱AI → 百度</td><td>config.yaml fallback_providers</td></tr>
</tbody></table>
```

### Phase 5: 创建config.yaml参考

```html
<h2>模型配置参考（config.yaml）</h2>
<pre><code># ===== 主模型配置 =====
model:
  provider: deepseek
  model: deepseek-v4-flash

# ===== 提供商配置 =====
providers:
  baidu:
    api_key: ${BAIDU_API_KEY}
    base_url: https://qianfan.baidubce.com/v2
  openrouter:
    api_key: ${OPENROUTER_API_KEY}
    base_url: https://openrouter.ai/api/v1

fallback_providers: '["zai","baidu"]'

# ===== 辅助模型 =====
auxiliary_models:
  vision:
    model: deepseek-v4-flash
    provider: deepseek
  web_extract:
    model: deepseek-v4-flash
    provider: deepseek
  delegation:
    model: deepseek-v4-flash
    provider: deepseek
context_compression:
  model: deepseek-v4-flash
  provider: deepseek
</code></pre>
```

### Phase 6: 快捷命令表

```html
<h2>快捷命令</h2>
<table><thead><tr><th>操作</th><th>命令</th></tr></thead><tbody>
<tr><td>查看当前模型</td><td><code>grep -A2 '^model:' ~/.hermes/config.yaml</code></td></tr>
| 切换主模型 | `hermes config set model.model [model] && hermes config set model.name [model] && hermes config set model.provider [provider]` |
<tr><td>切换飞书端模型</td><td>同上（飞书使用默认模型配置）</td></tr>
<tr><td>查看Provider列表</td><td><code>cat ~/.hermes/config.yaml | grep -A5 'providers:'</code></td></tr>
<tr><td>实时Token消耗</td><td><code>cat ~/.hermes/data/cost/*.json 2>/dev/null | python3 -m json.tool</code></td></tr>
</tbody></table>
```

### Phase 7: 模型切换记录

```html
<h2>飞书端模型切换记录</h2>
<table><thead><tr>
  <th>切换日期</th><th>原模型</th><th>新模型</th><th>原因</th><th>执行人</th>
</tr></thead><tbody>
<tr><td>2026-05-06</td><td>z-ai/glm-4-flash</td><td>deepseek-v4-flash</td><td>统一CLI端与飞书端模型，提升飞书端推理能力</td><td>Yestin</td></tr>
<!-- 新的切换记录追加在顶部 -->
</tbody></table>
```

### Phase 8: 更新到BookStack + 飞书同步 + RAG重摄入

```python
# === 步骤1: 更新BookStack页面 ===
result = api('PUT', '/pages/26', {"name": "模型资产库", "html": new_html})
print(f"✅ 模型资产库已更新, {len(new_html)} 字符")

# === 步骤2: 验证关键内容存在 ===
for item in ["deepseek-v4-flash", "模型路由配置", "config.yaml", "fallback_providers"]:
    assert item in new_html, f"缺失关键内容: {item}"
    print(f"  ✅ {item}")

# === 步骤3: 飞书同步 (BookStack→Feishu) ===
import subprocess
r = subprocess.run(
    ['node', 'sync-bookstack.js'],
    cwd='/home/yestin/projects/hermes-wiki',
    capture_output=True, text=True, timeout=120
)
print(r.stdout[-500:] if r.stdout else "No output")

# === 步骤4: RAG重摄入 ===
r = subprocess.run(
    ['node', 'rag-ingest.js'],
    cwd='/home/yestin/projects/hermes-wiki',
    capture_output=True, text=True, timeout=30
)
print(r.stdout[-200:] if r.stdout else "No output")
```

## 已知坑点

1. **页面ID固定**: 模型资产库固定为page 26。如果重建BookStack数据库，页面ID会变，需要先查询确认。
2. **飞书同步超时**: sync-bookstack.js遍历43页+，可能超时(60s+)。用 `timeout 120` 执行。
3. **HTML格式**: BookStack API使用HTML内容，必须是合法HTML片段（从`<h2>`开始，无DOCTYPE/html/head/body包装）。
4. **成本数据来源**: 从 `~/.hermes/data/cost/*.json` 或 `hermes cost` 命令获取实际成本数据。
5. **配置实际读取**: config.yaml中的模型配置通过 `grep` 或 `hermes config get` 获取，确保与实际运行配置一致。
6. **模型版本号**: 每次切换模型时，版本列使用 `hermes config get model.name` 的实际输出值，确保准确。
7. **CoT强制输出**: Nemotron-3全系列模型强制输出 `reasoning`/`reasoning_content` 字段（Chain of Thought），max_tokens需设200+以保证看到最终回复。短回复场景（如Cron任务）不适合。
8. **部分模型名存实亡**: NVIDIA NIM列表中的 Nemotron-4-340B、Llama-3.1-Nemotron-70B/51B、Mistral-Large 通过 chat/completions 返回空响应。可能需不同endpoint或只支持自托管。测试前先快速验证能否正常回复。
9. **嵌入模型不同端点**: 嵌入模型（如 nv-embedqa-e5-v5）使用 `/v1/embeddings` 而非 `/v1/chat/completions`。先确认API文档中的正确端点。
10. **NVIDIA免费Key限制**: NVIDIA提供免费API Key（build.nvidia.com），可列模型列表但推理需要有效Key。通过OpenRouter访问有free档（`:free`后缀），但直接NVIDIA NIM推理有速率限制。
11. **多Provider切换压测**: 切换主模型provider后，所有辅助模型（vision/web_extract/delegation/context_compression）必须同步切换。遗漏任何一个都会导致部分功能仍走旧provider。

## Verification

```bash
# 1. BookStack页面可访问
curl -s -o /dev/null -w "HTTP %{http_code}\n" http://localhost:8080/api/pages/26

# 2. 检查页面内容完整性
curl -s -H "Authorization: Token TOKEN_ID:RAW_SECRET" http://localhost:8080/api/pages/26 \
  | python3 -c "import sys,json;d=json.load(sys.stdin);h=d.get('html','');print(f'长度: {len(h)}字符, H2: {h.count(\"<h2\")}, 表格: {h.count(\"<table\")}')"

# 3. 飞书同步状态
cat ~/projects/hermes-wiki/.feishu-mapping.json | python3 -c "
import json,sys
m=json.load(sys.stdin)
for k in sorted(k for k in m if k.startswith('bookstack-')):
    print(f'  {k} -> {m[k]}')
"

# 4. 验证配置文件一致性
grep -A2 '^model:' ~/.hermes/config.yaml
grep 'fallback_providers' ~/.hermes/config.yaml
grep -A1 'auxiliary_models:' ~/.hermes/config.yaml

## Feedback Engine Patches
*自动生成于 2026-07-16 02:02:04*

## Tool Recommendations (from trajectory feedback)

### patch
Trajectory analysis shows **patch** strongly correlates with high session scores.
- Use `patch` for targeted find-and-replace edits instead of sed/awk.
- Supports fuzzy matching with 9 strategies for robust edits.
- Auto-runs syntax checks after modification.
- Preferred for surgical code changes over full file rewrites.

### Guardrails
- Ensure `old_string` is unique in the file unless `replace_all=True`.
- Include enough surrounding context to guarantee uniqueness.
- Use `mode='patch'` for V4A multi-file patches.

### Efficiency Tips
- Combine multiple edits into a single V4A patch when possible.
- Use `replace_all=True` for bulk replacements of the same pattern.
- Preview changes with `--dry-run` mode before applying.

---
## Feedback Engine Patches
*自动生成于 2026-07-17 02:02:37*

## Tool Recommendations (from trajectory feedback)

### patch
Trajectory analysis shows **patch** strongly correlates with high session scores.
- Use `patch` for targeted find-and-replace edits instead of sed/awk.
- Supports fuzzy matching with 9 strategies for robust edits.
- Auto-runs syntax checks after modification.
- Preferred for surgical code changes over full file rewrites.

### Guardrails
- Ensure `old_string` is unique in the file unless `replace_all=True`.
- Include enough surrounding context to guarantee uniqueness.
- Use `mode='patch'` for V4A multi-file patches.

### Efficiency Tips
- Combine multiple edits into a single V4A patch when possible.
- Use `replace_all=True` for bulk replacements of the same pattern.
- Preview changes with `--dry-run` mode before applying.

---
## Feedback Engine Patches
*自动生成于 2026-07-22 12:19:48*

## Tool Recommendations (from trajectory feedback)

### patch
Trajectory analysis shows **patch** strongly correlates with high session scores.
- Use `patch` for targeted find-and-replace edits instead of sed/awk.
- Supports fuzzy matching with 9 strategies for robust edits.
- Auto-runs syntax checks after modification.
- Preferred for surgical code changes over full file rewrites.

### Guardrails
- Ensure `old_string` is unique in the file unless `replace_all=True`.
- Include enough surrounding context to guarantee uniqueness.
- Use `mode='patch'` for V4A multi-file patches.

### Efficiency Tips
- Combine multiple edits into a single V4A patch when possible.
- Use `replace_all=True` for bulk replacements of the same pattern.
- Preview changes with `--dry-run` mode before applying.
