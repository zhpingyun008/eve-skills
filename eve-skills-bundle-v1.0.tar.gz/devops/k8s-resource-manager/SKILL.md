---
name: k8s-resource-manager
description: Kubernetes资源管理 — Pod/Deployment/Service/ConfigMap/Secret管理、kubectl命令wrapper、YAML模板生成、集群状态诊断、资源优化建议。触发词："k8s"/"kubernetes"/"kubectl"/"k8s管理"/"pod管理"/"集群诊断"/"namespace"。
depends_on:
  - container-security-scanner
related_skills:
  - chaos-engineer
  - incident-commander
  - docker-compose-manager
category: devops
triggers:
  - "k8s"
  - "kubernetes"
  - "kubectl"
  - "k8s管理"
  - "pod管理"
  - "集群诊断"
  - "namespace管理"
  - "deployment"
  - "cluster health"
  - "K8s部署"
  - "Helm"
  - "容器编排"
---

# K8s Resource Manager — Kubernetes资源管理


## Overview

Brief description of this skill's purpose and capabilities.
Kubernetes集群资源全生命周期管理：部署、监控、诊断、优化。

## Trigger Conditions

Load this skill when:
- User asks to manage K8s resources
- Deployment/Service configuration
- Cluster health check
- Pod troubleshooting
- Resource optimization
- Namespace management

## Workflow

### 1. Cluster Context Management

```bash
# List contexts
kubectl config get-contexts

# Switch context
kubectl config use-context production

# Current context info
kubectl cluster-info
kubectl get nodes -o wide
```

### 2. Resource Inspection

```bash
# All resources in namespace
kubectl get all -n my-namespace

# Detailed pod info
kubectl describe pod my-pod -n my-namespace

# Pod logs
kubectl logs -f my-pod -n my-namespace --tail=100

# Events sorted by time
kubectl get events -n my-namespace --sort-by='.lastTimestamp'

# Resource usage
kubectl top pod -n my-namespace
kubectl top node
```

### 3. Deploy Application

```yaml
# deploy.yaml — kubectl apply -f deploy.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: my-app
  namespace: production
spec:
  replicas: 3
  selector:
    matchLabels:
      app: my-app
  template:
    metadata:
      labels:
        app: my-app
    spec:
      containers:
      - name: app
        image: my-app:latest
        ports:
        - containerPort: 8080
        resources:
          requests:
            cpu: "100m"
            memory: "256Mi"
          limits:
            cpu: "500m"
            memory: "512Mi"
        livenessProbe:
          httpGet:
            path: /health
            port: 8080
          initialDelaySeconds: 10
        env:
        - name: DB_HOST
          valueFrom:
            secretKeyRef:
              name: app-secrets
              key: DB_HOST
---
apiVersion: v1
kind: Service
metadata:
  name: my-app-svc
  namespace: production
spec:
  selector:
    app: my-app
  ports:
  - port: 80
    targetPort: 8080
  type: ClusterIP
```

### 4. Troubleshooting

```bash
# Pod crash loop
kubectl describe pod crash-pod | grep -A5 "Events:"
kubectl logs crash-pod --previous

# Image pull issues
kubectl describe pod image-pull-pod | grep -E "Failed|Error|BackOff"

# Pending pods
kubectl describe pod pending-pod | grep -E "Events:|Warning"

# Resource constraints
kubectl describe pod oom-pod | grep -E "Limits|Requests|OOMKilled|Exit Code: 137"

# Network issues
kubectl run test-pod --image=busybox --rm -it --restart=Never -- wget -O- http://service-name:8080/health
```

### 5. Resource Optimization

```bash
# Identify over-provisioned pods
kubectl top pod -n production --sort-by=cpu | tail -20
kubectl top pod -n production --sort-by=memory | tail -20

# Check HPA status
kubectl get hpa -n production

# Node resource pressure
kubectl describe node | grep -A10 "Allocated resources"

# Optimize recommendations:
# 1. Set proper resource requests/limits
# 2. Use HPA for autoscaling
# 3. Use PDB for high availability
# 4. Right-size PVC storage
# 5. Use nodeSelector/affinity for workload placement
```

### 6. Rollback & Canary

```bash
# Rollback deployment
kubectl rollout undo deployment/my-app -n production

# Rollback to specific revision
kubectl rollout undo deployment/my-app -n production --to-revision=3

# Check rollout status
kubectl rollout status deployment/my-app -n production

# Canary deployment
kubectl set image deployment/my-app-canary app=my-app:v2 -n production
```

## Pitfalls

1. **Context confusion**: Running `kubectl delete` on wrong context = disaster. Always check `kubectl config current-context` before destructive operations.
2. **Namespace scope**: Many commands default to `default` namespace. Use `-n` or `--all-namespaces` explicitly.
3. **Resource limits unclear**: Missing requests/limits causes scheduling issues. Pods with no limits may be OOMKilled under pressure.
4. **kubectl vs API version**: `kubectl apply` auto-converts, but `kubectl get -oyaml` may show different API versions than your manifest. Use `--export` carefully (deprecated in v1.24+).
5. **Secret management**: Secrets are base64 encoded, not encrypted. Use external secrets operator (SOPS, Vault, SealedSecrets) for production.
6. **Storage retention**: PVCs persist after Pod deletion. Manual cleanup needed or use `kubectl delete pvc` with lifecycle labels.

## 合并来源 (Batch A Merge)

### 来自 k8s-deployer (已归档到 _archive/)
- **Progressive delivery**: RollingUpdate策略(maxSurge=1, maxUnavailable=0)
- **Helm图表管理**: 生成Helm charts + 管理rollouts
- **健康检查配置**: livenessProbe(httpGet /health:8080) + readinessProbe(httpGet /ready:8080)
- **自动扩缩容**: 检查HPA、PDB、metrics-server、Prometheus告警
- **Pitfalls**: ImagePullPolicy(dev=Always, prod=IfNotPresent)；资源限制过紧→OOMKilled；readiness vs liveness不能混用
- **验证**: `kubectl describe deployment` + `kubectl top pods`

## Verification

```bash
# Verify cluster access
kubectl cluster-info 2>&1 | grep -q "running at" && echo "✓ Cluster accessible" || echo "✗ No cluster access (is kubeconfig configured?)"
```

## Integration

- **iac-security-scanner**: Scan K8s manifests before apply
- **container-security-scanner**: Scan container images in pods
- **terraform-manager**: K8s resources managed via Terraform
- **health-dashboard**: Cluster health monitoring
