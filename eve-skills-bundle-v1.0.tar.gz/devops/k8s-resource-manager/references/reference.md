# k8s-resource-manager — Reference

## Overview
Kubernetes资源管理 — Pod/Deployment/Service/ConfigMap/Secret管理、kubectl命令wrapper、YAML模板生成、集群状态诊断、资源优化建议。触发词："k8s"/"kubernetes"/"kubectl"/"k8s管理"/"pod管理"/"集群诊断"/"namespace"。

## Integration Points
- Hermes Agent skill ecosystem
- evolution_engine.py scoring system
- self-audit verification

## Key Resources
- SKILL.md: main skill definition
- scripts/: executable code (if present)
