---
name: hermes-module-assessment
description: Evaluate optional Hermes Agent modules (Curator, Proxy, Kanban, etc.) — understand purpose, relevance to current setup, installation status, blast radius, and safe dry-run testing before enabling in production.
category: devops
trigger: |
  When the user encounters an unfamiliar Hermes Agent feature/module and needs to:
  - Understand what it does and whether it's relevant to this setup
  - Check if the module is installed and/or enabled
  - Evaluate the blast radius before enabling in production
  - Run a safe dry-run assessment
  - Pin/critical resources before the module could affect them
  - Decide whether to enable, configure, or skip the module

  Trigger phrases:
  - "What does the curator do?"
  - "Should I enable proxy?"
  - "评估一下这个模块"
  - "Is this feature relevant to us?"
  - "hermes curator/proxy/kanban evaluation"

  Also triggered when upgrading Hermes versions that introduce new modules.
steps: |
  1. UNDERSTAND the module
     ```
     hermes <module> --help
     hermes <module> status
     hermes <module> providers    # if applicable
     ```

  2. CHECK installation
     - If command fails with `ModuleNotFoundError` or `No module named`, the module is not installed
     - Check if it requires additional dependencies: `pip list | grep <module>`
     - If uninstalled, assess whether installation is justified

  3. IDENTIFY what the module manages
     - Check if it manages agent-created resources vs manually-created ones
     - Example: Curator only manages skills created via `create_skill` tool, NOT manually written SKILL.md files
     - Key test: `hermes <module> status --verbose` to see what it can affect

  4. PROTECT critical resources before testing
     - For curator: pin critical skills (one at a time)
       ```
       hermes curator pin <skill-name>
       ```
     - For proxy: port binding check (default 127.0.0.1:8645)
     - Create config backups before enabling new modules

  5. DRY-RUN assessment
     ```
     hermes curator run --dry-run
     ```
     This shows what changes would be made without actually applying them.

  6. ANALYZE blast radius
     | Question | How to check |
     |----------|-------------|
     | Does it modify existing data? | Check dry-run output |
     | Does it require API credentials? | Check config prerequisites |
     | Does it open network ports? | Check port binding config |
     | Does it affect all profiles or just one? | Check scope |
     | Can it delete/modify our custom resources? | Check what types it manages |

  7. DECIDE
     - Enable: If module adds value and has zero/minimal blast radius
     - Skip: If module is uninstalled, unnecessary, or adds attack surface without benefits
     - Enable with constraints: If module is useful but needs pinning/limiting

  8. DOCUMENT decision
     - Save to memory: module name, decision rationale, key findings
     - If relevant, update Hermes config to enable/disable the module
     - Update phase/roadmap status

pitfalls: |
  - Curator only manages "agent-created" skills (those made via `create_skill` tool at runtime). Manually written SKILL.md files in the skills directory are classified as "local" and are NOT affected by Curator.
  - `hermes proxy providers` may fail with `ModuleNotFoundError: No module named 'hermes_cli.proxy'` — means the proxy subpackage is not installed.
  - Always run `--dry-run` before `hermes curator run` — default mode APPLIES changes.
  - Profile-scoped HERMES_HOME affects module behavior — some modules only work from global context.
  - New Hermes versions may ship with modules that have missing built-in dependencies.

verification: |
  1. `hermes <module> status` shows correct enabled/disabled state
  2. `hermes <module> run --dry-run` reports 0 candidate changes (if no action needed)
  3. Critical resources remain pinned (for curator: `hermes curator status` shows pinned items)
  4. No unintended port listeners or credentials exposed
  5. Decision documented in memory

examples:
  - Curator (v0.14.0): Dry-run confirmed 0 candidates. 6 critical skills pinned. ENABLED but inactive.
  - Proxy (v0.14.0): Module not installed, Nous Portal OAuth unnecessary. SKIPPED.
  - Kanban (v0.14.0): Built-in dispatcher works. Missing kanban-worker skill fixed. ENABLED.
---
# Hermes Module Assessment

Systematic evaluation of optional Hermes Agent modules before enabling in production.

## Assessment Workflow

```
┌─────────────┐
│  New Module  │
└──────┬──────┘
       ▼
┌─────────────┐     ┌─────────────────┐
│ 1. Understand │────→│ hermes <mod> --help │
│               │     │ hermes <mod> status  │
└──────┬──────┘     └─────────────────┘
       ▼
┌─────────────┐     ┌─────────────────┐
│ 2. Check     │────→│ Command works?      │
│ Installation │     │ Dependencies met?   │
└──────┬──────┘     └─────────────────┘
       ▼
┌─────────────┐     ┌─────────────────┐
│ 3. Identify   │────→│ What does it manage? │
│ Scope        │     │ Blast radius?        │
└──────┬──────┘     └─────────────────┘
       ▼
┌─────────────┐     ┌─────────────────┐
│ 4. Protect    │────→│ Pin resources      │
│ Critical     │     │ Backup configs      │
└──────┬──────┘     └─────────────────┘
       ▼
┌─────────────┐     ┌─────────────────┐
│ 5. Dry-Run    │────→│ Preview changes    │
│ Assessment   │     │ Count candidates   │
└──────┬──────┘     └─────────────────┘
       ▼
┌─────────────┐     ┌─────────────────┐
│ 6. Analyze    │────→│ Value vs Risk      │
│ Blast Radius │     │ Attack surface     │
└──────┬──────┘     └─────────────────┘
       ▼
┌─────────────┐     ┌─────────────────┐
│ 7. Decide     │────→│ Enable / Skip / Limited │
└──────┬──────┘     └─────────────────┘
       ▼
┌─────────────┐
│ 8. Document  │
│ Decision     │
└─────────────┘
```

## Module Assessment Template

| Question | Answer |
|----------|--------|
| Module name | Curator / Proxy / Kanban / ... |
| Version introduced | v0.14.0 / ... |
| Installed? | Yes / No (ModuleNotFoundError) |
| What it manages | agent-created skills / OAuth proxy / task boards / ... |
| Affects our setup? | Yes / No (reason) |
| Blast radius | Critical / Medium / Low / None |
| Dry-run result | 0 candidates / X candidates |
| Decision | Enable / Skip / Limited |
## Real Examples

### Curator (v0.14.0)
- Command: `hermes curator status` → ENABLED, 0 agent-created skills
- Dry-run: 0 candidate skills, no changes
- Key insight: Only manages agent-created skills, not manually written SKILL.md
- Action: Pinned 6 critical CMMI5 skills. Keep ENABLED.

### Proxy (v0.14.0)
- Command: `hermes proxy --help` works, `hermes proxy providers` → ModuleNotFoundError
- Key insight: subpackage not installed, only useful for Nous Portal OAuth
- Action: SKIP (no value, reduces attack surface)

### Kanban (v0.14.0)
- Command: `hermes kanban boards create` → works
- Key insight: Built-in dispatcher runs in Gateway. Missing `kanban-worker` skill needs manual copy to profile-scoped skills dirs.
- Action: ENABLED with profile-scoped fix applied.

## Feedback Engine Patches
*自动生成于 2026-07-16 02:02:04*

## Tool Recommendations (from trajectory feedback)

### patch
Trajectory analysis shows **patch** strongly correlates with high session scores.
- Use `patch` for targeted find-and-replace edits instead of sed/awk.
- Supports fuzzy matching with 9 strategies for robust edits.
- Auto-runs syntax checks after modification.
- Preferred for surgical code changes over full file rewrites.

### Guardrails
- Ensure `old_string` is unique in the file unless `replace_all=True`.
- Include enough surrounding context to guarantee uniqueness.
- Use `mode='patch'` for V4A multi-file patches.

### Efficiency Tips
- Combine multiple edits into a single V4A patch when possible.
- Use `replace_all=True` for bulk replacements of the same pattern.
- Preview changes with `--dry-run` mode before applying.

---
## Feedback Engine Patches
*自动生成于 2026-07-17 02:02:37*

## Tool Recommendations (from trajectory feedback)

### patch
Trajectory analysis shows **patch** strongly correlates with high session scores.
- Use `patch` for targeted find-and-replace edits instead of sed/awk.
- Supports fuzzy matching with 9 strategies for robust edits.
- Auto-runs syntax checks after modification.
- Preferred for surgical code changes over full file rewrites.

### Guardrails
- Ensure `old_string` is unique in the file unless `replace_all=True`.
- Include enough surrounding context to guarantee uniqueness.
- Use `mode='patch'` for V4A multi-file patches.

### Efficiency Tips
- Combine multiple edits into a single V4A patch when possible.
- Use `replace_all=True` for bulk replacements of the same pattern.
- Preview changes with `--dry-run` mode before applying.

---
## Feedback Engine Patches
*自动生成于 2026-07-22 12:19:48*

## Tool Recommendations (from trajectory feedback)

### patch
Trajectory analysis shows **patch** strongly correlates with high session scores.
- Use `patch` for targeted find-and-replace edits instead of sed/awk.
- Supports fuzzy matching with 9 strategies for robust edits.
- Auto-runs syntax checks after modification.
- Preferred for surgical code changes over full file rewrites.

### Guardrails
- Ensure `old_string` is unique in the file unless `replace_all=True`.
- Include enough surrounding context to guarantee uniqueness.
- Use `mode='patch'` for V4A multi-file patches.

### Efficiency Tips
- Combine multiple edits into a single V4A patch when possible.
- Use `replace_all=True` for bulk replacements of the same pattern.
- Preview changes with `--dry-run` mode before applying.
