# Sprint Orchestrator — Reference

## Overview

Sprint Orchestrator is the core sprint management skill for the Hermes Agent DevOps pipeline.
It manages Backlog items, executes sprints via the CMMI5 Pipeline, and tracks sprint history.

## Commands

| Flag | Description |
|------|-------------|
| `--dry-run` | Show the next sprint item without executing |
| `--status` | Show current sprint status (idle or in-progress) |
| `--add <json>` | Add a new Backlog item (JSON format) |
| `--list` | List all Backlog items |
| `--backlog-empty` | Check if Backlog is empty (exit 0 = empty, 1 = non-empty) |
| `--help` | Show usage help |

## Priority Order

P0 > P1 > P2 > P3

## Backlog Location

- Backlog file: `~/.hermes/backlog/backlog.json`
- History file: `~/.hermes/backlog/sprint_history.jsonl`
- Schema: `~/.hermes/backlog/schema.json`

## Sprint Lock

A sprint lock file is created at `/tmp/sprint_in_progress` while a sprint is active.
This prevents concurrent sprint execution.

## Pipeline

Sprints execute steps via scripts in `~/projects/hermes-infra/agent-bridge/`.
