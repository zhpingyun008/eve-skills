# 自动每日运行 + Flask内部API调用模式

## 背景

当Flask应用的所有`/api/*`路由都受JWT保护时，内部自动化管道(Cron触发的每日运行)调用自身API时会被JWT中间件拦截返回401。

## 解决方案: X-Internal-Key 免认证机制

### 后端实现

在 `before_request` 钩子中添加内部密钥检查：

```python
# 配置内部密钥
INTERNAL_API_KEY = os.environ.get("INTERNAL_API_KEY", "fallback-key-here")

@app.before_request
def require_jwt_for_api():
    if request.method == 'OPTIONS':
        return
    # 内部调用免认证（X-Internal-Key头）
    if request.path.startswith('/api/') and request.headers.get('X-Internal-Key') == INTERNAL_API_KEY:
        return
    # 原有JWT检查逻辑保持不变...
```

### 内部调用函数

在触发每日运行的视图函数中，使用 `app.test_client()` 并传入内部密钥头：

```python
def _call_internal_api(url, body=None, method="POST"):
    """Call an internal route directly without HTTP auth."""
    with app.test_request_context():
        with app.test_client() as client:
            headers = {"X-Internal-Key": INTERNAL_API_KEY, "Content-Type": "application/json"}
            if method == "POST":
                resp = client.post(url, json=body or {}, headers=headers)
            else:
                resp = client.get(url, headers=headers)
            return {"status_code": resp.status_code, "data": resp.get_json()}
```

### Cron配置

通过Hermes Cron系统调度：

```bash
# Hermes Cron job - 每日09:00
cronjob action=create \
  name="Auto Daily Run (09:00)" \
  schedule="0 9 * * *" \
  prompt="执行每日自动运营流程: curl -s -X POST http://localhost:8850/api/auto/daily-run"
  # 确保auto/*端点在PUBLIC_API_ROUTES中（免JWT访问）
```

### 自动化管道结构（bidding-tool案例）

```python
def api_auto_daily_run():
    steps = []
    
    # Step 1: 更新推荐评分
    steps.append(_call_internal_api("/api/recommend/deals"))
    
    # Step 2: 自动创建跟进
    steps.append(_call_internal_api("/api/followups/auto-create"))
    
    # Step 3: 生成日报摘要
    steps.append(_call_internal_api("/api/reports/daily-digest"))
    
    # Step 4: 推送日报到讨论板
    steps.append(_call_internal_api("/api/reports/digest/push"))
    
    # Step 5: 检查逾期线索并告警
    # 直接读取数据源检查...
    
    # 记录运行历史到DB
    # 返回{status, steps:[], duration, timestamp}
```

### 注意事项

- `auto/*` 端点必须在 `PUBLIC_API_ROUTES` 中（Cron通过HTTP调用时免JWT）
- 内部调用使用 `app.test_client()` 而非真实HTTP请求
- 运行历史持久化到DB以便排查问题
- 日终汇总已推送到讨论板#standup（post可见）
- overdue告警数量第一次往往偏多（历史累积），后续逐步收敛
