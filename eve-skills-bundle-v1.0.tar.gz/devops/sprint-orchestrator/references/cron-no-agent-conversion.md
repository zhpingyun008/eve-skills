# Cron no_agent 内联脚本陷阱与批量修复

## 问题

`no_agent=true` 的Cron任务，`script` 字段如果填入内联shebang脚本内容（以 `#!/usr/bin/env bash` 或 `#!/usr/bin/env python3` 开头），Cron调度器会将其当作**文件路径**解析，导致：

```
Script not found: /home/yestin/.hermes/scripts/#!/usr/bin/env bash
output=$(...)
```

## 根因

Cron调度器的 `no_agent` 模式中，`script` 字段设计为接收**文件名**（相对 `~/.hermes/scripts/` 解析），而非内联脚本内容。当内容以 `#!` 开头时，调度器不会检测为内联脚本，而是尝试将其作为路径打开。

## 修复方法

### 单步手动修复

```bash
# 1. 将内联脚本内容写入独立文件
cat > ~/.hermes/scripts/run-health-check.sh << 'EOF'
#!/usr/bin/env bash
output=$(script 2>&1)
if echo "$output" | grep -qi "alert"; then echo "$output"; fi
EOF
chmod +x ~/.hermes/scripts/run-health-check.sh

# 2. 更新Cron配置
hermes cron update job_id=<JOB_ID> script=run-health-check.sh
```

### 批量修复 (20+个Cron)

当大量 `no_agent=true` 作业因内联脚本失败时，直接用Python操作 `jobs.json`：

```python
import json, os

SCRIPTS_DIR = os.path.expanduser('~/.hermes/scripts')

with open(os.path.expanduser('~/.hermes/cron/jobs.json')) as f:
    d = json.load(f)

jobs = d.get('jobs', d)
fixed = 0

for j in jobs:
    s = j.get('script', '')
    jid = j.get('id') or j.get('job_id')
    if not (j.get('no_agent') and s.startswith('#!')):
        continue
    
    ext = '.py' if 'python' in s.split('\n')[0].lower() else '.sh'
    fname = f'cron-{jid[:14]}{ext}'
    fpath = os.path.join(SCRIPTS_DIR, fname)
    
    with open(fpath, 'w') as f:
        f.write(s)
    os.chmod(fpath, 0o755)
    j['script'] = fname
    fixed += 1

with open(os.path.expanduser('~/.hermes/cron/jobs.json'), 'w') as f:
    json.dump(d, f, indent=2)

print(f'Fixed {fixed} cron jobs')
```

## 诊断

找出所有故障的 `no_agent` 作业：

```bash
python3 -c "
import json
with open('/home/yestin/.hermes/cron/jobs.json') as f:
    d = json.load(f)
jobs = d.get('jobs', d)
for j in jobs:
    s = j.get('script', '')
    if j.get('no_agent') and s.startswith('#!'):
        print(f'FAIL: [{j.get(\"id\",\"?\")[:14]}] {j.get(\"name\",\"?\")}')
"
```

## 经验

- **绝不**在 `script` 字段中使用内联 `#!/usr/bin/env ...` 内容
- `script` 字段只传**纯文件名**（不含路径）
- 所有包装脚本放在 `~/.hermes/scripts/` 下
- 2026-05-29 实战: 飞行中修复22个Cron，合计30秒
