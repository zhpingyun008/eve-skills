---
category: devops
name: trae-integration
description: "Trae IDE ↔ Hermes Agent 双向桥接 — MCP互通 + CLI互调 + 工作区共享。Trae v3.3.65已安装于Windows，Hermes在WSL。"
triggers:
  - "trae"
  - "打通trae"
  - "trae集成"
  - "trae ide"
author: Yestin
license: MIT
platforms: [linux, wsl]
---

# Trae IDE 使用方案

## 一句话

**终端开发 + 要改复杂逻辑时 `trae` 甩给Trae IDE**

## 日常用法

```bash
trae                # 打开Trae IDE + Hermes工作区（最常用）
trae .              # 打开当前目录
trae ~/项目          # 打开指定项目
trae --diff a b     # 对比两个文件
trae --goto f:42    # 跳转到文件第42行
```

## 双引擎分工

| 工具 | 干这个 | 别干这个 |
|------|--------|----------|
| **Hermes**（终端） | 自动化、cron、批量脚本、搞钱管道 | 全局重构、多文件联改 |
| **Trae**（IDE） | 复杂代码开发、AI对话编码、可视化diff | 需要24/7跑的任务 |

**文件互通、工具互通，哪个顺手用哪个。**

## ⚠️ 集成可见性（关键教训）

> **说"打通了"之前，必须先让用户看到效果。**
> 只配置好桥梁、验证脚本通过 ≠ 打通。用户需要看到 Trae 窗口弹出、能看到 WSL 文件、能调用工具。
> 验证步骤：(1) `trae` 命令无错误启动，(2) Windows 桌面弹出 Trae 窗口，(3) 进程确认运行中。

## 验证打通

```bash
bash ~/.hermes/skills/devops/trae-integration/scripts/trae-mcp-test.sh
# 输出: 6/6 通过
```

## 坑：trae CLI 阻塞终端

`trae` 命令直接执行会阻塞终端直到 Trae 窗口关闭。包装脚本使用后台启动：

```bash
"$TRAE_REAL" "$WORKSPACE" &>/dev/null &
disown
```

这样终端立即返回，Trae 在 Windows 桌面异步弹出。`exec` 会替换当前进程，只适合 `--diff`、`--goto` 等短暂操作。

## 坑：WSL→Windows 的 `wsl.exe` 调用

Trae 的 MCP 配置通过 `wsl.exe /home/yestin/hermes-mcp.sh` 调用 Hermes。测试 MCP 时必须确认：
1. `wsl.exe` 可在 PowerShell 中直接执行（Windows 系统自带）
2. WSL 路径 `/home/...` 在 `wsl.exe` 中可直接解析
3. 不要在 Desktop `.trae/mcp.json` 中使用 Windows 路径格式（`\\wsl.localhost\...`），MCP `command` 字段用 `wsl.exe` + Linux 路径

## 坑：Python `__pycache__` 导致 Flask 改动不生效

Flask 服务器修改 Python 代码后重启，旧 `.pyc` 缓存可能被沿用。每次 `pkill` 后必须清缓存：

```bash
fuser -k 5900/tcp
find /path/to/project -name "__pycache__" -exec rm -rf {} +
# 然后再启动
```

## 架构

```
Windows Trae IDE ←→ MCP stdio → WSL Hermes Agent
     ↑                            ↑
  trae 命令                   36个工具暴露
  桌面工作区                 hermes-full v1.23.3
```
