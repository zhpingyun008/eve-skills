#!/usr/bin/env bash
# Trae ↔ Hermes 桥接验证脚本
# 执行: bash /home/yestin/.hermes/skills/devops/trae-integration/scripts/trae-mcp-test.sh
set -e
PASS=0
FAIL=0

pass() { PASS=$((PASS+1)); echo "  ✅ $1"; }
fail() { FAIL=$((FAIL+1)); echo "  ❌ $1: $2"; }

echo "=========================================="
echo "  Trae ↔ Hermes 打通验证 v1.0"
echo "=========================================="

# Test 1: Trae CLI
echo ""
echo "--- [1/5] Trae CLI ---"
if command -v trae &>/dev/null; then
    VER=$(trae --version 2>&1 | head -1)
    pass "Trae CLI: $VER"
else
    fail "Trae CLI: command not found"
fi

# Test 2: Hermes MCP Server
echo ""
echo "--- [2/5] Hermes MCP Server ---"
if [ -f /home/yestin/hermes-mcp.sh ]; then
    pass "MCP启动脚本存在"
else
    fail "MCP启动脚本缺失"
fi

# Test 3: MCP Server可启动
echo ""
echo "--- [3/5] MCP Server启动测试 ---"
if bash /home/yestin/hermes-mcp.sh --version 2>&1 | grep -q "hermes-full" 2>/dev/null; then
    pass "MCP Server: tools loaded"
else
    # Try alternative: just check Python module imports
    if /home/yestin/.hermes/.venv/bin/python3 -c "from model_tools import get_tool_definitions; t=get_tool_definitions(quiet_mode=True); print(f'OK: {len(t)} tools')" 2>/dev/null; then
        pass "MCP Server: tools loaded"
    else
        fail "MCP Server: tools load failed"
    fi
fi

# Test 4: Trae MCP配置 (Windows Desktop)
echo ""
echo "--- [4/5] Trae MCP配置 ---"
MCP_FILE="/mnt/c/Users/Administrator/Desktop/.trae/mcp.json"
if [ -f "$MCP_FILE" ]; then
    if grep -q "hermes-full" "$MCP_FILE"; then
        pass "Desktop MCP配置正确 (hermes-full)"
    else
        fail "Desktop MCP缺少hermes-full"
    fi
else
    fail "Desktop MCP文件不存在"
fi

# Test 5: WSL文件互通
echo ""
echo "--- [5/5] WSL文件互通 ---"
if ls /mnt/c/Users/Administrator/Desktop/Hermes-Agent.code-workspace &>/dev/null; then
    pass "Workspace文件存在"
else
    fail "Workspace文件缺失"
fi

WSL_TEST=$(powershell.exe -Command "Test-Path '\\\\wsl.localhost\\Ubuntu\\home\\yestin\\company'" 2>/dev/null | tr -d '\r')
if [ "$WSL_TEST" = "True" ]; then
    pass "Windows可访问WSL文件系统"
else
    fail "Windows无法访问WSL文件系统"
fi

echo ""
echo "=========================================="
echo "  结果: $PASS 通过, $FAIL 失败"
echo "=========================================="
