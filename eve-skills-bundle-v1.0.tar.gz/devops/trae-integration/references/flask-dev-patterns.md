# Flask 开发常见陷阱 — AI 一人公司极速构建

## 背景线程在 Flask 中不可靠

Flask 开发服务器（`app.run()`）中启动的后台线程可能丢失请求上下文、模块导入路径或静默失败。

### ❌ 坏模式
```python
import threading
threading.Thread(target=lambda: heavy_work(task_id), daemon=True).start()
```
线程内的异常不会传播到主请求处理；task 状态永久卡在 "processing"。

### ✅ 好模式（管道执行 <50ms 时）
```python
# 直接同步处理，管道极快无需线程
result = pipeline.run(task)
base.save(task)
return jsonify(task)
```
管道执行在 20-50ms 内完成时，同步处理比异步更可靠。Flask 本身是多线程的，不会阻塞其他请求。

### ✅ 好模式（管道执行慢时）
使用 `concurrent.futures.ProcessPoolExecutor` 或 cron 任务异步处理，不要用 Flask 内的 daemon thread。

## Python 模块缓存

Flask 服务器启动时导入并缓存所有 Python 模块。运行时修改了 `.py` 文件后重启服务器，旧 `.pyc` 缓存可能被沿用。

### 症状
代码改了但行为没变，特别是 `import` 语句引用的技能模块。

### 修复
```bash
# 每次 code change 后重启前必须清除缓存
find /path/to/project -name "__pycache__" -exec rm -rf {} +
fuser -k PORT/tcp  # 确保旧进程彻底死亡
# 然后再启动
```

## `render_template` 缓存

Flask 在 debug=False 时缓存 Jinja2 模板。修改 HTML 后需要重启 Flask 进程才能看到更新。

```bash
# 开发时设置环境变量禁用模板缓存
FLASK_ENV=development
```

## 端口占用清理

```bash
# 一键杀死占用端口的进程
fuser -k PORT/tcp
```
