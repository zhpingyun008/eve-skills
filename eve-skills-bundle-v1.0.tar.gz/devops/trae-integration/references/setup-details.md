# Trae 集成 — 技术细节与故障排查

## Windows 端路径

| 组件 | 路径 |
|------|------|
| Trae IDE 可执行文件 | `C:\Users\Administrator\AppData\Local\Programs\Trae CN\Trae CN.exe` |
| Trae CLI 脚本 | `C:\Users\Administrator\AppData\Local\Programs\Trae CN\bin\trae` |
| 用户配置目录 | `C:\Users\Administrator\.trae-cn\` |
| MCP 配置文件 | `C:\Users\Administrator\Desktop\.trae\mcp.json` |
| 工作区文件 | `C:\Users\Administrator\Desktop\Hermes-Agent.code-workspace` |
| TRAE Work (独立产品) | `C:\Users\Administrator\AppData\Local\Programs\TRAE SOLO CN\TRAE SOLO CN.exe` |

## WSL 端路径

| 组件 | 路径 |
|------|------|
| CLI 包装脚本 | `/usr/local/bin/trae` |
| MCP 启动脚本 | `/home/yestin/hermes-mcp.sh` |
| MCP Server 核心 | `/home/yestin/.hermes/scripts/hermes-full-mcp-server.py` |
| 验证脚本 | `~/.hermes/skills/devops/trae-integration/scripts/trae-mcp-test.sh` |

## 恢复步骤（如果链接丢失）

```bash
# 重建 CLI
sudo ln -sf "/mnt/c/Users/Administrator/AppData/Local/Programs/Trae CN/bin/trae" /usr/local/bin/trae

# 验证 MCP
echo '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"test","version":"1.0"}}}' | timeout 5 bash /home/yestin/hermes-mcp.sh

# 验证 WSL 文件互通
powershell.exe -Command "Test-Path '\\wsl.localhost\Ubuntu\home\yestin\company'"
```

## MCP 配置格式

Desktop `.trae/mcp.json`:
```json
{
  "mcpServers": {
    "hermes-full": {
      "command": "wsl.exe",
      "args": ["/home/yestin/hermes-mcp.sh"],
      "type": "stdio",
      "env": { "HERMES_HOME": "/home/yestin/.hermes" }
    }
  }
}
```

Trae 用户设置 (`settings.json`) 需包含:
```json
{
  "claudeCode.enableAllProjectMcpServers": true,
  "claudeCode.enabledMcpjsonServers": ["hermes-full", "hermes-tools"]
}
```

## WSL 文件访问路径

Trae IDE 通过 `\\wsl.localhost\Ubuntu\home\yestin\` 访问 WSL 文件系统。
隐藏文件（`.` 开头）在 Windows 资源管理器中不可见，但在 Trae 的路径输入框中可直接输入完整路径。

## TRAE Work vs TRAE IDE

- **TRAE IDE**: AI 编码 IDE（VS Code 内核），有 SOLO Agent 模式
- **TRAE Work**: AI 工作助手（独立产品），有 Web 版和桌面版
- 两者是独立安装的独立产品，MCP 配置不同
