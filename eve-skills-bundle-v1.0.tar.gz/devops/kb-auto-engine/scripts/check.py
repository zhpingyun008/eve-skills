#!/usr/bin/env python3
"""
KB Auto-Engine Quality Gate — `[[link]]` 质量门禁升级版

Checks:
  1. ≥2 `[[link]]` outbound cross-references per page (WARNING)
  2. No dead links — all [[link]] targets must point to existing .md files (BLOCKER)
  3. Bidirectional linking — if A links to B, B should link back (WARNING)
  4. Generates quality-report-latest.md with per-page status

Usage:
  python3 check.py                          # Run quality gate on ~/company/
  python3 check.py --path ~/company/reports # Run on specific path
  python3 check.py --min-links 1            # Change minimum link threshold
  python3 check.py --report                 # Only generate report from cached scan
"""

import argparse
import json
import os
import re
import sys
from datetime import datetime
from pathlib import Path

# Default configuration
DEFAULT_SCAN_PATH = os.path.expanduser("~/company")
MIN_LINKS = 2
REPORT_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "quality-report-latest.md")

# Wiki link regex: [[target]] or [[target|label]]
WIKI_LINK_RE = re.compile(r'\[\[([^\]|#]+)(?:[|#][^\]]*)?\]\]')


def find_md_files(root_dir, exclude_patterns=None):
    """Find all .md files under root_dir."""
    if exclude_patterns is None:
        exclude_patterns = ['/node_modules/', '/__pycache__/', '/.git/']
    
    md_files = []
    root = Path(root_dir).expanduser().resolve()
    
    for f in root.rglob("*.md"):
        f_str = str(f)
        if any(p in f_str for p in exclude_patterns):
            continue
        md_files.append(f)
    
    return sorted(md_files)


def extract_wiki_links(content):
    """Extract all [[link]] targets from markdown content, excluding code blocks and false positives."""
    # Remove fenced code blocks first to avoid false positives
    cleaned = re.sub(r'```[\s\S]*?```', '', content)
    # Only remove inline code (`...`) that does NOT contain [[link]] patterns
    # Strategy: remove `` content, but restore any [[...]] found inside
    backtick_matches = re.findall(r'`([^`]+)`', cleaned)
    for bt in backtick_matches:
        wiki_in_bt = WIKI_LINK_RE.findall(bt)
        if not wiki_in_bt:
            # Safe to remove this backtick content
            cleaned = cleaned.replace(f'`{bt}`', '', 1)
    
    links = WIKI_LINK_RE.findall(cleaned)
    # Filter out false positives:
    # - Numeric-only targets (markdown reference links like [[1]])
    # - Empty targets
    # - Non-word targets (likely code artifacts)
    real_links = []
    for l in links:
        l = l.strip()
        if not l:
            continue
        if l.isdigit():
            continue  # [[1]] style markdown reference, not wiki link
        if len(l) < 2:
            continue
        real_links.append(l)
    return real_links


def resolve_wiki_link(target, base_dir, all_files_stem_set):
    """
    Try to resolve a wiki link target to an existing .md file.
    Returns the resolved Path or None.
    """
    # Direct match: target.md exists
    target_file = (base_dir / f"{target}.md")
    if target_file.exists():
        return target_file
    
    # Try with .md extension already in name
    if target.endswith('.md'):
        target_file = (base_dir / target)
        if target_file.exists():
            return target_file
    
    # Try relative path forms
    # If target looks like a path (contains /), try various base dirs
    if '/' in target:
        # Try from base_dir
        candidate = (base_dir / target)
        if candidate.exists():
            return candidate
        # Try with .md
        if not target.endswith('.md'):
            candidate = (base_dir / f"{target}.md")
            if candidate.exists():
                return candidate
    
    # Try matching by stem across the whole tree
    target_stem = target.lower().replace('.md', '')
    for stem in all_files_stem_set:
        if stem == target_stem:
            return None  # We know it exists but don't have the exact path
        if stem.endswith(f"/{target_stem}") or stem == target_stem:
            return None
        if target_stem in stem or stem in target_stem:
            return None  # Fuzzy match — exists
    
    return None


def scan_directory(scan_path, min_links=MIN_LINKS):
    """Main scan: find all .md files, extract [[link]] references, and evaluate quality."""
    scan_path = Path(scan_path).expanduser().resolve()
    
    print(f"🔍 Scanning: {scan_path}")
    print(f"📋 Min links threshold: {min_links}")
    print()
    
    md_files = find_md_files(scan_path)
    print(f"📁 Found {len(md_files)} .md files (excluding node_modules)")
    print()
    
    # Build a set of all file stems for dead link detection
    all_stems = set()
    for f in md_files:
        rel = f.relative_to(scan_path)
        stem = str(rel.with_suffix('')).lower()
        all_stems.add(stem)
        # Also add just the filename stem
        all_stems.add(f.stem.lower())
    
    results = []
    total_links = 0
    files_with_links = 0
    dead_links = []
    bidirectional_misses = []
    
    # First pass: extract links from all files
    file_links_map = {}
    for f in md_files:
        try:
            content = f.read_text(encoding='utf-8', errors='ignore')
        except Exception:
            continue
        
        rel_path = str(f.relative_to(scan_path))
        links = extract_wiki_links(content)
        file_links_map[rel_path] = {
            'path': rel_path,
            'full_path': str(f),
            'links': links,
            'link_count': len(links),
            'content': content,
        }
        total_links += len(links)
        if len(links) > 0:
            files_with_links += 1
    
    # Second pass: check dead links and bidirectional
    link_mapping = {}  # source -> set(targets)
    for rel_path, info in file_links_map.items():
        if info['link_count'] > 0:
            link_mapping[rel_path] = set()
            for target in info['links']:
                resolved = resolve_wiki_link(target, scan_path, all_stems)
                if resolved is None and target.lower().replace('.md', '') not in all_stems:
                    # Try fuzzy matching
                    found = False
                    for stem in all_stems:
                        if target.lower() in stem or stem in target.lower():
                            found = True
                            break
                    if not found:
                        dead_links.append((rel_path, target))
                link_mapping[rel_path].add(target.lower().replace('.md', ''))
    
    # Check bidirectional
    for src, targets in link_mapping.items():
        src_stem = Path(src).stem.lower()
        src_rel = str(Path(src).with_suffix(''))
        for tgt in targets:
            # Find files that match this target
            for other_rel, other_targets in link_mapping.items():
                if other_rel == src:
                    continue
                other_stem = Path(other_rel).stem.lower()
                other_rel_stem = str(Path(other_rel).with_suffix('')).lower()
                if tgt == other_stem or tgt == other_rel_stem:
                    # A->B exists, check if B->A exists
                    if src_stem not in other_targets and src_rel.lower() not in other_targets:
                        bidirectional_misses.append((src, other_rel))
    
    # Build per-file results
    for rel_path, info in file_links_map.items():
        link_count = info['link_count']
        
        # Determine status
        issues = []
        
        if link_count < min_links:
            issues.append(f"link_count_below_{min_links}")
        
        # Check if this file has dead links
        file_dead = [d for d in dead_links if d[0] == rel_path]
        if file_dead:
            issues.append(f"dead_links:{','.join(d[1] for d in file_dead)}")
        
        # Check if this file has bidirectional misses
        file_bi_misses = [b for b in bidirectional_misses if b[0] == rel_path]
        if file_bi_misses:
            bi_targets = [str(Path(b[1]).stem) for b in file_bi_misses]
            issues.append(f"missing_backlink:{','.join(bi_targets)}")
        
        if not issues:
            status = "PASS"
        elif any("dead_links" in i for i in issues):
            status = "BLOCKER"
        elif any("missing_backlink" in i for i in issues):
            status = "WARNING"
        elif any("link_count" in i for i in issues):
            status = "WARNING"
        else:
            status = "WARNING"
        
        results.append({
            'path': rel_path,
            'has_links': link_count > 0,
            'link_count': link_count,
            'status': status,
            'issues': issues,
        })
    
    return {
        'scan_path': str(scan_path),
        'total_files': len(md_files),
        'files_with_links': files_with_links,
        'total_links': total_links,
        'dead_links': dead_links,
        'bidirectional_misses': bidirectional_misses,
        'results': results,
        'timestamp': datetime.now().isoformat(),
    }


def generate_report(data, min_links=MIN_LINKS):
    """Generate a comprehensive quality report."""
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    passed = sum(1 for r in data['results'] if r['status'] == 'PASS')
    warnings = sum(1 for r in data['results'] if r['status'] == 'WARNING')
    blockers = sum(1 for r in data['results'] if r['status'] == 'BLOCKER')
    no_links = sum(1 for r in data['results'] if not r['has_links'])
    with_links = data['files_with_links']
    
    # Summary stats
    top_by_links = sorted(
        [r for r in data['results'] if r['has_links']],
        key=lambda x: -x['link_count']
    )[:20]
    
    report = []
    report.append(f"# KB Auto-Engine Quality Gate Report")
    report.append(f"")
    report.append(f"**Generated**: {now}")
    report.append(f"**Scan path**: {data['scan_path']}")
    report.append(f"**Min links threshold**: {min_links}")
    report.append(f"")
    report.append(f"---")
    report.append(f"")
    report.append(f"## Summary")
    report.append(f"")
    report.append(f"| Metric | Value |")
    report.append(f"|--------|-------|")
    report.append(f"| Total .md files | {data['total_files']} |")
    report.append(f"| Files with `[[link]]` | {with_links} |")
    report.append(f"| Files WITHOUT `[[link]]` | {no_links} |")
    report.append(f"| Total `[[link]]` refs | {data['total_links']} |")
    report.append(f"| ✅ PASS | {passed} |")
    report.append(f"| 🟡 WARNING | {warnings} |")
    report.append(f"| 🔴 BLOCKER | {blockers} |")
    report.append(f"| Dead links found | {len(data['dead_links'])} |")
    report.append(f"| Bidirectional misses | {len(data['bidirectional_misses'])} |")
    report.append(f"")
    
    # Quality Gate Status
    report.append(f"## Quality Gate Status")
    report.append(f"")
    if data['total_links'] == 0:
        report.append(f"❌ **OVERALL: FAIL** — Zero `[[link]]` cross-references found across all {data['total_files']} files.")
    elif blockers > 0:
        report.append(f"❌ **OVERALL: BLOCKER** — {blockers} files have dead links that must be fixed.")
    elif warnings > 0:
        report.append(f"⚠️ **OVERALL: WARNING** — {warnings} files need attention.")
    else:
        report.append(f"✅ **OVERALL: PASS** — All quality gates satisfied.")
    report.append(f"")
    
    # Gate details
    report.append(f"### Quality Gate Checks")
    report.append(f"")
    report.append(f"| Gate | Check | Result |")
    report.append(f"|------|-------|--------|")
    
    gate1 = "❌ FAIL" if data['total_links'] == 0 else f"{'✅' if sum(1 for r in data['results'] if r['link_count'] >= min_links) > 0 else '⚠️'} PASS" if blockers == 0 else "❌ FAIL"
    report.append(f"| ≥{min_links} `[[link]]` per page | Count `[[link]]` in body | {gate1} |")
    
    gate2 = "✅ PASS" if len(data['dead_links']) == 0 else f"❌ FAIL ({len(data['dead_links'])} dead links)"
    report.append(f"| No dead links | Resolve each `[[]]` target to existing .md | {gate2} |")
    
    gate3 = "✅ PASS" if len(data['bidirectional_misses']) == 0 else f"⚠️ WARNING ({len(data['bidirectional_misses'])} misses)"
    report.append(f"| Bidirectional linking | If A→B, B should A→ | {gate3} |")
    report.append(f"")
    
    # Dead links detail
    if data['dead_links']:
        report.append(f"## 🔴 Dead Links ({len(data['dead_links'])})")
        report.append(f"")
        report.append(f"| Source File | Broken Target |")
        report.append(f"|-------------|--------------|")
        for src, tgt in sorted(data['dead_links']):
            report.append(f"| `{src}` | `{tgt}` |")
        report.append(f"")
    
    # Bidirectional misses
    if data['bidirectional_misses']:
        report.append(f"## 🟡 Bidirectional Link Misses ({len(data['bidirectional_misses'])})")
        report.append(f"")
        report.append(f"| Source (A→B) | Missing Backlink (B→A) |")
        report.append(f"|--------------|----------------------|")
        for src, tgt in sorted(data['bidirectional_misses']):
            report.append(f"| `{src}` | `{tgt}` |")
        report.append(f"")
    
    # Files with links (top by count)
    if top_by_links:
        report.append(f"## Top Files by `[[link]]` Count")
        report.append(f"")
        report.append(f"| Path | Links | Status |")
        report.append(f"|------|-------|--------|")
        for r in top_by_links:
            report.append(f"| `{r['path']}` | {r['link_count']} | {r['status']} |")
        report.append(f"")
    
    # Per-directory summary
    report.append(f"## Per-Directory Summary")
    report.append(f"")
    dir_stats = {}
    for r in data['results']:
        parts = r['path'].split('/')
        top_dir = parts[0] if len(parts) > 1 else '.'
        if top_dir not in dir_stats:
            dir_stats[top_dir] = {'total': 0, 'with_links': 0, 'total_links': 0}
        dir_stats[top_dir]['total'] += 1
        if r['has_links']:
            dir_stats[top_dir]['with_links'] += 1
        dir_stats[top_dir]['total_links'] += r['link_count']
    
    report.append(f"| Directory | Files | With Links | Total Links | Coverage |")
    report.append(f"|-----------|-------|-----------|-------------|----------|")
    for d in sorted(dir_stats.keys()):
        s = dir_stats[d]
        if s['total'] == 0:
            continue
        pct = (s['with_links'] / s['total']) * 100
        report.append(f"| `{d}/` | {s['total']} | {s['with_links']} | {s['total_links']} | {pct:.1f}% |")
    report.append(f"")
    
    # Files without any links (sample)
    no_link_files = [r for r in data['results'] if not r['has_links']]
    if no_link_files:
        report.append(f"## Files WITHOUT `[[link]]` (Sample)")
        report.append(f"")
        report.append(f"Total: {len(no_link_files)} files. Showing first 30:")
        report.append(f"")
        report.append(f"| # | Path |")
        report.append(f"|---|------|")
        for i, r in enumerate(no_link_files[:30], 1):
            report.append(f"| {i} | `{r['path']}` |")
        if len(no_link_files) > 30:
            report.append(f"| ... | ... ({len(no_link_files) - 30} more) |")
        report.append(f"")
    
    # Recommendations
    report.append(f"## Recommendations")
    report.append(f"")
    if data['total_links'] == 0:
        report.append(f"1. **Start adding `[[link]]` cross-references** — Zero links found in {data['total_files']} files.")
        report.append(f"   - Add '## Related Entries' or '## Cross References' sections to key pages")
        report.append(f"   - Use format `[[page-name]]` (NOT `[text](url)` markdown links)")
        report.append(f"2. **Run this check weekly** — Add to cron for continuous quality monitoring")
    if data['dead_links']:
        report.append(f"3. **Fix dead links** — {len(data['dead_links'])} broken targets referenced in the table above")
    if data['bidirectional_misses']:
        report.append(f"4. **Add missing backlinks** — {len(data['bidirectional_misses'])} pairs where A→B but not B→A")
    report.append(f"")
    report.append(f"---")
    report.append(f"")
    report.append(f"*Report generated by KB Auto-Engine Quality Gate v2.0 | {now}*")
    
    return "\n".join(report)


def main():
    parser = argparse.ArgumentParser(
        description="KB Auto-Engine Quality Gate — [[link]] cross-reference checker"
    )
    parser.add_argument(
        "--path", "-p",
        default=DEFAULT_SCAN_PATH,
        help=f"Scan path (default: ~/company/)"
    )
    parser.add_argument(
        "--min-links", "-m",
        type=int,
        default=MIN_LINKS,
        help=f"Minimum [[link]] threshold (default: {MIN_LINKS})"
    )
    parser.add_argument(
        "--report", "-r",
        action="store_true",
        help="Only regenerate report from existing scan (not yet cached)"
    )
    parser.add_argument(
        "--output", "-o",
        default=None,
        help="Report output path (default: quality-report-latest.md in skill dir)"
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Output results as JSON"
    )
    
    args = parser.parse_args()
    
    scan_path = os.path.expanduser(args.path)
    if not os.path.isdir(scan_path):
        print(f"❌ Error: Path not found: {scan_path}")
        sys.exit(1)
    
    # Run scan
    data = scan_directory(scan_path, min_links=args.min_links)
    
    # Generate report
    report = generate_report(data, min_links=args.min_links)
    
    # Determine output path
    output_path = args.output or os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        "quality-report-latest.md"
    )
    
    # Write report
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(report)
    
    print(f"\n📄 Report written to: {output_path}")
    
    if args.json:
        print(json.dumps({
            'total_files': data['total_files'],
            'files_with_links': data['files_with_links'],
            'total_links': data['total_links'],
            'dead_links': len(data['dead_links']),
            'bidirectional_misses': len(data['bidirectional_misses']),
            'passed': sum(1 for r in data['results'] if r['status'] == 'PASS'),
            'warnings': sum(1 for r in data['results'] if r['status'] == 'WARNING'),
            'blockers': sum(1 for r in data['results'] if r['status'] == 'BLOCKER'),
            'no_links': sum(1 for r in data['results'] if not r['has_links']),
        }, indent=2))
    
    # Print summary
    print()
    print("=" * 60)
    print("KB Auto-Engine Quality Gate — Summary")
    print("=" * 60)
    print(f"  Total .md files: {data['total_files']}")
    print(f"  Files with [[link]]: {data['files_with_links']}")
    print(f"  Total [[link]] refs: {data['total_links']}")
    print(f"  Dead links: {len(data['dead_links'])}")
    print(f"  Bidirectional misses: {len(data['bidirectional_misses'])}")
    
    passed = sum(1 for r in data['results'] if r['status'] == 'PASS')
    warnings = sum(1 for r in data['results'] if r['status'] == 'WARNING')
    blockers = sum(1 for r in data['results'] if r['status'] == 'BLOCKER')
    
    print(f"  ✅ PASS: {passed}")
    print(f"  🟡 WARNING: {warnings}")
    print(f"  🔴 BLOCKER: {blockers}")
    
    if blockers > 0:
        print(f"\n❌ Gate FAILED — {blockers} blocker(s) found")
        sys.exit(1)
    elif warnings > 0:
        print(f"\n⚠️ Gate PASSED with {warnings} warning(s)")
        sys.exit(0)
    elif data['total_links'] == 0:
        print(f"\n⚠️ Gate PASSED — No links found (this is expected for non-wiki content)")
        sys.exit(0)
    else:
        print(f"\n✅ Gate PASSED")
        sys.exit(0)


if __name__ == "__main__":
    main()
