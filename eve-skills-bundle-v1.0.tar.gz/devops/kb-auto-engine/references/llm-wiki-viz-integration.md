# LLM Wiki 可视化服务器集成

本技能创建的 `llm-wiki-engine.py` 管理知识库的索引/质量/编译/RAG。可视化由独立的 `llm-wiki-viz` 技能提供。

## 集成方式

```
llm-wiki-engine.py  (编译/索引/质量)
         │
         ▼  schema/meta/index.json (共享数据源)
         │
llm-wiki-server.py  (可视化 HTTP 服务器)
  ├─ /api/index  → 读取 index.json
  ├─ /api/page   → 读取 wiki/*.md
  ├─ /api/graph  → 计算图谱
  └─ /api/search → 全文搜索
```

## 数据流

1. `python3 llm-wiki-engine.py all` → 更新 index.json + rag-chunks.json
2. `python3 llm-wiki-server.py` → 启动可视化服务 (port 3889)
3. 浏览器访问 http://localhost:3889 → D3.js 知识图谱 + 搜索 + 浏览

## 依赖

- 引擎脚本: 仅需 `pyyaml` (解析 frontmatter)
- 可视化服务器: 仅需 `pyyaml`，前端从 CDN 加载 D3.js + marked.js
- 前端文件独立，修改无需重启 server

## 已验证 (2026-06-20)

- 30 pages, 123 cross-refs, 0 blockers, 0 warnings
- 236 RAG chunks generated
- Graph: 30 nodes, 102 edges
- Tags: 68 tags from frontmatter
