# Cross-Reference Quality Audit — 2026-06-30

## Summary

First full `[[link]]` cross-reference audit of the Eve knowledge base.

| Metric | Value |
|--------|-------|
| Files scanned | 77 (projects/) |
| Files with `[[link]]` | 4 (after intervention) |
| Total `[[link]]` refs | 11 |
| Dead links | 3 (template placeholders) |
| Bidirectional misses | 4 |

## Interventions Made

1. **check.py upgraded** from no-op placeholder to full quality gate engine
2. **Bug fix**: check.py was stripping `[[link]]` inside backticks (`\`[[link]]\``). The `extract_wiki_links()` function was removing all inline code content before scanning for `[[link]]`. Fix: only remove backtick content that does NOT contain `[[link]]` patterns.
3. **Templates updated**: 04-日报模板.md + 05-周报模板.md gained `[[link]]` usage recommendations
4. **Architecture docs**: Phase0-架构评审报告.md + 1-总体技术架构方案.md gained real bidirectional `[[link]]` cross-references

## check.py CLI Usage

```bash
# Basic scan
python3 check.py --path ~/company/projects/

# Custom threshold
python3 check.py --path ~/company/reports/ --min-links 1

# JSON output for programmatic use
python3 check.py --path ~/company/ --min-links 2 --json

# Full company scan (slow: 116k+ files)
python3 check.py --path ~/company/ --min-links 1 --output ~/company/reports/kb-full-audit.md
```

## Key Insight

116,001 files across ~/company/ and ~/.hermes/skills/ had **zero** `[[link]]` cross-references. Every file is a knowledge silo. Building cross-references is a P1-P2 ongoing task, not a one-time fix.

## Gate Results (projects dir after fix)

- 1 file PASS (≥1 link, no dead links, bidirectional OK)
- 2 files BLOCKER (dead links — template placeholder refs like `[[项目名或模块名]]`)
- 74 files WARNING (no links)
