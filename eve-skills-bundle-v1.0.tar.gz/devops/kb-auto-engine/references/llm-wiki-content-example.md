# LLM Wiki Content Example — 30-Page Knowledge Base

This reference documents the concrete structure and content organization of a production 30-page LLM knowledge base, built under `/mnt/c/Users/<user>/Documents/LLM-Wiki/` for Obsidian on Windows + WSL generation.

## Vault Structure

```
LLM-Wiki/
├── .obsidian/                # Obsidian vault config (app.json, workspace.json)
├── raw/                      # Source materials (empty initially)
├── wiki/
│   ├── concepts/       (8)   # Core LLM concepts
│   ├── models/         (6)   # Model families
│   ├── techniques/     (6)   # Key techniques
│   ├── tools/          (4)   # Tools & frameworks
│   ├── practices/      (4)   # Best practices
│   └── benchmarks/     (2)   # Benchmarks
├── schema/
│   ├── rules/          (3)   # naming.md, cross-ref.md, quality-gates.md
│   ├── standards/      (2)   # page-structure.md, metadata.md
│   └── meta/                 # index.json, tags.yml
├── llm-wiki-engine.py         # Auto-compilation engine
├── rag-chunks.json            # 236 RAG-ready chunks
└── quality-report-latest.md   # Quality gate results
```

## Page List by Category

### Concepts (8)
| File | Title | Key Topics |
|------|-------|------------|
| `concept-transformer.md` | Transformer架构 | Encoder-Decoder, Self-Attention, PE, LayerNorm, Residual |
| `concept-attention.md` | Attention机制 | Bahdanau→Self-Attention, KV Cache, Flash Attention |
| `concept-pretraining.md` | 预训练 | Autoregressive, Scaling Laws, Chinchilla |
| `concept-fine-tuning.md` | 微调 | Full FT vs PEFT, Instruction Tuning, Catastrophic Forgetting |
| `concept-rlhf.md` | RLHF | SFT→RM→RLHF, PPO, DPO, Constitutional AI |
| `concept-rag.md` | RAG | Chunking, Vector DB, Hybrid Search, Re-ranking |
| `concept-embeddings.md` | 嵌入与向量表示 | Word2Vec→LLM Embeddings, Cosine Similarity |
| `concept-tokenization.md` | 分词 | BPE, WordPiece, SentencePiece, BBPE |

### Models (6)
| File | Title | Key Models |
|------|-------|------------|
| `model-gpt-series.md` | GPT系列 | GPT-1→GPT-4o→o1, API pricing |
| `model-llama.md` | LLaMA系列 | LLaMA 1→4, GQA/RoPE/SwiGLU |
| `model-claude.md` | Claude系列 | Claude 1→4.5, Constitutional AI, 200K ctx |
| `model-deepseek.md` | DeepSeek系列 | V2→R1→V3→R2, MLA/MoE |
| `model-mistral.md` | Mistral系列 | 7B→Mixtral→Large, SWA/MoE |
| `model-gemini.md` | Gemini系列 | 1.0 Pro→1.5→2.0, 1M ctx, Gemma |

### Techniques (6)
| File | Title | Key Topics |
|------|-------|------------|
| `technique-sft.md` | SFT | Dataset construction, Loss, Overfitting |
| `technique-dpo.md` | DPO | Implicit Reward, KTO/ORPO/Iterative DPO |
| `technique-quantization.md` | 模型量化 | GPTQ/AWQ/GGUF, QAT, Bitsandbytes |
| `technique-lora.md` | LoRA微调 | Low-rank, QLoRA, DoRA, AdaLoRA |
| `technique-prompt-engineering.md` | Prompt工程 | CoT/ToT/ReAct, System Prompt, Jailbreak |
| `technique-moe.md` | MoE | Sparse MoE, Router, Expert Balancing |

### Tools (4)
| File | Title | Key Topics |
|------|-------|------------|
| `tool-langchain.md` | LangChain | Chains/Agents/LCEL, LangSmith/LangServe |
| `tool-llamaindex.md` | LlamaIndex | Index types, Retriever, QueryEngine |
| `tool-vllm.md` | vLLM | PagedAttention, Continuous Batching |
| `tool-ollama.md` | Ollama | Modelfile, GGUF, OpenAI API, REST |

### Practices (4)
| File | Title | Key Topics |
|------|-------|------------|
| `practice-model-deployment.md` | 模型部署 | TensorRT-LLM, GPU selection, Batch |
| `practice-rag-system.md` | 构建RAG | Chunking, Hybrid Search, Ragas/ARES |
| `practice-agent-building.md` | 构建Agent | ReAct, MCP, LangGraph/CrewAI |
| `practice-evaluation.md` | LLM评估 | MMLU/HumanEval, Chatbot Arena, LLM-as-Judge |

### Benchmarks (2)
| File | Title | Key Topics |
|------|-------|------------|
| `benchmark-mmlu.md` | MMLU基准 | 57 subjects, MMLU-Pro, Score rankings |
| `benchmark-leaderboards.md` | 关键排行榜 | Arena ELO, Open LLM LB, SWE-bench |

## Quality Metrics (Final Run)

| Metric | Value |
|--------|-------|
| Total pages | 30 |
| Cross-references | 123 |
| RAG chunks | 236 |
| Quality blockers | 0 |
| Quality warnings | 0 |
| Published pages | 20 |
| Draft pages | 10 |

## Page Template Used

All pages follow this template:

```yaml
---
title: "Human-readable title"
category: "concept|model|technique|benchmark|tool|practice"
status: "published|draft"
created: "2026-06-20"
updated: "2026-06-20"
tags: [tag1, tag2]
---
```

Each page includes: H1 title, Mermaid diagram (concepts), spec table (models), code examples (techniques/tools), ≥2 `[[cross-refs]]`, and a Sources section.
