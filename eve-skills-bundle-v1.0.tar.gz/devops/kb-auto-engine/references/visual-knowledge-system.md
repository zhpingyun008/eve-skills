# Visual Knowledge System — Web-Based Knowledge Graph + Search + Page Viewer

Build a self-contained visual web application on top of a parsed markdown knowledge base. Uses Python stdlib HTTP server for the backend and a single embedded HTML page with D3.js for the frontend.

## Architecture

```
┌─ Browser ─────────────────────────────────────┐
│                                                │
│  index.html (SPA frontend)                     │
│  ├─ D3.js force-directed graph (30+ nodes)    │
│  ├─ Full-text search                          │
│  ├─ Category filter buttons                   │
│  ├─ Markdown page viewer                      │
│  └─ Stats dashboard                           │
│         │                                      │
│         ▼ REST API (JSON)                      │
└───────────────────────────────────────────────┘
         │
┌─ Python HTTP Server ──────────────────────────┐
│                                                │
│  /api/stats    → Knowledge base statistics     │
│  /api/index    → Full page index.json          │
│  /api/graph    → Nodes + edges for D3.js       │
│  /api/page?path= → Page content + frontmatter  │
│  /api/search?q=  → Full-text search results    │
│         │                                       │
│         ▼ File system                           │
└───────────────────────────────────────────────┘
         │
┌─ LLM-Wiki Vault ─────────────────────────────┐
│  schema/meta/index.json                       │
│  wiki/concepts/*.md                            │
│  wiki/models/*.md                              │
│  ...                                           │
└───────────────────────────────────────────────┘
```

## Backend: Python stdlib HTTP Server

No Flask, no dependencies — pure `http.server` from the standard library.

### Server Structure

```python
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

class WikiHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        params = parse_qs(parsed.query)
        
        if path == "/":
            self.serve_html()      # Serve the embedded SPA
        elif path == "/api/stats":
            self.serve_stats()     # JSON statistics
        elif path == "/api/graph":
            self.serve_graph()     # Nodes + edges
        elif path == "/api/page":
            self.serve_page()      # Markdown page content
        elif path == "/api/search":
            self.serve_search()    # Full-text search results
```

### Frontend HTML Embedding

The entire HTML/CSS/JS frontend is a Python triple-quoted string at the bottom of the server file. This makes it a single-file deploy:

```python
FRONTEND_HTML = r"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <script src="https://d3js.org/d3.v7.min.js"></script>
  <style>/* all styles inline */</style>
</head>
<body>
  <script>/* all JS inline */</script>
</body>
</html>
"""
```

### CORS Headers

Add CORS headers for development flexibility:
```python
self.send_header("Access-Control-Allow-Origin", "*")
self.send_header("Access-Control-Allow-Methods", "GET, OPTIONS")
```

## Frontend: D3.js Knowledge Graph

### Node Construction

```python
def get_graph_data():
    nodes = []
    edges = []
    
    # Build nodes from index
    for i, page in enumerate(index["pages"]):
        nodes.append({
            "id": f"n{i}",
            "path": page["path"],
            "title": page["title"],
            "category": page["category"],
            "color": CAT_COLORS[cat],
            "size": max(5, min(15, cross_refs + word_count/1000)),
        })
    
    # Build edges from [[link]] cross-references in page content
    for page in index["pages"]:
        content = read_page_content(page["path"])
        refs = re.findall(r'\[\[([^\]]+)\]\]', content)
        for ref in refs:
            target = resolve_wiki_link(ref)
            if target:
                edges.append({"source": src_id, "target": target_id})
```

### JavaScript Force Graph

```javascript
const svg = d3.select('#graph-area svg');
const simulation = d3.forceSimulation(nodes)
    .force('link', d3.forceLink(edges).distance(100))
    .force('charge', d3.forceManyBody().strength(-200))
    .force('center', d3.forceCenter(width/2, height/2));

// Nodes: circles with category-based colors and size = content volume
const node = svg.selectAll('circle').data(nodes)
    .join('circle')
    .attr('r', d => d.size)
    .attr('fill', d => d.color)
    .on('click', (e, d) => openPage(d.path))
    .on('mouseover', highlightConnections)
    .on('mouseout', resetHighlight);
```

### Interactive Features

| Feature | Implementation |
|---------|---------------|
| **Zoom/Pan** | `d3.zoom().scaleExtent([0.3, 3])` |
| **Drag nodes** | `d3.drag().on('start/drag/end')` with `d.fx/fy` |
| **Hover highlight** | Connected nodes at 0.8 opacity, others at 0.2 |
| **Hover tooltip** | Absolute-positioned div showing title + category |
| **Click navigation** | Opens page in the viewer panel |
| **Filter by category** | Re-render graph with subset of nodes |

## Full-Text Search

### Backend Scoring

```python
def search_pages(query):
    query = query.lower()
    for page in index["pages"]:
        content = read_page(page["path"])
        body = strip_frontmatter(content).lower()
        
        score = 0
        if query in page["title"].lower():  score += 10
        if query in page["category"]:        score += 3
        score += body.count(query)
        
        if score > 0:
            results.append({"path": path, "title": title, "score": score, "snippet": snippet})
    
    results.sort(key=lambda x: -x["score"])
    return results[:30]
```

### Frontend Search

```javascript
document.getElementById('search-input')
    .addEventListener('input', debounce(async (e) => {
        const q = e.target.value;
        if (q.length < 2) { resetPageList(); return; }
        const results = await fetchJSON(`/api/search?q=${encodeURIComponent(q)}`);
        renderPageList(results);
    }, 300));
```

## Markdown Page Viewer

### Simple Markdown Renderer (No Dependency)

Since we avoid adding marked.js as a dependency, implement a basic markdown-to-HTML converter:

```javascript
function simpleMarkdown(text) {
    let html = text;
    html = html.replace(/^### (.+)$/gm, '<h3>$1</h3>');
    html = html.replace(/^## (.+)$/gm, '<h2>$1</h2>');
    html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    html = html.replace(/`([^`]+)`/g, '<code>$1</code>');
    html = html.replace(/^> (.+)$/gm, '<blockquote>$1</blockquote>');
    html = html.replace(/^- (.+)$/gm, '<li>$1</li>');
    html = html.replace(/\|(.+)\|\n\|[-| ]+\|\n((?:\|.+\|\n?)+)/g, tableReplacer);
    return html;
}
```

### Wiki Link Handling

Convert `[[page-name]]` to clickable links in the viewer:

```javascript
body.replace(/\[\[([^\|#\]]+)(?:\|([^\]]+))?\]\]/g, 
    (m, target, label) => `<a class="wiki-link" onclick="openWikiLink('${target}')">${label || target}</a>`);
```

## Deployment

### Startup

```bash
cd ~/company && python3 scripts/llm-wiki-server.py &
```

### Port Convention

Use port 3889 (following the Eve service convention: 3888=dashboard, 3889=wiki visualizer, 8765=CEO, 8766=contact, 8767=discuss).

### Cron Auto-Restart (Optional)

```bash
hermes cron create --name "wiki-viz-health" --schedule "*/10 * * * *" \
  --no_agent=true \
  --script "wiki-server-health.sh"
```

Where `wiki-server-health.sh` contains:
```bash
#!/bin/bash
curl -sf http://localhost:3889/api/stats > /dev/null 2>&1 || \
  (cd ~/company && python3 scripts/llm-wiki-server.py &)
```

## Pitfalls

1. **YAML `date` serialization** — `yaml.safe_load()` returns Python `date` objects from dates like `2026-06-20`. These crash `json.dumps()` with `TypeError: Object of type date is not JSON serializable`. Fix: convert dates to strings after YAML parsing.

2. **Large frontend HTML strings** — Embedding the entire SPA in a Python string means escaping single quotes, backslashes, and f-string braces. Use `r"""..."""` (raw triple-quoted string) to avoid escape issues.

3. **HTTP server single-threaded** — `HTTPServer` processes one request at a time. For a personal knowledge base (1-2 concurrent users) this is fine. For multi-user, switch to `ThreadingHTTPServer`.

4. **D3.js CDN dependency** — The frontend loads D3 from `https://d3js.org/d3.v7.min.js`. If the user is offline, the graph won't render. Consider bundling a local copy or adding an offline fallback message.

5. **The HTML frontend is embedded, not a file** — Edits to the frontend require editing the Python script and restarting. For iterative frontend development, extract `index.html` as a separate file and serve it with `open()`.
