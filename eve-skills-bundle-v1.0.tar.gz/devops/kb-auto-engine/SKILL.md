---
name: kb-auto-engine
description: Build and auto-maintain a three-layer markdown knowledge base (raw/wiki/schema) with Python auto-compilation engine — indexing, quality gates, raw→wiki compilation, BookStack sync, RAG chunk generation, and cron-based auto-maintenance.
category: devops
triggers:
  - "知识库 / knowledge base / KB / 知识体系"
  - "LLM Wiki / LLM知识库 / LLM文档"
  - "Obsidian / Obsidian知识库 / Obsidian vault"
  - "知识库架构 / knowledge base architecture"
  - "知识编译 / knowledge compilation / raw to wiki"
  - "知识库自动维护 / auto-maintain KB / auto-compile"
  - "质量门禁 / quality gate / knowledge quality"
  - "知识库模板 / KB template / 页面标准"
  - "RAG知识库 / RAG KB / 向量知识库"
  - "自动化知识库 / auto knowledge base"
  - "三层架构 / three-layer / raw wiki schema"
  - "搭建知识库 / setup knowledge base / build wiki"
  - "知识库引擎 / KB engine"
  - "知识索引 / knowledge index / auto-index"
  - "知识库同步 / KB sync / BookStack sync"
  - "cross ref / 交叉引用 / 知识关联"
  - "page generation standard / 页面生成标准"
  - "双向同步 / bidirectional sync / BookStack sync / 知识库同步"
  - "BookStack ↔ 本地同步 / sync local BS"
  - "冲突检测 / conflict resolution / sync validation"
  - "卡通风格 / cartoon style / kb-badge / kb-cartoon-divider"
  - "自我校验 / self-validate / auto-fix / 偏差修正"
  - "可视化知识库 / visual knowledge base / knowledge graph / 知识图谱可视化"
  - "知识库浏览器 / KB web viewer / 知识库Web界面"
related_skills:
  - bookstack-kb-architecture
  - team-wiki-deploy
  - bookstack-update-sync
  - knowledge-base
  - llm-wiki-viz
  - obsidian-bridge
  - obsidian-bridge
---

# KB Auto-Engine — Three-Layer Markdown Knowledge Base with Auto-Compilation

## Overview

Build a structured markdown knowledge base with three layers (raw source materials → curated wiki pages → schema rules/standards), maintained by a Python auto-compilation engine that indexes, quality-checks, auto-compiles, syncs to BookStack, and generates RAG-ready chunks.

**Class**: DevOps / Knowledge Management — Content Architecture + Automation  
**Distinction**: This covers the *content architecture AND auto-maintenance* of a local markdown-based knowledge base. Use `bookstack-kb-architecture` for BookStack-specific platform content, and `team-wiki-deploy` for wiki platform deployment itself.

## Three-Layer Architecture

```
llm-wiki/
├── raw/                    # Raw source materials
│   ├── papers/             # Original papers (PDF/MD)
│   ├── docs/               # Official documentation
│   ├── references/         # External links index
│   └── templates/          # Compilation templates (paper-note, source-summary, model-card, benchmark-log)
│       ├── paper-note.md           # Paper notes (frontmatter + contribution + method + evaluation)
│       ├── source-summary.md       # Source abstracts (source + key points + action items)
│       ├── model-card.md           # Model cards (architecture + specs + capabilities + ecosystem)
│       └── benchmark-log.md        # Benchmark records (settings + results + comparison)
│
├── wiki/                   # Curated knowledge
│   ├── concepts/           # Core concepts files named `concept-{keyword}.md`
│   ├── models/             # Model archives named `model-{keyword}.md`
│   ├── techniques/         # Technical guides named `technique-{keyword}.md`
│   ├── benchmarks/         # Benchmark results
│   ├── tools/              # Tool documentation
│   ├── practices/          # Best practices
│   └── templates/          # Wiki page templates
│       ├── concept-page.md         # Concept page (overview + principle + relations + history)
│       ├── model-archive.md        # Model archive (specs + data + evaluation + ecosystem)
│       ├── technique-guide.md      # Technique guide (flow + code + effects + FAQ)
│       └── practice-note.md        # Practice note (steps + results + pitfalls + commands)
│
└── schema/                 # Rules and standards
    ├── README.md           # Three-layer relationship diagram
    ├── rules/              # Specification rules
    │   ├── naming.md               # Naming conventions (prefix table + kebab-case + prohibitions)
    │   ├── cross-ref.md            # Cross-reference rules (types + depth + bidirectional + checks)
    │   └── quality-gates.md        # Quality gates (BLOCKER/WARNING/PASS + auto-check commands)
    ├── standards/          # Page generation standards
    │   ├── page-structure.md       # Page structure standard (skeleton + type-specific + L1-L4 depth)
    │   ├── metadata.md             # Metadata standard (required fields + type-specific + status flow)
    │   └── style-guide.md          # Style guide (language + format + Mermaid + cross-ref)
    └── meta/               # Metadata
        ├── index.json              # Full index (auto-maintained)
        ├── tags.yml                # Tag taxonomy (8 categories, 30+ tags)
        └── status.yml              # Status management (draft/review/published/archived)
```

### Cross-Reference Architecture

```
wiki/concepts/ → raw/papers/ (tracing)
wiki/techniques/ → wiki/concepts/ (foundation)
wiki/models/ → wiki/techniques/ (tech stack)
wiki/benchmarks/ → wiki/models/ (evaluated models)
```

## Obsidian Vault Setup

> **Note**: The `obsidian-bridge` skill now provides automated bidirectional sync between the LLM Wiki and Obsidian,
> including BookStack sync, memory engine sync, project docs, and company assets. See `devops/obsidian-bridge` for the full pipeline.
> The manual setup below is retained for reference; use `obsidian-bridge` for production deployment.

After creating the three-layer directory structure, configure it as an Obsidian vault for direct use in the Obsidian app.

### Minimal .obsidian Config

Create `.obsidian/app.json` in the vault root:

```json
{
  "alwaysUpdateLinks": true,
  "showFrontmatter": true,
  "showLineNumber": true,
  "spellcheck": true,
  "useMarkdownLinks": true,
  "newLinkFormat": "relative",
  "baseFontSize": 16
}
```

Create `.obsidian/workspace.json` (minimal):

```json
{
  "promptVersion": "1.0.0",
  "communityPluginSortOrder": "download"
}
```

That's all that's needed — Obsidian auto-populates the rest on first open.

### WSL → Windows Deployment

When the vault needs to be accessible from Windows Obsidian but managed from WSL:

```bash
# Discover the Windows user (may be Administrator on single-user machines)
WINDOWS_USER=$(ls /mnt/c/Users/ | grep -v -E "^(Public|Default|All Users|desktop\.ini)$" | head -1)
VAULT_PATH="/mnt/c/Users/$WINDOWS_USER/Documents/Obsidian Vault"
mkdir -p "$VAULT_PATH"/wiki/{concepts,models,techniques,tools,practices,benchmarks}
mkdir -p "$VAULT_PATH"/reports "$VAULT_PATH"/decisions
```

The user opens Obsidian → "Open folder as vault" → selects the folder. Content generated from WSL reflects in Obsidian instantly.

> ⚠️ Path note: The actual KB root is at `~/projects/llm-wiki/`, not `~/llm-wiki/`. The Obsidian vault is at `/mnt/c/Users/$USER/Documents/Obsidian Vault/`. Use `obsidian-bridge` skill for automated bidirectional sync between these locations.

### Opening the Vault

1. Windows Obsidian → `Open folder as vault` → `Documents/LLM-Wiki`
2. `Ctrl+O` search pages | `Ctrl+Shift+F` full-text search
3. Graph View (`Ctrl+G`) for knowledge connections
4. Backlinks pane shows `[[link]]` cross-references

## Large-Scale Content Generation

When building a domain-specific knowledge base (e.g., LLM Wiki with 30+ pages), use `delegate_task` for parallel content generation.

### Content Planning Example

```
Core Concepts (8)  — Transformer, Attention, Pre-training, RLHF, RAG, Embeddings, Tokenization
Model Families (6) — GPT, LLaMA, Claude, DeepSeek, Mistral, Gemini
Techniques     (6) — SFT, DPO, Quantization, LoRA, Prompt Eng, MoE
Tools          (4) — LangChain, LlamaIndex, vLLM, Ollama
Practices      (4) — Deployment, RAG System, Agent Building, Evaluation
Benchmarks     (2) — MMLU, Leaderboards
```

### Parallel Generation Pattern (max_concurrent_children=3)

Split into batches respecting the concurrency limit:

**Batch 1** (3 parallel): concepts + models + techniques
**Batch 2** (3 parallel): tools + practices + benchmarks

Each subagent context must specify:
- Exact file paths
- YAML frontmatter requirements (all fields)
- Cross-reference format (`[[page-name]]`, not markdown links)
- Mermaid requirement for concept pages
- Page structure template per type

### Post-Generation Fix-Up

Subagents may produce inconsistent frontmatter (some use `description`/`tags` instead of `status`/`created`/`updated`). After all batches:

1. Run `python3 llm-wiki-engine.py quality` to detect issues
2. Fix missing dates with a batch script
3. Re-run `python3 llm-wiki-engine.py all` for clean index + report

### Reference

For a complete 30-page LLM knowledge base example, see `references/llm-wiki-content-example.md`.

## Visual Knowledge System (Web Interface)

Build a self-contained web application on top of the knowledge base for visual browsing. Uses Python stdlib HTTP server + embedded SPA frontend with D3.js force-directed graph.

### Architecture

- **Backend**: Python `http.server` on port 3889, single file, no dependencies
- **Frontend**: Self-contained HTML with inline CSS/JS, D3.js loaded from CDN
- **APIs**: `/api/stats`, `/api/index`, `/api/graph`, `/api/page?path=`, `/api/search?q=`

### Key Features

| Feature | Implementation |
|---------|---------------|
| Force-directed graph | D3.js with 30+ nodes, color=category, size=content volume |
| Node interaction | Click→open page, hover→highlight connected, drag to rearrange |
| Search | Backend word-scoring, frontend debounced input |
| Category filter | Button toggles per-category visibility |
| Markdown viewer | Simple JS renderer with `[[link]]` click handling |

### Deployment

```bash
cd ~/company && python3 scripts/llm-wiki-server.py &
# Visit http://localhost:3889
```

### Reference

For a complete implementation walkthrough (server code, frontend patterns, graph data construction, and known pitfalls), see `references/visual-knowledge-system.md`.

## Cross-Reference Quality Gate (check.py — implemented)

The quality gate is **already implemented** as `scripts/check.py`. This is not a design doc — it's a runnable CLI tool.

```bash
# Scan all .md files for [[link]] cross-references
python3 check.py --path ~/company/ --output ~/company/reports/kb-link-quality-report.md

# Scan with custom threshold (min 3 links per file)
python3 check.py --path ~/company/wiki/ --min-links 3 --json

# Quick check (files only)
python3 check.py --path ~/company/reports/
```

### Implemented Checks

| Check | What it does |
|-------|-------------|
| ✅ `[[link]]` scanning | Regex scans all .md files, excludes code blocks to avoid false positives |
| ✅ ≥N links threshold | Configurable min link count per file (default: 2, via `--min-links`) |
| ✅ Dead link detection | Verifies each `[[link]]` target resolves to an existing .md file |
| ✅ Bidirectional check | Detects when A→B but B does not link back to A |
| ✅ Code block exclusion | Strips ```...``` and inline `` content before counting |
| ✅ Directory exclusion | Auto-skips `node_modules/`, `__pycache__/`, `.git/` |
| ✅ Quality report | Generates `quality-report-latest.md` with per-file + per-directory stats |
| ✅ JSON output | `--json` flag for programmatic consumption |

### CLI Parameters

```bash
python3 check.py [--path DIR] [--min-links N] [--output FILE] [--json]
```

- `--path DIR` — Target directory (default: current dir)
- `--min-links N` — Minimum [[link]] references per file (default: 2)
- `--output FILE` — Write detailed report to file
- `--json` — Output as JSON for programmatic use

### Key Finding (2026-06-30 Audit)

First full audit of 116,001 .md files across ~/company/ and ~/.hermes/skills/ revealed **zero `[[link]]` cross-references** — every file is a knowledge silo. This is a P1 issue that should be addressed by:
1. Adding `[[link]]` recommendation to employee daily report templates
2. Core documents (SRS, architecture, quote templates) manually enriched with 2-3 cross-refs each
3. Weekly check.py run as CI gate

> Full audit details: `references/2026-06-30-cross-ref-audit.md`

## Auto-Compilation Engine (design — not implemented)

The following describes the **intended** `llm-wiki-engine.py` — a design doc for future implementation. The only currently implemented component is `scripts/check.py` (quality gate) above.

Create `llm-wiki-engine.py` — a Python CLI with these commands:

```bash
python3 llm-wiki-engine.py index     # Scan wiki/ → update index.json
python3 llm-wiki-engine.py quality   # Quality gates → report
python3 llm-wiki-engine.py compile   # new raw/ content → auto-compile to wiki/
python3 llm-wiki-engine.py sync      # published pages → BookStack API sync
python3 llm-wiki-engine.py watch     # Change detection → auto-trigger compile+index
python3 llm-wiki-engine.py rag       # Generate RAG chunks → rag-chunks.json
python3 llm-wiki-engine.py all       # Full pipeline (watch→index→quality→rag)
```

### auto-index

Scans all wiki/ pages, extracts YAML frontmatter (title, category, tags, status, created, updated), counts cross-references via `[[link]]` regex, and writes to `schema/meta/index.json`.

```python
def cmd_index():
    pages = []
    cross_refs_total = 0
    by_category = {}
    by_status = {}
    for f in find_markdown_files(WIKI_DIR):
        if "templates" in str(f): continue
        content = read_file(f)
        fm = parse_frontmatter(content)
        body = strip_frontmatter(content)
        refs = re.findall(r'\[\[([^\]]+)\]\]', body)
        entry = {
            "path": str(rel), "title": fm.get("title", f.stem),
            "category": fm.get("category", "unknown"), "tags": fm.get("tags", []),
            "status": fm.get("status", "draft"), "cross_refs": len(refs),
            "word_count": len(body.replace('\n', '')),
            "hash": hashlib.md5(content.encode()).hexdigest()[:12],
        }
        pages.append(entry)
    write_file(INDEX_FILE, json.dumps({"generated": datetime.now().isoformat(), "stats": {...}, "pages": pages}, ...))
```

### auto-quality (llm-wiki-engine.py — design only)

> **Note**: The cross-reference quality gate (`[[link]]` scanning, dead link detection, bidirectional check) is already implemented in `scripts/check.py`. This section describes the planned `llm-wiki-engine.py quality` command for frontmatter/word-count/Mermaid checks, which has NOT been implemented.

Checks each wiki page against these quality gates:

| Level | Check | Condition | Status |
|-------|-------|-----------|--------|
| 🔴 BLOCKER | frontmatter completeness | Missing required field `title`/`category`/`status` | Design |
| 🔴 BLOCKER | validity | Invalid status value | Design |
| 🟡 WARNING | word count | Concept/technique pages < 300 chars | Design |
| 🟡 WARNING | cross-refs | Published pages < 2 `[[links]]` | ✅ check.py |
| 🟡 WARNING | dead links | `[[link]]` target .md file not found | ✅ check.py |
| 🟡 WARNING | bidirectional | A→B but B doesn't →A | ✅ check.py |
| 🟡 WARNING | Mermaid | Concept pages without `mermaid` code block | Design |
| 🟡 WARNING | dates | Missing `created` or `updated` | Design |

Generates `quality-report-latest.md` with per-page status table.

### quality remediation workflow (via check.py)

After running `check.py --path DIR`, read the report and fix issues systematically. Common fixes by issue type:

**Fix #1: Missing cross-references (WARNING)**
Target: files with "link_count_below_N" or no `[[link]]` at all.
Add a "交叉引用" section at the end with 2+ `[[link]]` wiki-style links to related files.
🚨 **Format trap**: The quality gate checks for `[[page-name]]` (Obsidian/wiki format), NOT markdown `[text](url)` links. If you add `[Transformer](concept-transformer.md)`, the check still counts 0 refs. Use `[[concept-transformer]]` instead.
🚨 **Backtick trap**: `[[link]]` inside backticks (`` `[[link]]` ``) IS correctly counted by check.py (v2+) — the scanner preserves `[[...]]` inside inline code. If a file shows 0 links but you added `[[link]]` inside backticks, ensure you're running the latest version.

**Remediation flow:**
```bash
# 1. Run scan
python3 check.py --path ~/company/projects/ --min-links 2
# 2. Read report
cat quality-report-latest.md
# 3. Fix each file by adding `[[link]]` references
# 4. Re-run to verify
python3 check.py --path ~/company/projects/ --min-links 2
# 5. Repeat until PASS count stops improving
# 6. Weekly CI gate (optional cron)
```

**Prioritization:** P1 files without any links (quick win: add 1-2 refs), P2 files with dead links (remove or create target), P3 files with missing backlinks (add return link).

**Prioritization:** P0 BLOCKER frontmatter (each fix clears 4+ failures), P1 missing Mermaid, P2 missing cross-refs, P3 missing dates.

**Pitfall:** Only fix actual content pages, not test/stub pages. Delete test artifacts instead of fixing them.

### auto-compile

Scans `raw/` for new/changed `.md`/`.txt` files (excluding templates and README). Detects type from filename prefix (paper-/model-/technique-) and auto-creates a wiki page with minimal frontmatter.

```python
def cmd_compile(source_path=None):
    for src in sources:
        if "paper" in src_name: target_cat = "concepts"
        elif "model" in src_name: target_cat = "models"
        else: target_cat = "concepts"
        target = WIKI_DIR / target_cat / f"concept-{src_name}.md"
        if not fm:
            new_fm = {"title": src.stem, "category": target_cat.rstrip("s"),
                      "status": "draft", "sources": [str(rel)]}
            new_content = f"---\n{yaml.dump(new_fm)}---\n\n{content}"
```

### auto-watch

Detects three types of changes:
- New files in raw/ → triggers auto-compile
- New wiki files not in index → triggers index update
- Hash-changed wiki files → triggers quality check

### auto-sync

Reads published pages from index.json, converts to HTML via `strip_frontmatter()`, and creates/updates pages in BookStack via REST API.

```python
def cmd_sync(book_id=None, target_pages=None):
    for page in published_pages:
        body = strip_frontmatter(content)
        if existing_page:
            bs_api('PUT', f'/pages/{existing_page["id"]}', {"name": page["title"], "html": html_body})
        else:
            bs_api('POST', f'/books/{book_id}/pages', {"name": page["title"], "html": html_body})
```

### auto-rag

Splits each wiki page by `##` sections, creates structured chunks with metadata (source/title/category/tags/word_count), writes to `rag-chunks.json`.

## Bidirectional BookStack Sync Engine

Create `llm-wiki-sync.py` — a *separate* Python CLI from the compilation engine, dedicated to bidirectional sync between local markdown wiki and BookStack:

```bash
python3 llm-wiki-sync.py push       # Local → BookStack
python3 llm-wiki-sync.py pull       # BookStack → Local
python3 llm-wiki-sync.py sync       # Bidirectional (pull then push)
python3 llm-wiki-sync.py validate   # Self-validate + auto-fix
python3 llm-wiki-sync.py all        # Full pipeline (sync + validate)
```

### Architecture

```
┌──────────┐    ┌──────────────┐    ┌──────────────┐
│ 本地 .md  │◄──►│ 双向同步引擎  │◄──►│ BookStack API│
│ raw/wiki/ │    │              │    │ :8080        │
└──────────┘    └──────────────┘    └──────────────┘
                      │
               ┌──────┴──────┐
               │ 冲突检测      │
               │ · hash比对   │
               │ · 时间戳裁决  │
               │ · 自动修正    │
               └──────┬──────┘
                      │
               └── 自我校验 ──┘
```

### Markdown → BookStack HTML (`md_to_bs_html`)

Converts local markdown with YAML frontmatter to BookStack HTML with cartoon visual style:

| Source | Target |
|--------|--------|
| `--- yaml frontmatter ---` | `<h1>` title + `<span class="kb-badge">` category + tags |
| `## Title` | `<h2>Title</h2>` |
| `**bold**` | `<strong>bold</strong>` |
| `` `code` `` | `<code>code</code>` |
| ` ```mermaid ... ``` ` | `<pre class="mermaid">...</pre>` |
| `[[page\|text]]` | `<a href="/books/llm-wiki/page/slug">text</a>` |
| ` ```lang ... ``` ` | `<pre><code class="language-lang">...</code></pre>` |
| `✦ ✦ ✦ ✦ ✦` divider | Auto-injected in page header/footer |
| Page footer | `🤖 LLM Wiki · 自动同步 · {timestamp}` |

Category-to-badge mapping:
```python
PAGE_CATEGORY_MAP = {
    "concepts": {"icon": "🧠", "badge": "kb-badge-purple"},
    "models": {"icon": "🤖", "badge": "kb-badge-blue"},
    "techniques": {"icon": "🔧", "badge": "kb-badge-green"},
    "benchmarks": {"icon": "📊", "badge": "kb-badge-purple"},
    "tools": {"icon": "🛠️", "badge": "kb-badge-blue"},
    "practices": {"icon": "📝", "badge": "kb-badge"},
}
```

### BookStack HTML → Markdown (`bs_html_to_md`)

Reverse conversion extracting:
- Title from `<h1>`
- Category from `<span class="kb-badge">` icon+text
- Tags from remaining `<span class="kb-badge">` elements (filtering out category and date badges)
- Body content by stripping HTML tags and reversing the conversion

### Conflict Detection + Auto-Resolution

```python
# In sync-state.json, track per-page:
{
    "local_hash": "md5_of_markdown_body",
    "title": "Page Title",
    "last_push": "ISO timestamp",
    "last_pull": "ISO timestamp",
    "bs_page_id": 708
}

# During pull, detect conflicts:
page_state = state["pages"].get(local_path, {})
local_changed = page_state.get("local_hash", "") and page_state["local_hash"] != curr_hash
if local_changed and not force:
    # Timestamp-based resolution: newer wins
    last_push = page_state.get("last_push", "2000-01-01")
    bs_updated = detail.get("updated_at", "2000-01-01")
    if bs_updated > last_push:
        # BS version wins → overwrite local
    else:
        # Local version wins → skip pull
```

### Self-Validation (`cmd_validate`)

Checks three types of consistency deviation:
1. **Missing on BS**: Local file has no matching BookStack page → auto-create via POST /pages
2. **Missing locally**: BookStack page has no matching local .md → auto-pull and write
3. **Content mismatch**: Hash differs between local and BS page → push local version to BS

```python
def cmd_validate():
    # Get all BS pages (handles pagination via bs_list_pages)
    bs_map = {p["name"]: p for p in bs_list_pages(book_id)}
    
    for f in wiki_files:
        title = parse_fm(content)["title"]
        if title not in bs_map:
            # Auto-create BS page via POST /pages with book_id
        else:
            # Compare hash; if mismatch, push local to BS
    
    for name, bp in bs_map.items():
        if not local_exists:
            # Auto-pull from BS, convert to .md, write
```

### BookStack API Handling

- **Pagination**: `bs_list_pages(book_id)` handles pagination via offset/count loop (BookStack defaults to 100/page)
- **Correct endpoints**: POST /pages (not /books/{id}/pages) to create; GET /pages to list (with offset/count query params)
- **Shelf management**: PUT /shelves/{id} with "books" array to assign books
- **Token**: Bearer-style `Token {api_key}` header

### Sync State

Persisted in `schema/meta/sync-state.json`:
```json
{
    "last_sync": "ISO timestamp",
    "last_validation": "ISO timestamp",
    "stats": {"pushed": 3, "skipped": 2, "errors": 0},
    "pages": {
        "concepts/concept-transformer.md": {
            "local_hash": "md5_16char",
            "title": "Transformer 架构",
            "last_push": "ISO timestamp",
            "status": "published",
            "category": "concept",
            "bs_page_id": 710
        }
    }
}
```

### Cron Integration (extended)

Set up 3 cron jobs for auto-maintenance:

| Cron | Schedule | Command | Purpose |
|------|----------|---------|---------|
| Auto-Watch | `0 */2 * * *` | `python3 llm-wiki-engine.py watch` | Detect changes → auto-compile+index |
| Daily Sync+Validate | `0 */6 * * *` | `python3 llm-wiki-sync.py all` | Bidirectional sync + self-validate + auto-fix |
| Daily Compile+Sync | `0 2 * * *` | `python3 llm-wiki-engine.py compile && python3 llm-wiki-sync.py all && python3 llm-wiki-engine.py rag` | Full daily: compile raw→sync→RAG |
| Daily Quality | `0 6 * * *` | `python3 llm-wiki-engine.py quality && python3 llm-wiki-engine.py rag` | Quality check + RAG refresh |
| Weekly Full | `0 10 * * 0` | `python3 llm-wiki-engine.py all && python3 llm-wiki-sync.py all` | Full pipeline + BookStack sync |

### Engine Implementation Notes

- Use `read_json_or_yaml()` helper to handle both JSON and YAML index files
- JSX syntax requires `.jsx` extension for hook files containing JSX
- `changes = []` must be initialized before appending in watch function
- Auto-install `pyyaml` on first run if missing
- Use `hashlib.md5(content.encode()).hexdigest()[:12]` for change detection

## Wiki Page Standards

Each wiki/ page must follow this structure:

```
┌─────────────────────────────────┐
│   frontmatter (YAML)            │  Required fields per type
├─────────────────────────────────┤
│   # Title                       │  H1 matching frontmatter.title
├─────────────────────────────────┤
│   ## Overview                   │  2-3 sentence definition
├─────────────────────────────────┤
│   ## Core Principle             │  Mermaid diagram + explanation
├─────────────────────────────────┤
│   ## Key Features / Specs       │  Tables or lists
├─────────────────────────────────┤
│   ## Related Entries            │  ≥2 cross-refs via [[]]
├─────────────────────────────────┤
│   ## Sources                    │  raw/ tracing
└─────────────────────────────────┘
```

### Content Depth Levels
- **L1** (concept): Educational, ≤2000 chars
- **L2** (technique): Implementation, 3000-5000 chars
- **L3** (model): Archival, specs+evaluation+ecosystem
- **L4** (practice): Operational, steps+code+verification

### Type-Specific Requirements
| Type | Required Elements | Optional |
|------|------------------|----------|
| concept | Mermaid flowchart | Math formulas, timeline |
| model | Spec table + eval data | Architecture diagram, training config |
| technique | Flowchart + code example | Effect comparison, config table |
| benchmark | Results table + comparison | Eval settings, raw results |
| tool | Install command + usage | Config guide, perf test |
| practice | Steps + pitfalls | Key commands, scripts |

## Naming Conventions

### raw/ files
```
{prefix}-{date}-{keyword}.{ext}
prefix: paper- | doc- | ref- | blog- | code-
```

### wiki/ files
```
{type}-{keyword}.md
type: concept- | model- | technique- | bench- | tool- | practice-
```

### schema/ files
```
{domain}-{rule}.md
```

Rules: kebab-case, ASCII-only, ≤60 chars, no version in filename.

## Cross-Reference Rules

1. Each wiki page must have ≥2 `[[link]]` outbound refs
2. Bidirectional: if A refs B, B should ref A (via `related` field in frontmatter)
3. Depth: concepts→raw papers, techniques→concepts, models→techniques, benchmarks→models
4. Check for dead links: all `[[]]` paths must point to existing files

## Page Generation Standard

### Metadata (required)
```yaml
---
title: "Page Title"
category: devops
tags: ["tag1", "tag2"]
status: "draft|review|published|archived"
created: "YYYY-MM-DD"
updated: "YYYY-MM-DD"
---
```

### Type-specific fields
- concept: `prerequisites`, `related`
- model: `params`, `org`, `release`, `architecture`, `context`, `license`
- technique: `difficulty`, `sources`

### Status lifecycle
```
draft → review → published → archived
All can roll back to previous via revision
```

### Quality Gates (summary)
| Gate | Auto-Check |
|------|-----------|
| Frontmatter complete | YAML parser |
| ≥300 chars (concept/technique) | wc -m |
| ≥2 cross-refs | `grep '\[\['` |
| Status not draft | YAML parse |
| Concept has Mermaid | `grep '```mermaid'` |
| Dates filled | YAML parse |

## Pitfalls

- **index.json format**: Use JSON, not YAML, for machine-readability. If migrating from YAML, use `read_json_or_yaml()` helper.
- **JSX in .js files**: Hooks returning JSX must use `.jsx` extension.
- **Duplicate keys in object literals**: When building intent→action maps, ensure no duplicate keys.
- **Cron change detection**: `changes = []` must be initialized before the loop.
- **BookStack API quirks**: Shelf→book assignment requires direct DB insert into `bookshelves_books` table; POST /api/books silently ignores `shelf_id`.
- **BookStack API endpoints**: To create a page, use `POST /pages` with `book_id` in body (NOT `/books/{id}/pages` which only supports GET/HEAD). To list pages, use `GET /pages?offset=0&count=100` with pagination loop. BookStack returns max 100 items per page.
- **BookStack pagination**: Always use `bs_list_pages(book_id)` helper that loops through offset/count until empty. The `/books/{id}/pages` endpoint returns 404 for most books.
- **`links.md` sync corruption**: When BookStack bidirectional sync round-trips a `links.md` or `concept-links.md` page, the YAML frontmatter can get duplicated 3+ times in the local markdown file (each sync appends another copy). Symptoms: quality checker reports broken frontmatter, page renders incorrectly. Fix: strip all but the first `---...---` block and rewrite the file with a single clean frontmatter + body.
- **Markdown→HTML indentation**: BookStack HTML code blocks must use proper `\n` line breaks; use `<br>\n` for newlines in paragraphs.
- **Conflict detection**: Store `local_hash` (md5 of body content) AND `last_push` timestamp in sync-state.json. During pull, compare both hash AND timestamp to detect divergent edits.
- **Shelf creation**: Use `POST /shelves` to create, `PUT /shelves/{id}` with `"books": [book_id]` to assign books.
- **File hash detection**: Use `hashlib.md5(content.encode()).hexdigest()[:12]` for efficient change detection.
- **Raw→wiki filename mapping**: Only compile files NOT in templates/ or named README.md.
- **YAML date serialization**: `yaml.safe_load()` may return Python `date` objects from YAML frontmatter. These are NOT directly JSON-serializable. In the engine, convert all date-like objects to strings before `json.dumps()`:
  ```python
  for k, v in fm.items():
      if hasattr(v, 'isoformat'):
          fm[k] = str(v)
  ```
  Or use a custom JSON encoder: `class SafeEncoder(json.JSONEncoder): def default(self, obj): if hasattr(obj, 'isoformat'): return str(obj); return super().default(obj)`
- **Subagent frontmatter inconsistency**: delegate_task subagents creating wiki pages may use varying frontmatter fields (`tags`/`description` vs `status`/`created`/`updated`). Always run `quality` after batch generation and fix missing fields. The simplest fix: patch the YAML closing `---` to inject missing fields.

## Verification

```bash
# Test full pipeline
cd ~/projects/llm-wiki && python3 llm-wiki-engine.py all

# Verify index
python3 -c "import json; d=json.load(open('schema/meta/index.json')); print(f'Pages: {d[\"stats\"][\"total\"]}, Ref: {d[\"stats\"][\"cross_refs\"]}')"

# Verify RAG
python3 -c "import json; d=json.load(open('rag-chunks.json')); print(f'Chunks: {d[\"total_chunks\"]}')"

# Verify quality report
cat quality-report-latest.md | head -20

# Verify cron jobs
hermes cron list | grep "LLM Wiki"
```

## Feedback Engine Patches
*自动生成于 2026-07-16 02:02:04*

## Tool Recommendations (from trajectory feedback)

### patch
Trajectory analysis shows **patch** strongly correlates with high session scores.
- Use `patch` for targeted find-and-replace edits instead of sed/awk.
- Supports fuzzy matching with 9 strategies for robust edits.
- Auto-runs syntax checks after modification.
- Preferred for surgical code changes over full file rewrites.

### Guardrails
- Ensure `old_string` is unique in the file unless `replace_all=True`.
- Include enough surrounding context to guarantee uniqueness.
- Use `mode='patch'` for V4A multi-file patches.

### Efficiency Tips
- Combine multiple edits into a single V4A patch when possible.
- Use `replace_all=True` for bulk replacements of the same pattern.
- Preview changes with `--dry-run` mode before applying.

---
## Feedback Engine Patches
*自动生成于 2026-07-17 02:02:37*

## Tool Recommendations (from trajectory feedback)

### read_file
Trajectory analysis shows **read_file** strongly correlates with high session scores.
- Preferred over cat/head/tail in terminal.
- Use this for reading text files with line numbers and pagination.
- Supports offset and limit for large file navigation.

---
## Feedback Engine Patches
*自动生成于 2026-07-17 02:02:37*

## Tool Recommendations (from trajectory feedback)

### patch
Trajectory analysis shows **patch** strongly correlates with high session scores.
- Use `patch` for targeted find-and-replace edits instead of sed/awk.
- Supports fuzzy matching with 9 strategies for robust edits.
- Auto-runs syntax checks after modification.
- Preferred for surgical code changes over full file rewrites.

### Guardrails
- Ensure `old_string` is unique in the file unless `replace_all=True`.
- Include enough surrounding context to guarantee uniqueness.
- Use `mode='patch'` for V4A multi-file patches.

### Efficiency Tips
- Combine multiple edits into a single V4A patch when possible.
- Use `replace_all=True` for bulk replacements of the same pattern.
- Preview changes with `--dry-run` mode before applying.

---
## Feedback Engine Patches
*自动生成于 2026-07-21 08:58:12*

## Tool Recommendations (from trajectory feedback)

### write_file
Trajectory analysis shows **write_file** strongly correlates with high session scores.
- Use `write_file` to create new files or overwrite existing ones.
- Preferred over terminal heredoc for structured file creation.
- Automatically creates parent directories.

### Guardrails
- Always use absolute paths to avoid ambiguity.
- Creates parent directories — verify the intended path before writing.
- Overwrites entire file content — if you need targeted edits, use `patch` instead.

### Efficiency Tips
- Batch content creation: write whole files at once instead of appending line-by-line.
- For large files, consider splitting into multiple smaller files.
- Use `patch` for incremental updates to avoid full rewrites.

---
## Feedback Engine Patches
*自动生成于 2026-07-22 12:19:48*

## Tool Recommendations (from trajectory feedback)

### patch
Trajectory analysis shows **patch** strongly correlates with high session scores.
- Use `patch` for targeted find-and-replace edits instead of sed/awk.
- Supports fuzzy matching with 9 strategies for robust edits.
- Auto-runs syntax checks after modification.
- Preferred for surgical code changes over full file rewrites.

### Guardrails
- Ensure `old_string` is unique in the file unless `replace_all=True`.
- Include enough surrounding context to guarantee uniqueness.
- Use `mode='patch'` for V4A multi-file patches.

### Efficiency Tips
- Combine multiple edits into a single V4A patch when possible.
- Use `replace_all=True` for bulk replacements of the same pattern.
- Preview changes with `--dry-run` mode before applying.

---
## Feedback Engine Patches
*自动生成于 2026-07-22 12:19:49*

## Tool Recommendations (from trajectory feedback)

### read_file
Trajectory analysis shows **read_file** strongly correlates with high session scores.
- Preferred over cat/head/tail in terminal.
- Use this for reading text files with line numbers and pagination.
- Supports offset and limit for large file navigation.
