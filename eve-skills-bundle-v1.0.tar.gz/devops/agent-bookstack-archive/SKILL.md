---
name: agent-bookstack-archive
description: Automatically archive CMMI5 agent execution outputs (skill execution reports) to BookStack as detailed documentation pages. Scans agent output directories, groups reports by (agent, task), converts markdown to formatted HTML pages with skill metadata, and creates/updates chapters per agent.
category: devops
triggers:
  - "归档Agent产出 / archive agent outputs / 同步技能报告到知识库"
  - "agent执行记录归档到BookStack / CMMI5 pipeline output sync"
  - "批量创建Agent详情页面 / create detailed agent pages"
  - "BookStack技能详情同步 / skill execution detail pages"
  - "Agent skill output to BookStack / agent bookstack sync"
  - "CMMI5 pipeline output archival / 管道产出物归档"
  - "BookStack missing agent pages / 缺失页面补录"
  - "Agent产出可视化为文档 / agent output visualization"
  - "海航Agent执行记录 / haihang agent execution records"
  - "Book 814 sync / 海航AI-Agent执行记录同步"
permanent: false
locked: false
auto_enable: false
---

# agent-bookstack-archive — Agent执行产出归档与工程文档生成

## Overview

CMMI5 10-Agent管道执行后，每个Agent产生两类产出：
1. **Layer 1: 技能执行元数据** — markdown格式存放于 `~/projects/{project}/output/{AGENT}/skills/`，记录每个技能被调用时的参数、步骤、产出清单
2. **Layer 2: 真实交付文档** — 格式化的HTML页面存放在BookStack中，包含SRS、架构设计、项目章程等真正有内容的工程文档

本技能提供**两层次**的BookStack同步能力：
- **Layer 1 (归档)**: 将技能执行元数据markdown批量转为HTML页面，适合追踪Agent做了什么
- **Layer 2 (生成)**: 基于Agent领域知识直接生成真实的工程交付文档，配备精美卡通视觉风格，适合团队查阅

**重要区分**: Layer 1 (元数据归档) 和 Layer 2 (真实文档生成) 是两个不同概念。用户通常期望看到的是Layer 2——有实际项目内容的SRS、架构图、测试报告，而非"技能X被调用了Y次"的元数据日志。

**Class**: DevOps / Knowledge Management — Agent Archival & Doc Generation  
**Distinction**: 
- `bookstack-kb-architecture` = *设计*知识库结构(Shelf/Book/Chapter)
- `bookstack-update-sync` = *更新日志*条目同步
- `bookstack-mermaid-integration` = *渲染Mermaid图*
- **本技能** = *归档Agent产出* + *生成真实工程文档*

## Trigger Conditions

This skill applies when:
- CMMI5 pipeline agents (PM/REQ/ARCH/DEV/SEC/TEST/QA/CM/DOC/SPI) have completed execution
- Agent skill output files exist in the project's output directory
- User asks "为什么BookStack上看不到详细的Agent产出?" or "归档Agent执行记录"
- User asks "产出的内容没有实质内容/只是技能元数据" — 需要切换到Layer 2
- Multiple pipeline runs have created duplicate chapters/pages that need cleanup
- A new project is launched and its agent outputs need BookStack archival
- BookStack sync failed for some agents (PM/REQ common) and manual recovery needed
- Need to generate beautiful cartoon-styled engineering documents quickly

---

## Two-Layer Approach

### Layer 1: Skill Metadata Archival (元数据归档)

当用户问"归档Agent产出"，或者只需要追踪Agent的执行记录时，用此层次。

**输入**: `~/projects/{project}/output/{AGENT}/skills/{task}__{skill}.md`
**产出**: BookStack页面，每(Agent, Task)一个页面，包含所有技能的执行步骤、参数、产出清单

详见下方 Execution Flow。

### Layer 2: Real Deliverable Generation (真实文档生成)

当用户问"看不到详细文档/内容没有实质内容/需要真正的SRS"时，用此层次。每个Agent生成真正有项目特定内容的工程文档，而非技能调用记录。

**输入**: Agent的领域知识 + 项目背景
**产出**: BookStack页面，每(Agent, 文档类型)一个页面，包含真实内容和卡通视觉风格

### Per-Agent Document Template Structure

Below is the standard document set each agent should produce as real deliverables. Use the `build()` helper pattern (see Layer 2 helpers) for DRY page assembly.

| Agent | Documents | Key Sections | 
|-------|-----------|--------------|
| **PM** | 项目章程, WBS, 甘特图, 风险登记册 | Grid4 metrics, milestone table, Mermaid tree/gantt, risk matrix |
| **REQ** | SRS(IEEE830), 用例模型, RTM, 竞品分析 | 4-section SRS, use case Mermaid + table, RTM trace, SWOT |
| **ARCH** | C4架构, API设计, ER模型, 4 ADRs | Context+Container Mermaid, endpoint table, ER diagram, decision records |
| **DEV** | 代码架构, API契约 | Directory Mermaid, module table, contract endpoint list |
| **SEC** | STRIDE威胁模型, SAST扫描 | 6-category STRIDE table, vulnerability matrix |
| **TEST** | 测试计划, 测试报告 | 4-level test matrix, metrics dashboard (pass/coverage/latency) |
| **QA** | 质量门禁, 代码审查 | Gate check table (PASS/FAIL), code issue list |
| **CM** | 基线清单, 版本标签 | Asset manifest table, hash verification |
| **DOC** | 用户手册, 部署指南 | Quick start, component requirements table |
| **SPI** | DORA指标, 改进建议 | 4 DORA metrics, CMMI5 assessment 10x100% |

### CMMI5 Content Depth Standards (Layer 2 Documents)

"Too simple" is the most common user complaint. CMMI5-compliant documents must be **substantive** — quantified, structured, and traceable. Use these patterns:

#### Pattern 1: Document Control Header

Every page must have a document header with tracking metadata:

```python
def doc_header(doc_id, title, subtitle, version="V1.0", author="Hermes PM Agent"):
    badges = (
        f'<span class="kb-badge kb-badge-lg">{doc_id}</span>'
        f'<span class="kb-badge kb-badge-green kb-badge-lg">{version}</span>'
        f'<span class="kb-badge kb-badge-blue kb-badge-lg">{now}</span>'
        f'<span class="kb-badge kb-badge-yellow kb-badge-lg">{author}</span>'
    )
    return f'''<div class="kb-card-comic" style="text-align:center;padding:30px 20px;">
  <div style="font-size:48px;margin-bottom:10px;">📄</div>
  <h1 style="color:#2d3436;font-size:1.8em;margin:8px 0;font-weight:800;">{title}</h1>
  <p style="color:#636e72;font-size:1em;margin:6px 0;">{subtitle}</p>
  <div style="margin:14px 0;">{badges}</div>
  <div style="margin-top:12px;padding:8px 16px;background:#fff3e0;border:1px dashed #fdcb6e;display:inline-block;border-radius:8px;">
    <span style="font-weight:600;color:#e17055;">{doc_id} | {version} | {now}</span>
  </div>
</div>'''
```

Document ID format: `{HH}-{AGENT}-{DOCTYPE}-{SEQ}` — e.g. HH-PM-PC-001, HH-REQ-SRS-001, HH-ARCH-API-001.

#### Pattern 2: Quantified KPIs (Not Just Descriptions)

BAD: `<p>项目目标是提升购票转化率</p>` — qualitative, unmeasurable
GOOD: Tables with numeric targets, current values, and thresholds:

```python
T(["目标维度","具体目标","成功标准(KPI)","时限"],[
    ["业务","AI购票覆盖全渠道","购票转化率≥35%","2026-Q3"],
    ["技术","构建NLP+推荐引擎","意图识别率≥92%","2026-Q2"],
    ["质量","全过程CMMI5合规","过程域通过率100%","2026-Q2"]
])
```

Every table must have **measurable columns** (KPI, threshold, current value, status).

#### Pattern 3: Risk Assessment with P×I Scoring

Use probability × impact scoring with 8+ risk items:

```python
T(["ID","风险描述","概率(P)","影响(I)","P×I","等级","应对策略","负责人"],[
    ["R1","航司API不稳定/限频","0.7","0.8","0.56","🔴 严重","多源冗余+降级+缓存策略","DEV"],
    ["R2","NLU意图识别准确率不足","0.5","0.7","0.35","🟡 中","兜底搜索+引导式对话+人工客服","AI"],
    # ... 6-8 rows minimum
])
```

Thresholds: P×I ≥ 0.30 = 🔴 严重, 0.15-0.29 = 🟡 中, < 0.15 = 🟢 低

#### Pattern 4: Weighted Quality Gate Scoring

Each gate item has a weight, current score, and weighted score:

```python
T(["门禁项","测量指标","当前值","阈值","权重","得分","状态"],[
    ["测试通过率","全部测试通过百分比","92.3%","≥90%","25","23.1","✅ PASS"],
    ["代码覆盖率","行覆盖率","87.3%","≥80%","20","17.5","✅ PASS"],
    ["高危漏洞数","CRITICAL+HIGH数量","3","<3","25","0","❌ FAIL"],
    # ... 5 items minimum
    ["**综合**","**质量评分**","**70.6/100**","**≥80**","100","70.6","**❌ 未通过**"]
])
```

#### Pattern 5: Full Traceability Chains

Requirements must be traced through design → code → test:

```python
T(["需求ID","描述","模块","优先级","设计文档","代码模块","测试用例","状态"],[
    ["F-001","智能航班查询","G1-搜索","P0","ARCH-1 架构设计","app/services/search.py","TC-001~010","✅ 已批准"],
    # ... all requirements
])
```

#### Document-Specific Section Structures

Each document type follows a proven section plan. Below is the complete map.

**PM-1 项目章程** (6 sections):
1. S("📊 1. 项目概要") → G4 grid (budget/team/schedule/CMMI level)
2. S("📌 2. 项目背景与目标") → C() with 3 paragraphs (background/goal/scope)
3. S("🎯 3. 项目目标与KPI") → T() with 5 rows (business/tech/quality/experience/financial)
4. S("👥 4. 项目组织与干系人") → T() with 6 rows (Sponsor/PM/PO/TechLead/DEV/QA)
5. S("📅 5. 里程碑计划") → T() with 4 rows (M1-M4, dates, deliverables, acceptance criteria)
6. S("⚠️ 6. 假设与约束") → C() with assumptions + constraints

**PM-2 WBS** (3 sections):
1. S("📊 1. WBS树形图") → M() with 6 main branches, 24+ leaf nodes
2. S("📋 2. WBS词典") → T() with 14 rows (each: WBS/name/description/hours/owner/deliverable)
3. S("📊 3. 工作量分布") → T() with 6 phases (total hours/percentage)

**PM-4 风险登记册** (3 sections):
1. S("📊 1. 风险登记册") → T() with 8 rows (ID/description/category/P/I/P×I/level/strategy/owner)
2. S("📈 2. 风险热力图分布") → C() with risk summary counts
3. S("📋 3. 风险应对计划") → T() with 4 specific mitigation plans (trigger/owner/contingency)

**REQ-1 SRS规格说明书** (5 sections):
1. S("📌 1. 引言") → C() with purpose/scope/definitions
2. S("📋 2. 总体描述") → C() with product positioning/user profile/constraints/assumptions
3. S("⚙️ 3. 功能需求") → T() with 8 rows (ID/module/description/input/output/priority)
4. S("🔒 4. 非功能需求") → T() with 8 rows (ID/category/description/metric/priority)
5. Ti() with standard reference

**QA-1 质量门禁** (2 sections):
1. S("📊 1. 质量门禁检查项") → T() with 6 rows (item/metric/current/threshold/weight/score/status) + W() on failure
2. S("📋 2. 改进计划") → T() with 3 rows (improvement/target/date/owner)

**SEC-1 STRIDE威胁模型** (3 sections):
1. S("📊 1. STRIDE威胁分析矩阵") → T() with 6 rows (STRIDE category/threat/component/risk/vector/mitigation)
2. S("🔐 2. 安全控制矩阵") → T() with 6 control domains
3. S("⚠️ 3. 安全风险评级") → T() with severity count summary

**SPI-1 DORA效能指标** (2 sections):
1. S("📊 1. DORA四指标") → T() with 4 rows (metric/current/benchmark/rating/direction)
2. S("📊 2. CMMI5过程域评估") → T() with 16 rows (process area/maturity/completion/deliverables/status)

#### Content Depth Checklist

Before publishing a Layer 2 document, verify:
- [ ] Document ID present (HH-{AGENT}-{TYPE}-001)
- [ ] Version/badge bar present
- [ ] At least 4 sections per document (avg 6)
- [ ] Tables have 5+ rows each (avg 8)
- [ ] Tables have 6+ columns for complex documents
- [ ] Quantified KPIs present (numbers, percentages, thresholds)
- [ ] At least one Mermaid diagram per document where applicable
- [ ] Measurable success criteria, not just qualitative descriptions
- [ ] Traceability (requirement→design→code→test) for REQ documents
- [ ] Risk scoring (P×I with color-coded levels) for PM documents
- [ ] Tip box with document control note

### BookStack Structure (Both Layers)

Each agent gets a chapter in the dedicated book. Each (agent, doc-type) combination gets one page.

```
📖 项目-Agent执行记录 (Book)
├── 📊 项目管理 (Chapter)          4 pages
├── 📋 需求工程 (Chapter)          4 pages
├── 🏗️ 系统架构 (Chapter)          4 pages
├── 💻 开发实现 (Chapter)          2 pages
├── 🛡️ 安全合规 (Chapter)          2 pages
├── 🧪 测试验证 (Chapter)          2 pages
├── ✅ 质量保证 (Chapter)          2 pages
├── 📦 配置管理 (Chapter)          1-2 pages
├── 📚 文档生成 (Chapter)          2 pages
└── 📈 过程改进 (Chapter)          2 pages
```
Total: 25-27 pages across 10 chapters.

### Layer 2: Efficient Generation Pattern (build() Helper)

For generating all agent documents with real content, use this pattern to avoid repetitive HTML string concatenation. Each page is built from a list of section descriptors:

```python
# Section type codes:
# 'D' = divider (kb-cartoon-divider)
# 'S' = section title (kb-section-title)
# 'C' = card content (kb-card-comic)
# 'T' = table (kb-table) with (headers, rows) tuple
# 'M' = mermaid diagram
# 'Ti' = tip box with (title, content)
# 'W' = warning box with (title, content)
# 'G' = grid4 metrics with 4-tuple items

def B(e, t, s, badges):
    """Banner - matches existing project doc style with badges"""
    bgs = " ".join('<span class="kb-badge kb-badge-lg '+c+'">'+l+'</span>' for l,c in badges)
    return '<div class="kb-card-comic" style="text-align:center;padding:30px 20px;">'\
        '<div style="font-size:48px;margin-bottom:10px;">'+e+'</div>'\
        '<h1 style="color:#2d3436;font-size:1.8em;margin:8px 0;font-weight:800;">'+t+'</h1>'\
        '<p style="color:#636e72;font-size:1em;margin:6px 0;">'+s+'</p>'\
        '<div style="margin:14px 0;">'+bgs+'</div></div>'

def D(): return '<div class="kb-cartoon-divider">\u2708\ufe0f \u2708\ufe0f \u2708\ufe0f</div>'
def S(t): return '<div class="kb-section-title">'+t+'</div>'
def C(c): return '<div class="kb-card-comic">'+c+'</div>'
def T(h,rows): return '<table class="kb-table"><tr>'+"".join("<th>"+x+"</th>" for x in h)+"</tr>"+"".join("<tr>"+"".join("<td>"+c+"</td>" for c in r)+"</tr>" for r in rows)+'</table>'
def M(c): return '<div class="mermaid" style="background:#FFFFFF;padding:16px;">'+c+'</div>'
def Ti(t,c): return '<div class="kb-tip"><strong>\U0001f4a1 '+t+':</strong> '+c+'</div>'

def build(e, t, s, badges, secs):
    """Assemble a complete page from section descriptors."""
    h = B(e,t,s,badges)
    for sec in secs:
        tp=sec[0]
        if tp=='D': h+=D()
        elif tp=='S': h+=S(sec[1])
        elif tp=='C': h+=C(sec[1])
        elif tp=='T': h+=T(sec[1],sec[2])
        elif tp=='M': h+=M(sec[1])
        elif tp=='Ti': h+=Ti(sec[1],sec[2])
        elif tp=='W': h+=W(sec[1],sec[2])
        elif tp=='G': h+=G4(sec[1])
    return h

# Example usage:
page_html = build("\U0001f39c", "Project Charter", "Subtitle", [("Badge1",""), ("V1.0","kb-badge-green")], [
    ("D",),
    ("S", "Section Title"),
    ("T", ["Header1","Header2"], [["Row1Col1","Row1Col2"]]),
    ("M", "graph TD\\n  A-->B"),
])
```

### CRITICAL Pitfall: Function Name Conflict

Do NOT name the page creation function `page()` — it clashes with Python built-in names and creates confusing scope issues when variables like `page = build(...)` are used. Name it `mkpg()`, `make_pg()`, or `create_page()`:

```python
# GOOD:
def mkpg(ch_id, name, html):
    r = api('POST', '/pages', {"book_id":814, "chapter_id":ch_id, "name":name[:190], "html":html})
    return r.get('id')

# BAD - 'page' variable shadows function:
def page(...): ...
p = page(...)  # Confusing!
```

### Layer 2: Batch Generation Cleanup

Before generating Layer 2 documents, always clean up existing chapters to avoid duplicates from previous runs:

```python
# Step 1: Identify duplicates by (agent, task)
groups = defaultdict(list)
for c in chapters:
    key = extract_agent_task_key(c)  # e.g., "PM_PM-1"
    groups[key].append(c['id'])

# Step 2: Keep only the newest (highest ID) per group
for key, ids in groups.items():
    keep, *delete = sorted(ids, reverse=True)
    for cid in delete:
        api('DELETE', f'/chapters/{cid}')

# Step 3: Delete pages in duplicate chapters before deleting chapters
for c in chapters_to_delete:
    for p in c.get('pages', []):
        api('DELETE', f'/pages/{p["id"]}')
    api('DELETE', f'/chapters/{c["id"]}')
```

见下方 "Layer 2: Document Generation Flow"。

---

## Architecture

### Directory Structure (Layer 1)

```
~/projects/{project}/output/{AGENT}/
├── skills/
│   ├── {task}__{skill_name_1}.md    # Skill execution report
│   ├── {task}__{skill_name_2}.md
│   └── ...
├── artifacts/                        # Other agent artifacts
└── reports/                          # Agent reports
```

### BookStack Structure (Both Layers)

Each agent gets a chapter in the dedicated book. Each (agent, task/doc-type) combination gets one page.

```
📖 项目-Agent执行记录 (Book)
├── 📊 项目管理 (Chapter)
│   ├── 📄 PM/项目章程                    (Layer 2 - 真实文档)
│   ├── 📄 PM/WBS工作分解                 (Layer 2)
│   ├── 📄 PM/甘特图排期                  (Layer 2)
│   └── 📄 PM/风险登记册                  (Layer 2)
├── 📋 需求工程 (Chapter)
│   ├── 📄 REQ/SRS需求规格说明书           (Layer 2 - IEEE 830)
│   ├── 📄 REQ/用例模型                    (Layer 2)
│   ├── 📄 REQ/需求追踪矩阵               (Layer 2)
│   └── 📄 REQ/竞品分析                   (Layer 2)
├── 🏗️ 系统架构 (Chapter)
│   ├── 📄 ARCH/系统架构设计               (Layer 2 - C4)
│   ├── 📄 ARCH/API接口设计                (Layer 2)
│   ├── 📄 ARCH/数据库ER模型               (Layer 2)
│   └── 📄 ARCH/架构决策记录               (Layer 2)
├── 💻 开发实现 (Chapter)
│   ├── 📄 DEV/代码结构                    (Layer 2)
│   └── 📄 DEV/API契约                     (Layer 2)
├── 🛡️ 安全合规 (Chapter)
│   ├── 📄 SEC/威胁模型                    (Layer 2)
│   ├── 📄 SEC/SAST扫描报告                (Layer 2)
│   └── 📄 SEC/依赖审计                    (Layer 2)
├── 🧪 测试验证 (Chapter)
│   ├── 📄 TEST/测试计划                   (Layer 2)
│   ├── 📄 TEST/测试用例                    (Layer 2)
│   └── 📄 TEST/测试报告                    (Layer 2)
├── ✅ 质量保证 (Chapter)
│   ├── 📄 QA/质量门禁报告                  (Layer 2)
│   ├── 📄 QA/缺陷报告                      (Layer 2)
│   └── 📄 QA/代码审查                      (Layer 2)
├── 📦 配置管理 (Chapter)
│   ├── 📄 CM/基线清单                      (Layer 2)
│   └── 📄 CM/版本标签                      (Layer 2)
├── 📚 文档生成 (Chapter)
│   ├── 📄 DOC/用户手册                     (Layer 2)
│   ├── 📄 DOC/API文档                      (Layer 2)
│   └── 📄 DOC/部署指南                     (Layer 2)
└── 📈 过程改进 (Chapter)
    ├── 📄 SPI/DORA效能指标                 (Layer 2)
    ├── 📄 SPI/CMMI5评估                    (Layer 2)
    └── 📄 SPI/改进建议                     (Layer 2)
```

---

## Layer 1: Skill Metadata Archive Flow

### Phase 1: Audit — Compare local files vs BookStack pages

```python
import os, json, urllib.request
from collections import defaultdict

TOKEN = "token_id:token_secret"
AUTH = f"Token {TOKEN}"
BASE = "http://localhost:8080/api"
PROJECT_ROOT = os.path.expanduser("~/projects/haihang-agent")

def api(method, path, data=None):
    body = json.dumps(data).encode() if data else None
    req = urllib.request.Request(f"{BASE}{path}", data=body,
        headers={'Authorization': AUTH, 'Content-Type': 'application/json'},
        method=method)
    resp = urllib.request.urlopen(req, timeout=15)
    return json.loads(resp.read().decode()) if resp.status != 204 else {"success": True}

# Step 1: Collect local agent output files
local_files = defaultdict(lambda: defaultdict(list))
for agent in sorted(os.listdir(f"{PROJECT_ROOT}/output")):
    skills_dir = f"{PROJECT_ROOT}/output/{agent}/skills"
    if not os.path.isdir(skills_dir): continue
    for f in sorted(os.listdir(skills_dir)):
        if '__' not in f or not f.endswith('.md'): continue
        task = f.split('__')[0]
        local_files[agent][task].append(os.path.join(skills_dir, f))

# Step 2: Collect existing BookStack pages
book = api('GET', '/books/{BOOK_ID}')
existing_pages = set()
for c in book.get('contents', []):
    for p in c.get('pages', []):
        existing_pages.add(p['name'])

# Step 3: Identify missing pages
missing = []
for agent, tasks in sorted(local_files.items()):
    for task in sorted(tasks.keys()):
        page_name = f"📄 {agent}/{task} — 技能详情"
        if not any(page_name in p for p in existing_pages):
            missing.append((agent, task))
```

### Phase 2: Build Chapter Mapping

CRITICAL: The `AGENT_CHAPTERS` dict must include ALL 10 agents. PM is commonly missed.

```python
AGENT_CHAPTERS = {
    "PM": "📊 项目管理 - Agent执行记录",
    "REQ": "📋 需求工程 - Agent执行记录",
    "ARCH": "🏗️ 系统架构 - Agent执行记录",
    "DEV": "💻 开发实现 - Agent执行记录",
    "SEC": "🛡️ 安全合规 - Agent执行记录",
    "TEST": "🧪 测试验证 - Agent执行记录",
    "QA": "✅ 质量保证 - Agent执行记录",
    "CM": "📦 配置管理 - Agent执行记录",
    "DOC": "📚 文档生成 - Agent执行记录",
    "SPI": "📈 过程改进 - Agent执行记录",
}
```

### Phase 3: Get or Create Chapters (CRITICAL — Use Full Name Match)

```python
CHAPTER_IDS = {}  # Module-level cache

def get_or_create_chapter(agent_id, book_id=814):
    """Get existing or create chapter for this agent.
    
    CRITICAL: Uses AGENT_CHAPTERS dict to match chapter names EXACTLY.
    Substring match (agent_id in c['name']) fails for Chinese chapter names
    because e.g. 'PM' is not in '项目管理 - Agent执行记录'.
    This creates a new chapter EVERY call -> duplicates -> cycle error.
    """
    expected_name = AGENT_CHAPTERS.get(agent_id)
    
    # 1. Check cache (with verification)
    if agent_id in CHAPTER_IDS:
        verify = api('GET', f'/chapters/{CHAPTER_IDS[agent_id]}')
        if 'error' not in verify:
            return CHAPTER_IDS[agent_id]
        del CHAPTER_IDS[agent_id]
    
    # 2. Match by FULL NAME, with slug fallback
    book = api('GET', f'/books/{book_id}')
    for c in book.get('contents', []):
        if c['type'] != 'chapter':
            continue
        if expected_name and c['name'] == expected_name:
            CHAPTER_IDS[agent_id] = c['id']
            return c['id']
        if agent_id.lower() in c.get('slug', '').lower():
            CHAPTER_IDS[agent_id] = c['id']
            return c['id']
    
    # 3. Create new chapter
    ch_name = expected_name or f'{agent_id} - Agent执行记录'
    chapter = api('POST', '/chapters', {'book_id': book_id, 'name': ch_name})
    if 'error' not in chapter:
        CHAPTER_IDS[agent_id] = chapter['id']
        return chapter['id']
    
    # 4. Name collision fallback
    if 'already exists' in str(chapter).lower() or 'duplicate' in str(chapter).lower():
        book2 = api('GET', f'/books/{book_id}')
        for c in book2.get('contents', []):
            if c['type'] == 'chapter' and c['name'] == ch_name:
                CHAPTER_IDS[agent_id] = c['id']
                return c['id']
    return None
```
```

### Phase 4: Convert Markdown Skills to BookStack HTML
Each skill report markdown file follows this format:
```
# Skill Execution: {skill_name}
**Agent**: {agent}
**Task**: {task}
**Description**: {desc}
**Executed**: {timestamp}

## Metadata
| Key | Value |
|-----|-------|
| name | ... |
| category | ... |
| ... | ... |

## Execution Steps (N)
1. Step 1: ...
2. Step 2: ...

## Expected Outputs (N)
- Output 1
- Output 2

## Context
- **task_name**: {task}
- **project**: ...

## Execution Result
- **Status**: ✅ Completed
```

Convert to HTML with this pattern (each skill gets a card):

```python
def md_to_html(md):
    """Simple markdown to HTML for our specific file format."""
    import re
    html = md
    html = re.sub(r'`([^`]+)`', r'<code>\1</code>', html)
    html = re.sub(r'\*\*([^*]+)\*\*', r'<strong>\1</strong>', html)
    html = re.sub(r'^### (.+)$', r'<h4>\1</h4>', html, flags=re.MULTILINE)
    html = re.sub(r'^## (.+)$', r'<h3>\1</h3>', html, flags=re.MULTILINE)
    # Tables: | A | B | -> <table>...
    html = re.sub(r'\|(.+)\|\n\|[-| ]+\|\n((?:\|.+\|\n?)*)', _table_repl, html)
    # Lists
    html = re.sub(r'^\d+\.\s+(.+)$', r'<li>\1</li>', html, flags=re.MULTILINE)
    html = re.sub(r'^\*\s+(.+)$', r'<li>\1</li>', html, flags=re.MULTILINE)
    # Wrap consecutive <li> in <ul>
    ...  # (handle list wrapping logic)
    # Paragraphs
    ...
    return html

def build_skill_page_html(agent, task, skill_files):
    """Build a complete BookStack page HTML for one task with all skills."""
    sections = []
    for sf in sorted(skill_files):
        with open(sf) as f:
            content = f.read()
        # Parse key fields from markdown
        name = re.search(r'^# Skill Execution: (.+)$', content, re.M).group(1)
        desc = re.search(r'\*\*Description\*\*: (.+)', content).group(1)
        executed = re.search(r'\*\*Executed\*\*: (.+)', content).group(1)
        steps_html = extract_section(content, "Execution Steps")
        outputs_html = extract_section(content, "Expected Outputs")
        meta_html = extract_metadata_table(content)
        
        section_html = f'''
<div class="kb-card" style="margin:16px 0;padding:16px;background:#1a1a2e;border-radius:8px;border-left:4px solid #6c5ce7;">
  <h3 style="color:#6c5ce7;margin-top:0;">🔧 {name}</h3>
  <p style="color:#b2bec3;">{desc}</p>
  <p style="color:#636e72;font-size:0.9em;">📅 {executed}</p>
  {meta_html}
  <h4>📋 执行步骤</h4>
  {steps_html}
  <h4>📦 预期产出</h4>
  {outputs_html}
</div>'''
        sections.append(section_html)
    
    return f'''<h2>📄 {agent}/{task} — 详细技能产出</h2>
<div class="kb-card-glass" style="text-align:center;">
  <h3 style="color:#6c5ce7;">{agent} Agent · {task}</h3>
  <p style="color:#636e72;">{len(skill_files)}个技能模块</p>
</div>
{''.join(sections)}
<div class="kb-tip">💡 此页面由自动化归档脚本生成。</div>'''
```

### Phase 5: Create Pages in BookStack

```python
for agent, tasks in missing:
    ch_id = get_or_create_chapter(agent)
    for task in sorted(tasks.keys()):
        skill_files = local_files[agent][task]
        html = build_skill_page_html(agent, task, skill_files)
        display_name = f"📄 {agent}/{task} — 技能详情 ({len(skill_files)}个模块)"
        result = api('POST', '/pages', {
            'book_id': BOOK_ID,
            'chapter_id': ch_id,
            'name': display_name[:190],
            'html': html,
        })
        if 'error' not in result:
            print(f"  ✅ {agent}/{task}: page_id={result['id']}")
        else:
            print(f"  ❌ {agent}/{task}: {result['error'][:80]}")
        time.sleep(0.3)  # Rate limiting
```

## Common Failure Modes & Fixes

**Root causes** (two independent failure modes):

| Cause | Description | Fix |
|-------|-------------|-----|
| PM scheduler bypass | `pm_scheduler.py` calls skills directly, does NOT use `agent_base.py.run()` → no `bookstack_sync.create_agent_page()` called | Add explicit `bookstack_sync` call to `pm_scheduler.py`, or refactor PM to use `agent_base` subclass |
| Exception skips sync | `agent_base.py.run()` has try/except around `execute()`. If `execute()` throws (e.g., DB lock), sync code after the try block is skipped entirely | Refactor to use "partial completion" pattern: capture exception but still call BookStack sync |

**Detection**: Run `agent_bridge.py list tasks` — if PM shows no BookStack pages (check `ls ~/projects/haihang-agent/output/PM/skills/` vs Book 814 pages), run Phase 1 audit.

### Failure 2: AGENT_CHAPTERS missing agents

`bookstack_sync.py` had only 9 agents in `AGENT_CHAPTERS` (PM was missing). When PM tried to create a chapter, it used fallback name `"PM - Agent执行记录"` without emoji prefix.

**Fix**: Ensure `AGENT_CHAPTERS` dict has all 10 agents:
```python
AGENT_CHAPTERS = {
    "PM": "📊 项目管理 - Agent执行记录",  # ← Most commonly forgotten
    "REQ": "📋 需求工程 - Agent执行记录",
    ...
}
```

### Failure 3: Duplicate chapters from multiple runs

Each pipeline run creates chapters with unique IDs. Over multiple runs, Book 814 accumulates duplicate chapters (same agent, same task → different chapter IDs), plus thousands of orphaned entity rows.

**Fix A: API-based dedup (light cleanup):**
```python
# Group chapters by (agent, task), keep newest (highest ID), delete rest
groups = defaultdict(list)
for c in chapters:
    key = extract_agent_task_key(c)
    groups[key].append(c['id'])

for key, ids in groups.items():
    keep, *delete = sorted(ids, reverse=True)  # Keep highest ID (newest)
    for cid in delete:
        api('DELETE', f'/chapters/{cid}')
```

**Fix B: DB-level mass cleanup (heavy — for 100+ orphaned pages):**
When 10+ pipeline runs have created 100+ duplicate pages and 50+ stale chapters, use direct MariaDB cleanup:
```sql
-- Step 1: Keep only latest pipeline run entities
-- Define keep IDs for the latest run's chapters
DELETE FROM entity_page_data WHERE page_id IN (
  SELECT id FROM entities WHERE type='page' AND book_id=814 AND id NOT IN ({keep_pages})
);
DELETE FROM entities WHERE type='page' AND book_id=814 AND id NOT IN ({keep_pages});
DELETE FROM entities WHERE type='chapter' AND book_id=814 AND id NOT IN ({keep_chapters});

-- Step 2: Clean orphaned pages (child references deleted chapters)
DELETE FROM entity_page_data WHERE page_id IN (
  SELECT id FROM entities WHERE type='page' AND book_id=814 
  AND chapter_id NOT IN (SELECT id FROM entities WHERE type='chapter' AND book_id=814)
);
DELETE FROM entities WHERE type='page' AND book_id=814 
  AND chapter_id NOT IN (SELECT id FROM entities WHERE type='chapter' AND book_id=814);

-- Step 3: Verify cleanup counts
SELECT COUNT(*) as remaining_pages FROM entities WHERE type='page' AND book_id=814;
SELECT COUNT(*) as remaining_chapters FROM entities WHERE type='chapter' AND book_id=814;
```
Uses `/home/yestin/opt/mariadb/bin/mysql --socket=/tmp/mariadb.sock -u root bookstack` for socket auth.

**Critical:** Ensure `keep_pages` includes skill detail pages (858-881) and base PM pages (855-856, 885-890) that have unique content not regenerated by the latest pipeline run.

### Failure 4: Misleading error messages on completed tasks

`agent_tasks` table may show `error` field with old failure messages even after status is `completed`. This happens when a task is manually set to completed after failing.

**Fix**:
```python
conn.execute("UPDATE agent_tasks SET error = NULL WHERE status='completed' AND error IS NOT NULL")
```

### Failure 6: BookStack "would create a cycle" error on page creation

When `POST /pages` returns `"Setting X as parent of X would create a cycle"`:

| Root Cause | Detection | Fix |
|-----------|-----------|-----|
| **Stale chapter cache** — `get_or_create_chapter()` caches chapter IDs in a module-level dict. If a chapter is deleted (e.g., duplicate cleanup), the cached ID becomes invalid. When used as `chapter_id`, BookStack may interpret it as the page's own ID | Compare cached IDs against current BookStack chapters | In `get_or_create_chapter()`, verify cached chapters before returning: `verify = api('GET', f'/chapters/{cached_id}'); if 'error' in verify: del cache; re-fetch all chapters` |
| **Entity ID collision** — In rare cases, BookStack's entity system may map a chapter ID to a page's internal ID | Create page fails with cycle error | Add fallback: if page creation with `chapter_id` fails with 'cycle' or 'parent', retry without `chapter_id` (pure book-level page) |
| **Substring match failure in multilingual names** — `agent_id in c['name']` checks if e.g. `"PM" in "项目管理 - Agent执行记录"` → FALSE because chapter names use Chinese, not English acronyms | Every call creates a new chapter → duplicates → eventually cycle error | Match by full chapter name from `AGENT_CHAPTERS` (not substring), with slug fallback |

**Root Cause Deep Dive — Substring Match Failure:**

The most common root cause is that `get_or_create_chapter()` uses `agent_id in c['name']` (substring check), but chapter names use Chinese text that does not contain English agent IDs:

```
# AGENT_CHAPTERS defines:
"PM": "项目管理 - Agent执行记录"
# But check is: "PM" in "项目管理 - Agent执行记录" -> FALSE
# Since no match found -> creates new chapter EVERY time
# Multiple runs -> duplicate chapters -> cycle error
```

**Fixed `get_or_create_chapter()` pattern:**
```python
CHAPTER_IDS = {}  # Module-level cache

def get_or_create_chapter(agent_id):
    # 0. Use AGENT_CHAPTERS dict for exact name lookup
    expected_name = AGENT_CHAPTERS.get(agent_id)
    
    # 1. Check cache (with verification)
    if agent_id in CHAPTER_IDS:
        verify = _api('GET', f'/chapters/{CHAPTER_IDS[agent_id]}')
        if "error" not in verify:
            return CHAPTER_IDS[agent_id]
        del CHAPTER_IDS[agent_id]  # Stale

    # 2. Match by FULL NAME (not substring), with slug fallback
    book = api('GET', f'/books/{BOOK_ID}')
    for c in book.get('contents', []):
        if c['type'] != 'chapter':
            continue
        if expected_name and c['name'] == expected_name:
            CHAPTER_IDS[agent_id] = c['id']
            return c['id']
        if agent_id.lower() in c.get('slug', '').lower():
            CHAPTER_IDS[agent_id] = c['id']
            return c['id']

    # 3. Create new chapter
    ch_name = expected_name or f"{agent_id} - Agent执行记录"
    chapter = api('POST', '/chapters', {'book_id': BOOK_ID, 'name': ch_name})
    if 'error' not in chapter:
        CHAPTER_IDS[agent_id] = chapter['id']
        return chapter['id']
    
    # 4. If name collision on creation, find existing by name
    if 'already exists' in str(chapter).lower() or 'duplicate' in str(chapter).lower():
        book2 = api('GET', f'/books/{BOOK_ID}')
        for c in book2.get('contents', []):
            if c['type'] == 'chapter' and c['name'] == ch_name:
                CHAPTER_IDS[agent_id] = c['id']
                return c['id']
    return None
```

**Verification that the fix works:** Test idempotency by calling get_or_create_chapter() twice with cache cleared between calls:
```python
ch1 = get_or_create_chapter("DEV")  # Should find existing
CHAPTER_IDS = {}                     # Clear cache
ch2 = get_or_create_chapter("DEV")  # Should find SAME chapter
assert ch1 == ch2, f"Idempotency broken: {ch1} != {ch2}"
```

**Fallback pattern for page creation:**
```python
result = api('POST', '/pages', {
    'book_id': BID, 'chapter_id': ch_id, 'name': name, 'html': html
})
if 'error' in result:
    err = result['error']
    if 'cycle' in err.lower() or 'parent' in err.lower() or 'chapter' in err.lower():
        result = api('POST', '/pages', {
            'book_id': BID, 'name': name, 'html': html  # no chapter_id
        })
```

**Token verification:** When debugging BookStack API errors, verify the token with:
```bash
curl -w '%{http_code}' -H 'Authorization: Token {id}:{secret}' http://localhost:8080/api/pages/285
# 200 = valid, 401 = token expired/incorrect
```

**Security redaction awareness:** File displays showing `***` are from the security system masking tokens/secrets — the actual bytes on disk are fine. Verify with:
```python
python3 -c "print(open('bookstack_sync.py','rb').read().hex()[:50])"
# Hex decodes to actual content

When `agent_bridge.py` write operations (log_skill_invocation, submit_feedback) collide, the exception propagates to `agent_base.py.run()` which catches it and returns early — skipping the BookStack sync.

**Fix**: Apply retry logic to all DB write operations:
```python
def _write_with_retry(conn, sql, params, max_retries=5, description=""):
    for attempt in range(max_retries):
        try:
            c = conn.cursor()
            c.execute(sql, params)
            conn.commit()
            return c.lastrowid
        except sqlite3.OperationalError as e:
            if "locked" in str(e) and attempt < max_retries - 1:
                time.sleep(0.1 * (2 ** attempt))
                continue
            raise
```

Also fix `agent_base.py` to not skip sync on partial failure:

```python
# BAD: Current pattern
try:
    result = self.execute(dry_run=dry_run)
except Exception as e:
    bridge.update_task_status(..., "failed")
    return  # ← Sync code skipped!

# GOOD: Partial completion pattern
try:
    result = self.execute(dry_run=dry_run)
except Exception as e:
    result = {"status": "partial", "error": str(e)}
    print(f"⚠️ Partial execution: {e}")

# Always run completion logic
if not dry_run:
    bridge.update_task_status(...)
    bookstack_sync.create_agent_page(...)
```

## Pitfalls

1. **BookStack API DELETE returns 204 No Content** — The `urllib.request.urlopen()` for DELETE requests returns no body. Handle with `resp.status == 204` check.

2. **Page name uniqueness** — BookStack enforces unique page names within a book. If you run the sync twice, duplicate names cause HTTP errors. Check existence before creating.

3. **Chapter detection uses full name, not substring** — The `get_or_create_chapter()` function must match by exact chapter name from `AGENT_CHAPTERS`, NOT by `agent in c['name']` (substring). For agent "PM", `"PM" in "项目管理 - Agent执行记录"` is FALSE because chapter names use Chinese, not English acronyms. Always match by full name from `AGENT_CHAPTERS`, with slug-based fallback.

4. **API rate limiting** — Add `time.sleep(0.3)` between page creation calls. BookStack's default rate limiter allows ~30 requests per minute.

5. **HTML length limits** — Pages with too many skills (e.g., 7 skills for PM) produce 10KB+ HTML. BookStack handles this fine, but very long pages (>30KB) may cause editor performance issues.

6. **Markdown table parsing** — The `| A | B |` markdown table format in skill reports needs careful regex. The separator line `|---|` must be captured and skipped. Use multi-step regex with lookaheads.

7. **Stale chapter cache causes "would create a cycle"** — The `CHAPTER_IDS` module-level dict in `bookstack_sync.py` never verifies cached chapters still exist. If a chapter is deleted externally (e.g., duplicate cleanup), the stale ID causes BookStack to reject page creation with "Setting X as parent of X would create a cycle". **Fix**: Always verify cached chapters with `api('GET', f'/chapters/{cached_id}')` before using them. See Failure 6 for the full pattern.

## Verification

After sync, verify completeness:

```python
book = api('GET', f'/books/{BOOK_ID}')
chapters = [c for c in book.get('contents', []) if c['type'] == 'chapter']
agents_found = set()
for c in chapters:
    for p in c.get('pages', []):
        # Extract agent from page name: "📄 PM/scheduler-cycle..."
        parts = p['name'].split('/')[0].split(' ')[-1] if '/' in p['name'] else ''
        if parts:
            agents_found.add(parts)
expected = {'PM','REQ','ARCH','DEV','SEC','TEST','QA','CM','DOC','SPI'}
missing_agents = expected - agents_found
print(f"Agents covered: {agents_found}")
print(f"Missing: {missing_agents or 'None ✅'}")
```
