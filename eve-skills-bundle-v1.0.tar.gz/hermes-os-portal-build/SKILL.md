---
category: uncategorized
description: Full lifecycle for building Hermes OS Portal features (Auth & RBAC, Alert
  Center, Observability Dashboard). Covers Flask backend modules, route registration,
  template creation, and auth integration.
name: hermes-os-portal-build
---

# Hermes OS Portal Build Guide

## Architecture
- Dashboard: Flask app at `/home/yestin/projects/hermes-dashboard/`
- App entry: `app.py` (registers blueprints from `frontend/routes.py` + `frontend/portal_routes.py`)
- Backend modules: `backend/*.py` (reusable engines)
- Templates: `frontend/templates/portal_*.html`
- Port: 8050 (internal)

## Adding a New Portal Feature

### 1. Create Backend Module
Create `backend/<module>.py` with:
- SQLite database for persistence (use `threading.local()` for connection safety)
- CRUD functions
- Export `init()` function for DB initialization

### 2. Register Routes (portal_routes.py)
- Add `from backend import <module>` import
- Add page route: `@bp.route("/portal/<name>")` with `@auth_manager.login_required`
- Add API routes: `@bp.route("/portal/api/<name>/...")`
- Apply decorators: `@auth_manager.login_required`, `@auth_manager.admin_required`, `@auth_manager.operator_required`
- Pass user context: `ctx = _inject_user_context()` then `render_template("...", **ctx)`

### 3. Create Template
Create `frontend/templates/portal_<name>.html` with dark theme (CSS variables in :root)

### 4. Add Nav Link
In `frontend/templates/portal.html`:
- Add nav item in `<div class="sidebar-nav">` under relevant section
- Add to `COMMANDS` array in command palette JS

### 5. Restart
```
kill $(cat /tmp/hermes-dashboard.pid) 2>/dev/null; sleep 1
cd /home/yestin/projects/hermes-dashboard && python3 app.py &
```

## Auth System
- `backend/auth_manager.py` — SQLite users + bcrypt + Flask session + JWT + audit log
- Default credentials: admin / admin123
- Three roles: admin (full), operator (ops actions), viewer (read-only)
- `@login_required`, `@admin_required`, `@operator_required` decorators
- API token auth: `Authorization: Bearer <token>`
- `/portal/login` public, `/portal/about` public, everything else protected

## Alert Engine (Phase 7)
- `backend/alert_engine.py` — Rule-based threshold alerts
- Rules: metric + condition (gt/lt/gte/lte/eq/ne) + threshold + severity + cooldown
- Channels: feishu webhook, command execution
- Alert lifecycle: firing → acknowledged → resolved
- Auto collect system metrics (CPU/Memory/Disk/Load/Services)

## Observability Engine (Phase 8)
- `backend/observability.py` — Time-series metric storage + SLA + health events
- Metric trend: charts at /portal/observability
- SLA tracking: per-service daily uptime percentage
- Top process detection (by CPU/Memory)
- Chart.js from CDN for real-time graphs

## Default Users Created
- admin/admin123 (role=admin) — full access
- operator1/pass123456 (role=operator) — ops access
- viewer1/pass123456 (role=viewer) — read-only