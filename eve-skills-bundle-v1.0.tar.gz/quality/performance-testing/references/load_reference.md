# load-test-generator — Reference

## Overview
Load/stress test generation — k6, Locust, Artillery scripts. Ramp-up patterns, scenario design, threshold assertions.

## Integration Points
- Hermes Agent skill ecosystem
- evolution_engine.py scoring system
- self-audit verification

## Key Resources
- SKILL.md: main skill definition
- scripts/: executable code (if present)
