# performance-profiler — Reference

## Overview
Performance profiling — CPU, memory, I/O profiling with flame graphs. Python (py-spy), Node.js (clinic), Go (pprof), JVM (async-profiler).

## Integration
- Hermes Agent ecosystem (quality/performance-profiler)
- evolution_engine.py / self_audit.py scoring
