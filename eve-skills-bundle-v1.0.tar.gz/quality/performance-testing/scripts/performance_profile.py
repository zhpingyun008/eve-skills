#!/usr/bin/env python3
"""Performance profiler — timer, memory tracker, function profiler decorator.
For multi-process profiling, use delegate_task to profile components in parallel."""
import time, argparse, functools, tracemalloc
from contextlib import contextmanager

@contextmanager
def timer(label="operation"):
    start = time.perf_counter()
    yield
    print(f"[TIMER] {label}: {time.perf_counter()-start:.4f}s")

@contextmanager
def memory_tracker(label="operation"):
    tracemalloc.start()
    yield
    current, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    print(f"[MEMORY] {label}: current={current/1024:.1f}KB peak={peak/1024:.1f}KB")

def profile_function(func):
    @functools.wraps(func)
    def wrapper(*a, **kw):
        start = time.perf_counter()
        result = func(*a, **kw)
        print(f"[PROFILE] {func.__name__}: {time.perf_counter()-start:.4f}s")
        return result
    return wrapper

def main():
    ap = argparse.ArgumentParser(description="Performance profiling utilities")
    ap.add_argument("--benchmark", action="store_true", help="Run quick CPU benchmark (10M iter)")
    ap.add_argument("--memory", action="store_true", help="Show memory usage snapshot")
    ap.add_argument("--fib", type=int, default=0, help="Profile fibonacci(N)")
    args = ap.parse_args()
    if args.benchmark:
        with timer("CPU benchmark"):
            total = sum(range(10_000_000))
        print(f"Result: {total}")
    if args.memory:
        with memory_tracker("list allocation"):
            data = [i**2 for i in range(100_000)]
    if args.fib > 0:
        @profile_function
        def fib(n):
            a, b = 0, 1
            for _ in range(n): a, b = b, a+b
            return a
        print(f"fib({args.fib}) = {fib(args.fib)}")
    if not (args.benchmark or args.memory or args.fib):
        ap.print_help()

if __name__ == "__main__":
    main()
