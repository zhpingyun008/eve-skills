#!/usr/bin/env python3
"""Generate HTTP load test script (k6 JavaScript format).
For multi-endpoint testing, use delegate_task to run scenarios in parallel."""
import argparse

TEMPLATE = """import http from 'k6/http';
import { check, sleep } from 'k6';

export const options = {
  stages: [
    { duration: '%ds', target: %d },
    { duration: '%ds', target: %d },
    { duration: '%ds', target: 0 },
  ],
  thresholds: {
    http_req_duration: ['p(95)<%d'],
    http_req_failed: ['rate<%.2f'],
  },
};

export default function () {
  const res = http.%s('%s');
  check(res, { 'status %d': (r) => r.status === %d });
  sleep(1);
}
"""

def main():
    ap = argparse.ArgumentParser(description="Generate k6 load test script")
    ap.add_argument("url", help="Target URL")
    ap.add_argument("--method", default="GET")
    ap.add_argument("--vus", type=int, default=100, help="Target virtual users")
    ap.add_argument("--duration", type=int, default=60, help="Steady state duration (s)")
    ap.add_argument("--warmup", type=int, default=30)
    ap.add_argument("--cooldown", type=int, default=30)
    ap.add_argument("--status", type=int, default=200, help="Expected HTTP status")
    ap.add_argument("--p95", type=int, default=500, help="p95 latency threshold (ms)")
    ap.add_argument("-o", "--output", help="Output file")
    args = ap.parse_args()
    script = TEMPLATE % (args.warmup, max(1, args.vus//5), args.duration, args.vus, args.cooldown, args.p95, 0.01, args.method.lower(), args.url, args.status, args.status)
    if args.output:
        with open(args.output, 'w') as f:
            f.write(script)
        print(f"Generated: {args.output}")
    else:
        print(script)

if __name__ == "__main__":
    main()
