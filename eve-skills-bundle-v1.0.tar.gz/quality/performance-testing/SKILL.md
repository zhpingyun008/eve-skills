---
name: performance-testing
description: Performance testing suite — load test generation (k6/Locust/Artillery scripts with ramp-up patterns and threshold assertions) and performance profiling (CPU/memory/I/O flame graphs for Python/Node.js/Go/JVM).
category: quality
triggers:
  - "负载测试"
  - "load test"
  - "k6"
  - "stress test"
  - "性能测试"
  - "性能分析"
  - "profiling"
  - "flame graph"
  - "CPU分析"
  - "memory leak"
related_skills:
  - visual-regression
  - accessibility-audit
  - chaos-engineer
---

# performance-testing — Load Testing + Performance Profiling


## Overview

performance-testing — Load Testing + Performance Profiling skill - auto-validated.
Merged from: load-test-generator + performance-profiler

A complete performance testing toolkit pairing **load/stress test generation** (k6, Locust, Artillery) with **performance profiling** (py-spy, clinic.js, pprof, async-profiler) for before/after optimization validation.

---

## Part 1: Load Test Generation

Generate realistic load test scenarios with automated threshold checking.

### Trigger Conditions
- Commander orders: 负载测试 / load test / stress test
- Pre-launch performance validation
- Capacity planning

### Workflow

#### Step 1: Define Scenarios
```javascript
// k6 script
import http from 'k6/http';
import { check, sleep } from 'k6';

export const options = {
  stages: [
    { duration: '2m', target: 100 },   // Ramp up
    { duration: '5m', target: 100 },   // Steady state
    { duration: '2m', target: 200 },   // Spike
    { duration: '5m', target: 200 },   // Peak
    { duration: '2m', target: 0 },     // Ramp down
  ],
  thresholds: {
    http_req_duration: ['p(95)<500'],  // 95% < 500ms
    http_req_failed: ['rate<0.01'],    // < 1% errors
  },
};

export default function () {
  const res = http.get('http://api.example.com/users');
  check(res, { 'status 200': (r) => r.status === 200 });
  sleep(1);
}
```

#### Step 2: Run Test
```bash
k6 run test.js --out json=results.json
```

#### Step 3: Analyze Results
- p50, p95, p99 latency
- Error rate under load
- Throughput (req/s)
- Resource saturation (CPU, memory, connections)

#### Step 4: Identify Bottlenecks
Correlate latency spikes with resource metrics.

### Pitfalls
- Test from same network to avoid measuring WAN latency
- Don't test against production with real data
- Gradual ramp-up — sudden spike may not reflect reality

---

## Part 2: Performance Profiling

Language-specific performance profiling with actionable optimization recommendations.

### Trigger Conditions
- Commander orders: 性能分析 / profiling / flame graph
- Production latency regression
- Capacity planning review

### Workflow

#### Step 1: Select Profiler
| Language | CPU | Memory | I/O |
|----------|-----|--------|-----|
| Python | py-spy | memray | — |
| Node.js | clinic flame | clinic heapprofiler | clinic bubbleprof |
| Go | pprof | pprof heap | pprof block |
| JVM | async-profiler | async-profiler | — |

#### Step 2: Capture Profile
```bash
# Python CPU
py-spy record -o profile.svg -- python app.py

# Node.js CPU
clinic flame -- node app.js

# Go
curl http://localhost:6060/debug/pprof/profile?seconds=30 > cpu.prof
go tool pprof -http=:8080 cpu.prof
```

#### Step 3: Analyze Hot Paths
Identify top CPU consumers, memory allocations, blocking I/O.

#### Step 4: Recommend Optimizations
- Hot loop → algorithm improvement
- Repeated DB queries → caching/batching
- Large allocations → object pooling
- Blocking I/O → async

### Pitfalls
- Profiling adds overhead — don't run on production without sampling profiler
- Optimize based on data, not intuition
- Measure before and after to confirm improvement

### Verification
Run load test before/after optimization; compare p99 latency.

---

## Scripts

- `scripts/load_generate.py` — Load test generation helper (from load-test-generator)
- `scripts/performance_profile.py` — Performance profiling helper (from performance-profiler)

## Integration

- **load-test-generator** provides the workload; **performance-profiler** captures the metrics
- Use together in a cycle: load test → profile → optimize → re-test
- Results feed into capacity planning and SLO definition
