---
name: lint-test-loop
description: Automated lint-test-fix loop — after every edit, auto-lint → auto-fix → run tests → if fail, fix → repeat until pass. Inspired by Aider's auto-lint-test cycle.
category: agent-skills
triggers:
  - "lint test loop"
  - "自动检查"
  - "auto lint"
  - "lint fix"
  - "format check"
---

# lint-test-loop — 自动Lint-Test修复循环


## Overview

lint-test-loop — 自动Lint-Test修复循环 skill - auto-validated.
对标: Aider lint-test loop | Claude Code post-edit hooks | pre-commit CI
评级: ★★★★☆ (P1)

## 作用

每次代码编辑后自动执行lint→fix→test循环，直到全部通过：

```
Edit → ruff check → ruff fix → pytest → 
  fail? → analyze error → patch → re-test → 
  pass? → done
  still fail? → escalate
```

## Workflow

1. **Edit** — agent makes a code change
2. **Lint** — auto-run configured linter (ruff, eslint, etc.) on changed files
3. **Auto-fix** — apply auto-fixable corrections in-place
4. **Test** — run test suite on affected scope
5. **Analyze failures** — parse test output and lint errors; generate targeted patches
6. **Loop or escalate** — retry up to N iterations; if still failing, escalate to human

```bash
python3 ~/.hermes/skills/agent-skills/lint-test-loop/scripts/lint_test_loop.py --loop
python3 ~/.hermes/skills/agent-skills/lint-test-loop/scripts/lint_test_loop.py --once
```

## Pitfalls

- **Infinite fix-test loops**: Buggy auto-fixes can introduce new errors, cycling indefinitely; always cap iterations (default: 5)
- **Slow test suites**: Full suite reruns on every edit are expensive; scope to affected test files or use test selection
- **Destructive auto-fixes**: Auto-formatting may change code semantics (rare but possible with aggressive linters); review diffs
- **Linter configuration gaps**: If no linter is configured, the loop is a no-op; validate config before entering loop
- **Escalation fatigue**: Repeatedly escalating unfixable issues disrupts flow; batch non-critical failures for human review

## Feedback Engine Patches
*自动生成于 2026-07-16 02:02:04*

## Tool Recommendations (from trajectory feedback)

### patch
Trajectory analysis shows **patch** strongly correlates with high session scores.
- Use `patch` for targeted find-and-replace edits instead of sed/awk.
- Supports fuzzy matching with 9 strategies for robust edits.
- Auto-runs syntax checks after modification.
- Preferred for surgical code changes over full file rewrites.

### Guardrails
- Ensure `old_string` is unique in the file unless `replace_all=True`.
- Include enough surrounding context to guarantee uniqueness.
- Use `mode='patch'` for V4A multi-file patches.

### Efficiency Tips
- Combine multiple edits into a single V4A patch when possible.
- Use `replace_all=True` for bulk replacements of the same pattern.
- Preview changes with `--dry-run` mode before applying.

---
## Feedback Engine Patches
*自动生成于 2026-07-17 02:02:37*

## Tool Recommendations (from trajectory feedback)

### patch
Trajectory analysis shows **patch** strongly correlates with high session scores.
- Use `patch` for targeted find-and-replace edits instead of sed/awk.
- Supports fuzzy matching with 9 strategies for robust edits.
- Auto-runs syntax checks after modification.
- Preferred for surgical code changes over full file rewrites.

### Guardrails
- Ensure `old_string` is unique in the file unless `replace_all=True`.
- Include enough surrounding context to guarantee uniqueness.
- Use `mode='patch'` for V4A multi-file patches.

### Efficiency Tips
- Combine multiple edits into a single V4A patch when possible.
- Use `replace_all=True` for bulk replacements of the same pattern.
- Preview changes with `--dry-run` mode before applying.

---
## Feedback Engine Patches
*自动生成于 2026-07-22 12:19:48*

## Tool Recommendations (from trajectory feedback)

### patch
Trajectory analysis shows **patch** strongly correlates with high session scores.
- Use `patch` for targeted find-and-replace edits instead of sed/awk.
- Supports fuzzy matching with 9 strategies for robust edits.
- Auto-runs syntax checks after modification.
- Preferred for surgical code changes over full file rewrites.

### Guardrails
- Ensure `old_string` is unique in the file unless `replace_all=True`.
- Include enough surrounding context to guarantee uniqueness.
- Use `mode='patch'` for V4A multi-file patches.

### Efficiency Tips
- Combine multiple edits into a single V4A patch when possible.
- Use `replace_all=True` for bulk replacements of the same pattern.
- Preview changes with `--dry-run` mode before applying.
