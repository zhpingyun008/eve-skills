# multi-model-router Reference

P1 Agent Skill