---
name: multi-model-router
description: Route tasks to different models based on task type and cost optimization. Pro for reasoning/architecture, Flash for review/testing, glm-4-flash (¥0.10/M) for Cron. DeepSeek V4 + Z.AI GLM + OpenRouter triple-provider. Aider-inspired per-task routing.
category: agent-skills
triggers:
  - "model router"
  - "多模型"
  - "模型路由"
  - "switch model"
  - "评估最佳方案"
  - "降低成本"
  - "cost optimization"
  - "Pro vs Flash"
  - "模型分配"
  - "glm-4-flash"
  - "智谱"
---

# multi-model-router — 多模型成本最优路由器


## Overview

multi-model-router — 多模型成本最优路由器 skill - auto-validated.
对标: Aider --model + --editor-model | OpenRouter multi-model | DeepSeek V4 Pro/Flash
评级: ★★★★★ (P0) | 最后更新: 2026-05-05

> ✅ 2026-05-05: glm-4-flash上线 (Z.AI), L3 Cron成本↓95%, OpenRouter双Provider就绪, fallback_providers配置完成

## L0-L3 场景分层路由（2026-05-02新增）

### 分层决策树

```
任务进入
  │
  ├─ L0 · 关键层 (安全/资金/合规/架构决策) → Pro only，不降级
  │    触发: --audit | CVE | threat-model | compliance | sudo | rm -rf | migration | ADR
  │
  ├─ L1 · 高推理层 (多文件重构/算法/Bug根因) → Pro default
  │    触发: refactor≥3files | diagnose | algorithm | architecture
  │    降级条件: 单文件+无行为变更 → Flash
  │
  ├─ L2 · 中推理层 (审查/测试/文档/扫描) → Flash优先
  │    触发: code-review | test-engine | doc-generator | dependency-scanner | load-test | refactor-suggester
  │    回退条件: 安全敏感代码/Critical CVE/输出明显退步 → Pro
  │    缓存: 24h热点缓存，相同输入免调用
  │
  └─ L3 · 机械层 (Cron/辅助/查询/格式化) → glm-4-flash
      触发: cron | vision | web_extract | compression | session_search | delegate | git status | regex
      控制: max_tokens=800, caveman-mode输出, ¥0.10/M
```

### 分层路由表

| 层级 | 定义 | 目标模型 | 占比 | 月成本 | 回退策略 |
|:----:|------|:------:|:----:|:-----:|------|
| **L0** | 安全/资金/合规/架构 | **Pro** | 15% | ¥2.19 | 永不降级 |
| **L1** | 复杂编码/调试/规划 | **Pro** | 35% | ¥5.11 | 任务简化后→Flash |
| **L2** | 审查/测试/文档/扫描 | **Flash** | 30% | ¥2.27 | 发现退步→Pro+记录 |
| **L3** | Cron/辅助/查询/格式 | **GLM** | 20% | **¥0.01** | 无需回退 |

### L0 · 关键层（Pro only）

| 任务 | 触发特征 | max_tokens |
|------|---------|:---------:|
| 安全审查 | `security` / `威胁` / `CVE` / `audit` | 4000 |
| 危险操作 | `rm -rf` / `sudo` / `chmod 777` / `mkfs` | 2000 |
| CMMI5合规 | `governance` / `compliance` / `audit` | 4000 |
| 架构决策 | `ADR` / `技术选型` / `database migration` | 4000 |
| 资金操作 | `cost` / `budget` / `purchase` / `财务` | 3000 |

### L1 · 高推理层（Pro default）

| 任务 | 降级条件 (→Flash) |
|------|------------------|
| 多文件重构 | → 单文件+无行为变更 |
| 算法设计 | → 算法在参考文档中 |
| Bug根因分析 | → 错误已知+有SO答案 |
| 架构设计 | → 仅补文档，不设计 |
| Agent编排 | → 单Agent简单任务 |

### L2 · 中推理层（Flash优先，24h缓存）

| 任务 | 回退Pro条件 |
|------|-----------|
| 代码审查 | 涉及安全敏感代码/CVE相关 |
| 测试生成 | 集成测试/边界条件复杂 |
| API文档 | 安全接口/鉴权流程 |
| 依赖扫描 | 发现Critical CVE需深度分析 |
| 性能分析 | 异常模式需根因推理 |
| 负载测试 | 结果异常需诊断 |
| 重构建议 | 涉及架构级变更 |

### L3 · 机械层（glm-4-flash，max_tokens=800）

| 任务 | 配置 |
|------|------|
| Cron守护进程 | glm-4-flash + caveman-mode |
| 辅助模型 (vision/web_extract/compression) | glm-4-flash |
| 子代理委托 | glm-4-flash + max_tokens=800 |
| 状态查询 (git/health) | glm-4-flash |
| 格式转换 (JSON↔YAML/Markdown) | glm-4-flash |

### 退化模式数据库

Flash→Pro回退时自动记录：
```
~/.hermes/data/routing/degradation.jsonl
{task_type, input_hash, reason, timestamp}
```
积累10+案例后分析规律，优化路由规则。

### 熔断规则

| 场景 | 动作 |
|------|------|
| Flash连续3次回退(同一任务类型) | 永久路由Pro + 更新规则 |
| Pro API超时/限流 | 降级Flash + 标记"非关键决策" |
| 月成本超预算(>¥5) | 触发告警 + 暂停非关键Cron |

## ⚠️ 折扣到期风险 (2026-05-01发现)

DeepSeek当前75%折扣延长至 **2026-05-31**。到期后若不延续：

| 模型 | 当前(75% off) | 原价 | 月成本影响 |
|------|-------------|------|-----------|
| Flash 输入 | ¥1/M | ¥4/M | +¥0.60 |
| Flash 输出 | ¥4/M | ¥16/M | +¥0.60 |
| Pro 输入 | ¥2/M | ¥8/M | +¥1.50 |
| Pro 输出 | ¥8/M | ¥32/M | +¥3.20 |
| **总计** | **¥3.65** | **¥14.60** | **↑300%** |

应对预案：
1. 删除低价值cron (Trends每日扫描可降至2次/周)
2. 主对话控制输出token (已实施)
3. 评估迁移至其他Provider (Groq免费层等)
4. 监控5月下旬官方公告

## Context Caching (已自动生效)

DeepSeek内置Context Caching，自动缓存重复前缀token：

| 类型 | 价格 | 节省 |
|------|------|------|
| Cache Hit | $0.0028/M (¥0.02/M) | 省98%输入 |
| Cache Miss | $0.14/M (¥1/M) | 标准 |

Hermes的system prompt (SOUL.md) 作为稳定前缀 → 每次对话自动缓存命中 → 月省¥0.50-1.50。
配置: `prompt_caching: cache_ttl: 5m` (config.yaml中已启用)

## 跨厂商成本对比（2026-05更新）

### 全网最低价排行（输出 ¥/M tokens）

| 排名 | 模型 | 输出 ¥/M | 厂商 | Hermes接入 |
|:---:|------|:---:|------|------|
| 🥇 | **glm-4-flash** | **¥0.10** | 智谱AI | **Z.AI直连** |
| 🥈 | doubao-1.5-lite | ¥0.30 | 字节火山 | OpenRouter |
| 🥉 | ERNIE Lite/Tiny | ¥0.60 | 百度千帆 | OpenRouter |
| 4 | deepseek-v4-flash | ¥2.00 | DeepSeek | 直连(当前) |
| 5 | Gemini 2.0 Flash | ¥2.92 | Google | OpenRouter |
| 6 | ERNIE 4.5 Turbo | ¥6.00 | 百度千帆 | OpenRouter |
| 7 | deepseek-v4-pro | ¥6.00 | DeepSeek | 直连(当前,75%off) |

### 关键发现

1. **国内模型成本碾压国际**：glm-4-flash (¥0.10) vs GPT-4o-mini (¥4.38) = 便宜43倍
2. **OpenRouter有中间商差价**：glm-4.7-flash通过OpenRouter ¥2.92/M，Z.AI直连 ¥0.10/M → 差29倍
3. **glm-4.5-air:free 免费**：OpenRouter有零成本GLM模型，但需OpenRouter API Key
4. **ERNIE 4.5 Turbo (¥6)** = deepseek-v4-pro折扣价(¥6) → 折扣到期后最佳平替

### 四层最优模型矩阵

```
L0 安全/架构  → deepseek-v4-pro (¥6)     + ERNIE 4.5 Turbo fallback
L1 编码/调试  → deepseek-v4-pro (¥6)
L2 审查/测试  → deepseek-v4-flash (¥2)    + Gemini Flash fallback
L3 Cron/辅助  → glm-4-flash (¥0.10) 🔥
```

## Provider接入操作指南

### Z.AI (智谱AI) 接入 glm-4-flash [✅ 已完成 2026-05-05]

**状态：已上线。5个L3 Cron + 辅助模型(vision/web_extract/compression)全部切glm-4-flash。**

验证命令：
```bash
hermes auth status zai  # 应显示 logged in ✅
hermes -m glm-4-flash --provider zai -z "你好"  # 测试连通 ✅
```

### 百度千帆 ERNIE 4.5 Turbo 接入 [✅ 已完成 2026-05-05]

**状态：已上线。L0/L1热备，fallback顺位#2。**

模型名: `ernie-4.5-turbo-128k`
API Key格式: `bce-v3/ALTAK-xxx/yyy` (AK/SK组合)
认证方式: Bearer Token直连 (非OAuth)
端点: `https://qianfan.baidubce.com/v2/chat/completions`

验证:
```bash
hermes -m ernie-4.5-turbo-128k --provider baidu -z "测试"  # ✅ 通过
```

价格: ¥3/M输入, ¥6/M输出 (128K上下文) — 与deepseek-v4-pro折扣价持平

### 交互式认证阻断处理

`hermes auth add <provider>` 使用 `getpass` 交互式输入，在Feishu/WSL非TTY环境下会EOFError崩溃。

**解决方案：** 直接写 `.env` 文件，不要用 `hermes auth add`。
```bash
# ✅ 正确做法
echo 'PROVIDER_API_KEY=xxx' >> ~/.hermes/.env

# ❌ 错误做法（会崩溃）
hermes auth add zai
```

### 折扣到期预案（2026-05-31）

DeepSeek 75%折扣到期后若恢复原价(¥32/M)：

| 场景 | 方案 | 月成本 |
|------|------|:---:|
| 不处理 | Pro原价 ¥32/M | ¥31.95 🔴 |
| 切ERNIE | ERNIE 4.5 Turbo ¥6/M | ¥10.63 🟢 |
| 切GLM | glm-5 ¥10/M | ¥14.63 🟡 |

**推荐：** P1接入ERNIE 4.5 Turbo作为L0/L1热备，折扣到期日一键切换。

## 搜索缓存 (已实施)

perception.py搜索聚合器新增24h响应缓存：
- md5-based key (跨进程确定性)
- Cache hit: <0.1s (50x加速), 零API消耗
- 月省: ¥0.10-0.20

## 输出控制（2026-05-02新增）

### L2/L3 max_tokens限制

| 层级 | max_tokens | 输出模式 | 说明 |
|:----:|:---------:|------|------|
| L0 关键 | 4000 | 完整输出 | 安全/合规/架构 |
| L1 高推理 | 3000 | 完整输出 | 复杂编码/调试 |
| L2 中推理 | **2000** | 精简+caveman可选 | 审查/测试/文档 |
| L3 机械 | **800** | caveman-mode | Cron/查询/格式 |

### caveman-mode激活规则

L3任务自动激活极简通信模式：
- 砍掉冠词(a/an/the)、填充词(just/really)、客套语(sure/certainly)
- 保留技术术语精确不变、代码块原样输出、错误信息逐字引用
- 安全警告/不可逆操作确认时自动跳出极简，事后恢复

caveman-mode示例：
```
优化前: "Sure! I'd be happy to help you with that. The results from the CVE scan show that..."
优化后: "CVE扫描完成: 3个Critical, 需立即修复. 详情:"
```

### 退化模式数据库

Flash→Pro回退自动记录到 `~/.hermes/data/routing/degradation.jsonl`

分析命令：
```bash
python3 ~/.hermes/scripts/degradation_db.py --analyze    # 退化模式分析
python3 ~/.hermes/scripts/degradation_db.py --query code-review  # 查询特定任务
```

永久路由Pro规则：同任务类型≥3次退化 → 更新路由表

## 当前模型矩阵 (最终版) — 基于特长深度分配

| 模型 | 价格 | Provider | 核心特长 | Cron |
|------|:---:|------|------|:---:|
| deepseek-v4-pro | ¥6/M | DeepSeek | **1M上下文·最强推理·安全审计** | 0 |
| ERNIE 4.5 Turbo | ¥6/M | 百度千帆 | **安全审计最深·中文理解最优** | 0(热备) |
| **glm-4-air** | **¥1/M** | Z.AI | **代码审查·周报·SDLC·编码子代理** | 3 |
| **glm-4-flash** | **¥0.10/M** | Z.AI | **快频·Delegation·Auxiliary** | 2 |
| **glm-4.5-air:free** | **$0/M** | OpenRouter | **慢频Cron零成本** | 5 |

**deepseek-v4-flash 已彻底淘汰。**

### 特长路由表

| 任务类型 | 最优模型 | 理由 |
|---------|:-------:|------|
| 超长文档分析(>128K) | **DS-Pro** | 唯一1M上下文 |
| 安全审计/CVE | **DS-Pro/ERNIE45** | 两者最强,ERNIE更详尽 |
| 系统架构设计 | **DS-Pro** | 推理最强 |
| 复杂调试/算法 | **DS-Pro** | 1M上下文承载完整代码库 |
| 中文语义分析 | **ERNIE45** | 中文理解最深 |
| 代码审查(L2) | **GLM-Air** | ¥1/M性价比最优 |
| SDLC/CMMI5合规 | **GLM-Air** | 结构化任务,无需旗舰 |
| 慢频Cron(每2h+) | **GLM-Free** | 零成本 |
| 快频Cron(每<1h) | **GLM-Flash** | 防OpenRouter限流 |
| Delegation编码 | **GLM-Air** | 需要编码能力(¥1 vs Flash的¥0.10差异小) |
| Delegation简单 | **GLM-Flash** | ¥0.10/M极致 |
| 辅助模型 | **GLM-Flash** | ¥0.10/M 

### 每月成本精算

| 组件 | 模型 | 月成本 |
|------|------|:---:|
| L0/L1 主对话 | deepseek-v4-pro ¥6 | ¥2.60 |
| L2 审查+周报(3任务) | glm-4-air ¥1 | ¥0.57 |
| L3 Cron(5任务) | glm-4.5-air:free | **$0** |
| L3 Cron(2快频) | glm-4-flash ¥0.10 | ¥0.00 |
| Auxiliary | glm-4-flash ¥0.10 | ¥0.04 |
| Delegation | glm-4-flash ¥0.10 | ¥0.02 |
| **合计** | | **¥3.23** |

> L3 Cron免费化后月成本从¥2.67降至¥3.23？不对，让我重算...

### 实际月成本

| 组件 | 模型 | 月成本 |
|------|------|:-----:|
| L0/L1 主对话 | deepseek-v4-pro ¥6 | **¥2.60** |
| L2 审查+周报(3任务) | glm-4-air ¥1 | **¥0.57** |
| L3 Cron(5免费+2快频) | glm-4.5-air:free + glm-4-flash | **$0 + ¥0.00** |
| Auxiliary | glm-4-flash ¥0.10 | **¥0.04** |
| Delegation | glm-4-flash ¥0.10 | **¥0.02** |
| **合计** | | **¥3.23** |

> 5个L3 Cron任务从¥0.10/M降至$0/M。月省¥0.01。

## 路由策略 (两类模型环境)

### 策略 A: 主对话Pro + L3全GLM + L2 Flash + ERNIE热备（✅ 当前架构）

```
L0/L1 主对话 ──→ deepseek-v4-pro     (¥6/M, 最强推理)
    │               └→ fallback: ERNIE 4.5 Turbo 128K (¥6/M)
    ├── 规划/架构设计
    ├── 代码生成/重构
    ├── 安全审查
    └── 复杂调试/多步骤编排

L2 审查测试 ──→ deepseek-v4-flash    (¥2/M, 性价比)
    ├── 代码审查
    ├── 测试生成
    └── 文档/扫描

L3 Cron/辅助 ──→ glm-4-flash 🔥       (¥0.10/M, 省95%)
    │               └→ fallback: doubao-1.5-lite (¥0.30/M, OpenRouter)
    ├── Cron定时作业 (5个LLM任务)
    ├── Auxiliary辅助 (vision/web_extract/compression)
    └── Delegation子代理
```

**结论**: 四模型矩阵已部署。Pro有ERNIE热备，Cron全GLM省95%，fallback双保险 (zai→baidu)。

### 策略 C: 多Provider路由（四Provider矩阵）

| Provider | 状态 | 主力场景 | 备选场景 |
|------|:---:|------|------|
| DeepSeek | ✅ 直连 | L0/L1 Pro (¥6/M) | L2 Flash (¥2/M) |
| **Z.AI (智谱)** | ✅ 直连 | **L3 Cron glm-4-flash ¥0.10/M** 🔥 | L0备选 glm-5 ¥10/M |
| **Baidu (千帆)** | ✅ 直连 | **L0热备 ERNIE 4.5 Turbo ¥6/M** | L2备选 ERNIE Speed ¥2/M |
| OpenRouter | ✅ 配置 | 国际模型网关 | 免费模型探索 |

## 成本分析速查

### 典型月消耗估算 (Hermes Agent)

| 组件 | Token/月 | 成本/月 | 占比 |
|------|---------|---------|------|
| 主对话 Pro | 500K in + 200K out | ¥2.60 | 64% |
| Cron Flash (5个LLM任务) | 100K in + 25K out | ¥0.20 | 5% |
| System Crontab (5个机械任务) | 0 | ¥0.00 | 0% |
| Auxiliary Flash | 300K in + 100K out | ¥0.70 | 17% |
| Delegation Flash | 150K in + 50K out | ¥0.35 | 9% |
| **合计** | **1.35M** | **¥8.72** | **100%** |

### glm-4-flash接入后节省

| 组件 | 原模型 | 原成本 | 新模型 | 新成本 | 节省 |
|------|------|:---:|------|:---:|:---:|
| Cron (5 LLM) | deepseek-v4-flash | ¥0.20 | **glm-4-flash** | **¥0.01** | **↓95%** |
| Auxiliary | deepseek-v4-flash | ¥0.70 | **glm-4-flash** | **¥0.04** | **↓94%** |
| Delegation | deepseek-v4-flash | ¥0.35 | **glm-4-flash** | **¥0.02** | **↓94%** |
| 主对话 Pro | deepseek-v4-pro | ¥2.60 | 不变 | ¥2.60 | — |
| **合计** | — | **¥3.85** | — | **¥2.67** | **↓31%** |

### 优化检查清单

1. ✅ 后台Cron全切glm-4-flash？ (2026-05-05完成, 5任务)
2. ✅ 辅助模型全切glm-4-flash？ (2026-05-05完成, vision/web_extract/compression)
3. ✅ 机械Cron零LLM化 (2026-04-30完成, 5→系统crontab)
4. ✅ Z.AI Provider已接入 (2026-05-05完成)
5. ⬜ ERNIE 4.5 Turbo作L0热备？ (OpenRouter已就绪, 待配置)
6. ⬜ 主对话per-turn降级？ (ROI存疑, ¥0.39/月)

## 机械Cron零LLM化模式 (已实践)

判断标准 — cron作业可迁移到系统crontab的条件：
1. 任务可表示为确定性命令序列（无分支决策）
2. 不需要LLM总结/分析输出
3. 失败处理简单（重试/告警即可，无需推理）

迁移步骤：
```
1. 为每个cron创建独立Shell脚本 → ~/.hermes/scripts/cron/<name>.sh
2. 写入系统crontab → crontab -e
3. 从Hermes cron移除 → cronjob remove <job_id>
4. 验证日志输出 → ~/.hermes/logs/cron/
```

已迁移案例 (2026-04-30)：
| 任务 | 脚本 | crontab | 月省 |
|------|------|---------|------|
| Config Backup | config_backup.sh | 0 2 * * * | ¥0.04 |
| Memory Compact | memory_compact.sh | 0 4,16 * * * | ¥0.04 |
| Skill Audit | skill_audit.sh | 0 6 * * * | ¥0.04 |
| Healer Check | healer_check.sh | 0 */6 * * * | ¥0.04 |
| Memory Maintain | memory_maintain.sh | 0 8 * * * | ¥0.04 |

绝对节省虽小(¥0.20/月)，但零副作用 — 消除了LLM在确定性任务上的浪费。

## L2热点缓存（2026-05-02新增）

脚本: `~/.hermes/scripts/cost_cache.py`

对L2任务（code-review/test-engine/doc-generator等）的Flash输出进行24h缓存：
- 相同输入 → 缓存命中 → 零API消耗
- 命中率预期: ~20%（稳定代码库重复审查场景）
- 月省: ~¥0.50（原价）

```bash
# 查询缓存
python3 ~/.hermes/scripts/cost_cache.py --get code-review "diff_hash"

# 写入缓存（在Flash任务完成后自动调用）
python3 ~/.hermes/scripts/cost_cache.py --set code-review "diff_hash" "...output..."

# 统计命中率
python3 ~/.hermes/scripts/cost_cache.py --stats

# 清理7天前过期缓存
python3 ~/.hermes/scripts/cost_cache.py --clean
```

## Cron注入模式（2026-05-05升级为GLM）

所有L3 Cron prompt使用glm-4-flash：

```
[L3·GLM] <任务描述>. <输出约束>. <执行命令>.
```

实例化（5个L3 Cron已实施）：

| 级别 | 前缀 | Token限制 | 适用Cron |
|:----:|------|:---:|------|
| L2 | `[L2·Flash]` | ≤500 tokens | SDLC+CMMI5, Meta-Evolution |
| L3 | `[L3·GLM]` | ≤300 tokens | RSS, CVE+GitHub+Trends, GBrain, Curriculum, Full-stack |

注入后成本: Cron Token ¥2/M→¥0.10/M，降幅95%。

## Pitfalls

- **Stale pricing**: 模型价格频繁变动，季度复查此skill
- **Quality cliff**: Flash/GLM处理复杂推理会明显退步，不要为省钱牺牲L0/L1安全审查质量
- **Per-turn routing complexity**: 同session切换模型增加延迟和失败风险
- **False economy**: ¥4/月的成本不值得引入复杂路由逻辑；简洁架构优先
- **RTK unavailable in WSL**: rtk-ai/rtk需brew安装，WSL环境降级为grep/sed管道
- **Hermes config双段问题**: `config.yaml`中`auxiliary:`和`auxiliary_models:`是两个独立段，`hermes config set`只写后者，`hermes config show`可能读前者。两段需同步更新。
- **fallback_providers语法**: `hermes config set fallback_providers '["zai"]'` — 必须用单引号包裹JSON数组。
- **OpenRouter密钥格式**: 新密钥必须以`sk-or-v1-`开头。旧格式可能被拒(401)。`/api/v1/models`端点为公开访问无需认证，不能用来验证密钥有效性。
