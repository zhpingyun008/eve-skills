---
name: code-explainer
description: Natural language explanation of code blocks — function-level breakdown with complexity analysis, algorithm explanation, annotated code walkthroughs. Turns code into human-readable explanations.
category: agent-skills
triggers:
  - "explain this code"
  - "explain function"
  - "what does this do"
  - "code walkthrough"
  - "code explanation"
  - "explain algorithm"
  - "break down this function"
  - "how does this work"
  - "walk me through this code"
  - "complexity analysis"
---

# Code Explainer
<!-- Prompt v2.0 — 2026-05-05 -->

## Purpose
Transform any code block into clear, structured natural language explanations. Provide function-level breakdowns, complexity analysis, algorithm walkthroughs, and line-by-line annotations. Help developers understand unfamiliar code, onboard to new codebases, and review algorithmic choices.

## Triggers
- "explain this code"
- "explain function X"
- "what does this do?"
- "code walkthrough"
- "code explanation"
- "explain algorithm"
- "break down this function"
- "how does this work?"
- "walk me through this code"

## Explanation Structure

When asked to explain code, produce a structured explanation with these sections:

### 1. High-Level Summary (1-2 sentences)
What does this code do at a glance? Who calls it, what does it return, what side effects?

### 2. Signature & Contract
- Input parameters (name, type, purpose, constraints)
- Return value (type, meaning, edge cases)
- Exceptions raised
- Side effects (I/O, mutations, global state)

### 3. Algorithm / Approach
Describe the algorithmic strategy in plain language. What approach was chosen and why? Mention alternative approaches the developer could have taken.

### 4. Step-by-Step Walkthrough
Numbered steps tracing the execution flow, referencing specific lines:

```
[L12] Initialize accumulator to zero
[L14] Loop over each element in the input list
[L15]   If element meets condition, add to accumulator
[L18] Return the accumulated result
```

### 5. Complexity Analysis
Use the complexity metrics from `references/reference.md`:
- Cyclomatic complexity (decision points count)
- Cognitive complexity (nesting, breaks in linear flow)
- Time complexity (Big O)
- Space complexity (Big O)
- Line count

### 6. Edge Cases & Gotchas
- What happens with empty/null input?
- Boundary conditions
- Potential bugs or pitfalls
- Thread safety concerns

### 7. Example Usage
A concrete example showing input and expected output.

## Output Template

```
【Code Explanation: <function_name>】

📋 Summary
<1-2 sentence overview>

📝 Signature
  Parameters:
    - param1 (Type): description
    - param2 (Type, optional): description
  Returns: Type — description
  Raises: ExceptionType — when

🧠 Algorithm
<Plain-language description of the approach>

🔍 Walkthrough
  [L10] Step one description
  [L12] Step two description
  ...

📊 Complexity
  Cyclomatic: N    Cognitive: N
  Time:  O(...)    Space: O(...)
  Lines: N

⚠️ Edge Cases
  - Empty input: <behavior>
  - Null: <behavior>
  - ...

💡 Example
  Input:  ...
  Output: ...
```

## Language-Specific Hints

### Python
- Decorators: explain what they wrap and why
- Context managers: explain resource lifecycle
- Generators: explain laziness and yield points
- `*args` / `**kwargs`: explain what gets collected
- Async/await: explain concurrency model

### JavaScript/TypeScript
- Closures: explain captured scope
- Promises/async: explain chain or await behavior
- Prototypes/classes: explain inheritance
- Callbacks: explain inversion of control
- Type guards: explain narrowing

### Rust
- Ownership: explain moves vs borrows vs clones
- Lifetimes: explain what they constrain
- Pattern matching: explain exhaustiveness
- `unsafe`: flag and explain why it's needed

## Workflow

### Step 1: Identify Scope
- If user selected a block, use that
- If user named a function, find it with `search_files` or `symbol-index`
- If ambiguous, ask which function/block

### Step 2: Read the Code
```
read_file(path, offset=<func_start>, limit=<func_length>)
```
Get enough context (imports, class definition, surrounding functions) to understand the code.

### Step 3: Analyze
- Count decision points for cyclomatic complexity
- Assess nesting depth and flow breaks for cognitive complexity
- Identify the algorithm pattern (divide-and-conquer, DP, greedy, etc.)
- List edge cases by examining conditionals and error handling

### Step 4: Produce Explanation
Follow the output template. Keep walkthrough steps concise (one per logical action, not one per line). Use concrete variable names from the actual code.

### Step 5: Offer Follow-ups
- "Want me to suggest a refactor to reduce complexity?"
- "Should I generate unit tests for the edge cases?"
- "Would you like me to explain related functions?"

## Constraints & Safety
- **PRIORITY 1**: Accuracy. If uncertain, state it explicitly — never guess.
- **PRIORITY 2**: Conciseness. Keep explanations tight — no more than needed.
- **PRIORITY 3**: Actionable follow-ups. Offer next steps only after explanation is complete.
- **Max explanation iteration**: Cap at 6 tool calls total (read_file + search_files). Never loop indefinitely over code lines — if explaining, process each line at most once.
- **Max explanation depth**: Single function ≤ 50 lines or 2 pages of explanation. For longer code, summarize at section level.
- **No hallucination**: If code is ambiguous or missing, state uncertainty explicitly — never guess types, behavior, or intent.
- **No debug execution**: Do not run or modify the explained code. Read-only operation.
- **Fallback**: If `read_file` fails or function not found, report the exact error and suggest alternatives.
- **Scope limit**: If asked to explain entire codebase, redirect to use `repo-map` for architecture overview first.

## Pitfalls
- Don't over-explain trivial lines (assignments, returns) — focus on logic
- Don't guess types if the language is untyped — state what the code implies
- When complexity is high (>10 cyclomatic), proactively suggest refactoring
- For very long functions (>50 lines), summarize sections rather than line-by-line
- Don't explain the language itself (e.g., "a for loop iterates...") — assume the user knows the language

## Integration
- Load `symbol-index` for function discovery in large codebases
- After explanation, offer `test-engine` for edge case test generation
- For complex functions, offer `refactor-assist` to reduce complexity
- Use `repo-map` to explain how the function fits in the broader architecture

---
## Feedback Engine Patches
*自动生成于 2026-07-15 02:02:38*

## Tool Recommendations (from trajectory feedback)

### read_file
Trajectory analysis shows **read_file** strongly correlates with high session scores.
- Preferred over cat/head/tail in terminal.
- Use this for reading text files with line numbers and pagination.
- Supports offset and limit for large file navigation.

---
## Feedback Engine Patches
*自动生成于 2026-07-17 02:02:37*

## Tool Recommendations (from trajectory feedback)

### read_file
Trajectory analysis shows **read_file** strongly correlates with high session scores.
- Preferred over cat/head/tail in terminal.
- Use this for reading text files with line numbers and pagination.
- Supports offset and limit for large file navigation.

---
## Feedback Engine Patches
*自动生成于 2026-07-21 08:58:12*

## Tool Recommendations (from trajectory feedback)

### search_files
Trajectory analysis shows **search_files** strongly correlates with high session scores.
- Use instead of grep/rg/find in terminal.
- Content search: regex inside files (faster than shell grep).
- File search: glob patterns with results sorted by modification time.
- Supports output modes: `content`, `files_only`, `count`.

### Guardrails
- Regex patterns: ensure proper escaping for special characters.
- File globs: use simple patterns like `*.py`, `*config*`.
- For large directory trees, narrow with `path` parameter.

### Efficiency Tips
- Combine content search with `output_mode='files_only'` for fast file discovery.
- Use `context=N` for surrounding lines around matches.
- Limit results with `limit` parameter to avoid overwhelming output.

---
## Feedback Engine Patches
*自动生成于 2026-07-22 12:19:48*

## Tool Recommendations (from trajectory feedback)

### search_files
Trajectory analysis shows **search_files** strongly correlates with high session scores.
- Use instead of grep/rg/find in terminal.
- Content search: regex inside files (faster than shell grep).
- File search: glob patterns with results sorted by modification time.
- Supports output modes: `content`, `files_only`, `count`.

### Guardrails
- Regex patterns: ensure proper escaping for special characters.
- File globs: use simple patterns like `*.py`, `*config*`.
- For large directory trees, narrow with `path` parameter.

### Efficiency Tips
- Combine content search with `output_mode='files_only'` for fast file discovery.
- Use `context=N` for surrounding lines around matches.
- Limit results with `limit` parameter to avoid overwhelming output.

---
## Feedback Engine Patches
*自动生成于 2026-07-22 12:19:49*

## Tool Recommendations (from trajectory feedback)

### read_file
Trajectory analysis shows **read_file** strongly correlates with high session scores.
- Preferred over cat/head/tail in terminal.
- Use this for reading text files with line numbers and pagination.
- Supports offset and limit for large file navigation.
