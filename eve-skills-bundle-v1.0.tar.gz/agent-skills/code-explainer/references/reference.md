# Code Complexity Metrics Reference

## Overview

This document defines the complexity metrics used by code-explainer to analyze
and report on code structure. Understanding these metrics helps explainers
provide consistent, actionable insights.

---

## Cyclomatic Complexity

### Definition
Cyclomatic complexity measures the number of linearly independent paths through
a program's source code. It counts decision points — each branch creates a new
path that must be tested.

### Formula
```
M = E − N + 2P

Where:
  M = cyclomatic complexity
  E = number of edges in the control flow graph
  N = number of nodes in the control flow graph
  P = number of connected components (exit points)
```

### Simplified Counting
In practice, start at 1 (the main path) and add 1 for each:
- `if` / `else if` / `elif`
- `for` / `while` loops
- `case` / `switch` branches
- `catch` / `except` blocks
- `&&` and `||` logical operators (each adds 1)
- Ternary operators (`x ? a : b`)
- `continue` statements inside loops (in some metrics)

### Interpretation

| Score | Risk Level | Meaning |
|-------|-----------|---------|
| 1–5   | Low       | Simple, easy to test |
| 6–10  | Moderate  | Manageable but needs attention |
| 11–20 | High      | Complex, hard to test thoroughly |
| 21–50 | Very High | Very complex, high defect risk |
| 50+   | Critical  | Untestable, strongly recommend refactoring |

### Example
```python
# Cyclomatic complexity: 1 (base)
def simple(x):
    return x * 2

# Cyclomatic complexity: 3 (1 base + 1 if + 1 elif)
def moderate(x):
    if x > 0:
        return "positive"
    elif x < 0:
        return "negative"
    return "zero"

# Cyclomatic complexity: 5 (1 base + 1 for + 1 if + 1 elif + 1 and)
def higher(x, y):
    if x > 0 and y > 0:
        return "both positive"
    elif x < 0:
        return "x negative"
    return "other"
```

---

## Cognitive Complexity

### Definition
Cognitive complexity measures how difficult code is for a human to understand.
Unlike cyclomatic complexity, it penalizes:
- Nesting depth (each level multiplies the penalty)
- Breaks in linear flow (continue, break, early returns)
- Non-local control flow (recursion, callbacks)

### Scoring Rules

**Increments (additive):**
- `if`, `else if`, `elif`: +1
- `for`, `while`, `do-while`: +1
- `catch` / `except`: +1
- `switch` / `case`: +1 per case
- `goto`: +1
- `&&`, `||` chains: +1 per operator after the first in a sequence
- Recursion: +1

**Nesting multiplier:**
Each nesting level adds an incremental penalty:
- Level 1: no extra
- Level 2: +1 per increment
- Level 3: +2 per increment
- ...and so on

**Sequences:**
A sequence of structures at the same nesting level is counted as the sum
of their individual costs — no extra penalty.

### Interpretation

| Score | Risk Level | Meaning |
|-------|-----------|---------|
| 0–5   | Low       | Easy to understand |
| 6–15  | Moderate  | Requires some mental effort |
| 16–25 | High      | Difficult to follow |
| 25+   | Very High | Consider refactoring |

### Example
```python
# Cognitive: 1 (single if)
def low(x):
    if x:
        return 1
    return 0

# Cognitive: 4 (for=1, if at nesting level 1 costs 1+1=2, return=0, total=3+1 base)
def moderate(items):
    for item in items:          # +1
        if item.is_active:      # +1, nesting 1 => +1 extra = 2
            item.process()      # no increment
    return True

# Cognitive: ~10
def higher(data):
    for group in data:              # +1
        if group.valid:             # +2 (1 base + 1 nesting)
            for item in group:      # +2 (1 base + 1 nesting, level 2)
                if item.flagged:    # +3 (1 base + 2 nesting, level 3)
                    item.alert()    # no increment
    return
```

---

## Time Complexity (Big O)

### Common Classes

| Notation | Name | Example |
|----------|------|---------|
| O(1) | Constant | Array access by index, hash table lookup |
| O(log n) | Logarithmic | Binary search, balanced BST operations |
| O(n) | Linear | Single loop, linear search |
| O(n log n) | Linearithmic | Merge sort, heap sort, fast FFT |
| O(n²) | Quadratic | Nested loops, bubble sort, insertion sort |
| O(n³) | Cubic | Triple nested loops, matrix multiplication (naive) |
| O(2ⁿ) | Exponential | Recursive Fibonacci, subset generation |
| O(n!) | Factorial | Traveling salesman (brute force) |

### How to Estimate
1. Count loops: one loop → O(n), nested loops → multiply
2. Recursion: analyze the recurrence relation (Master Theorem)
3. Built-in operations: know your language (e.g., Python list append is O(1)
   amortized, but list insert at index 0 is O(n))
4. Look for divide-and-conquer patterns (often O(n log n))

---

## Space Complexity

### What to Count
- **Auxiliary space**: extra memory allocated during execution (not input)
- **Input space**: memory for input data (sometimes counted, sometimes not)
- **Call stack**: recursion depth × frame size

### Examples
```python
# Space: O(1) — constant extra space
def sum_list(nums):
    total = 0
    for n in nums:
        total += n
    return total

# Space: O(n) — creates a new list the same size as input
def double_all(nums):
    return [n * 2 for n in nums]

# Space: O(n) — recursion depth creates n stack frames
def factorial(n):
    if n <= 1:
        return 1
    return n * factorial(n - 1)
```

---

## Explanation Structure Guidelines

### What Makes a Good Explanation

1. **Start with the big picture.** Before diving into details, answer: what
   problem does this solve? Who calls this? What does it return?

2. **Use concrete variable names.** Refer to actual names from the code so
   the reader can map explanation to source.

3. **Explain the "why", not just the "what".** Don't say "it loops over items";
   say "it loops over items to find the first one matching the predicate."

4. **Highlight design choices.** If the code uses a hash map where a list would
   also work, explain the trade-off (O(1) lookup vs O(n)).

5. **Flag surprises.** If the code does something non-obvious (e.g., an early
   return that guards the rest), call it out explicitly.

6. **Connect to the bigger system.** If you know how this function fits into
   the codebase (from repo-map or symbol-index), mention it.

### What to Avoid
- Repeating the code verbatim in prose
- Explaining language syntax the user likely knows
- Diving into details before establishing context
- Guessing types without evidence
- Skipping edge cases because "they're obvious"
