---
name: role-agents
description: Enhanced role-based multi-agent system and gstack-inspired virtual engineering team. Define agents with roles (Architect, Developer, Tester, PM, CEO, Eng Manager, Designer, Reviewer, QA Lead, Security Officer, Release Engineer) with goals, tools, and collaboration patterns.
category: agent-skills
triggers:
  - "role agent"
  - "角色Agent"
  - "多角色"
  - "architect agent"
  - "team"
  - "虚拟团队"
  - "virtual team"
  - "ceo review"
  - "eng review"
  - "ship it"
  - "office hours"
  - "gstack"
---

# role-agents — 角色化Agent系统 + 虚拟工程团队


## Overview

role-agents — 角色化Agent系统 + 虚拟工程团队 skill - auto-validated.
Merged from: role-agents + virtual-team (gstack)

A complete role-based multi-agent framework. Use pre-built role templates for standard development tasks, or the gstack-inspired virtual engineering team (8 specialist roles with slash commands) for a full software factory experience.

---

## Part 1: Pre-defined Role Agents (CrewAI-inspired)

对标: CrewAI Agent roles | MetaGPT role-based agents
评级: ★★★★☆ (P1)

### Pre-defined Roles

| 角色 | 目标 | 工具 |
|------|------|------|
| Architect | 设计系统架构 | arch-designer, repo-map |
| Developer | 编写高质量代码 | smart-edit, code-review |
| Tester | 确保代码质量 | test-engine, coverage |
| Reviewer | 审查代码变更 | code-review, bandit |
| DevOps | 部署和监控 | cicd-builder, ops-monitor |
| PM | 管理需求和进度 | req-analyzer, plan-first |

```bash
python3 ~/.hermes/skills/agent-skills/role-agents/scripts/role_agents.py --team "architect,developer,tester"
python3 ~/.hermes/skills/agent-skills/role-agents/scripts/role_agents.py --assign "architect: design auth system"
```

### Workflow

#### Step 1: Define the task
The user describes a task requiring multiple perspectives. Identify which roles are needed:
- Greenfield project → Architect + Developer + Tester
- Bug fix → Developer + Tester + Reviewer
- Architecture review → Architect + Reviewer
- Planning → PM + Architect

#### Step 2: Assemble the team
```bash
python3 ~/.hermes/skills/agent-skills/role-agents/scripts/role_agents.py --team "architect,developer,tester"
```
Each role agent receives:
- Role-specific system prompt
- Curated tool set
- Shared project context

#### Step 3: Sequential execution
Agents collaborate in order:
1. **Architect** (if included): produces design/spec from requirements
2. **Developer**: implements against the spec
3. **Tester**: validates against the spec, reports bugs
4. **Reviewer** (if included): code review + security audit
5. **PM** (if included): tracks completion against plan

#### Step 4: Handoff artifacts
Each agent produces structured output consumed by the next:
```
Architect → design.md
Developer → code changes
Tester → test report
Reviewer → review comments
PM → status update
```

#### Step 5: Iterate
If Tester or Reviewer finds issues, loop back to Developer with specific feedback. Cap iterations at 3 to avoid infinite loops.

### Pitfalls

- Role agents are simulated personas, not separate LLM instances — they share the same model and context; avoid expecting true independence
- Sequential execution can be slow for simple tasks — only invoke multi-agent mode for non-trivial work
- Architect over-specification can constrain the Developer — leave implementation details to the implementing role
- Tester may find edge cases the Developer can't reproduce — ensure the handoff includes reproduction steps
- Role context accumulates across the chain — long chains (5+ roles) may exhaust the context window; summarize intermediate outputs
- Circular feedback (Tester→Developer→Tester) can loop indefinitely — always set a maximum iteration count
- Assigning all roles to every task produces noise and slow results — be selective; most tasks need only 2-3 roles

---

## Part 2: Virtual Engineering Team (gstack-inspired)

*Merged from: virtual-team*

对标: gstack (Garry Tan) | 评级: ★★★★★

### Core Philosophy

> "I don't think I've typed like a line of code probably since December." — Andrej Karpathy

One person delivering like a twenty-person team. The key isn't tools — it's role division. Let AI work under the right mental model.

### 8 Specialist Roles

| 角色 | 命令 | 职责 |
|------|------|------|
| **CEO** | /ceo-review | 产品战略、范围控制、优先级 |
| **Eng Manager** | /eng-review | 架构锁定、技术决策、风险评估 |
| **Designer** | /design-review | UI/UX审查、视觉一致性 |
| **Reviewer** | /review | 代码审查、逻辑错误、安全 |
| **QA Lead** | /qa | 浏览器测试、E2E验证 |
| **Security Officer** | /cso | OWASP+STRIDE审计 |
| **Release Engineer** | /ship | 版本发布、部署、回滚 |
| **DevEx** | /devex | 开发者体验、工具链优化 |

### Workflows

#### Standard Development Flow
```
/office-hours → /plan-ceo-review → /plan-eng-review
     → implement → /review → /qa → /ship
```

#### Quick Fix Flow
```
/bug-report → /investigate → fix → /review → /ship
```

#### Security Audit
```
/cso → fix criticals → /review → /qa → /ship
```

### Integration with Hermes Skills

| 虚拟角色 | Hermes技能 |
|---------|-----------|
| CEO | plan-first + CMMI5 DAR |
| Eng Manager | arch-designer + repo-map |
| Reviewer | code-review + bug-fixer |
| QA Lead | test-engine + browser_vision |
| Security | sandbox-exec + dependency-scanner |
| Release | cicd-builder + release-manager |
| DevEx | refactor-assist + doc-generator |

### Pitfalls
- Long role chains (5+) exhaust context → summarize intermediate outputs
- Review-fix cycles can be infinite → max 3 rounds
- Don't use all roles for every task → most need 2-3 roles

---

## Scripts

- `scripts/role_agents.py` — Role-based agent system (from role-agents)
- `scripts/virtual_team.py` — Virtual engineering team orchestration (from virtual-team)
