# role-agents Reference

P1 Agent Skill