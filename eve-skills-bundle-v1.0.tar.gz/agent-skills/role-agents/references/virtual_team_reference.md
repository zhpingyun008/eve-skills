# virtual-team — Reference

## Overview
gstack-inspired virtual engineering team — CEO, Engineering Manager, Designer, Reviewer, QA Lead, Security Officer, Release Engineer. 8 specialist roles with slash commands, all Markdown, all free. Transforms Hermes into a complete software factory.

## Integration
- Hermes Agent ecosystem (virtual-team)
- evolution_engine.py / self_audit.py scoring
