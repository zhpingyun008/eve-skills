#!/usr/bin/env python3
"""fullstack-builder — P1 Agent Skill"""
import sys, json

def main():
    if len(sys.argv) > 1 and sys.argv[1] == "--check":
        print(json.dumps({"status": "ok", "skill": "fullstack-builder", "tier": "P1"}))
    else:
        print(f"{skill} — use --check for status")

if __name__ == "__main__":
    main()
