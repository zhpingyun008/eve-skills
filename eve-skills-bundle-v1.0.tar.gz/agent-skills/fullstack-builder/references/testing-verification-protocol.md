# 全栈项目验证测试协议

## 用户测试偏好

该用户有严格的测试偏好，所有系统测试/验证阶段必须遵守以下规则：

### 核心原则：只读测试

**测试阶段仅允许 GET 请求**，禁止任何可能产生副作用或写入数据的操作，包括：

| 禁止的操作 | 原因 |
|-----------|------|
| POST /api/... | 创建新数据 |
| PUT /api/... | 更新已有数据 |
| DELETE /api/... | 删除数据 |
| PATCH /api/... | 部分更新 |

### 验证策略

由于测试阶段无法写入测试数据，验证系统功能时应：

```
1. 依赖已存在的测试数据（如预先上传的测试PDF）
2. 只调用 GET 端点验证：
   - GET /api/health              → 检查服务健康
   - GET /api/batches/            → 查看已有批次
   - GET /api/batches/{id}        → 查看单批次详情
   - GET /api/config              → 检查配置
3. 功能验证仅做状态确认，不创建/修改数据
```

### 修复操作策略

需要写入数据的操作（如修复BUG后的全链路测试）使用受控API：

| 操作 | 工具 |
|------|------|
| 修改文件 | `patch` (find-and-replace) |
| 创建文件 | `write_file` |
| 技能管理 | `skill_manage` |
| 记忆写入 | `memory` |
| 项目管理 | `cronjob` (只读操作用 list, 修复用 update) |

### 验证测试步骤（GET-only）

```bash
# 1. 健康检查
curl -s http://localhost:8001/api/health

# 2. 检查已有数据
curl -s http://localhost:8001/api/batches/ | python3 -c "..."

# 3. 前端状态
curl -s -o /dev/null -w '%{http_code}' http://localhost:5173/
```

### 系统重启后的恢复验证

全栈项目（FastAPI + Vue/Vite）重启后需验证：
1. 后端进程：`uvicorn app.main:app` 运行中
2. 前端进程：`vite --host --port 5173` 运行中
3. 两端 HTTP 响应正常
4. 测试材料/上传目录可访问
