# 可折叠分组表格模式 (Collapsible Grouped Table)

## 场景

API返回带分组键（如 `round_no`、`category_id`）的数组，前端希望按组展示为可折叠卡片，每组头部有汇总统计。

## 核心模式

### 后端数据要求

每个item必须包含分组键：

```json
{
  "results": [
    {"check_no": 1, "check_name": "姓名核对", "round_no": 1, "status": "pass"},
    {"check_no": 2, "check_name": "岗位级别", "round_no": 1, "status": "error"},
    {"check_no": 8, "check_name": "账单核对", "round_no": 2, "status": "warn"}
  ]
}
```

### 前端Computed分组 + Reactive展开状态

```vue
<script setup>
import { computed, reactive, watch } from 'vue'

const props = defineProps({ items: { type: Array, default: () => [] } })
const expandedRounds = reactive({})

// 1. 轮次名称映射
const ROUND_NAMES = { 1: '基本信息核对', 2: '账单核对' }

// 2. 数字转中文
function cnRound(n) {
  const map = ['一', '二', '三', '四', '五', '六']
  return map[n - 1] || n
}

// 3. 分组逻辑
const groupedItems = computed(() => {
  const groups = {}
  for (const item of props.items) {
    const key = item.round_no || 1
    if (!groups[key]) {
      groups[key] = {
        round_no: key,
        round_name: ROUND_NAMES[key] || `轮次${key}`,
        items: [],
        passCount: 0, warnCount: 0, errorCount: 0,
      }
    }
    groups[key].items.push(item)
    if (item.status === 'pass') groups[key].passCount++
    else if (item.status === 'warn' || item.status === 'warning') groups[key].warnCount++
    else if (item.status === 'error') groups[key].errorCount++
  }
  return Object.values(groups).sort((a, b) => a.round_no - b.round_no)
})

// 4. 默认展开第一组
watch(() => props.items.length, (len) => {
  if (len > 0) {
    const groups = groupedItems.value
    if (groups.length > 0 && !expandedRounds[groups[0].round_no]) {
      expandedRounds[groups[0].round_no] = true
    }
  }
}, { immediate: true })

function toggleRound(roundNo) {
  expandedRounds[roundNo] = !expandedRounds[roundNo]
}
</script>
```

### 模板结构

```html
<el-card v-for="group in groupedItems" :key="group.round_no" class="round-card">
  <template #header>
    <div class="round-header" @click="toggleRound(group.round_no)">
      <el-icon>{{ expandedRounds[group.round_no] ? ArrowDown : ArrowRight }}</el-icon>
      <span>第{{ cnRound(group.round_no) }}轮 · {{ group.round_name }}</span>
      <el-tag size="small">{{ group.items.length }}项</el-tag>
      <span class="pass">🟢{{ group.passCount }}</span>
      <span class="warn">🟡{{ group.warnCount }}</span>
      <span class="error">🔴{{ group.errorCount }}</span>
    </div>
  </template>
  <el-table v-if="expandedRounds[group.round_no]" :data="group.items" stripe size="small">
    <!-- 表格列定义 -->
  </el-table>
</el-card>
```

### CSS关键点

```css
.round-header {
  display: flex;
  align-items: center;
  cursor: pointer;
  user-select: none;
}
.round-card { margin-bottom: 12px; border-radius: 8px; }
```

## 常见陷阱

### 陷阱1：View层Computed遗漏了分组键

**症状：** 子组件始终平铺展示，无法分组

```js
// ❌ 错误
const checkItems = computed(() => results.results.map(r => ({
  name: r.check_name,      // 只取了展示字段
  status: r.status,         // 忘了传round_no
})))

// ✅ 正确
const checkItems = computed(() => results.results.map(r => ({
  name: r.check_name,
  round_no: r.round_no,     // 透传分组键
  status: r.status,
})))
```

### 陷阱2：reactive对象未初始化导致展开无效

```js
// ❌ 错误：首次点击不会展开
const expandedRounds = reactive({})

// ✅ 正确：watch+immediate确保首次数据加载时自动展开第一个组
watch(() => props.items.length, (len) => { ... }, { immediate: true })
```

### 陷阱3：状态值不统一导致计数错误

```js
// ❌ 错误：后端返回 'warning' 但前端只检查 'warn'
else if (item.status === 'warn') group.warnCount++

// ✅ 正确：包容性检查
else if (item.status === 'warn' || item.status === 'warning') group.warnCount++
```

## 什么时候用

- ✅ 审计/检查/核对类结果展示（按轮次/类别/模块分组）
- ✅ 任务/工单列表（按状态/优先级分组）
- ✅ 测试结果（按测试套件/模块分组）
- ❌ 数据量>500条时（用服务端分页而非前端分组）
- ❌ 分组层级>2层时（考虑嵌套组件而非单层分组）

## 变体：双列统计布局

左右两列展示不同维度的统计数据：

```
<el-row :gutter="16">
  <el-col :span="14">
    <!-- 进度条组 (el-progress) -->
    <div v-for="item in stats">
      <el-progress :percentage="pct(item.count, total)" :color="item.color" />
    </div>
  </el-col>
  <el-col :span="10">
    <!-- 统计卡片 -->
    <div class="issue-item">🔴 错误: {{ count }}</div>
    <div class="issue-item">🟡 警告: {{ count }}</div>
  </el-col>
</el-row>
```

百分比计算：
```js
function pct(val, total) {
  if (!total) return 0
  return Math.round((val / total) * 100)
}
```
