# Flask API Docs Page Pattern

Auto-generated HTML endpoint documentation for Flask admin tools (no Swagger dependency).

## API Endpoint

```python
@app.route("/api/docs")
def api_docs():
    """Auto-generated API documentation page."""
    routes = [
        ("GET", "/api/init", "Combined init (stats+report+queue+cold)", "系统"),
        ("GET", "/api/stats", "Bid statistics", "系统"),
        # ... list every endpoint organized by category
    ]
    
    categories = {}
    for method, path, desc, cat in routes:
        categories.setdefault(cat, []).append((method, path, desc))
    
    html = "<!DOCTYPE html><html><head><title>API 文档</title>..."
    for cat, items in categories.items():
        html += f"<h2>{cat}</h2><table>..."
        for method, path, desc in items:
            html += f"<tr><td>{method}</td><td>{path}</td><td>{desc}</td></tr>"
    return html
```

## HTML Template

Use a dark theme consistent with the admin UI. Include:
- Header with doc title + total endpoint count
- Category sections with tables
- Each row: HTTP method badge (colored: GET=green, POST=blue, PUT=orange, DELETE=red) + path + description

## Endpoint Categories

For bidding/sales tools, organize into 8+ categories:
1. 系统 (System) — init, health, logs, backup
2. 标书 (Bids) — list, stats, recent, cleanup, update
3. 发送 (Sending) — send, send-queue, schedule
4. 线索 (Leads) — list, scored, import
5. 中标 (Deals) — list, create, update
6. 邮件 (Email) — templates CRUD, send-cold, analytics
7. 报表 (Reports) — daily, charts, pending, csv export
8. AI — chat assistant

## Maintenance

When adding new endpoints, update the `routes` list in api_docs(). The 500 error from forgetting to update docs is better than having no docs at all.
