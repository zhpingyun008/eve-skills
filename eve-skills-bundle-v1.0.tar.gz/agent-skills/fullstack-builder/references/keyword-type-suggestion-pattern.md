# Keyword-Rule Type Suggestion Pattern

Project type/entity classification using keyword rules. Predictable, zero-LLM, instant.

## Architecture

```
POST /api/suggest-type {requirement: string} →
  keyword matching (4+ rule sets) → {project_type, confidence}
```

## Backend Implementation

```python
@app.route("/api/suggest-type", methods=["POST"])
def suggest_type():
    data = request.get_json(force=True)
    req = (data.get("requirement") or "").strip()
    if not req:
        return jsonify({"success": False, "error": "需求为空"}), 400
    
    rules = [
        (["开发", "平台", "软件", "系统", "APP", "小程序"], "研发", 0.85),
        (["信息化", "数字化", "OA", "ERP", "CRM", "管理系统"], "信息化", 0.85),
        (["采购", "设备", "硬件", "服务器", "网络设备"], "采购", 0.80),
        (["运维", "维护", "托管", "监控", "运营"], "运维", 0.80),
    ]
    
    for keywords, ptype, confidence in rules:
        if any(kw in req for kw in keywords):
            return jsonify({"project_type": ptype, "confidence": confidence})
    
    return jsonify({"project_type": "", "confidence": 0.0})
```

## Frontend Integration (debounced)

```javascript
let _typeTimer = null;
async function suggestProjectType() {
    clearTimeout(_typeTimer);
    _typeTimer = setTimeout(async () => {
        const req = document.getElementById('requirement').value.trim();
        if (req.length < 5) return;
        try {
            const r = await fetch('/api/suggest-type', {
                method:'POST', headers:{'Content-Type':'application/json'},
                body: JSON.stringify({requirement: req})
            }).then(r => r.json());
            if (r.project_type && r.confidence > 0.5) {
                const el = document.getElementById('project_type');
                if (!el.value) {
                    el.value = r.project_type;
                    el.style.borderColor = 'var(--accent2)';
                    setTimeout(() => el.style.borderColor = '', 3000);
                }
            }
        } catch(e) { /* silent */ }
    }, 600);
}
```

## Design Principles

| Principle | Rationale |
|-----------|-----------|
| **Rules over LLM** | Keyword matching is instant, predictable, zero cost |
| **Confidence scoring** | Higher confidence for distinct keywords (研发=0.85) vs ambiguous (运维=0.80) |
| **Only fill if empty** | Don't overwrite user's manual selection |
| **Visual feedback** | Brief green border flash confirms auto-fill |
| **Silent failure** | Network errors don't block user flow |

## Extending Rules

Add new rule sets as tuple entries — checked in order, most specific/certain first:
```python
(["AI", "大模型", "机器学习", "深度学习"], "AI", 0.85),
(["区块链", "Web3", "NFT", "智能合约"], "区块链", 0.80),
```
