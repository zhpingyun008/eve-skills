# Smart Lead/Entity Suggestion Pattern

## Use Case

When user types input text in a form, auto-suggest matching entities (leads, orgs, contacts) from a data source so they can one-click select and pre-fill a selector/target.

## Architecture

```
Input (oninput, 400ms debounce) → GET /api/<entity>/suggest?q=keyword → JSON results → inline suggestion cards → onclick → populate target selector
```

## Backend (Flask)

```python
@app.route("/api/leads/suggest")
def leads_suggest():
    q = request.args.get("q", "").strip().lower()
    if not q or len(q) < 2:
        return jsonify({"query": q, "total": 0, "results": []})
    leads_path = os.path.join(DATA_DIR, "leads.json")
    if not os.path.exists(leads_path):
        return jsonify({"query": q, "total": 0, "results": []})
    with open(leads_path) as f:
        leads = json.load(f)
    matched = []
    for l in leads:
        org = (l.get("org") or "").lower()
        project = (l.get("project") or "").lower()
        if q in org or q in project:
            matched.append({"org": l["org"], "email": l.get("email", ""), "tier": l.get("tier", 3)})
    matched = matched[:5]  # Limit to 5
    return jsonify({"query": q, "total": len(matched), "results": matched})
```

## Frontend (Vanilla JS)

```javascript
let _suggestTimer = null;
async function suggestLeads() {
    clearTimeout(_suggestTimer);
    _suggestTimer = setTimeout(async () => {
        const text = document.getElementById('text-input')?.value?.trim() || '';
        const el = document.getElementById('lead-suggestions');
        if (text.length < 3) { el.style.display = 'none'; return; }
        const keywords = text.slice(0, 30).replace(/[^\u4e00-\u9fa5a-zA-Z0-9]/g, ' ').trim();
        if (!keywords) { el.style.display = 'none'; return; }
        try {
            const r = await api(`/api/leads/suggest?q=${encodeURIComponent(keywords)}`);
            if (!r.results || r.results.length === 0) { el.style.display = 'none'; return; }
            el.style.display = 'block';
            el.innerHTML = '<div style="font-size:0.7rem;color:var(--muted);margin-bottom:4px">🏢 匹配线索:</div>' +
                r.results.map(l => `<div class="lead-suggestion" onclick="selectSuggestedLead('...')">
                    <span class="org">${l.org}</span>
                    <span class="tier-badge tier-${l.tier||3}">T${l.tier||3}</span>
                    <span class="email">${l.email || '无邮箱'}</span>
                    <span style="font-size:0.7rem;color:var(--primary)">选择 →</span>
                </div>`).join('');
        } catch(e) { /* silent fail */ }
    }, 400);
}
```

## HTML Elements

```html
<textarea id="text-input" oninput="suggestLeads()"></textarea>
<div id="lead-suggestions" style="display:none;margin-bottom:8px"></div>
<select id="lead-select"><option value="">自由生成</option></select>
```

## Pitfalls

1. **Debounce is essential** — without it, every keystroke fires a request. 300-400ms is the sweet spot.
2. **Minimum query length** — require ≥3 chars to avoid empty-result noise.
3. **Special character escaping** — org names with quotes need `replace(/'/g,"\\'")` in onclick inline handlers.
4. **No error toast on suggestion failure** — silent fail is intentional; user is typing, don't distract.
5. **Results limited to 5** — keeps UI clean and response fast.
