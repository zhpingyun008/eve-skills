# Shopify Order Sync Integration Guide

## When to Use This

An Eve product backend (FastAPI + SQLAlchemy) already has Order/OrderPlatform models and CRUD endpoints. Now you need to auto-import orders from a Shopify store so the business dashboard shows real revenue data — not manual entries.

## Backend Implementation

### 1. Sync endpoint (`desk/routes.py`)

```python
@router.post("/sync/{platform_id}")
async def sync_orders(platform_id: int, days: int = 7,
                      user: User = Depends(get_current_user), db: AsyncSession = Depends(get_session)):
    result = await db.execute(select(OrderPlatform).where(
        OrderPlatform.id == platform_id, OrderPlatform.tenant_id == user.tenant_id))
    platform = result.scalar_one_or_none()
    if not platform: raise HTTPException(status_code=404)
    if platform.platform_type == "shopify":
        return await _sync_shopify(platform, user.tenant_id, db, days)
    raise HTTPException(400, detail=f"Unsupported: {platform.platform_type}")
```

### 2. Shopify API client (same file, private function)

```python
async def _sync_shopify(platform, tenant_id, db, days=7):
    import httpx
    url = f"https://{platform.name}/admin/api/2024-01/orders.json"
    headers = {"X-Shopify-Access-Token": platform.api_key}
    params = {"status": "any", "limit": 50,
              "created_at_min": (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()}

    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.get(url, headers=headers, params=params)
        resp.raise_for_status()
        shopify_orders = resp.json().get("orders", [])

    imported = 0
    for so in shopify_orders:
        # de-duplicate by platform_order_id
        existing = await db.execute(select(Order).where(
            Order.platform_order_id == str(so["id"]), Order.tenant_id == tenant_id))
        if existing.scalar_one_or_none(): continue

        # Map Shopify financial_status → internal status
        status_map = {"pending":"pending","authorized":"confirmed","paid":"confirmed",
                      "refunded":"refunded","cancelled":"cancelled","fulfilled":"shipped"}
        order_status = status_map.get(so.get("financial_status","pending"), "pending")
        if so.get("fulfillment_status") == "fulfilled": order_status = "delivered"

        customer = so.get("customer") or {}
        billing = so.get("billing_address") or {}
        order = Order(tenant_id=tenant_id, platform_id=platform.id,
            platform_order_id=str(so["id"]), platform_name=platform.name,
            order_number=str(so.get("order_number","")),
            customer_name=f"{customer.get('first_name','')} {customer.get('last_name','')}",
            total_amount=float(so.get("total_price",0)),
            status=order_status,
            items=[{"id":li["id"],"title":li["title"],"quantity":li["quantity"]}
                   for li in so.get("line_items",[])],
            order_date=datetime.fromisoformat(so["created_at"].replace("Z","+00:00")))
        db.add(order); imported += 1

    platform.last_sync_at = datetime.now(timezone.utc)
    await db.commit()
    return {"success":True, "imported":imported, "skipped":len(shopify_orders)-imported}
```

### 3. Platform credentials management

```python
@router.put("/platforms/{platform_id}")
async def update_platform(platform_id, api_key="", user=Depends(get_current_user),
                          db=Depends(get_session)):
    platform = await db.get(OrderPlatform, platform_id)
    if not platform or platform.tenant_id != user.tenant_id: raise HTTPException(404)
    if api_key: platform.api_key = api_key
    await db.commit(); await db.refresh(platform)
    return platform
```

## Frontend Integration

### React PlatformManager Component

```tsx
// Desk.tsx — between stats and order list
function PlatformManager({ onSync }: { onSync: () => void }) {
  // States: platforms[], showAdd, configuring (platform id), syncing (platform id)
  // UI: Add platform button → domain + type form → save
  //      Each platform row: name + type + 🔑/⚙️ + Configure button + Sync button
  //      Configure mode: inline input for Shopify Admin API Token + save
  //      Sync button disabled while in progress, shows "同步中..."
}
```

### API Client

```typescript
export const orderApi = {
  updatePlatform: (id: number, apiKey: string) =>
    request(`/api/v1/desk/platforms/${id}?api_key=${encodeURIComponent(apiKey)}`, { method: 'PUT' }),
  sync: (platformId: number, days = 7) =>
    request(`/api/v1/desk/sync/${platformId}?days=${days}`, { method: 'POST' }),
};
```

## Getting Shopify Credentials

Shopify Admin → Settings → Apps and sales channels → Develop apps
→ Create app → Configure Admin API scopes (read_orders, read_products)
→ Generate Admin API access token (shpat_xxxxxxxxx)

## Key Points

1. **Same pattern works for any platform** (Taobao, JD, Pinduoduo) — just swap the API adapter function
2. **De-duplication** uses `platform_order_id + tenant_id` — never import the same order twice
3. **Chinese URL characters cause "Invalid HTTP request" in curl** — always URL-encode or use Python/JS to send requests
4. **API token stored server-side only** — never expose in frontend code
5. **Sync scope**: adjustable `days` parameter (default 7 days back)
