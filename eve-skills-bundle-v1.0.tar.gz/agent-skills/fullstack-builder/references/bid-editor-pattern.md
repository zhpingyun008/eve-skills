# Bid Editor / Inline Document Edit Pattern (标书在线编辑器)

For products that generate markdown documents, add inline editing capability so users can tweak content directly in the Web UI without needing a separate editor.

## API

```
POST /api/bid/update  {path, content}  → {success}
POST /api/bid/delete  {path}           → {success}
GET  /api/bid-content?path=<path>      → {content}
```

## Implementation

```python
@app.route("/api/bid/update", methods=["POST"])
def api_bid_update():
    data = request.get_json(force=True)
    path = data.get("path", "")
    content = data.get("content", "")
    
    if not os.path.exists(path):
        return jsonify({"error": "文件不存在"}), 404
    if not content.strip():
        return jsonify({"error": "内容不能为空"}), 400
    
    with open(path, "w") as f:
        f.write(content)
    
    # Update tracking metadata
    tracking_file = os.path.expanduser("~/company/data/bid-tracking.json")
    if os.path.exists(tracking_file):
        with open(tracking_file) as f:
            tracking = json.load(f)
        for b in tracking.get("bids", []):
            if b.get("bid_path") == path:
                b["updated_at"] = datetime.now().strftime("%Y-%m-%d %H:%M")
        with open(tracking_file, "w") as f:
            json.dump(tracking, f, ensure_ascii=False, indent=2)
    
    return jsonify({"success": True})


@app.route("/api/bid/delete", methods=["POST"])
def api_bid_delete():
    data = request.get_json(force=True)
    path = data.get("path", "")
    if not path or not os.path.exists(path):
        return jsonify({"error": "文件不存在"}), 404
    try:
        os.remove(path)
        return jsonify({"success": True, "path": path})
    except Exception as e:
        return jsonify({"error": str(e)}), 500
```

## Web UI Flow — Full Chain

### State Variables

```javascript
let _editBidPath = '';           // path of the currently open bid
let _editBidName = '';           // filename for display
const _editorFile = {};          // cache { content: '...' }
```

### Preview Mode

```javascript
function previewBid(path) {
    _editBidPath = path;
    _editBidName = path.split('/').pop() || path;
    
    document.getElementById('bid-modal').classList.add('show');
    document.getElementById('modal-title').innerHTML = `📖 ${_editBidName.slice(0,40)}`;
    
    const el = document.getElementById('modal-body');
    el.innerHTML = '<div class="loading"></div>';
    
    fetch(`/api/bid-content?path=${encodeURIComponent(path)}`)
        .then(r => r.json()).then(d => {
            if (d.error) { el.innerHTML = `<div class="empty-state">${d.error}</div>`; return; }
            _editorFile.content = d.content;     // cache for edit mode
            el.innerHTML = `<pre>${d.content}</pre>`;
        });
}
```

### Direct Edit Mode — v2.20 (preferred over preview→edit flow)

```javascript
async function editBidDirect(path) {
    // Direct edit — fetch content then open editor, skipping preview entirely
    _editBidPath = path;
    _editBidName = path.split('/').pop() || path;
    document.getElementById('bid-modal').classList.add('show');
    document.getElementById('modal-title').innerHTML = '⏳ 加载中...';
    const el = document.getElementById('modal-body');
    el.innerHTML = '<div class="loading"></div>';

    try {
        const r = await fetch(`/api/bid-content?path=${encodeURIComponent(path)}`)
            .then(r => r.json());
        if (r.error) { el.innerHTML = `<div class="empty-state">${r.error}</div>`; return; }
        _editorFile.content = r.content;
        _showEditor(r.content);
    } catch(e) {
        el.innerHTML = '<div class="empty-state">加载失败</div>';
    }
}
```

Use this for the ✏️ button in the bid list, replacing `previewBid+setTimeout`:

```html
<button onclick="editBidDirect('${b.path}')" title="编辑标书">✏️</button>
```

### Edit Mode — v2.19 Enhanced (from preview)

```javascript
async function editBid() {
    if (!_editBidPath) { toast('📖 请先点击标书名称预览', 'warn'); return; }
    
    const el = document.getElementById('modal-body');
    const currentContent = _editorFile.content || el.textContent || el.innerText;
    const charCount = currentContent.length;
    
    // Update modal title with filename + char count
    document.getElementById('modal-title').innerHTML = `✏️ ${_editBidName.slice(0,35)} (${charCount}字)`;
    
    // Build UI: toolbar + textarea (EMPTY content) + char count
    el.innerHTML = `
        <div id="editor-toolbar" style="display:flex;gap:6px;margin-bottom:6px;flex-wrap:wrap">
            <span style="font-size:0.75rem;color:var(--muted);flex:1">${charCount}字</span>
            <button class="btn btn-sm" onclick="toggleFullscreen()">⛶ 全屏</button>
            <button class="btn btn-sm btn-success" onclick="saveBid()">💾 保存</button>
            <button class="btn btn-sm" onclick="previewBid('${_editBidPath}')">取消</button>
            <span id="edit-status" style="font-size:0.75rem;color:var(--muted);margin-left:4px"></span>
        </div>
        <textarea id="bid-editor" style="width:100%;height:400px;..."
            oninput="updateCharCount()"></textarea>
        <div style="font-size:0.7rem;color:var(--muted);margin-top:4px" id="edit-char-count">
            ${charCount} 字符
        </div>`;
    
    // Set content via DOM API — NEVER inline in HTML
    document.getElementById('bid-editor').value = currentContent;
}
```

### Fullscreen Toggle

```javascript
function toggleFullscreen() {
    const editor = document.getElementById('bid-editor');
    const modal = document.getElementById('bid-modal').querySelector('.modal-content');
    if (!editor) return;
    
    const isFull = editor.style.height === '80vh';
    editor.style.height = isFull ? '400px' : '80vh';
    modal.style.maxWidth = isFull ? '800px' : '95vw';
    modal.style.width = isFull ? '' : '95vw';
}
```

### Tab Key → 4 Spaces

```javascript
// Add onkeydown to textarea
// <textarea onkeydown="return handleEditorKey(event)"></textarea>

function handleEditorKey(e) {
    if (e.key === 'Tab') {
        e.preventDefault();
        const ta = e.target;
        const start = ta.selectionStart;
        const end = ta.selectionEnd;
        ta.value = ta.value.substring(0, start) + '    ' + ta.value.substring(end);
        ta.selectionStart = ta.selectionEnd = start + 4;
        updateCharCount();
        return false;
    }
    return true;
}
```

### _showEditor helper

```javascript
function _showEditor(content) {
    const charCount = content.length;
    document.getElementById('modal-title').innerHTML = `✏️ ${_editBidName.slice(0,35)} (${charCount}字)`;
    const el = document.getElementById('modal-body');
    el.innerHTML = `...toolbar with fullscreen/save/cancel buttons...`;
    // Set content via DOM, NOT inline in innerHTML
    document.getElementById('bid-editor').value = content;
    document.getElementById('bid-editor').focus();
}
```

### Auto-fetch in editBid

If `_editorFile.content` is empty, `editBid()` should fetch content directly rather than relying on DOM textContent:

```javascript
async function editBid() {
    if (!_editBidPath) { toast('📖 请先预览标书', 'warn'); return; }
    
    // Auto-fetch if content not cached
    if (!_editorFile.content) {
        try {
            const r = await fetch(`/api/bid-content?path=${encodeURIComponent(_editBidPath)}`)
                .then(r => r.json());
            if (r.error) { toast(`加载失败: ${r.error}`, 'error'); return; }
            _editorFile.content = r.content;
            _showEditor(r.content);
        } catch(e) { toast('加载失败', 'error'); }
        return;
    }
    
    const el = document.getElementById('modal-body');
    const currentContent = _editorFile.content || el.textContent || el.innerText;
    _showEditor(currentContent);
}
```

### Save → Auto-refresh Preview + List + Stats + List

```javascript
async function saveBid() {
    const content = document.getElementById('bid-editor').value;
    if (!content.trim()) { toast('内容不能为空', 'error'); return; }
    
    try {
        const r = await api('/api/bid/update', {path: _editBidPath, content});
        _editorFile.content = content;  // update cache
        
        document.getElementById('edit-status').textContent = '✅ 已保存';
        toast('✅ 标书已保存');
        
        // Auto-refresh back to preview after 600ms
        loadRecent();         // refresh bid list
        loadStats();          // update stats after content change
        setTimeout(() => previewBid(_editBidPath), 800);
    } catch(e) {
        document.getElementById('edit-status').textContent = `❌ ${e.message}`;
        toast(`❌ 保存失败: ${e.message}`, 'error');
    }
}
```

### Delete

```javascript
async function deleteBid(path) {
    if (!confirm(`确认删除标书？\n${path.split('/').pop()}`)) return;
    try {
        const r = await api('/api/bid/delete', {path});
        toast(`🗑️ 已删除: ${r.path.split('/').pop()}`);
        closeModal();         // standard close
        loadRecent();         // refresh list
        loadStats();          // update stats
    } catch(e) { toast(`❌ 删除失败: ${e.message}`, 'error'); }
}
```

## Modal Structure — Recommended

```html
<div class="modal-overlay" id="bid-modal" onclick="if(event.target===this)closeModal()">
    <div class="modal-content">
        <div class="modal-header">
            <h3 id="modal-title">标书预览</h3>
            <button class="modal-close" onclick="closeModal()">&times;</button>
        </div>
        <div class="modal-body" id="modal-body"><div class="loading"></div></div>
        <div class="modal-footer" style="display:flex;gap:8px;justify-content:space-between">
            <button style="background:#ef4444;color:#fff" onclick="deleteBid(path)">🗑️</button>
            <div style="display:flex;gap:8px">
                <button onclick="editBid()">✏️</button>
                <button onclick="printBid(path)">🖨️</button>
                <button onclick="shareBid(path)">🔗</button>
                <button onclick="closeModal()">关闭</button>
            </div>
        </div>
    </div>
</div>
```

## Discoverability

Every button MUST have a `title` attribute:

```javascript
// Preview — most important, must be obvious
`<button title="预览标书">📖</button>`
`<a href="javascript:previewBid(path)">标书名称</a>`  // bid name is clickable

// Edit — inline in bid list for quick access
`<button title="编辑标书" onclick="previewBid(path);setTimeout(editBid,300)">✏️</button>`
```

The bid name link is the most discoverable entry point. The 📖 button provides the tooltip. The ✏️ button in the list is for power users who know what they want.

## Pitfalls

1. **HTML escaping**: NEVER inline `${content}` in textarea HTML. Always:
   ```javascript
   innerHTML = '<textarea id="x"></textarea>';  // empty
   document.getElementById('x').value = content; // via DOM
   ```

2. **Content freshness**: After preview loads, `_editorFile.content` has the raw API content. Edit mode reads from this cache, not from DOM `textContent` (which may include whitespace artifacts from `<pre>` tags).

3. **Save → Preview cycle**: After save, auto-refresh preview so the user sees the saved version. 600ms delay allows the toast to appear first.

4. **Inline ✏️ button**: Use `editBidDirect(path)` for the pipeline ✏️ button. It fetches content and opens editor directly with no timing dependency. For the modal footer ✏️ button, use `editBid()` which auto-fetches content if `_editorFile.content` is empty. NEVER use `previewBid(path); setTimeout(editBid, N)` — the async fetch may not complete in time, resulting in the editor displaying "loading" text as content.

5. **editBid() auto-fetch**: If `_editorFile.content` is empty (e.g., modal footer ✏️ clicked after preview has been closed/reopened), `editBid()` should fetch content directly:**: Always use a named function `closeModal()` rather than inline `document.getElementById('modal').classList.remove('show')`. This allows the modal-footer's close button and overlay click to use the same handler.

6. **Char count in title**: Updating `modal-title` innerHTML during edit is fine, but when returning to preview, reset the title to `📖 ${filename}`.
