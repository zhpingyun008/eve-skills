# Auto Share + Tracking Pixel Pattern

## Problem
When sending documents via email, the sender has no way to know if the recipient opened/viewed the document. Adding a share link with tracking pixel creates a feedback loop.

## Implementation

### 1. Auto-create share on send
In the send-bid/send-document API endpoint, auto-generate a UUID share_id and save to `data/shares.json`:

```python
import uuid
share_id = uuid.uuid4().hex[:12]
share_file = os.path.join(os.path.dirname(__file__), "data", "shares.json")
shares = {}
if os.path.exists(share_file):
    with open(share_file) as f: shares = json.load(f)
shares[share_id] = {
    "path": path, "name": os.path.basename(path),
    "email": email, "created": datetime.now().strftime("%Y-%m-%d %H:%M"),
}
with open(share_file, "w") as f: json.dump(shares, f, ensure_ascii=False, indent=2)
```

### 2. Embed tracking pixel in shared page
In the /share/<id> view, append a 1x1 transparent GIF image:

```python
tracking_pixel = f'<img src="/track/{share_id}" width="1" height="1" style="display:none" alt=""/>'
# Append to bottom of HTML body: {html_body}{tracking_pixel}
```

### 3. Track pixel endpoint
```python
@app.route("/track/<share_id>")
def track_view(share_id):
    """Return 1x1 transparent GIF and log the view."""
    from src.database import get_db
    db = get_db()
    db.execute("""CREATE TABLE IF NOT EXISTS tracking_views (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        share_id TEXT, ip TEXT, ua TEXT,
        viewed_at TEXT DEFAULT (datetime('now','localtime'))
    )""")
    db.execute("INSERT INTO tracking_views (share_id, ip, ua) VALUES (?, ?, ?)",
               (share_id, request.remote_addr or "", request.user_agent.string or ""))
    db.commit()
    gif = base64.b64decode("R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7")
    return Response(gif, mimetype="image/gif")
```

## Key Points
- Share JSON file path: `data/shares.json` (simple file-based, no extra DB table needed)
- Tracking pixel is a single transparent GIF pixel — renders instantly, no visual impact
- Tracking data goes to SQLite tracking_views table for persistence
- Email notifications should include the share URL (e.g. `http://host/share/{share_id}`)
