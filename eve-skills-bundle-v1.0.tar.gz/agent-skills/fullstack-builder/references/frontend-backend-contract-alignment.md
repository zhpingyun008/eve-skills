# 前后端接口契约对齐 — 全栈多Agent开发陷阱

## 场景

多Agent并行开发全栈项目时，后端subagent和前端subagent各自独立工作，
修BUG或加功能时可能无意间改变API字段名/状态枚举/材料类型键名，
导致前端无声故障（上传不识别、进度不动、结果不显示）。

---

## 三大经典陷阱

### 陷阱1：材料类型键名断裂

**症状：** 文件上传成功、API返回200、但不显示在材料清单中

**根因链路：**

```
file_service.py MATERIAL_TYPES → 返回 material_type = "settlement"
extractor MAP                  → 使用 "settlement_workload"        ← 不匹配！
前端 MATERIALS key             → 使用 "settlement"                 ← 不匹配！
```

**修复：** 以 `file_service.detect_material_type()` 的返回值为唯一事实来源，
前端MATERIALS数组的key必须与之完全一致。

**快速检测命令：**

```bash
# 后端返回的键名
grep '"' backend/app/services/file_service.py | grep ':'
# 前端期待的键名
grep "key:" frontend/src/views/UploadView.vue
# 比对两组是否一致
```

### 陷阱2：状态枚举值不匹配

**症状：** 点击「开始核对」后，进度条始终0%、结果页始终不显示

**根因：** 前端用 `=== 'completed'` 判断完成，API返回 `"done"`

**经典不匹配表：**

| 前端硬编码 | API实际返回 | 结果 |
|-----------|------------|------|
| `=== 'completed'` | `"done"` | ❌ 永远不加载结果 |
| `=== 'running'` | `"checking"` | ❌ 永远不启动轮询 |
| `=== 'failed'` | `"error"` | ❌ 永远不显示错误态 |

**修复：**
- 后端返回后立即在全栈测试中curl验证状态值
- 前端改用包容性检查：`status === 'done' || status === 'completed'`
- 或前后端约定同一份常量表

### 陷阱3a：跨组件状态一致性

**症状：** ProgressBar显示"等待中"但后端返回`"done"`；或状态标签颜色不对。

**根因：** 后端状态枚举是`"done"`，但ProgressBar、CheckView、UploadView、HistoryView各自独立写死了不同的判断逻辑——部分只认`"completed"`，部分只认`"done"`。

**受影响的组件清单（必须全部检查）：**

| 组件 | 检查点 |
|------|--------|
| ProgressBar.vue | `tagType`, `tagText`, `progressStatus` computed |
| CheckView.vue | `statusTagType`, `statusText`, `loadResults()`, `startPolling()` |
| UploadView.vue | `statusType()`, `statusLabel()` |
| HistoryView.vue | `statusType()`, `statusLabel()` |
| CheckTable.vue | round card汇总中的状态判断 |

**修复模式：**

每个状态判断函数必须同时兼容后端所有可能的枚举值：

```js
// ✅ 统一模式
function isDone(s)  { return s === 'done' || s === 'completed' }
function isRunning(s) { return s === 'running' || s === 'checking' || s === 'parsing' }
function isFailed(s) { return s === 'failed' || s === 'error' }

// ProgressBar tagType
if (isDone(status))   return 'success'
if (isRunning(status)) return 'primary'
if (isFailed(status))  return 'danger'
return 'warning'
```

**预防：** 在项目初期就定义一份共享的状态映射表（JSON常量），前端所有组件引用同一份，后端枚举也引用同一份。变更时只需改一处。

---

### 陷阱3b：Fix subagent污染接口契约

**症状：** 修好一个BUG → 引入另一个BUG（如材料识别失效）

**根因：** Fix subagent在修改后端时，无意改变了前端依赖的字段名

**预防措施（在Fix subagent context中声明）：**

```
【重要】禁止修改以下内容：
- API路由路径和HTTP方法
- API响应字段名
- 材料类型键名（material_type）
- 状态枚举值
- 前端Vue组件props和emit事件名
```

**验证命令（Fix后执行）：**

```bash
# 1. 确认后端键名未被改变
grep -c "settlement_workload" backend/app/services/file_service.py

# 2. 确认前端键名未变
curl -s -X POST ... | python3 -c "import sys,json; d=json.load(sys.stdin); print(d['materials'][0]['material_type'])"

# 3. 确认前后端匹配
```

---

## 通用预防策略

1. **单一事实来源**：材料类型键名、状态枚举、API字段名只在一个地方定义，其他层引用
2. **禁止隐式映射**：`MATERIAL_TYPE_TO_ENGINE_KEY` 等映射表是危险信号——优先统一键名而非加映射层
3. **全栈集成验证快照**：构建完成后立即curl全链路API返回，与前端期望比对
4. **Fix subagent安全边界**：在context中显式声明不可修改的接口契约

---

## 陷阱4：响应体结构不匹配（顶层字段名）

**症状：** 前端`results.items`永远为空，表格始终空白，但API明确返回了24条数据

**根因：** 后端返回`{results: [...], issues: {error:[], warning:[]}}`，而前端直接写死`response.items`和`response.issues`（期望数组），字段名和结构双重不匹配

**经典不匹配表：**

| 前端期望 | API实际返回 | 结果 |
|---------|------------|------|
| `response.items` | `response.results`（数组） | ❌ 表格空白 |
| `response.issues`（数组） | `response.issues`（对象`{error:[], warning:[]}`） | ❌ IssueList无数据 |
| `summary.passed` | `summary.pass_count` | ❌ 统计卡片显示0 |
| `summary.warnings` | `summary.warning_count` | ❌ 统计卡片显示0 |
| `summary.errors` | `summary.error_count` | ❌ 统计卡片显示0 |
| `checkItem.name` | `checkItem.check_name` | ❌ 表格列空白 |
| `checkItem.round_no` | 未传递 | ❌ 无法按轮次分组 |

**修复方案（三层兜底）：**

### 第1层：入站映射（View层Computed）

在Vue computed中做一次数据转换，而非在各子组件中逐个适配：

```js
const checkItems = computed(() => {
  if (!results.value?.results) return []  // ← 后端用results而非items
  return results.value.results.map(r => ({
    name: r.check_name,           // ← 映射字段名
    round_no: r.round_no,         // ← 透传分组字段
    status: r.status === 'warning' ? 'warn' : r.status,  // ← 标准化状态值
    expected: r.detail?.expected,  // ← 展开嵌套字段
    actual: r.detail?.actual,
    diff: r.detail?.diff,
    remark: r.detail?.remark || '',
  }))
})

const mergedIssues = computed(() => {
  if (!results.value?.issues) return []
  const raw = results.value.issues
  const list = []
  // 后端可能返回分组格式 {error:[], warning:[]}
  if (raw.error && Array.isArray(raw.error)) {
    raw.error.forEach(i => list.push({...i, severity: 'error'}))
    raw.warning?.forEach(i => list.push({...i, severity: 'warning'}))
  }
  // 也可能返回平铺数组
  if (Array.isArray(raw)) list.push(...raw)
  return list
})
```

### 第2层：子组件字段兼容

模板中使用兜底访问而非单字段：

```html
<el-table-column prop="name" label="检查项" min-width="200">
  <template #default="{ row }">
    {{ row.name || row.check_name || '-' }}
  </template>
</el-table-column>
```

### 第3层：API层统一（终极方案）

在后端response model或前端axios拦截器中做一次标准化，所有组件直接消费统一格式。

**全链路验证命令：**

```bash
# 1. 检查API返回的结构
curl -s http://localhost:8001/api/batches/30/check/results | python3 -c "
import sys,json; d=json.load(sys.stdin)
print('顶层键:', list(d.keys()))
print('results类型:', type(d['results']).__name__, len(d['results']))
print('issues类型:', type(d['issues']).__name__)
if isinstance(d['issues'], dict): print('  子键:', list(d['issues'].keys()))
print('summary:', json.dumps(d['summary'], ensure_ascii=False))
"

# 2. 前端接口层期望的键名
grep -n "\.items\|\.results\|\.issues\|\.summary" frontend/src/views/*.vue

# 3. 后端实际返回的键名
grep -n "return {" backend/app/routers/*.py | head -20
```

---

## 通用预防策略（补充）

5. **归一化层**：在前端API请求层（axios拦截器）或后端response model中，统一做一次字段名/结构转换，避免每个View层手动映射
6. **结构快照测试**：每次前后端变更后，curl全链路API → 保存JSON快照 → 与前一次diff，确保响应结构不变
7. **子组件健壮性**：模板用`row.fieldA || row.fieldB`兜底，而不是假设字段名固定不变
8. **字段清单验证**：对接前后端时，维护一份api-contract.json声明所有字段名+类型+路径，变更时双端比对此文件

---

## 陷阱5：缺失分组字段导致前端无法按结构展示

**症状：** 前端CheckTable重写为按轮次分组折叠展示（4个卡片+每轮汇总），但表格始终显示平铺，无法分组

**根因：** View层computed映射时只提取了展示字段（name/expected/actual/status），遗漏了分组键（round_no）

```
// ❌ 错误 — 未传递分组键
const checkItems = computed(() =>
  results.results.map(r => ({
    name: r.check_name,
    status: r.status,
    // round_no 缺失 → CheckTable无法分组
  }))
)

// ✅ 正确 — 透传分组键
const checkItems = computed(() =>
  results.results.map(r => ({
    name: r.check_name,
    round_no: r.round_no,   // ← 透传分组字段
    status: r.status,
  }))
)
```

**对子组件设计要求：** 只要子组件支持分组折叠模式（传入groupKey），就应当：
1. 从`props.items`中提取`round_no`（或任意`groupKey`）
2. 按groupKey分组 → 每个组生成折叠卡片
3. 每组头部展示汇总统计（通过/警告/错误计数）
4. 默认展开第一组

**分组折叠组件模板参考（Vue3）：**

```html
<el-card v-for="group in groupedItems" :key="group.round_no">
  <template #header>
    <div class="round-header" @click="toggleRound(group.round_no)">
      <el-icon>{{ expanded ? ArrowDown : ArrowRight }}</el-icon>
      {{ group.round_name }} ({{ group.items.length }}项)
      <span class="pass">🟢{{ group.passCount }}</span>
      <span class="warn">🟡{{ group.warnCount }}</span>
      <span class="error">🔴{{ group.errorCount }}</span>
    </div>
  </template>
  <el-table v-if="expanded" :data="group.items">...</el-table>
</el-card>
```

**Computed分组逻辑（JS）：**

```js
const groupedItems = computed(() => {
  const groups = {}
  for (const item of props.items) {
    const key = item.round_no || 1
    if (!groups[key]) {
      groups[key] = {
        round_no: key,
        items: [],
        passCount: 0, warnCount: 0, errorCount: 0
      }
    }
    groups[key].items.push(item)
    if (item.status === 'pass') groups[key].passCount++
    else if (item.status === 'warn') groups[key].warnCount++
    else if (item.status === 'error') groups[key].errorCount++
  }
  return Object.values(groups).sort((a, b) => a.round_no - b.round_no)
})
```

**预防：** View层computed中必须把后端所有关键字段（包括分组键）透传给子组件，不要只挑展示字段。先确认子组件的`props`声明，再构建computed返回结构。
