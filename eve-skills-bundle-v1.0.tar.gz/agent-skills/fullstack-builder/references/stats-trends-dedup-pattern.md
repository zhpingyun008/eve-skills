# Stats Trends + Lead Dedup Patterns

## Stats Trends — Daily/Weekly Aggregation

For admin tools that need to show trends over time:

```python
@app.route("/api/stats/trends")
def api_stats_trends():
    """Get daily trends for the past 30 days."""
    from src.database import get_db
    db = get_db()
    rows = db.execute("""SELECT * FROM daily_ops ORDER BY date DESC LIMIT 30""").fetchall()
    
    # Weekly aggregates by YYYY-MM
    weekly = {}
    for r in rows:
        d = dict(r)
        week_key = d["date"][:7]  # YYYY-MM
        if week_key not in weekly:
            weekly[week_key] = {"bids":0,"sent":0,"cold":0,"replies":0}
        weekly[week_key]["bids"] += (d.get("bids_generated",0) or 0)
        weekly[week_key]["sent"] += (d.get("bids_sent",0) or 0)
    
    # Current snapshot
    report = generate_daily_report()
    s = report["summary"]
    
    return jsonify({
        "today": {"date": report["date"], "sent": s["sent_bids"], "pipeline": s["pipeline_value_wan"]},
        "weekly": weekly,
        "daily": [dict(r) for r in rows],
    })
```

**Frontend usage**: Display in a trends section in the reports/dashboard tab, or use Chart.js if available.

## Lead Dedup — Merge Duplicates by Organization

For products managing leads/contacts, dedup by organization name:

```python
@app.route("/api/leads/dedup", methods=["POST"])
def api_leads_dedup():
    leads_file = os.path.expanduser("~/company/data/leads.json")
    with open(leads_file) as f: leads = json.load(f)
    
    merged = []
    seen_orgs = set()
    
    for l in leads:
        org = l.get("org", "").strip().lower()
        if not org:
            merged.append(l)
            continue
        if org in seen_orgs:
            # Merge: keep first entry, update missing fields from duplicate
            for existing in merged:
                if existing.get("org","").strip().lower() == org:
                    if l.get("email") and not existing.get("email"):
                        existing["email"] = l["email"]
                    if l.get("match") and existing.get("match","").strip():
                        existing["match"] += " | " + l["match"]
                    if l.get("phone") and not existing.get("phone"):
                        existing["phone"] = l["phone"]
                    break
        else:
            seen_orgs.add(org)
            merged.append(l)
    
    with open(leads_file, "w") as f:
        json.dump(merged, f, ensure_ascii=False, indent=2)
    
    return jsonify({"success": True, "before": len(leads), "after": len(merged), "deduped": len(leads)-len(merged)})
```

**Key**: Normalize org names to lowercase+strip for matching. Keep first occurrence, supplement missing fields from duplicates.
