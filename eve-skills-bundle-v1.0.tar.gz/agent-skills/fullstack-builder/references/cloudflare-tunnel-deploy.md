# Cloudflare Tunnel 部署模式

> 用于将本地FastAPI服务快速暴露到公网。已验证3次(port 9000/8081/8083/8084)。

---

## 标准部署流程

```bash
# 1. 清理旧进程
kill $(lsof -ti:{PORT}) 2>/dev/null; sleep 1

# 2. 启动服务
cd {PROJECT_DIR} && source ~/.hermes/.env && python -m uvicorn api.server:app --host 0.0.0.0 --port {PORT} &

# 3. 验证本地健康
sleep 2 && curl http://localhost:{PORT}/health
# 期望: HTTP 200

# 4. 启动Cloudflare隧道（后台）
cloudflared tunnel --url http://localhost:{PORT} > /tmp/cloudflared_{NAME}.log 2>&1 &

# 5. 等待隧道就绪 + 提取公网URL
sleep 5
grep -E "trycloudflare\\.com" /tmp/cloudflared_{NAME}.log | tail -1
# 输出: https://xxxx.trycloudflare.com

# 6. 保存URL
echo 'https://xxxx.trycloudflare.com' > {PROJECT_DIR}/.public_url

# 7. 公网验证
curl -s -o /dev/null -w "HTTP %{http_code}" https://xxxx.trycloudflare.com/health
# 期望: HTTP 200
```

## 通用脚本

```bash
deploy_tunnel() {
    local PORT=$1 NAME=$2 PROJECT_DIR=$3
    echo "[deploy] Killing old process on :$PORT..."
    kill $(lsof -ti:$PORT) 2>/dev/null; sleep 1
    
    echo "[deploy] Starting $NAME on :$PORT..."
    cd $PROJECT_DIR && source ~/.hermes/.env && nohup python -m uvicorn api.server:app --host 0.0.0.0 --port $PORT > /dev/null 2>&1 &
    sleep 3
    
    echo "[deploy] Starting Cloudflare tunnel..."
    cloudflared tunnel --url http://localhost:$PORT > /tmp/cloudflared_$NAME.log 2>&1 &
    sleep 6
    
    URL=$(grep -oP 'https://[a-z-]+\.trycloudflare\.com' /tmp/cloudflared_$NAME.log | head -1)
    echo "[deploy] Public URL: $URL"
    echo "$URL" > $PROJECT_DIR/.public_url
    
    # Verify
    CODE=$(curl -s -o /dev/null -w "%{http_code}" --max-time 10 "$URL/health" 2>/dev/null)
    echo "[deploy] Health check: HTTP $CODE"
}
```

## 服务端特殊处理

不同项目类型的启动命令不同：

| 项目类型 | 启动命令 |
|---------|---------|
| FastAPI (api.server) | `python -m uvicorn api.server:app --host 0.0.0.0 --port PORT` |
| FastAPI (main:app) | `python -m uvicorn main:app --host 0.0.0.0 --port PORT` |
| 独立Python脚本 | `python server.py`（需脚本内置uvicorn.run） |

## 已知陷阱

1. **cloudflared DNS解析失败**: WSL环境下 `trycloudflare.com` 可能间歇性DNS超时。重试可解决。实测成功率约80%。
2. **URL提取时机**: cloudflared启动后约4-7秒才生成URL。`sleep 5`太短的话URL可能还没出现。
3. **多隧道冲突**: 每个端口需要独立的log文件。不能用同一个log文件。
4. **后台进程持久化**: `nohup` + `&` 确保进程在shell退出后继续运行。background=true 的Hermes进程在会话结束后也继续。
5. **进程残留**: 重部署前必须先 `kill $(lsof -ti:PORT)`，否则新进程因为端口占用启动失败。

## 已部署实例

| 产品 | 端口 | 类型 | 公网URL |
|------|------|------|---------|
| freelancer-tool | 9000 | main:app | classified-found-detected-unwrap.trycloudflare.com |
| 智账AI | 8081 | api.server | clusters-julie-beam-mind.trycloudflare.com |
| 去重工具 | 8083 | api.server | refined-evaluation-gem-chef.trycloudflare.com |
| Listing工具 | 8084 | api.server | balanced-polo-restrict-las.trycloudflare.com |
