# Tracking Pixel Pattern

1x1 transparent GIF tracking for document/email view detection.

## Backend

```python
import base64
from flask import Response

# 1x1 transparent GIF (43 bytes)
TRANSPARENT_GIF = base64.b64decode(
    "R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
)

@app.route("/track/<share_id>")
def api_tracking_pixel(share_id):
    """1x1 transparent GIF that logs when a document is viewed."""
    from src.database import get_db
    db = get_db()
    db.execute("""CREATE TABLE IF NOT EXISTS tracking_views(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        share_id TEXT, ip TEXT, ua TEXT,
        viewed_at TEXT DEFAULT (datetime('now'))
    )""")
    db.execute("INSERT INTO tracking_views(share_id,ip,ua) VALUES(?,?,?)",
        (share_id, request.remote_addr or "", 
         request.user_agent.string[:200] if request.user_agent else ""))
    db.commit()
    db.close()
    return Response(TRANSPARENT_GIF, mimetype="image/gif")

@app.route("/api/tracking/views/<share_id>")
def api_tracking_views(share_id):
    """Get view statistics for a shared document."""
    db = get_db()
    rows = db.execute(
        "SELECT * FROM tracking_views WHERE share_id=? ORDER BY viewed_at DESC LIMIT 50", 
        (share_id,)
    ).fetchall()
    db.close()
    return jsonify({"share_id": share_id, "total": len(rows), "views": [dict(r) for r in rows]})
```

## Embedding in Documents

For generated documents (bids/emails), append a tracking image:
```markdown
---

---
*本标书由 Eve AI 智能生成 | 查看追踪 ID: {share_id}*
![tracking](https://your-domain.com/track/{share_id})
```

The 1x1 GIF is invisible to the reader but logs the view server-side.

## Requirements

- `import base64` at top of app.py
- `from flask import Response` 
- SQLite table `tracking_views` auto-created on first request

## Detection Accuracy

- Records: timestamp + IP address + User-Agent
- Limitations: email clients that block remote images (most by default), cached views, VPN/proxies
- Best for: share links (web browser) where images load by default
