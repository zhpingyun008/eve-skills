# .pyc Disaster Recovery — Recover Corrupted Python Source from Bytecode

## When to use

A Python app.py or module was truncated/corrupted during editing (write_file with line-number-prefixed content, str.replace + write_file truncation, etc.). The `.pyc` file in `__pycache__/` still has the compiled bytecode from the last successful run.

## Recovery approach (two-tier)

### Tier 1: Quick Assessment
First, verify the .pyc is from before the corruption:
```bash
# Check pyc timestamp - should be before the corruption event
ls -la __pycache__/app.cpython-311.pyc
# Check pyc contains the expected functions
python3 -c "
import marshal, types
with open('__pycache__/app.cpython-311.pyc', 'rb') as f:
    header = f.read(16)  # Skip 16-byte header
    code = marshal.loads(header + f.read())
# List known function names
for const in code.co_consts:
    if isinstance(const, types.CodeType):
        print(const.co_name)
"
```

### Tier 2: Decompile (if available)
Try decompyle3 or uncompyle6:
```bash
pip3 install uncompyle6
python3 -c "
import uncompyle6
with open('app_recovered.py', 'w') as f:
    uncompyle6.decompile_file('__pycache__/app.cpython-311.pyc', f)
"
```
Note: Both decompyle3 and uncompyle6 do NOT support Python 3.11+. They will write just metadata.

### Tier 3: .pyc bytecode navigation (Python 3.11+)
```python
import marshal, types
with open('__pycache__/app.cpython-311.pyc', 'rb') as f:
    header = f.read(16)  # 4 magic + 4 flags + 8 hash or timestamp+size
    code = marshal.loads(header + f.read())

# Walk all code objects
functions = []
def walk(c, depth=0):
    for const in c.co_consts:
        if isinstance(const, types.CodeType):
            functions.append((depth, const.co_name, len(co.co_code)))
            walk(const, depth+1)
walk(code)
```

### Tier 4: Sub-agent Reconstruction (most reliable)

When the file is too large to reconstruct manually, delegate:

1. Point the sub-agent to the `.pyc` file and the project structure
2. Give it context about file organization (routes, helpers, main block)
3. The sub-agent will use marshal+dis to understand structure and reconstruct

Key instructions for the sub-agent:
```bash
# Give full context to the sub-agent:
- The .pyc path
- The project type (Flask, FastAPI, etc.)
- Key imports and dependencies
- The working directory
- Known functions from the .pyc scan
```

Example delegation:
```
delegate_task(
    goal="Restore corrupted app.py from .pyc bytecode cache",
    context=f"File: {path}/web/app.py corrupted.\n" +
            f"Pyc: {path}/web/__pycache__/app.cpython-311.pyc\n" +
            f"Project: Flask+SocketIO web app with 65+ routes\n" +
            f"Main block: socketio.run(app, host='0.0.0.0', port=5900)\n" +
            f"Known imports: Flask, SocketIO, RequirementTask, RequirementBase\n" +
            f"Dependencies: core/base.py, core/bootstrap.py, skills/*.py\n" +
            f"VERSION: {read VERSION}",
    toolsets=["terminal","file"]
)
```

### Prevention
- Always use `patch()` tool rather than `execute_code` for file modifications
- Take backups: `cp app.py app.py.bak` before major edits
- Use git: the project should be version-controlled
- Never use `read_file()` output directly as `write_file()` input
