# 前端材料类型检测镜像 — 上传前即时预览

## 场景

文件上传流程中，后端根据文件名关键词自动检测材料类型（如“发票”→“invoice”）。
如果检测不准确（文件名不包含关键词），文件被静默跳过，用户完全不知情。

## 方案：前端镜像检测

将后端的文件名→材料类型关键词匹配逻辑复制到前端，选择文件后**立即**在UI中显示每份文件的识别结果。

## 实现步骤

### 1. 后端关键词表（`file_service.py`）

```python
MATERIAL_KEYWORDS = [
    (["付款确认单", "付款确认", "确认单"], "payment_confirmation", "付款确认单"),
    (["进/离场单", "进离场单", "离场单", "进场单"], "departure_note", "进/离场单"),
    (["结算工作量", "结算"], "settlement_workload", "结算工作量"),
    (["考勤明细", "考勤"], "attendance", "考勤明细"),
    (["考核评分", "考核"], "assessment", "考核评分"),
    (["付款申请审核表", "付款申请", "审核表", "audit"], "payment_audit", "付款申请审核表"),
    (["发票", "invoice"], "invoice", "发票"),
]
```

### 2. 前端镜像（`FileUploader.vue` computed）

```js
const MATERIAL_KEYWORDS = [
  { keywords: ['付款确认单', '付款确认', '确认单'], key: 'payment_confirmation', label: '付款确认单' },
  { keywords: ['进/离场单', '进离场单', '离场单', '进场单'], key: 'departure_note', label: '进/离场单' },
  // ... 完全复制后端逻辑
]

function detectType(filename) {
  const lower = filename.toLowerCase()
  for (const rule of MATERIAL_KEYWORDS) {
    for (const kw of rule.keywords) {
      if (lower.includes(kw.toLowerCase())) {
        return { material_key: rule.key, material_label: rule.label }
      }
    }
  }
  return { material_key: null, material_label: '未识别' }
}

const detectedFiles = computed(() =>
  fileList.value.map(f => ({
    name: f.name, size: f.size,
    ...detectType(f.name),
  }))
)
```

### 3. 前端UI展示

```html
<div v-for="file in detectedFiles" :class="{ warn: !file.material_key }">
  <el-icon v-if="file.material_key" color="#67c23a"><CircleCheck /></el-icon>
  <el-icon v-else color="#e6a23c"><Warning /></el-icon>
  <span>{{ file.name }}</span>
  <el-tag v-if="file.material_key" size="small" type="success">
    {{ file.material_label }}
  </el-tag>
  <el-tag v-else size="small" type="warning">未识别</el-tag>
</div>
```

## 的优势

- **即时反馈**：用户选择文件后立即看到识别结果，无需等待上传
- **预防错误**：未识别的文件高亮显示，用户可及时补充或调整
- **零额外API调用**：完全前端计算，无网络开销
- **一致性保障**：前后端逻辑一致，不会出现前端显示成功但后端跳过的情况

## 陷阱

1. **关键词必须同步**：前端镜像逻辑必须与后端保持完全一致。更新后端关键词表时，前端必须同步更新。
2. **支持多语言**：关键词匹配使用 `toLowerCase()`，确保大小写不敏感。
3. **不替代后端**：前端预览只是UX增强，后端才是真正的类型检测。前后端结果可能因文件名空格/编码有差异。
