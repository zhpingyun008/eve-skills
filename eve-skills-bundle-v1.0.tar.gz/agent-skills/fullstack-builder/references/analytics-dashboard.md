# Analytics Dashboard — Zero-Dependency Canvas Charts & Data Panels

## Architecture Pattern

Add analytics/monitoring panels to existing Flask webapps using **zero external dependencies** — no Chart.js, ECharts, or D3.

```
Backend:  Flask endpoints returning JSON stats
Frontend: Vanilla JS Canvas rendering + CSS-styled panels
Data:     Aggregated from existing DB/task store
```

## Backend API Design

### Pattern: Tiered Endpoints

| Endpoint | Purpose | Aggregation |
|----------|---------|-------------|
| `/api/dashboard/v2` | Full stats (trend/budget/tags/status) | Heavy — iterates all records |
| `/api/benchmark/<id>` | Single-item vs cohort comparison | Moderate — one item + cohort |
| `/api/search/docs?q=` | Document full-text search | Heavy — scans all doc text |
| `/api/timeline` | Event stream (created/archived) | Light — metadata only |

### Response Shape Convention

```json
{
  "success": true,
  "total_tasks": 52,
  "completion_rate": 100.0,
  "monthly_trend": [{"month": "2026-06", "count": 52}],
  "budget_brackets": {"≤50万": 52, "50-100万": 0},
  "status_distribution": {"done": 52},
  "tag_distribution": [{"name": "政府", "count": 1}],
  "project_types": {}
}
```

### Key Backend Patterns

- **Budget binning**: `_parse_budget(val)` → if `<=50`, `<=100`, `<=500`, `<=1000`, `>1000`
- **Monthly trend**: Extract `YYYY-MM` from `created_at`, `defaultdict(int)` counter, sort keys
- **Benchmark stats**: `sorted(arr)` → `min/max/avg/median` — compute percentile via `val/avg*100`
- **Full-text search**: `doc_text.lower().find(q_lower)` + snippet extraction `[pos-60:pos+len(q)+60]`

## Canvas Chart Engine (Zero-Dependency)

### Pie Chart (`drawPie`)

```js
function drawPie(canvasId, data, labels, legendId) {
  const c = document.getElementById(canvasId);
  const ctx = c.getContext('2d');
  const cx = c.width/2, cy = c.height/2, R = Math.min(c.width,c.height)/2 - 10;
  let start = -Math.PI/2;
  data.forEach((v,i) => {
    const angle = (v/total) * Math.PI * 2;
    ctx.beginPath(); ctx.moveTo(cx,cy); ctx.arc(cx,cy,R,start,start+angle);
    ctx.closePath();
    // Gradient fill
    ctx.fillStyle = CHART_COLORS[i];
    ctx.fill();
    // Percentage label (only for slices > 0.3 rad)
    if (angle > 0.3) {
      const mx = cx + Math.cos(start + angle/2) * R*0.6;
      const my = cy + Math.sin(start + angle/2) * R*0.6;
      ctx.fillText(Math.round(v/total*100)+'%', mx, my+4);
    }
    start += angle;
  });
}
```

### Bar Chart (`drawBar`)

```js
function drawBar(canvasId, data, labels, color) {
  const c = document.getElementById(canvasId);
  const ctx = c.getContext('2d');
  const max = Math.max(...data, 1);
  const pad = {t:10, b:20, l:30, r:10};
  const bw = (W - pad.l - pad.r) / data.length;
  data.forEach((v,i) => {
    const bh = (v/max) * (H - pad.t - pad.b);
    const x = pad.l + i * bw + bw*0.1;
    const y = H - pad.b - bh;
    // Rounded rect bars with gradient
    ctx.fillStyle = grad;
    ctx.beginPath(); ctx.roundRect(x,y,w,bh, [3,3,0,0]); ctx.fill();
    // Value above bar
    ctx.fillText(v, x+w/2, y-4);
    // Label below bar
    ctx.fillText(label, x+w/2, H-4);
  });
}
```

### Line Chart (`drawLine`)

```js
// Grid lines (dashed) → area fill (gradient) → line (solid) → dots (circles) → data labels
ctx.strokeStyle = '#1e293b'; ctx.setLineDash([3,3]);
// ... draw horizontal grid lines ...
ctx.setLineDash([]);
// Area fill
ctx.beginPath(); ctx.moveTo(points[0].x, H-pad.b);
points.forEach(p => ctx.lineTo(p.x, p.y));
ctx.lineTo(points[points.length-1].x, H-pad.b); ctx.closePath();
ctx.fillStyle = gradient; ctx.fill();
// Line
ctx.beginPath(); ctx.moveTo(points[0].x, points[0].y);
points.forEach(p => ctx.lineTo(p.x, p.y));
ctx.strokeStyle = '#3b82f6'; ctx.lineWidth=2.5; ctx.stroke();
// Dots
points.forEach((p,i) => {
  ctx.beginPath(); ctx.arc(p.x, p.y, 4, 0, Math.PI*2);
  ctx.fillStyle = '#3b82f6'; ctx.fill();
  ctx.fillText(data[i], p.x, p.y-9);
});
```

### Color Palette (12-color)

```js
const CHART_COLORS = [
  '#3b82f6','#10b981','#f59e0b','#ef4444','#8b5cf6',
  '#ec4899','#06b6d4','#84cc16','#f97316','#6366f1',
  '#14b8a6','#e11d48'
];
```

## Frontend UI Pattern

### Tab-based Dashboard Panel

```html
<div class="dash-tabs">
  <button class="dash-tab active" onclick="switchDashTab('charts')">📊 图表分析</button>
  <button class="dash-tab" onclick="switchDashTab('search')">🔍 搜索</button>
  <button class="dash-tab" onclick="switchDashTab('timeline')">📅 时间线</button>
  <button class="dash-tab" onclick="switchDashTab('benchmark')">📐 对标</button>
</div>
<div class="dash-panel active" id="dash-charts">...</div>
<div class="dash-panel" id="dash-search">...</div>
```

### Lazy Loading

```js
function switchDashTab(tab) {
  // toggle classes... then:
  if (tab === 'charts') loadDashV2();    // Fetch API data
  if (tab === 'timeline') loadTimeline(); // Fetch API data
}
```

### CSS Patterns

- `.dash-tabs`: flex row with active state (background: accent)
- `.dash-panel`: `display: none` / `display: block` on active
- Canvas charts wrapped in `.chart-canvas-wrap` (flex centered)
- `.chart-legend`: flex-wrap with colored dots for pie charts

## Project Timeline

```html
<div class="timeline-container">
  <!-- CSS ::before pseudo-element for vertical line -->
  <div class="timeline-item">
    <div class="timeline-dot created"></div>
    <div class="tl-time">2026-06-13 <span class="today-badge">[今日]</span></div>
    <div class="tl-detail">项目「AI质检系统」立项创建</div>
  </div>
</div>
```

CSS uses `position: relative` with `::before` for the vertical connector line and absolutely positioned `.timeline-dot` circles. Color-coded: green=created, yellow=archived.

## Full-Text Search Results

```html
<div class="search-doc-item" onclick="loadTask(taskId)">
  <div class="sdi-header">
    <span class="sdi-name">项目名称</span>
    <span class="sdi-type">srs/proposal/reqlist</span>
  </div>
  <div class="sdi-snippet">...<mark>搜索词</mark>高亮片段...</div>
  <div class="sdi-meta">
    <span>📌 N处匹配</span>
    <span>🆔 id前缀</span>
  </div>
</div>
```

RegExp highlighting: `text.replace(new RegExp('('+q.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+')', 'gi'), '<mark>$1</mark>')`

## Benchmark Panel

Two-column grid: left = current project metrics, right = cohort average. Full-width percentile bar at bottom showing where the project sits relative to cohort average.

```html
<div class="benchmark-compare">
  <div class="benchmark-card"><h4>当前项目</h4>...rows...</div>
  <div class="benchmark-card"><h4>同类平均</h4>...rows...</div>
  <div class="benchmark-pct-bar">
    <div class="benchmark-pct-fill" style="width:{pct}%"></div>
    <div class="benchmark-pct-marker" style="left:{pct}%"></div>
  </div>
</div>
```

## Pitfalls

1. **HTML canvas `roundRect`** — only available in modern browsers (Chrome 99+, Firefox 112+). For max compatibility, use `ctx.moveTo+lineTo+arc` for rounded rects.
2. **Dark theme** — chart colors must work on `#0f172a` background. Use light/dim text colors (`#94a3b8`, `#64748b`) for labels, not white.
3. **Canvas sizing** — Set `width`/`height` attributes on `<canvas>` element, not CSS. CSS sizing scales the canvas and blurs it.
4. **Long text in charts** — Labels longer than 6-7 chars need truncation (`label.slice(0,5)+'..'`) in bar chart x-axis.
5. **Search performance** — Full-text search over all projects iterates every task and loads every document. For large datasets (>500 projects), add server-side pagination or a dedicated search index.
6. **API aggregation** — Dashboard endpoints that iterate all records (like `dashboard/v2`) can be slow. Consider caching with a time-based expiry for production use.
