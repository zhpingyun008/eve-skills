# 延伸已有FastAPI产品的标准模式

从 zhizhang-ai v2.4 迭代升级(CSV导出+搜索过滤)中提取。

## 四步扩展模式

### Step 1: 数据模型 (api/models.py)
```python
# 新增请求/响应模型
class TxSearchRequest(BaseModel):
    query: str = ""
    date_from: str = ""
    date_to: str = ""
    category: str = ""
    type: str = ""
    limit: int = 50
    offset: int = 0

# 扩展现有响应模型添加新字段
class TxListResponse(BaseModel):
    transactions: List[TransactionResponse]
    count: int
    total: int = 0  # 新增：总记录数
```

### Step 2: 业务逻辑 (engine/*.py)
在引擎类中新增方法。注意SQL注入防护—使用参数化查询：
```python
def search_transactions(self, query="", date_from="", date_to="",
                        category="", tx_type="", limit=50, offset=0):
    conditions = []
    params = []
    if query:
        conditions.append("(description LIKE ? OR note LIKE ?)")
        params.extend([f'%{query}%', f'%{query}%'])
    if date_from:
        conditions.append("date >= ?")
        params.append(date_from)
    # ... 更多条件
    where = " AND ".join(conditions) if conditions else "1=1"
    # 使用format拼接表名(安全)，参数化传值(安全)
    with sqlite3.connect(self.db_path) as conn:
        count = conn.execute(f"SELECT COUNT(*) FROM transactions WHERE {where}", params).fetchone()[0]
        rows = conn.execute(f"SELECT * FROM transactions WHERE {where} ORDER BY date DESC LIMIT ? OFFSET ?",
                           params + [limit, offset]).fetchall()
    return {"transactions": [...], "total": count}
```

### Step 3: API端点 (api/server.py) — ⚠️ 常见陷阱
```python
# 1. 从api.models导入新模型 — 易遗漏！
from api.models import (
    ...,
    TxSearchRequest,  # ← 新增模型必须加入import
)

# 2. 新增POST端点
@app.post("/api/transactions/search", response_model=TxListResponse)
async def search_transactions(req: TxSearchRequest):
    result = engine.search_transactions(...)
    return TxListResponse(...)

# 3. 新增GET端点 (CSV导出)
@app.get("/api/transactions/export")
async def export_transactions(query: str = "", ...):
    result = engine.search_transactions(...)
    import csv, io
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["ID", "日期", "描述", ...])
    for t in result["transactions"]:
        writer.writerow([t.get("id",""), ...])
    return Response(content=output.getvalue(),
                    media_type="text/csv; charset=utf-8-sig",
                    headers={"Content-Disposition": "attachment; filename=export.csv"})
```

### Step 4: 前端 (static/index.html)
后端更新的同时更新前端UI:
- 搜索栏：input+date+select组合
- 导出按钮：调用export API + blob下载
- 加载状态：loading guard + toast提示

**注意**: zhizhang-ai前端在 `static/index.html` (非 templates/).

### 重启验证
```bash
# 1. kill旧进程
kill $(ss -tlnp | grep ':<port>' | grep -oP 'pid=\K[0-9]+')
sleep 1

# 2. 后台启动
cd /path/to/project && python3 api/server.py &

# 3. 健康检查
curl -s http://localhost:<port>/health

# 4. 验证新API
curl -s http://localhost:<port>/api/transactions/export | head -3
curl -s -X POST http://localhost:<port>/api/transactions/search \
  -H "Content-Type: application/json" -d '{"limit": 3}'

# 5. 前端验证
curl -s http://localhost:<port>/ | grep "searchQuery\|exportCSV"
```

## 已知陷阱
1. **模型import遗漏**: server.py中新增的Pydantic模型必须在文件头的import块添加，否则NameError
2. **前端文件位置**: 检查是 `templates/` 还是 `static/` — zhizhang-ai使用后者
3. **CSV编码**: 使用 `utf-8-sig` (带BOM) 确保Excel正确打开中文
4. **后台启动**: 使用 `terminal(background=true)` 而非 shell `&` — Hermes不识别后者
