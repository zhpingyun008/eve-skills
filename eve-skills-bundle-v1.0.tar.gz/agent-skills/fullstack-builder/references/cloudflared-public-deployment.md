# Cloudflared Quick Tunnel 公网部署

## 适用场景

在WSL/本地开发环境中，将FastAPI/Flask等HTTP服务快速暴露到公网，无需域名、无需备案、零成本。

## 前置条件

- 可用的HTTP服务运行在 localhost:PORT
- 网络能访问 github.com（下载binary）和 trycloudflare.com

## 安装

```bash
# Linux amd64
wget -q https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 -O /tmp/cloudflared
sudo mv /tmp/cloudflared /usr/local/bin/
sudo chmod +x /usr/local/bin/cloudflared

# 验证
cloudflared --version
# → cloudflared version 2026.6.0
```

## 启动隧道

```bash
# 后台运行，日志输出到文件
cloudflared tunnel --url http://localhost:PORT > /tmp/cloudflared_SERVICE.log 2>&1 &

# 等待3-5秒建立连接
sleep 5

# 获取公网URL
grep -E "trycloudflare\\.com" /tmp/cloudflared_SERVICE.log
# → https://random-words.trycloudflare.com
```

## 在Hermes Agent中使用

```python
# 启动隧道（后台进程）
r = terminal(
    f"cloudflared tunnel --url http://localhost:{port} > /tmp/cloudflared_{name}.log 2>&1",
    background=True, timeout=3600
)

# 等待隧道就绪
time.sleep(8)

# 提取公网URL
r2 = terminal(f"grep -E 'trycloudflare\\.com' /tmp/cloudflared_{name}.log", timeout=5)
url_line = r2['output'].split('\n')[-1]  # last matching line
public_url = url_line.split('https://')[1].split()[0]
public_url = 'https://' + public_url

# 保存URL
with open(f'.public_url', 'w') as f:
    f.write(public_url)
```

## 验证

```bash
# 通过公网URL测试
curl -s -o /dev/null -w "HTTP %{http_code}" https://RANDOM.trycloudflare.com/health
# → HTTP 200

# 健康检查日志
cat /tmp/cloudflared_SERVICE.log | grep -E "PASS|healthy|created|Tunnel"
```

## 多服务部署

每个端口需要独立的cloudflared进程：

```bash
cloudflared tunnel --url http://localhost:9000 > /tmp/cf_app1.log 2>&1 &
cloudflared tunnel --url http://localhost:8081 > /tmp/cf_app2.log 2>&1 &
```

## 注意事项

1. **无uptime保证** — quick tunnel是Cloudflare免费服务，不适合生产环境
2. **每个连接90秒超时** — 空闲连接自动断开，但浏览器访问会自动重连
3. **URL随机** — 每次重启隧道URL会变，不适合长期固定域名
4. **地域选择** — 隧道节点自动选择最近区域（如lax01=洛杉矶）
5. **QUIC协议** — cloudflared默认使用QUIC协议，比TCP更快建立连接
6. **WSL兼容** — WSL2中经过验证可正常工作（需要Windows宿主网络）
7. **日志持久化** — 日志文件包含URL，重启后可重新读取

## 故障排查

| 症状 | 原因 | 解决 |
|------|------|------|
| `invalid UUID length: 0` | DNS临时故障 | 重试即可，通常第二次成功 |
| `Failed to connect` | 网络不通 | 测 `curl trycloudflare.com` |
| HTTP 502 | 本地服务未启动 | 先验证 `curl localhost:PORT` |
| HTTP 503 | 隧道未完全建立 | 等待5-10秒后重试 |
