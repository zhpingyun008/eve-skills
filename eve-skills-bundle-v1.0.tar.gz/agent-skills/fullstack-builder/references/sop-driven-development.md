# SOP-Driven Full-Stack Development — Pattern Reference

## When to Use
Project requirements originate from a detailed Standard Operating Procedure (SOP) with 20+ business rules, multi-party data cross-validation, and specific formula-driven calculations. Example: settlement material verification (24 checks), compliance audit, financial reconciliation.

## Workflow

```
SOP Document → Rule Index (SRS) → Check Engine Design → 
  Parallel: Extractors + Engine Implementation →
  API Integration → Report Generation → Testing
```

## Key Patterns

### 1. Rule Indexing (SRS Phase)
- Export every rule from SOP into a numbered checklist
- Map each rule to: FR编号, data source, calculation formula, pass/fail criteria
- Establish traceability chain: SOP条款 → FR编号 → check function

### 2. Independent Check Functions
Each rule gets its own function with signature:
```python
def check_{no}(materials_data: dict, config: dict) -> dict:
    """Returns {'status': 'pass'|'warning'|'error', 'detail': {...}, 'errors': [...], 'warnings': [...]}"""
```

### 3. Configurable Business Parameters
| Parameter | Default | Description |
|-----------|---------|-------------|
| working_days | 30 | Calendar days for payment deadline calc |
| tax_rate | 6.0 | VAT rate (%) |
| coefficient_tiers | [≥90→1.0, 70-89→0.9, <70→0.7] | Performance tiers |
| amount_tolerance | 0.02 | ¥ tolerance for rounding |

### 4. Parallel Backend Development
```python
# Phase 1: Core infrastructure (write directly)
# Phase 2: Delegate independent modules
delegate_task(goal="Build extractors", ...)
delegate_task(goal="Build check engine", ...)
# Phase 3: API routes + services (write after subagents complete)
```

### 5. String Matching for Financial Documents
- Chinese OCR fuzzy matching required (形近字字典)
- Money normalization: strip ¥/￥/commas
- Date parsing: support multiple formats (YYYY-MM-DD, YYYY年MM月DD日)

## Reference Project
- Path: `/home/yestin/projects/settlement-check/`
- 54 files, 88 tests, 24 check items
- Tech: FastAPI + Vue3 + SQLite + pdfplumber + pytesseract
