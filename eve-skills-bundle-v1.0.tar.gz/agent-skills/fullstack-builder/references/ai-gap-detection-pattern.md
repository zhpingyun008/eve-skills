# AI Gap Detection Pattern (Requirements Elicitation)

When building AI-powered document generation systems, use a multi-dimensional gap detection engine to collect missing information before kicking off the AI pipeline. This prevents low-quality output from insufficient input.

## Architecture

```
User Input (raw text + optional fields)
    │
    ▼
Gap Detection Engine
    ├── 1. Length check (too short?)
    ├── 2. Required field check (name/type/budget/duration)
    ├── 3. Keyword pattern check (missing dimensions)
    │
    ▼
    ├── All satisfied → proceed to generation
    └── Gaps found → return questions array → user fills → re-submit
```

## Implementation Pattern

```python
def detect_gaps(raw: str, name: str, ptype: str, budget: str, duration: str) -> list[str]:
    """Return list of questions to ask the user. Empty list = no gaps."""
    questions = []
    import re
    
    # 1. Content length
    if not raw or len(raw) < 15:
        questions.append("请详细描述项目目标和核心功能需求")
    
    # 2. Required project fields
    if not name:
        questions.append("请提供项目名称")
    if not ptype:
        questions.append("请选择项目类型（如：研发/信息化/采购/运维）")
    if not budget:
        questions.append("请提供大致预算范围（如：200万）")
    if not duration:
        questions.append("请提供预计工期（如：8个月）")
    
    # 3. Key dimensions (content analysis)
    dimensions = [
        ("目标|目的|建设", "请补充项目目标——例如建设目标、业务目的等"),
        ("用户|人员|角色", "请说明主要用户或角色群体——例如面向哪些人员使用"),
        ("技术|平台|系统|架构", "请说明技术栈或平台选型——例如期望使用什么技术/平台/系统"),
        ("数据|用户数|并发", "请提供预估数据量——例如用户数、并发量、数据规模等"),
    ]
    for pattern, question in dimensions:
        if not re.search(pattern, raw):
            questions.append(question)
    
    # 4. Structural hints
    if not re.search(r'\d+[)）、]', raw):
        questions.append("建议按序号列出核心功能模块（如：1)xxx 2)xxx），以获得更精准的结果")
    
    return questions
```

## Usage in API

```python
@app.route("/api/submit", methods=["POST"])
def submit():
    data = request.get_json() or {}
    raw_input = data.get("requirement", "").strip()
    force = data.get("force", False)
    
    # Only run gap detection when not forced
    if not force:
        questions = detect_gaps(raw_input, name, ptype, budget, duration)
        if questions:
            return jsonify({
                "success": False,
                "need_more": True,
                "questions": questions,
                "message": "需求信息不足，请补充以下内容后重新提交",
            })
    
    # Proceed to AI generation...
```

## Frontend Integration

```javascript
async function submitTask() {
  const resp = await fetch(API+'/submit', { method:'POST', body: formData });
  const data = await resp.json();
  
  if (data.need_more) {
    // Show gap questions to user
    showGapQuestions(data.questions);
    return;
  }
  
  // Proceed with generation...
  pollStatus(data.task_id);
}
```

## Gap Detection Dimensions (sorted by priority)

| Priority | Dimension | Keyword Patterns | Question |
|----------|-----------|------------------|----------|
| P0 | Content length | len < 15 | "请详细描述项目目标和核心功能需求" |
| P0 | Project name | name is empty | "请提供项目名称" |
| P0 | Project type | ptype is empty | "请选择项目类型" |
| P0 | Budget | budget is empty | "请提供预算范围" |
| P0 | Duration | duration is empty | "请提供预计工期" |
| P1 | Objectives | 目标/目的/建设 | "请补充项目目标" |
| P1 | User roles | 用户/人员/角色 | "请说明用户角色群体" |
| P1 | Tech stack | 技术/平台/系统 | "请说明技术栈选型" |
| P1 | Data volume | 数据/用户数/并发 | "请提供预估数据量" |
| P2 | Feature list structure | \d+[)）、] | "建议按序号列出功能模块" |

## Pitfalls

1. **Don't block force submits**: Always provide a `force=true` parameter that bypasses gap detection. Users who already know what they want should not be blocked.
2. **Don't repeat questions**: If the user already filled the name/type/budget/duration fields in the form, don't ask for them again even if the raw text is short.
3. **Char count is not enough**: A 200-character requirement may still be missing key dimensions like user roles or tech stack. Content analysis is essential.
4. **Prevent infinite loops**: After the user responds to gap questions, clear the gap state so re-submission with `force=false` doesn't re-trigger the same gaps.
5. **Regenerate gap list**: Don't hardcode the list — generate it based on actual content analysis so new gaps can be detected as the project evolves.
