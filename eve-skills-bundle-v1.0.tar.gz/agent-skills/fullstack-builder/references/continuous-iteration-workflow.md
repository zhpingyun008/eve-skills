# 持续迭代工作流 (Continuous Iteration Workflow)

## 概述

当用户仅说"继续"或"继续优化完善功能"时，该工作流指导从现有项目审计到5功能并行实施的完整路径。

## 触发条件

用户输入: "继续", "继续优化", "继续优化完善功能", "continue"

## 执行流程

### Step 1: 系统全景检查（3分钟）

执行任务前的必要状态摸查：

```bash
# 1. 进程健康检查
ps aux | grep -E 'python|flask|uvicorn|fastapi|node' | grep -v grep

# 2. 端口占用检查
ss -tlnp | grep -E '<已知端口范围>'

# 3. 错误日志概览
grep -c 'ERROR' ~/.hermes/logs/errors.log
grep -oP "(ERROR|WARNING)\s+\w+\.\w+" ~/.hermes/logs/errors.log | sort | uniq -c | sort -rn | head -10

# 4. 待办/Backlog检查
cat ~/.hermes/backlog/backlog.json 2>/dev/null | python3 -c "..."

# 5. 产品代码概览（代码行数、路由数、依赖）
wc -l app.py static/index.html
grep -n "@app.route\|@router" app.py | wc -l
```

### Step 2: 代码审计（5分钟）

对目标项目进行5维度快速审计：

| 维度 | 检查项 |
|------|--------|
| **安全** | 认证缺失、硬编码密钥、debug=True、SQL注入、XSS |
| **错误处理** | try/except覆盖、404/500 handler、日志记录 |
| **性能** | 无分页加载、N+1查询、同步IO |
| **代码质量** | DRY违反、函数复杂度、注释覆盖 |
| **UX/UI** | 空状态、加载状态、错误提示、响应式 |

**产出**: 按 P0(安全)→P1(功能缺陷)→P2(体验优化) 排列的5个优化点清单

### Step 3: 并行实施（`delegate_task` 模式）

使用 `delegate_task` 并行执行独立功能：

**Phase A** (3路并行):
- 任务1: 安全修复 (JWT认证/密钥迁移/debug关闭)
- 任务2: 后端已有但前端缺失的UI (如版本对比/图表)
- 任务3: 数据可视化/Chart.js集成

**Phase B** (2路并行):
- 任务4: 批量操作/取消机制
- 任务5: 分页/空状态优化

**`delegate_task` 注意事项**:
- 每个task需要完整的 `goal` + `context` (文件路径、行数范围、已有API)
- context必须包含项目路径和关键文件结构信息
- 任务间存在文件依赖时(如多任务修改同一文件)必须串行或在context中明确冲突区域
- 子代理的 `toolsets` 设为 `["terminal", "file"]` 足以完成代码修改

### Step 4: 服务重启

```bash
# 查找systemd服务
systemctl --user list-units --no-pager | grep -i "项目名"
# 重启
systemctl --user restart <service-name>.service
# 验证
sleep 2 && curl -s http://localhost:<port>/api/health
```

**注意**: 如果用户block了restart操作，说明希望自行控制重启时机。此时仅更新VERSION文件和前端标题，等待用户后续重启。

### Step 5: BookStack同步

```bash
python3 ~/.hermes/skills/devops/bookstack-update-sync/scripts/sync.py \
  "功能描述: 版本号+5个功能清单" \
  "分类" \
  "/books/39/page/..."
```

### Step 6: 最终汇报

汇报模板：
```
## 产品名 vX.Y 完成报告

### 本轮产出
| # | 项目 | 状态 | 详情 |
|---|------|------|------|
| 1 | 功能1 | ✅ | 一句话描述 |
| 2 | 功能2 | ✅ | ... |
| 3 | 功能3 | ✅ | ... |
| 4 | BookStack同步 | ✅ | |

### 系统全景
服务:端口 → ✅ (关键状态数字)
剩余事项: 1-2条

### 成本核算
模型调用: ~XX万 tokens / ¥X.XX
```

## 坑 Pitfalls

1. **服务运行实例可能有多重** — systemd进程 + 旧nohup进程可能同时绑定同一端口。用 `ss -tlnp` 确认哪个进程实际持端口
2. **`hermes config set` 修改config.yaml** — Hermes阻止直接写入config.yaml，必须用 `hermes config set <key> <value>` 命令
3. **VERSION文件可能已更新** — 自动cron/其他agent可能已写入新版本号。读取VERSION再决定新版本号
4. **子代理的file changed警告** — 子代理输出的 `[NOTE: subagent modified files the parent previously read]` 是信息性提示，父会话只需在需要时重新读取文件
5. **JWT认证添加后需处理window.open** — 下载/打印/CSV导出的 `window.open()` 调用需追加 `?token=` query参数，因为window.open不携带Authorization header
