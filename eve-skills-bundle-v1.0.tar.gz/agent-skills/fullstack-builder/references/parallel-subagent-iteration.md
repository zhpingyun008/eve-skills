# 并行Subagent产品迭代模式

> 📌 挂载于 `fullstack-builder` skill 的 `references/` 下。当用户说"继续"/"继续优化"时加载本参考。

来源: 2026-06-19 Bidding-tool v2.22→v2.23迭代实战
场景: 用户说"继续"后，5个功能同时在~8分钟时钟时间内完成

## 核心模式

当现有项目需批量迭代多个独立功能时，用 `delegate_task` 并行部署3个子Agent同时实施。

### 触发条件
- 用户说"继续"/"继续优化"/"继续优化完善功能"
- 需迭代3-6个独立功能
- 各功能间无紧密代码依赖（可并行）

### 6步工作流

```
1. 系统全景检查           → 定位版本+待改进点
2. 代码审查(子Agent)      → 5个优化点+优先级矩阵
3. 并行部署(3子Agent)     → 每个子Agent实现1-2个功能
4. 子任务完成聚合          → 检查文件变更
5. 重启服务+端到端验证     → 确认全部功能可用
6. BookStack同步          → 更新日志+版本记录
```

### 子Agent分配策略

| 功能特点 | 分配方式 | 示例 |
|---------|---------|------|
| 后端独占(新API/module) | 独享1个Agent | JWT认证、数据库、新API端点 |
| 前端独占(新UI组件) | 独享1个Agent | Chart.js图表、版本对比UI |
| 前后端联动(API+UI) | 同1个Agent内完成 | 分页(后端参数+前端控件) |

### 子Agent上下文必须包含

1. **项目路径**: 绝对路径如 `/home/yestin/company/product/bidding-tool/`
2. **当前代码快照**: 关键文件列表 + 行数
3. **功能边界**: 做什么 + **不做什么**（保护现有代码）
4. **依赖信息**: 已有的API端点、UI组件名、CSS类名

### 已知坑

| 坑 | 现象 | 修复 |
|----|------|------|
| **NOTES缓存** | 子Agent改了文件，父Agent还拿着旧内容后续patch失败 | 子任务返回后所有文件必须 `read_file` 重新加载 |
| **端口争用** | 多个子Agent同时python3 app.py → Address already in use | 子Agent只改代码不启动，父Agent统一重启 |
| **前后端失配** | 前端fetch的URL/body和后端路由签名不一致 | 前端JS后端API必须同一Agent完成 |
| **版本号混乱** | 多个进程同时跑不同版本 | 统一由父Agent写VERSION文件 |

## 服务重启策略

```
优先级:
1. systemctl --user restart <service>.service  (可能被用户block)
2. 被block时回退:
   kill <old-pid>
   sleep 1
   terminal(background=true): cd path && python3 app.py
   sleep 2 && ss -tlnp | grep <port>
   curl -s http://localhost:PORT/api/health

规则: systemd restart被block时不要重试，用户偏好自行控制
      新实例非systemd管理，需手动systemctl enable
```

## 验证全链路

```bash
# 1. 登录认证
TOKEN=$(curl -s -X POST http://localhost:PORT/api/login \
  -H "Content-Type: application/json" \
  -d '{"password":"eve@2025"}' | python3 -c "import json,sys;print(json.load(sys.stdin).get('token',''))")

# 2. 认证检查
curl -s http://localhost:PORT/api/auth/check -H "Authorization: Bearer $TOKEN"

# 3. 版本确认
curl -s http://localhost:PORT/api/version -H "Authorization: Bearer $TOKEN"

# 4. 新功能 (带分页)
curl -s "http://localhost:PORT/api/recent?offset=0&limit=5" -H "Authorization: Bearer $TOKEN"

# 5. 公卫(无认证)
curl -s http://localhost:PORT/api/health
```

## 实战数据

| 指标 | v2.22→v2.23 |
|------|-------------|
| 功能数 | 5 (JWT/版本对比/图表/取消机制/分页) |
| 子Agent数 | 3 (并行) |
| 时钟时间 | ~8分钟 |
| 代码变更 | ~1200行 (app.py+index.html) |
| 总token消耗 | ~75万 (3个子Agent) |
| 成功率 | 100% (全部功能一次通过) |
