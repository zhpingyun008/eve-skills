# 项目Kickoff常见问题

## 缺失参考文件处理

当提示词模板引用 `/workspace/xxx.md`、`/root/uploads/xxx.docx` 等路径时：

1. 先 `find / -name "filename*" 2>/dev/null | head -5` 搜索全系统
2. 检查 `/mnt/c/` Windows挂载目录：`find /mnt/c -name "filename*" 2>/dev/null | head -5`
3. 如果都不存在：基于对话上下文中嵌入的业务规则直接推进
4. 关键规则/公式保存到 `~/workspace/` 作为工作区参考

**原则**：提示词中附带的业务规则描述足以作为开发依据。不要因"文件不存在"阻塞项目进度。

## 技术栈确认

Kickoff时需确认目标环境是否有所需依赖（python库、node、docker等）：
- `pip list | grep pdfplumber` — PDF解析
- `which tesseract` — OCR识别  
- `pip list | grep openpyxl` — Excel解析
- `pip list | grep fastapi` — 后端框架
- `which node && node --version` — 前端构建
