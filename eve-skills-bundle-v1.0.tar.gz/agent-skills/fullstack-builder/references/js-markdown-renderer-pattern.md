# Pure-JS Markdown Renderer Pattern

Zero-dependency Markdown-to-HTML renderer for Vanilla JS dashboards. Suitable for document previews, content display, and simple wikis where an npm package is undesired.

## Implementation

```javascript
function renderMarkdown(text) {
  if (!text) return '(暂无内容)';
  const lines = text.split('\n');
  let html = '';
  let inCode = false, codeBuf = [];
  
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    
    // Code block toggle
    if (line.trim().startsWith('```')) {
      if (inCode) { 
        html += '<pre><code>' + escapeHtml(codeBuf.join('\n')) + '</code></pre>\n'; 
        codeBuf = []; 
      } else { 
        if (codeBuf.length) html += '<p>' + escapeHtml(codeBuf.join('\n')) + '</p>\n'; 
        codeBuf = []; 
      }
      inCode = !inCode; 
      continue;
    }
    
    if (inCode) { codeBuf.push(line); continue; }
    if (codeBuf.length) { html += '<p>' + escapeHtml(codeBuf.join('\n')) + '</p>\n'; codeBuf = []; }
    
    const trimmed = line.trim();
    if (!trimmed) { html += '<br>\n'; continue; }
    
    const escaped = escapeHtml(trimmed);
    
    if (/^#{6}\s/.test(trimmed)) html += `<h6>${escaped.replace(/^#{6}\s*/, '')}</h6>\n`;
    else if (/^#{5}\s/.test(trimmed)) html += `<h5>${escaped.replace(/^#{5}\s*/, '')}</h5>\n`;
    else if (/^#{4}\s/.test(trimmed)) html += `<h4>${escaped.replace(/^#{4}\s*/, '')}</h4>\n`;
    else if (/^#{3}\s/.test(trimmed)) html += `<h3>${escaped.replace(/^#{3}\s*/, '')}</h3>\n`;
    else if (/^#{2}\s/.test(trimmed)) html += `<h2>${escaped.replace(/^#{2}\s*/, '')}</h2>\n`;
    else if (/^#\s/.test(trimmed)) html += `<h1>${escaped.replace(/^#\s*/, '')}</h1>\n`;
    else if (/^[-*]\s/.test(trimmed)) html += `<li>${escaped.replace(/^[-*]\s*/, '')}</li>\n`;
    else if (/^\d+[.)]\s/.test(trimmed)) html += `<li>${escaped.replace(/^\d+[.)]\s*/, '')}</li>\n`;
    else if (/^---+\s*$/.test(trimmed)) html += '<hr>\n';
    else html += `<p>${escaped}</p>\n`;
  }
  
  // Flush remaining code buffer
  if (inCode) html += '<pre><code>' + escapeHtml(codeBuf.join('\n')) + '</code></pre>\n';
  else if (codeBuf.length) html += '<p>' + escapeHtml(codeBuf.join('\n')) + '</p>\n';
  
  // Wrap consecutive <li> in <ul>
  html = html.replace(/((?:<li>.*?<\/li>\n?)+)/g, '<ul>$1</ul>\n');
  return html;
}

function escapeHtml(s) {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
```

## Supported Syntax

| Markdown | HTML Output |
|----------|-------------|
| `# h1` / `## h2` ... `###### h6` | `<h1>`...`<h6>` |
| `- item` / `* item` | `<li>` (auto-wrapped in `<ul>`) |
| `1. item` / `1) item` | `<li>` (auto-wrapped in `<ul>`) |
| `---` | `<hr>` |
| `` `code` `` | `<code>` |
| `**bold**` | `<strong>` |
| ` ```code block``` ` | `<pre><code>` |
| Blank line | `<br>` |
| Paragraph text | `<p>` |

## Integration

Replace `textContent` with `innerHTML` in your document display:

```javascript
// Before (raw markdown)
document.getElementById('doc_content').textContent = content;

// After (rendered HTML)
document.getElementById('doc_content').innerHTML = renderMarkdown(content);
```

## Styling the Rendered Content

```css
.doc-content h1, .doc-content h2, .doc-content h3 {
  color: var(--accent); margin: 16px 0 8px;
}
.doc-content p { margin: 6px 0; line-height: 1.7; }
.doc-content ul { padding-left: 20px; margin: 4px 0; }
.doc-content li { margin: 2px 0; }
.doc-content pre { background: #0a0f1a; padding: 12px; border-radius: 8px; overflow-x: auto; }
.doc-content code { background: rgba(255,255,255,0.08); padding: 2px 6px; border-radius: 4px; font-size: 0.85em; }
.doc-content hr { border: none; border-top: 1px solid var(--border); margin: 16px 0; }
```

## Pitfalls

1. **textContent vs innerHTML**: Switching from `textContent` to `innerHTML` means content must be HTML-escaped. The `escapeHtml()` call in `renderMarkdown` handles this, but any content inserted outside the renderer (e.g., error messages) must also be escaped.
2. **Code blocks with language tags**: The simple renderer treats ` ```python ` the same as ` ``` ` — the language tag is included in the code output. For a more polished experience, strip the language tag or use it for syntax highlighting.
3. **Nested lists**: Not supported. The renderer turns all `- ` lines into flat `<li>` elements and wraps consecutive ones in `<ul>`. Nested indentation is ignored.
4. **Inline HTML in markdown**: Not supported — all `<` `>` `&` are escaped. This is intentional for safety but means raw HTML in documents is displayed as text.
5. **Performance**: For documents >500KB, consider chunked rendering or virtual scrolling to avoid blocking the main thread.

## Alternative: Backend Markdown Renderer

When the backend needs to render markdown (e.g., for HTML export endpoints), use a Python version with the same logic:

```python
def render_markdown_to_html(text):
    """Python equivalent of the JS renderMarkdown()"""
    import re
    lines = text.split('\n')
    # ... same logic as JS but with Python syntax
    return html
```

Keep both implementations in sync — feature parity is critical.
