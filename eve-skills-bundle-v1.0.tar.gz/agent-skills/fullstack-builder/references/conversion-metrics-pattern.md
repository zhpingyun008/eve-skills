# Conversion Rate Metrics Pattern

## Use Case

When a management/statistics endpoint returns raw counts (total/sent/pending), add derived metrics to give immediate business-insight context without frontend calculation.

## Metric Set

| Metric | Formula | Meaning |
|--------|---------|---------|
| `reply_rate` | `replies / sent * 100` | % of sent documents that got a response |
| `send_rate` | `(sent + pending) / total * 100` | % of total documents that entered the send pipeline |
| `lead_email_rate` | `leads_with_email / leads_count * 100` | % of leads that have a contactable email |

## Implementation (Flask)

Add to the existing `/api/stats` (or equivalent) endpoint, after raw data collection:

```python
@app.route("/api/stats")
def api_stats():
    # ... existing raw data collection ...
    
    # Safe division with fallback to 0.0
    sent = stats.get("sent_bids", 0)
    total = stats.get("total_bids", 0)
    pending = stats.get("pending_send", 0)
    replies = stats.get("email_replies", 0)
    leads = stats.get("leads_count", 0)
    leads_email = stats.get("leads_with_email", 0)
    
    stats["reply_rate"] = round(replies / sent * 100, 1) if sent else 0.0
    stats["send_rate"] = round((sent + pending) / total * 100, 1) if total else 0.0
    stats["lead_email_rate"] = round(leads_email / leads * 100, 1) if leads else 0.0
```

## Optional: Trends Data

Add trend data from a daily_ops table (or equivalent):

```python
try:
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT date, replies, sent FROM daily_ops ORDER BY date ASC LIMIT 30")
    trend = []
    for row in cur.fetchall():
        d, r, s = row
        trend.append({
            "date": d,
            "replies": r,
            "sent": s,
            "reply_rate": round(r / s * 100, 1) if s else 0.0
        })
    stats["reply_trend"] = trend
except Exception:
    stats["reply_trend"] = []
```

## Frontend Display

In the stats grid, add cards for the new metrics:

```html
<div class="stat-card">
    <div class="num">2.6%</div>
    <div class="label">📬 回复率</div>
</div>
<div class="stat-card">
    <div class="num">83.5%</div>
    <div class="label">📤 发送率</div>
</div>
<div class="stat-card">
    <div class="num">81.4%</div>
    <div class="label">📧 线索邮箱率</div>
</div>
```

## Pitfalls

1. **Zero-division safety** — every `/` must be guarded with `if denominator else 0.0`. Sent counts can be 0 for new deployments.
2. **Decimal precision** — `round(x, 1)` avoids repeating decimals (e.g. 2.564... → 2.6%).
3. **Trends error isolation** — wrap DB queries in try/except and default to []. A failing trends query shouldn't crash the whole endpoint.
4. **Field name consistency** — match the raw field names already used by the frontend to avoid breaking existing code.
