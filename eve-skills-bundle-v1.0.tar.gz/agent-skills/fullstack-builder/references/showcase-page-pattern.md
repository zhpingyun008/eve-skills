# Public Showcase Page Pattern

## Problem
An internal admin tool generates valuable business data (bids, proposals, reports) that could serve as sales/marketing material for potential clients. Need a public-facing page that displays this data professionally.

## Solution
Create a dedicated Flask route that returns a standalone HTML page (no login required) showing system stats, key opportunities, and generated assets in a professional grid layout.

## Implementation

### Flask Backend

```python
@app.route("/showcase")
def api_showcase():
    """Public showcase page — no auth required."""
    data_dir = os.path.join(os.path.dirname(__file__), "data")
    bids = sorted(glob.glob(os.path.join(data_dir, "*.md")), key=os.path.getmtime, reverse=True)
    
    # Gather stats
    leads = load_leads()
    total_budget = sum(budget_from_lead(l) for l in leads)
    
    # Top opportunities: sort by budget descending
    opportunities = sorted(
        [{"org": l["org"], "project": l.get("project",""), "budget": f"¥{b}万"} 
         for l in leads if (b := budget_from_lead(l)) >= 50],
        key=lambda x: -float(x["budget"].replace("¥","").replace("万",""))
    )[:10]
    
    # Bid cards
    items = []
    for b in bids[:30]:
        fname = os.path.basename(b)
        project = clean_name(fname)
        size = os.path.getsize(b)
        mtime = datetime.fromtimestamp(os.path.getmtime(b)).strftime("%m/%d")
        items.append({"name": project, "size": f"{size//1024}KB", "date": mtime})
    
    return f"""<!DOCTYPE html><html lang=zh-CN>
    <head><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1">
    <title>Showcase Title</title>
    <style>...professional CSS...</style></head>
    <body>
        <div class=hero>...</div>
        <div class=container>
            <div class=stats>4 stat cards</div>
            <h2>🏆 重点商机</h2>
            <table>top opportunities table</table>
            <h2>📂 资产库</h2>
            <div class=grid>asset cards</div>
        </div>
        <div class=footer>Powered by ... auto-generated</div>
    </body></html>"""
```

### CSS Design

Professional showcase styling (light theme, not dark admin theme):

```css
body { font-family: system-ui; background: #f8fafc; color: #1e293b; }
.hero { background: linear-gradient(135deg, #1e3a5f, #2563eb); color: #fff; padding: 40px 20px; text-align: center; }
.stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 16px; margin: 30px 0; }
.stat-card { background: #fff; border-radius: 12px; padding: 20px; text-align: center; box-shadow: 0 1px 3px rgba(0,0,0,.1); }
.stat-card .num { font-size: 2rem; font-weight: 700; color: #2563eb; }
.grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 16px; }
.card { background: #fff; border-radius: 12px; padding: 16px; box-shadow: 0 1px 3px rgba(0,0,0,.1); transition: transform .2s; }
.card:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,.15); }
```

### Key Design Decisions
1. **Light theme** — Professional showcase should feel clean and trustworthy
2. **No auth** — Public pages should be accessible without login
3. **Auto-generated** — Data refreshes on every page load (no caching needed)
4. **Responsive grid** — CSS Grid auto-fill for mobile-friendly cards
5. **Link from admin UI** — Add a nav link in the admin header so internal users can find it

### When to Use
- SaaS products needing a landing/demo page
- Bid/proposal generators showing case studies
- Any admin tool where generated data has sales value
