# LLM Backend Integration for Hermes Agent Environments

When a FastAPI/Flask backend needs to call LLMs (DeepSeek, OpenAI, etc.) in a Hermes Agent environment, the standard `openai` library approach fails because API keys are masked for display security.

## The Problem

```python
# ❌ This does NOT work from a FastAPI backend:
import os
key = os.environ.get("DEEPSEEK_API_KEY")     # → "" (empty)
key = open("~/.hermes/config.yaml").read()   # → "sk-3ae...1214" (display-masked)

# Even reading config.yaml directly returns the obfuscated value.
# The terminal tool also masks keys in its output.
```

## Solution: Hermes Proxy Script Pattern

### Step 1: Create a proxy script

Create `backend/app/services/hermes_proxy.py`:

```python
#!/usr/bin/env python3
"""Hermes模型调用代理 — 子进程调用方式"""
import json, sys, os, yaml
sys.path.insert(0, os.path.expanduser("~/.hermes/.venv/lib/python3.11/site-packages"))
from openai import OpenAI

with open(os.path.expanduser("~/.hermes/config.yaml")) as f:
    cfg = yaml.safe_load(f)

provider_cfg = cfg.get("providers", {}).get("deepseek", {})
client = OpenAI(
    api_key=provider_cfg["api_key"],          # 真实值，不受终端遮罩影响
    base_url=provider_cfg.get("base_url", "https://api.deepseek.com"),
)

input_data = json.loads(sys.stdin.read())
resp = client.chat.completions.create(
    model=input_data.get("model", "deepseek-chat"),
    messages=input_data["messages"],
    temperature=input_data.get("temperature", 0.1),
    max_tokens=input_data.get("max_tokens", 4096),
)
print(resp.choices[0].message.content)
```

Key points:
- Reads `~/.hermes/config.yaml` directly (PyYAML reads real bytes, unaffected by display masking)
- Uses the OpenAI library from Hermes' venv (`~/.hermes/.venv`)
- Accepts input via stdin (JSON), outputs to stdout
- Uses `"deepseek-chat"` model (not `"deepseek-v4-flash"` which returns empty responses)

### Step 2: Create LLM service layer

Create `backend/app/services/llm_service.py`:

```python
import subprocess, json
from typing import List, Dict

PROXY_SCRIPT = "/path/to/backend/app/services/hermes_proxy.py"

class LLMService:
    def _call(self, messages: List[Dict], temperature=0.1, max_tokens=8192) -> str:
        payload = json.dumps({
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        })
        result = subprocess.run(
            ["python3", PROXY_SCRIPT],
            input=payload,
            capture_output=True,
            text=True,
            timeout=120,
        )
        result.check_returncode()
        return result.stdout.strip()

    def extract_data(self, material_type, material_name, raw_text) -> dict:
        """LLM结构化提取"""
        user_prompt = f"从以下{material_name}文本中提取结构化数据...\n{raw_text[:8000]}"
        messages = [
            {"role": "system", "content": "你是一个数据提取专家。输出JSON格式。"},
            {"role": "user", "content": user_prompt},
        ]
        content = self._call(messages)
        return self._parse_json(content)

    def run_checks(self, materials_data, sop_text) -> dict:
        """LLM执行核对"""
        user_prompt = f"请对以下材料执行24项检查...\n{json.dumps(materials_data, ensure_ascii=False)}"
        messages = [
            {"role": "system", "content": "你是一个核对专家。"},
            {"role": "user", "content": user_prompt},
        ]
        content = self._call(messages, max_tokens=16384)
        return self._parse_json(content)

    def _parse_json(self, content: str) -> dict:
        """三级容错JSON解析"""
        import re
        # 1. 直接解析
        try: return json.loads(content)
        except: pass
        # 2. 代码块提取
        m = re.search(r'```(?:json)?\s*([\s\S]*?)```', content)
        if m:
            try: return json.loads(m.group(1))
            except: pass
        # 3. 最外层花括号
        m = re.search(r'\{[\s\S]*\}', content)
        if m:
            try: return json.loads(m.group(0))
            except: pass
        return {"raw": content}
```

## Model Name Note

For DeepSeek provider, the working model name is **`deepseek-chat`** (not `deepseek-v4-flash`):

```python
# ✅ Works: returns real content
model = "deepseek-chat"

# ❌ Silent failure: returns empty string ""
model = "deepseek-v4-flash"

# ❌ Not supported: returns 400 error
model = "deepseek"
```

## Async Background Processing (FastAPI)

For LLM-heavy endpoints (10-60s per call), use background thread + polling:

```python
import threading, json
from app.database import SessionLocal  # Must be importable

def _run_async(batch_id: int):
    """后台线程：独立DB会话"""
    db = SessionLocal()
    try:
        # ... LLM work ...
        db.commit()
    except Exception as e:
        db.rollback()
        # Update status to "error"
    finally:
        db.close()

@router.post("/batches/{id}/check")
def start_check(batch_id: int, db: Session = Depends(get_db)):
    batch.status = "parsing"
    db.commit()
    thread = threading.Thread(target=_run_async, args=(batch_id,), daemon=True)
    thread.start()
    return {"status": "parsing", "message": "已启动"}
```

### SessionLocal pattern key points:
- `from app.database import SessionLocal` (must be importable within the function)
- Each thread creates its own session (not shared)
- `db.flush()` for partial saves (issues, results) before final `db.commit()`
- Wrap in try/except/finally with `db.close()` for cleanup

## Frontend Status Mapping

| Backend status | Display | Action |
|---|---|---|
| `pending` | 等待中 | Show waiting state |
| `parsing` | 解析中（LLM提取） | Start polling (2s interval) |
| `checking` | 核对中（LLM检查） | Continue polling |
| `done` | 已完成 | Stop polling, load results |
| `error` | 核对失败 | Show error |
| `completed` (legacy) | 已完成 | Treat same as `done` |
| `running` (legacy) | 核对中 | Treat same as `checking` |
| `failed` (legacy) | 核对失败 | Treat same as `error` |

## Two-Stage File Extraction

For structured data extraction from PDF/XLSX files:

```
Stage 1: Extract raw text (lightweight, deterministic)
  ├── PDF → pdfplumber.extract_text() + extract_tables()
  └── XLSX → openpyxl.iter_rows(values_only=True)

Stage 2: Send raw text to LLM for structured extraction
  ├── LLM prompt asks for JSON output
  ├── Each material type has its own field specification
  └── ≤8000 chars per call (truncate if needed)
```

## Dependencies

```txt
# For proxy script (Hermes venv already has these)
# For backend:
httpx>=0.27.0
PyYAML>=6.0
```

Note: The proxy script uses the Hermes venv's openai library, not the backend's venv.

## Pitfalls

1. **subprocess.run timeout**: Set `timeout=120` minimum. LLM calls can take 30s+ for complex extraction. Default timeout is None (infinite) which is worse.
2. **JSON parsing**: LLMs often wrap JSON in ` ```json...``` ` blocks. Use the three-level fallback parser.
3. **Model name**: `deepseek-v4-flash` returns EMPTY strings (HTTP 200 with empty content). Always use `deepseek-chat`.
4. **Thread safety**: Background threads must NOT share the DB session from the request handler. Each thread calls `SessionLocal()` independently.
5. **Frontend legacy status**: Backend status values changed from `completed`/`running`/`failed` to `done`/`checking`/`error`. Frontend must handle both.
