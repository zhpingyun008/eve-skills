# AI Chat Assistant for Web Apps

## Overview
Embed a floating chat bubble in a Web UI that uses DeepSeek (or fallback keywords) to answer user questions about system state.

## Flask Endpoint

```python
@app.route("/api/chat", methods=["POST"])
def api_chat():
    data = request.get_json(force=True)
    message = data.get("message", "").strip()
    if not message:
        return jsonify({"reply": "请说点什么"})
    
    # Build context from system state
    context = f"总线索{s['total_leads']}条/标书{s['sent_bids']}/{s['total_bids']}已发/管道¥{s['pipeline_value_wan']:.0f}万"
    prompt = f"回答简短中文(30字以内)。\n{context}\n用户: {message}"
    
    # Try DeepSeek first
    try:
        key = _get_deepseek_key()
        if key:
            req_body = json.dumps({"model":"deepseek-chat","messages":[{"role":"system","content":prompt},{"role":"user","content":message}],"max_tokens":200}).encode()
            req = urllib.request.Request("https://api.deepseek.com/chat/completions",data=req_body,
                headers={"Content-Type":"application/json","Authorization":f"Bearer {key}"},method="POST")
            resp = urllib.request.urlopen(req,timeout=10)
            reply = json.loads(resp.read().decode()).get("choices",[{}])[0].get("message",{}).get("content","")
            if reply: return jsonify({"reply":reply})
    except: pass
    
    # Fallback: rule-based
    if "标书" in message: reply = f"标书{s['sent_bids']}/{s['total_bids']}已发"
    elif "线索" in message: reply = f"线索{s['total_leads']}条"
    else: reply = f"标书{s['sent_bids']}/{s['total_bids']}已发，管道¥{s['pipeline_value_wan']:.0f}万"
    return jsonify({"reply":reply})
```

## Web UI

HTML: floating bubble button + slide-up panel with chat messages + input
CSS: fixed-position bubble (56px, gradient, shadow), panel (360x500, bottom-right)
JS: toggleChat(), sendChat() with api('/api/chat', {message})

## Key Points
- **Context injection**: Pass live system state into the prompt for accurate answers
- **Fallback chain**: DeepSeek → rule-based keyword matching
- **No history**: Stateless — each question gets fresh context
