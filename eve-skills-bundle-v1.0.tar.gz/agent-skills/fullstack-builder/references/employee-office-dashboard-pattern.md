# Employee Office Dashboard Pattern (2026-06-03)

## Pattern: SQLite → JSON cron → HTML/CSS/JS frontend

Used for the Eve visual office (`office.html`) showing 30 AI employees in a 2D office layout with real-time status.

## Architecture

```
employee_activity.db (SQLite)
    │
    ├── employee_status  — role, current_status, current_task, last_heartbeat
    ├── activities       — per-employee activity log (output_summary has task descriptions)
    └── discuss.db       — discussion posts (channels, author_role, title, content)
            │
            ▼
    cron (every 3 min): sync SQLite → website/data/employees.json
    cron (every 5 min): sync discuss.db → website/data/discuss-posts.json
            │
            ▼
    office.html fetches both JSON files every 15 seconds
    Renders: Department zones → Employee desk cards → Meeting room → Activity feed → Project kanban
```

## Key Components

### Employee Desk Card
Each card shows:
- Emoji avatar (mapped by role name)
- Status color bar at top (green=working, blue=learning, yellow=idle, gray=sleeping)
- Role name + display name
- Status dot + label
- Current task (from activities.output_summary)
- Last heartbeat (time ago)

### JS Mapping Tables
```javascript
const DEPARTMENTS = {
  '商务中心': { barColor:'#22c55e', roles:['scout','scribe','closer'] },
  '交付中心': { barColor:'#3b82f6', roles:['lead','maker','arch',...] },
  '产品增长中心': { barColor:'#a78bfa', roles:['pm','product','analyst',...] },
  '能力中心': { barColor:'#eab308', roles:['evolver','qm','qa',...] },
  '管理层': { barColor:'#f97316', roles:['yestin'] },
};
const EMOJI = { scout:'🔍', scribe:'✍️', closer:'💼', ... };
const STATUS_COLOR = { working:'#22c55e', learning:'#3b82f6', idle:'#eab308', ... };
const CHANNEL_COLORS = { general:'#a78bfa', leads:'#22c55e', alerts:'#ef4444', ... };
```

### Data Enrichment: Task from Activities
The `employee_status.current_task` was empty. Solution:
```sql
-- Get latest activity output_summary for each employee
SELECT a.employee, a.output_summary
FROM activities a
INNER JOIN (
    SELECT employee, MAX(id) as max_id
    FROM activities WHERE output_summary IS NOT NULL AND output_summary != ''
    GROUP BY employee
) latest ON a.id = latest.max_id;
```
Then UPDATE employee_status.current_task with the result.

### Project Kanban Section
Added between meeting room and department zones. Fetches from `kanban.json`:
- Active project card (name, budget, timeline, status)
- Lead pipeline card (total leads count)
- Sales funnel card (cold emails sent, responses, conversion rate)

## Pitfalls Encountered

1. **Data source mismatch**: Frontend fetched from `/reports/ceo-dashboard-live.json` which had no employee data. Fixed by switching to `/data/employees.json` from SQLite. **Always curl-verify the JSON structure before building rendering logic.**

2. **Empty task field**: `employee_status.current_task` was NULL because the status update script didn't sync from activities. Fixed by backfilling from `activities.output_summary`.

3. **Cron sync order**: The cron job ran before the DB was updated. Forced immediate sync after DB update.

## When to Use This Pattern

- Any real-time status dashboard showing team/employee/workflow state
- Data comes from SQLite or local DB
- Need zero-dependency frontend (single HTML file, no build step)
- Need auto-refresh every 15-30 seconds
