# AI Document Optimization Pattern

For admin tools that generate or manage documents (bids/proposals/reports), add AI-powered quality analysis.

## Architecture

Frontend (button per doc) → POST /api/bid/optimize → backend analysis → JSON response → modal display

## Backend Implementation

### Route

```python
@app.route("/api/bid/optimize", methods=["POST"])
def api_bid_optimize():
    data = request.get_json(force=True)
    bid_path = data.get("path", "")
    if not os.path.exists(bid_path):
        return jsonify({"error": "文件不存在"}), 404
    with open(bid_path) as f: content = f.read()
    
    # Try AI analysis first
    try:
        from src.generator import _get_deepseek_key
        key = _get_deepseek_key()
        if key:
            result = _ai_optimize(content, key)
            if result: return jsonify(result)
    except: pass
    
    # Fallback: rule-based
    return jsonify(_rule_optimize(content))
```

### AI Mode (DeepSeek)

Send content[:3000] chars with JSON-structured prompt:

```python
def _ai_optimize(content, key):
    prompt = f"""Analyze this document and suggest improvements.
Dimensions: structure/tech/business/competitive.
Return JSON: 
{{
    "score": 0-100, "structure_score": 0-100, "tech_score": 0-100,
    "business_score": 0-100, "competitive_score": 0-100,
    "strengths": ["..."], "weaknesses": ["..."],
    "suggestions": ["建议1:具体操作", "建议2:具体操作"]
}}
Content: {content[:3000]}"""
    
    # POST to deepseek API with response_format={"type": "json_object"}
    # Parse response, return dict
```

### Rule-based Fallback

Keyword matching for 4 dimensions. Fast, no API cost, works offline:

```python
def _rule_optimize(content):
    has_structure   = any(kw in content for kw in ["项目概述","需求分析","技术方案","实施计划","项目背景"])
    has_tech        = any(kw in content for kw in ["技术架构","系统架构","技术路线","平台架构"])
    has_business    = any(kw in content for kw in ["报价","价格","交付","售后","服务承诺","付款"])
    has_competitive = any(kw in content for kw in ["优势","资质","案例","认证","团队"])
    
    structure_score   = 80 if has_structure else 40
    tech_score        = 70 if has_tech else 35
    business_score    = 75 if has_business else 30
    competitive_score = 65 if has_competitive else 25
    total_score       = int((structure_score + tech_score + business_score + competitive_score) / 4)
    
    suggestions = []
    if not has_structure:
        suggestions.append("建议补充项目概述、需求分析、技术方案等标书必备章节")
    if not has_tech:
        suggestions.append("建议增加技术架构图和技术路线描述")
    if not has_business:
        suggestions.append("建议增加报价明细、交付计划、售后服务体系")
    if not has_competitive:
        suggestions.append("建议增加公司资质、成功案例、团队优势")
    if len(content) < 2000:
        suggestions.append(f"内容偏少({len(content)}字)，建议补充细节")
    suggestions.append("建议加入图表和数据引用增强可信度")
    
    return {"score": total_score, "structure_score": structure_score, ...,
            "suggestions": suggestions[:5], "total_chars": len(content), "using_ai": False}
```

## Frontend

### Button in each doc item
```javascript
<button onclick="optimizeDoc('${doc.path}')" title="优化建议">💡</button>
```

### Modal Function
```javascript
async function optimizeDoc(path) {
    showGlobalLoading();
    const r = await api('/api/bid/optimize', {path});
    hideGlobalLoading();
    // Render inside modal:
    // - 4 score cards (总体/结构/技术/商务)
    // - AI vs rules badge
    // - ✅ Strengths (green)
    // - ❌ Weaknesses (red)  
    // - 💡 Suggestions (5 cards with padding)
}
```

## Performance Considerations
- Content truncated to 3000 chars for AI API
- Rule-based fallback is instant (<10ms)
- Both modes produce the same JSON shape for consistent rendering
- 30s timeout on DeepSeek call

## Related
- `quality-scoring-pattern.md` — Simpler rule-based scoring (length/structure/customization)
- `flask-health-retry-system.md` — SMTP retry pattern used in cold email send
