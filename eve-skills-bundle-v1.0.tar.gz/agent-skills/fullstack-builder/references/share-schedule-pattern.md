# Bid Share Links + Scheduled Send

## Share Links (Public View)

### API — Create
```python
@app.route("/api/share/create", methods=["POST"])
def api_share_create():
    import uuid
    data = request.get_json(force=True)
    bid_path = data.get("path", "")
    if not os.path.exists(bid_path): return jsonify({"error":"文件不存在"}),404
    share_id = uuid.uuid4().hex[:12]
    # Save to shares.json
    share_file = "data/shares.json"
    shares = {}
    if os.path.exists(share_file):
        with open(share_file) as f: shares = json.load(f)
    shares[share_id] = {"path":bid_path,"name":os.path.basename(bid_path),"created":datetime.now()}
    with open(share_file,"w") as f: json.dump(shares,f,ensure_ascii=False,indent=2)
    return jsonify({"success":True,"share_id":share_id,"url":f"http://{request.host}/share/{share_id}"})
```

### API — Public View
```python
@app.route("/share/<share_id>")
def api_share_view(share_id):
    share_file = "data/shares.json"
    shares = {}
    if os.path.exists(share_file):
        with open(share_file) as f: shares = json.load(f)
    bid_path = shares.get(share_id,{}).get("path","")
    if not bid_path or not os.path.exists(bid_path):
        return "<h3>Not found</h3>",404
    with open(bid_path) as f: content = f.read()
    import markdown
    html_body = markdown.markdown(content,extensions=['extra','codehilite'])
    return f"""<!DOCTYPE html><html lang=zh-CN><head><meta charset=utf-8>
    <meta name=viewport content="width=device-width,initial-scale=1">
    <style>body{{font-family:system-ui;max-width:900px;margin:0 auto;padding:20px;line-height:1.7}}
    table{{border-collapse:collapse;width:100%}}th,td{{border:1px solid #ddd;padding:8px}}</style>
    <body>{html_body}</html>"""
```

## Scheduled Send

### SQLite Schema
```sql
CREATE TABLE IF NOT EXISTS scheduled_sends (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    bid_path TEXT NOT NULL,
    email TEXT NOT NULL,
    send_at TEXT NOT NULL,
    status TEXT DEFAULT 'pending',
    created_at TEXT DEFAULT (datetime('now'))
);
```

### API — Schedule
```python
@app.route("/api/schedule/send", methods=["POST"])
def api_schedule_send():
    data = request.get_json(force=True)
    bid_path, email, send_at = data.get("path",""), data.get("email",""), data.get("send_at","")
    if not bid_path or not email or not send_at:
        return jsonify({"error":"Missing params"}),400
    db = get_db()
    db.execute("INSERT INTO scheduled_sends(bid_path,email,send_at) VALUES(?,?,?)",
               (bid_path, email, send_at))
    db.commit(); db.close()
    return jsonify({"success":True,"message":f"Scheduled at {send_at}"})
```

### API — List
```python
@app.route("/api/schedule/list")
def api_schedule_list():
    rows = get_db().execute(
        "SELECT * FROM scheduled_sends ORDER BY send_at ASC LIMIT 20"
    ).fetchall()
    get_db().close()
    return jsonify([dict(r) for r in rows])
```

## Web UI Buttons

Add to each bid item's action bar:
```javascript
<button onclick="shareBid('${path}')" title="Share">🔗</button>
<button onclick="scheduleSend('${path}')" title="Schedule">📅</button>
```

## Key Points
- **Share links are public** — no auth, anyone with the UUID can view
- **UUID is 12 hex chars** — 12^16 combinations, sufficient for non-security use
- **Scheduled send** needs a cron job to check `pending` rows with `send_at <= now()` and execute them
- No cleanup — shares accumulate in shares.json; clear manually
