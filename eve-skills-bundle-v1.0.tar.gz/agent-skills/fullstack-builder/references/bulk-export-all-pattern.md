# Bulk Export All Projects Pattern

Aggregate all completed projects/entities into a single ZIP download.

## Architecture

```
GET /api/export/batch-all →
  filter status=done → load each task → extract documents →
  create ZIP → send_file download
```

## Backend

```python
import zipfile, os, time
from pathlib import Path

@app.route("/api/export/batch-all", methods=["GET"])
def batch_export_all():
    tasks = base.list_all()
    done = [t for t in tasks if t.get("status") == "done"]
    if not done:
        return jsonify({"success": False, "error": "没有已完成的项目可导出"}), 400
    
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    export_dir = Path(__file__).parent.parent / "exports"
    export_dir.mkdir(exist_ok=True)
    zip_path = export_dir / f"batch-all-{timestamp}.zip"
    
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for t in done:
            tid = t.get("task_id")
            task_obj = base.load(tid)
            if not task_obj: continue
            docs = task_obj.cleaned_requirement or {}
            safe_name = (task_obj.project_name or tid).replace("/","_").replace("\\","_")
            for dtype in ["proposal", "checklist", "srs"]:
                content = docs.get(dtype, "")
                if content:
                    zf.writestr(f"{safe_name}_{dtype}.md", content)
    
    return send_file(str(zip_path), as_attachment=True,
                     download_name=f"全部项目_{timestamp}.zip")
```

## Pitfalls

1. **Memory**: Loading all done tasks can be heavy. For 50+ tasks, batch.
2. **ZIP_DEFLATED**: Requires zlib. Fallback: `ZIP_STORED`.
3. **Temp files**: Generated on disk. Add cleanup cron or delete after download.
4. **Name collisions**: Same project name overwrites. Add task_id suffix: `f"{safe_name}_{tid[:8]}_{dtype}.md"`.
