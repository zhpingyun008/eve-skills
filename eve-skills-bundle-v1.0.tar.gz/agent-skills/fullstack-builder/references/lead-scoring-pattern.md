# Lead Scoring Pattern (多维度线索智能评分)

## Scoring Dimensions

| Dimension | Weight | Scoring Logic |
|-----------|--------|---------------|
| **Budget** | 30% | ≥500万=30, ≥200万=25, ≥100万=20, ≥50万=15, >0=10, unknown=5 |
| **Has Email** | 20% | Has email=20, No email=0 |
| **Deadline** | 30% | Overdue=30, ≤1d=30, ≤3d=25, ≤7d=20, ≤14d=15, ≤30d=10, No DL=5 |
| **Tier** | 20% | T1=+10, T2=+5, T3=+0 |

## Priority Levels

| Score Range | Priority | Color |
|-------------|----------|-------|
| ≥90 | 🔥 紧急 | var(--danger) / red |
| 75-89 | ✅ 高优 | var(--success) / green |
| 60-74 | 📋 跟进 | var(--warning) / yellow |
| <60 | ⏳ 观察 | var(--muted) / gray |

## Implementation (Python)

```python
def score_leads():
    leads = json.load(open(LEADS_FILE))
    scored = []
    
    for lead in leads:
        score = 50  # Base
        
        # Budget (regex extract from match text)
        m = re.search(r'(\d+\.?\d*)\s*万', lead.get("match", ""))
        budget = float(m.group(1)) if m else 0
        score += {500:30, 200:25, 100:20, 50:15}.get(max(k for k in [500,200,100,50,0] if budget >= k), 5)
        
        # Email
        score += 20 if lead.get("email") else 0
        
        # Deadline (regex extract 月日)
        m = re.search(r'(\d+)月(\d+)日', lead.get("match", ""))
        if m:
            deadline = datetime(year, int(m.group(1)), int(m.group(2)))
            days = (deadline - today).days
            score += 30 if days <= 1 else 25 if days <= 3 else 20 if days <= 7 else 15 if days <= 14 else 10 if days <= 30 else 5
        else:
            score += 5
        
        # Tier bonus
        score += {1:10, 2:5, 3:0}.get(lead.get("tier", 3), 0)
        
        scored.append({
            "id": lead["id"], "org": lead["org"],
            "score": score,
            "priority": "🔥 紧急" if score >= 90 else "✅ 高优" if score >= 75 else "📋 跟进" if score >= 60 else "⏳ 观察",
        })
    
    scored.sort(key=lambda x: x["score"], reverse=True)
    return {"total": len(scored), "avg_score": ..., "by_priority": ..., "leads": scored}
```

## Web UI Integration
- Leads table adds a "评分" column
- "按评分排序" checkbox toggles score-based sort
- Score color-coded: red(≥90) / green(75-89) / yellow(60-74) / gray(<60)
- Scored leads loaded on page init via `/api/leads/scored`

## API Endpoint
```
GET /api/leads/scored → {total, avg_score, top_score, by_priority, leads: [{id,org,score,priority,...}]}
```

## Pitfalls
1. **Budget regex too greedy**: `(\d+\.?\d*)\s*万` matches price in "预算500万" but also false positives in "总XXXX万元". Always check the context or trim the match string.
2. **Deadline parsing failure**: `(\d+)月(\d+)日` works for Chinese dates but fails for "6月12日截止" vs "2026年6月12日". Handle both formats.
3. **Score Map initialization**: In JS, build scoreMap once from scoredLeads array, not inside the sort callback (avoids O(n²) lookup per compare).
4. **Scoring recalculation**: Score changes when leads.json is updated. Don't cache scores indefinitely — regenerate on each API call.
