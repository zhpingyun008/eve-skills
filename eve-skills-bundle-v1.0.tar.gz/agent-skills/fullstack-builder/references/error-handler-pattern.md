# Global Error Handler Pattern for Flask APIs

For API-first Flask apps (not HTML-rendering ones), add global error handlers for clean JSON error responses.

## Pattern

```python
from flask import jsonify

@app.errorhandler(404)
def not_found(e):
    return jsonify({"error": "接口不存在", "docs": "/api/docs"}), 404

@app.errorhandler(500)
def server_error(e):
    return jsonify({"error": "服务器内部错误", "message": str(e)}), 500
```

## Key Points
- Always return JSON (not HTML) for API-first apps
- 404 handler should include a link to API docs if available
- 500 handler returns the error message for debugging
- Add these early in the file, right after the index route
- Flask registers these globally — they catch all unhandled routes and exceptions

## Pitfalls
- `@app.errorhandler(404)` only catches Flask-routed paths, not static file 404s
- For `send_from_directory` fallback, use `@app.route("/<path:path>")` catch-all route instead
- 500 handler's `str(e)` may expose internals in production — consider logging only in production
