# Document-Driven Business Rules Automation System

Pattern: build a full-stack system where business rules are extracted from SOP/regulatory documents, then automated as independent check items.

## Architecture Pattern

```
SOP/Regulatory Documents
    ↓ (extract rules)
Business Rules (24+ check items)
    ↓ (implement)
Check Engine (independent check functions)
    ↓ (pair with)
File Upload + Data Extraction (PDF/Excel/OCR)
    ↓ (generate)
Standardized Report (Markdown+HTML)
```

## Key Design Rules

### 1. Material Type Key — Single Source of Truth

Define ALL material types in ONE place. Every layer uses the SAME key:

```
file_service.py:     MATERIAL_TYPES = {"settlement": "结算工作量", ...}
upload router:       material_type = file_service.detect_material_type(filename)
check engine:        materials_data["settlement"]  (same key!)
frontend checklist:  { key: 'settlement', name: '结算工作量', ... }
```

**CRITICAL**: If keys mismatch between layers, checks silently skip data. Symptoms: "all passed but nothing was actually checked."

### 2. Multi-File Upload with Form Fields

FastAPI multipart upload requires both files AND form fields:

```python
# Frontend FormData (Vue 3)
const formData = new FormData()
formData.append('supplier_name', batchForm.value.supplier_name)
formData.append('settlement_period', batchForm.value.settlement_period)
for (const file of uploadedFiles) {
    formData.append('files', file.raw || file)
}

# Backend (FastAPI)
def create_batch(
    supplier_name: str = Form(...),
    settlement_period: str = Form(...),
    files: List[UploadFile] = File(...),
):
```

### 3. Upload Response Must Include Materials

Frontend needs materials in the upload response to update checklist:

```python
class BatchWithMaterials(BatchOut):
    materials: List[MaterialOut] = []
```

### 4. Filename-Based Material Detection

Use keyword matching, not exact filename matching:

```python
keyword_map = [
    ("结算工作量", "settlement"),
    ("考勤", "attendance"),
    ("付款确认单", "payment_confirmation"),
    ...
]
for keyword, mtype in keyword_map:
    if keyword in filename:
        return mtype
```

### 5. Check Engine Design

- Each check item = independent function `def check_xxx(materials: dict, config: dict) -> dict`
- Returns `{"status": "pass"/"warning"/"error", "detail": {...}, "errors": [...], "warnings": [...]}`
- Use `Decimal` for ALL monetary calculations
- Handle missing materials gracefully (skip check, log warning)
- Run in rounds: Round1 (internal consistency) → Round2 (cross-material) → Round3 (business rules) → Supplement

### 6. Frontend Checklist Synchronization

After upload, update checklist from API response materials:

```javascript
const result = await uploadBatch(formData)
const materials = result.materials || []
checklist.value.forEach((item) => {
    const matched = materials.find((m) => m.material_type === item.key)
    if (matched) {
        item.uploaded = true
        item.file = matched.original_filename
    }
})
```

### 7. Error Handling in Frontend

Catch errors with `.message` to avoid "[object Object]":

```javascript
catch (err) {
    const msg = err.message || '请求失败'
    ElMessage.error(msg)  // NOT '上传失败: ' + err.message
}
```

## Common Pitfalls

| Symptom | Root Cause | Fix |
|---------|-----------|-----|
| Upload returns empty materials | Filename doesn't match any keyword | Add filename keyword to detect_material_type |
| All checks pass with no meaningful data | Material key mismatch between layers | Audit key names across all 3 layers |
| Frontend shows "[object Object]" | catch handler appends object without .message | Use err.message extraction pattern |
| "缺少字段" after upload | FormData missing supplier_name/settlement_period | Add form fields before files |
| Backend port conflict | Other app already listening | Use different port, update vite proxy |

## SOP-Based Check Engine Skeleton

```python
# One function per check, all same signature
def check_amount_calculation(materials: dict, config: dict) -> dict:
    persons = materials.get("settlement", {}).get("persons", [])
    errors = []
    for p in persons:
        unit_price = Decimal(str(p["unit_price"]))
        days = Decimal(str(p["settlement_days"]))
        coeff = Decimal(str(p["coefficient"]))
        expected = (unit_price * days * coeff).quantize(Decimal("0.01"))
        billed = Decimal(str(p["total_amount"]))
        if abs(expected - billed) > Decimal(str(config.get("amount_tolerance", 0.02))):
            errors.append({"name": p["name"], "expected": str(expected), "billed": str(billed)})
    return {
        "status": "error" if errors else "pass",
        "detail": {"checked_count": len(persons), "error_count": len(errors)},
        "errors": errors,
    }
```
