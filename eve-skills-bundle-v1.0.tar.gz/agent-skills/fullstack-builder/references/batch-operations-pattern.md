# Batch Operations Pattern (批量操作)

For admin tools with list views, add checkbox-based batch operations so users can act on multiple items at once instead of one-by-one.

## Architecture

```javascript
let _selectedBids = new Set();  // Set of paths/IDs

function toggleSelectBid(path) {
    if (_selectedBids.has(path)) _selectedBids.delete(path);
    else _selectedBids.add(path);
    updateBatchBar();
}

function toggleSelectAll() {
    const cb = document.getElementById('select-all');
    if (!cb) return;
    if (cb.checked) {
        document.querySelectorAll('.bid-checkbox').forEach(c => {
            c.checked = true; _selectedBids.add(c.value);
        });
    } else {
        document.querySelectorAll('.bid-checkbox').forEach(c => { c.checked = false; });
        _selectedBids.clear();
    }
    updateBatchBar();
}

function updateBatchBar() {
    const bar = document.getElementById('batch-bar');
    const count = document.getElementById('batch-count');
    if (!bar || !count) return;
    const n = _selectedBids.size;
    bar.style.display = n > 0 ? 'flex' : 'none';
    count.textContent = `已选 ${n} 份`;
    // Sync select-all checkbox state
    const totalCbs = document.querySelectorAll('.bid-checkbox');
    const checkedCbs = document.querySelectorAll('.bid-checkbox:checked');
    const selAll = document.getElementById('select-all');
    if (selAll) {
        selAll.checked = totalCbs.length > 0 && checkedCbs.length === totalCbs.length;
        selAll.indeterminate = checkedCbs.length > 0 && checkedCbs.length < totalCbs.length;
    }
}
```

## Web UI

### Checkbox per item
```html
<div class="bid-item">
    <label class="batch-check">
        <input type="checkbox" class="bid-checkbox" value="${path}"
            onchange="toggleSelectBid('${path}')">
    </label>
    <div class="info">
        <div class="name">${name}</div>
        <div class="meta">${metadata}</div>
    </div>
    <div class="actions">${buttons}</div>
</div>
```

### Batch action bar (hidden by default, shown on selection)
```html
<div id="batch-bar" style="display:none;padding:8px 12px;background:#1e293b;border-radius:8px;
     align-items:center;gap:8px;flex-wrap:wrap;animation:fadeIn .2s ease">
    <span id="batch-count" style="font-size:0.8rem;color:var(--muted)">已选 0 份</span>
    <button class="btn btn-sm btn-warning" onclick="batchSend()">📤 发送选中</button>
    <button class="btn btn-sm" style="background:#ef4444;color:#fff" onclick="batchDelete()">🗑️ 删除选中</button>
</div>
```

### CSS
```css
.batch-check { display:flex; align-items:center; padding:0 4px 0 8px; }
.batch-check input { width:16px; height:16px; cursor:pointer; accent-color:#2563eb; }
#batch-bar { animation: fadeIn .2s ease; }
@keyframes fadeIn { from { opacity:0; transform:translateY(-8px); } to { opacity:1; transform:translateY(0); } }
```

## Batch Operations

### Batch Send
```javascript
async function batchSend() {
    const paths = Array.from(_selectedBids);
    if (paths.length === 0) { toast('请先选择', 'warn'); return; }
    const email = prompt(`收件人邮箱（${paths.length}份）：`);
    if (!email || !email.includes('@')) { toast('无效邮箱', 'error'); return; }
    
    let sent = 0, failed = 0;
    for (const path of paths) {
        try {
            const r = await api('/api/send-bid', {path, email});
            if (r.success) sent++; else failed++;
        } catch(e) { failed++; }
    }
    toast(`📤 批量发送：${sent}成功/${failed}失败`);
    _selectedBids.clear();
    updateBatchBar();
    loadRecent();  // refresh list
    loadStats();   // update stats
}
```

### Batch Delete
```javascript
async function batchDelete() {
    const paths = Array.from(_selectedBids);
    if (paths.length === 0) { toast('请先选择', 'warn'); return; }
    if (!confirm(`确认永久删除 ${paths.length} 份？`)) return;
    
    let deleted = 0, failed = 0;
    for (const path of paths) {
        try {
            const r = await api('/api/bid/delete', {path});
            if (r.success) deleted++; else failed++;
        } catch(e) { failed++; }
    }
    toast(`🗑️ 批量删除：${deleted}已删/${failed}失败`);
    _selectedBids.clear();
    updateBatchBar();
    loadRecent();
    loadStats();
}
```

## Principles

1. **Use a Set, not array** — dedup and fast `has()/delete()/clear()`
2. **Standalone toggle functions** — each checkbox calls `toggleSelectBid(path)` independently
3. **Auto-hide bar** — when count hits 0, bar disappears with fadeIn animation
4. **Per-item error isolation** — each operation in its own try-catch so one failure doesn't block the rest
5. **Select-all checkbox** — uses `indeterminate` state for partial selection
6. **Post-operation cleanup** — clear selection, refetch list, update stats

## Pitfalls

1. **DOM vs Set sync**: When user clicks an item checkbox, `toggleSelectBid` updates the Set AND calls `updateBatchBar()`. Never update the DOM checkbox state directly without also updating the Set.
2. **Event propagation**: Checkbox change events bubble. Use `event.stopPropagation()` if the checkbox is inside a clickable item.
3. **Select-all edge case**: When a new batch of items loads (e.g., after search/filter), the select-all checkbox needs to be reset since `_selectedBids` contains old paths that no longer match DOM checkboxes.
