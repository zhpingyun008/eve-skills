# Deal Management Pattern (中标管理)

For products that manage bids/proposals/contracts, add a deal management lifecycle to close the loop from proposal → contract → payment.

## Data Model (SQLite)

```sql
CREATE TABLE deals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    lead_id INTEGER,
    org TEXT,
    project TEXT,
    status TEXT DEFAULT 'pending',  -- won/lost/pending/followup
    contract_amount REAL DEFAULT 0,
    paid_amount REAL DEFAULT 0,
    notes TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
);
```

## API Design

```
GET    /api/deals          → list all deals (latest first)
POST   /api/deals/create   → create deal {org, project, status, contract_amount, paid_amount}
PUT    /api/deals/<id>     → update deal fields {status, contract_amount, ...}
```

Update logic: dynamically build SET clause from provided fields:
```python
fields = []
vals = []
for k in ["status","contract_amount","paid_amount","notes"]:
    if k in data:
        fields.append(f"{k}=?")
        vals.append(data[k])
if fields:
    vals.append(deal_id)
    db.execute(f"UPDATE deals SET {','.join(fields)}, updated_at=datetime('now') WHERE id=?", vals)
```

## Web UI Integration

- Add ✅ button to each bid item in pipeline, opens prompt chain: status → amount → paid
- Add deals-content panel below pipeline (collapsible)
- Show summary bar: ✅ won / total, ¥ contract total, ¥ paid total
- Per-deal row: org + project + status badge + amounts + edit button

## Status labels
| status | display |
|--------|---------|
| won | ✅中标 |
| lost | ❌未中标 |
| followup | 📋跟进中 |
| pending | ⏳待定 |

## Aggregation (summary bar)
```javascript
const won = deals.filter(d => d.status === 'won');
const totalAmount = won.reduce((s,d) => s + d.contract_amount, 0);
const totalPaid = won.reduce((s,d) => s + d.paid_amount, 0);
```

See also: `customer-timeline-pattern.md` for per-org interaction history.
