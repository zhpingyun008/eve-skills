# One-Click Deploy Script Pattern

For any Flask+systemd product, create a `setup.sh` that handles the full deployment lifecycle.

## Script Structure

```bash
#!/bin/bash
set -e

# 1. Check environment
PYTHON=$(command -v python3 || command -v python)
if [ -z "$PYTHON" ]; then echo "❌ Need Python 3"; exit 1; fi

# 2. Create directories
mkdir -p src data scripts static backups

# 3. Install dependencies
$PYTHON -m pip install flask markdown 2>/dev/null

# 4. Create systemd service file
mkdir -p ~/.config/systemd/user
cat > ~/.config/systemd/user/my-service.service << 'EOF'
[Unit]
Description=My Service
After=network.target
[Service]
Type=simple
ExecStart=/path/to/venv/bin/python3 /path/to/app.py
Restart=always
RestartSec=5
[Install]
WantedBy=default.target
EOF

# 5. Initialize database
$PYTHON -c "import sys; sys.path.insert(0,'.'); from src.database import get_db; get_db();"

# 6. Create data files if missing
for f in data.json tracking.json; do
    [ -f "~/company/data/$f" ] || echo "[]" > "~/company/data/$f"
done

# 7. Start service
systemctl --user enable my-service.service 2>/dev/null || true
systemctl --user restart my-service.service
sleep 2

# 8. Verify
if systemctl --user is-active my-service.service >/dev/null 2>&1; then
    echo "✅ Service running"
else
    echo "❌ Failed - check: journalctl --user -u my-service -n 50"
fi
```

## Key Rules
- **Never** use `User=` directive in user-level systemd services (causes exit code 216)
- Use `ExecStart` with full paths to the venv Python, not system Python
- `Restart=always` for production reliability
- Verify with `systemctl --user is-active` after restart
