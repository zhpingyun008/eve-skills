# Vite 8 + oxc Parser — TypeScript Config Fix

## Symptom

After scaffolding a standard Vite + React + TypeScript project (via `create-vite@latest`), the dev server starts but every page request logs:

```
[TSCONFIG_ERROR] Failed to load tsconfig for 'src/main.tsx': Tsconfig not found
```

The browser shows a blank page with this error in the console. The standard Vite template's project-reference tsconfig (`tsconfig.json` → `tsconfig.app.json` + `tsconfig.node.json`) works fine with Vite 6/7 but fails with Vite 8's new `oxc` Rust-based parser.

## Root Cause

Vite 8 replaces the default TypeScript parser (swc/esbuild) with `oxc` (Rust-based). The oxc parser does not resolve project references (`"references": [{ "path": "./tsconfig.app.json" }]`) in the same way. It looks for a single tsconfig file at the project root.

## Fix

Merge all tsconfig files into a single `tsconfig.json`, removing project references:

```json
{
  "compilerOptions": {
    "tsBuildInfoFile": "./node_modules/.tmp/tsconfig.app.tsbuildinfo",
    "target": "es2023",
    "lib": ["ES2023", "DOM"],
    "module": "esnext",
    "types": ["vite/client"],
    "skipLibCheck": true,
    "moduleResolution": "bundler",
    "allowImportingTsExtensions": true,
    "verbatimModuleSyntax": false,
    "moduleDetection": "force",
    "noEmit": true,
    "jsx": "react-jsx",
    "noUnusedLocals": false,
    "noUnusedParameters": false,
    "noFallthroughCasesInSwitch": true,
    "strict": false
  },
  "include": ["src"],
  "references": []
}
```

Key changes from the default Vite 8 template:
1. **Remove `"files": []`** — oxc doesn't understand empty files array + references
2. **Remove separate `tsconfig.app.json` / `tsconfig.node.json`** — merge all options into one
3. **Set `verbatimModuleSyntax: false`** — prevents `[MISSING_EXPORT]` errors from rolldown bundler for interfaces defined in the same file (see Pitfalls)
4. **Set `noUnusedLocals: false`, `noUnusedParameters: false`** — prevents build failures during rapid prototyping (re-enable for production CI)
5. **Set `strict: false`** — optional, speeds up development iteration

Then delete the extra tsconfig files and restart:
```bash
rm -f tsconfig.app.json tsconfig.node.json
kill $(lsof -t -i:5173) 2>/dev/null
npx vite --host 0.0.0.0
```

## Verification

```bash
curl -s http://localhost:5173/ | head -3
# Expected: <!doctype html><html lang="en"><head>
# No TSCONFIG_ERROR in server logs
```

## Prevention

When scaffolding a new project with Vite 8 (vite >= 8.0.0), immediately merge the tsconfig files and set `verbatimModuleSyntax: false` before starting development. The default template's project-reference pattern is legacy from Vite 6/7 and will be deprecated in future Vite versions.

## Pitfalls

- **Don't delete `tsconfig.node.json` without merging its contents first** — it contains settings for `vite.config.ts` that the build pipeline needs
- **Don't set `strict: true` during initial prototyping** — it will surface hundreds of type errors from React/JSX that block development
- **Don't use `--reload` with SQLite** — see `sqlite-dev-mode-patterns.md` for details
- **`verbatimModuleSyntax: true` → blank page / `Missing export` errors**: In Vite 8, `rolldown` (the Rust-based bundler) enforces strict module export checking even for interfaces defined and exported in the same file. If `verbatimModuleSyntax: true` and the browser shows a blank page with no console errors except a JS exception, or the build fails with `[MISSING_EXPORT] "X" is not exported by "src/api/client.ts"` for interfaces you know are exported, set `verbatimModuleSyntax: false` in tsconfig.json. This is a bundler-level issue, not a TypeScript correctness issue — the rolldown bundler treats TypeScript interfaces differently from esbuild/swc when `verbatimModuleSyntax` is enabled. Do NOT use `export type` workarounds; just flip the flag to `false`.
