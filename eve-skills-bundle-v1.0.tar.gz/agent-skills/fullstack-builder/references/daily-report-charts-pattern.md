# Daily Report + Charts Pattern

## Architecture

```
src/reports.py (data engine) → /api/reports/daily (Flask endpoint) → Web UI tab (Vanilla JS)
src/reports.py (data engine) → /api/reports/charts (Flask endpoint) → Web UI progress bars + cards
src/reports.py (data engine) → /api/reports/pending (Flask endpoint) → Web UI pending reminders list
```

## src/reports.py Structure

Three core functions:
- `generate_daily_report()` — structured dict with summary/leads/urgent/bids/cold_email sections
- `get_chart_data()` — budget distribution, tier distribution, email status, bid status
- `get_pending_reminders()` — overdue/urgent/upcoming/no-deadline items sorted by urgency

### Data Sources
All from JSON files loaded via `load_json(path)` helper (handles missing files gracefully):
- `leads.json` — 62+ leads with org/project/tier/email/match(budget+deadline)
- `bid-tracking.json` — sent/pending bids per lead
- `lead-tracking.json` — cold email SMTP stats + replies

### Budget Extraction
```python
import re
m = re.search(r'(\d+\.?\d*)\s*万', lead.get("match", ""))
if m: float(m.group(1))
```

### Deadline Extraction
```python
m = re.search(r'(\d+)月(\d+)日', lead.get("match", ""))
if m: month, day = int(m.group(1)), int(m.group(2))
deadline = datetime(today.year, month, day)
days_left = (deadline - today).days
```

### Chart Data Shapes
```json
{
  "budget_distribution": [{"label":"0-50万","value":N}, ...],
  "tier_distribution": [{"label":"T1(紧急)","value":N}, ...],
  "email_status": {"with_email": N, "without_email": N},
  "bid_status": {"sent": N, "pending": N, "no_email": N}
}
```

## Web UI Integration

### Tab Setup
```html
<div class="tab" onclick="switchTab('reports')">📈 日报</div>
```

### Panel Structure
Three cards:
1. 📈 Today's Brief — 3-card stats grid (total outgoing / sent / pending) + pipeline value + cold email stats
2. 📊 Charts — Two-column grid: budget distribution (progress bars) + tier distribution (progress bars) + send status (3 cards)
3. ⏰ Pending Reminders — Count (overdue/urgent_7days) + sorted list with clickable items + send button per item

### Key JS pattern: progress bars
```javascript
<div class="progress-bar">
  <div class="progress-fill" style="width:${Math.min(100, value / max * 100)}%"></div>
</div>
```

### Key JS pattern: pending item
```javascript
const daysStr = days_left === 999 ? '无截止' : 
  days_left < 0 ? `<span style="color:var(--danger)">逾期${Math.abs(days_left)}天</span>` : 
  `${days_left}天`;
```

## Pitfalls
- **Inline Python in shell**: Don't try to parse JSON with inline Python when the pipe involves complex Unicode or single-quote data. Always use curl + python3 -c with double quotes for the outer shell.
- **Deadline comparison across months**: When deadline is in months 1-12, don't forget the current year may differ. Cross-year deadlines should cap days_left.
- **Empty data handling**: Every loop should handle missing fields gracefully (l.get("field", "") or || 0).
- **Report data staleness**: JSON files written by cron jobs may be stale. Add a `generated_at` timestamp so the user knows freshness.
