# Batch Lead Import for Flask Web Apps

## Overview
Add a CSV/JSON batch import feature for lead/contact management systems. Supports dedup, auto-id, and source tagging.

## Flask Endpoint

```python
@app.route("/api/leads/import", methods=["POST"])
def api_import_leads():
    import csv, io
    
    data = request.get_json(force=True)
    source = data.get("source", "json")  # json or csv
    content = data.get("content", "")
    
    leads_file = os.path.expanduser("~/company/data/leads.json")
    
    # Load existing
    existing = []
    if os.path.exists(leads_file):
        with open(leads_file) as f:
            existing = json.load(f)
    
    imported = []
    existing_orgs = set(l.get("org", "").strip().lower() for l in existing if l.get("org"))
    
    if source == "json":
        items = json.loads(content)
        for item in items if isinstance(items, list) else [items]:
            if not item.get("org"): continue
            if item["org"].strip().lower() in existing_orgs: continue
            if not item.get("id"): item["id"] = len(existing) + len(imported) + 1
            imported.append(item)
    elif source == "csv":
        reader = csv.DictReader(io.StringIO(content))
        for row in reader:
            org = row.get("组织", row.get("org", "")).strip()
            if not org: continue
            if org.lower() in existing_orgs: continue
            imported.append({
                "id": len(existing) + len(imported) + 1,
                "org": org,
                "project": row.get("项目", row.get("project", "")),
                "email": row.get("邮箱", row.get("email", "")),
                "phone": row.get("电话", row.get("phone", "")),
                "need": row.get("需求", row.get("need", "")),
                "match": row.get("匹配", row.get("match", "")),
                "tier": int(row.get("等级", row.get("tier", 2))),
                "source": "批量导入",
            })
    
    if imported:
        existing.extend(imported)
        with open(leads_file, "w") as f:
            json.dump(existing, f, ensure_ascii=False, indent=2)
    
    return jsonify({"success": True, "imported": len(imported), "total": len(existing)})
```

## Web UI Implementation

### HTML (toggle-able import panel)
```html
<div id="import-container" style="display:none">
    <div class="card">
        <h4>📥 批量导入线索</h4>
        <div>
            <button onclick="setImportMode('json')">JSON</button>
            <button onclick="setImportMode('csv')">CSV</button>
            <span id="import-mode-label">当前: JSON</span>
        </div>
        <textarea id="import-text" rows="6" 
            placeholder='[{"org":"名称","project":"项目","email":"..."}]'></textarea>
        <button onclick="doImport()">📥 导入</button>
        <span id="import-result"></span>
    </div>
</div>
```

### JavaScript
```javascript
let _importMode = 'json';

function toggleImport() {
    const c = document.getElementById('import-container');
    c.style.display = c.style.display === 'none' ? 'block' : 'none';
}

async function doImport() {
    const content = document.getElementById('import-text').value.trim();
    if (!content) return;
    
    const r = await api('/api/leads/import', { 
        source: _importMode, 
        content 
    });
    
    if (r.imported > 0) {
        loadLeads();  // Refresh the leads table
        toast(`📥 导入${r.imported}条线索`);
    }
}
```

## Key Points
- Dedup by organization name (lowercase trimmed) — not by project
- JSON format: array of objects with at minimum `{"org": "..."}`
- CSV format: first row as headers, at minimum `组织` or `org` column
- Auto-assigns `"source": "批量导入"` for filtering later
- Always return `imported` and `total` count for feedback
