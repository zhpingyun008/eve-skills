# Flask Admin Utility Patterns

Reference for the 5 utility endpoints added in round 8 of the 智项智造 project:
[Import, Compare, Templates, Backup, Logs]

## 1. Excel/CSV Batch Import (POST /api/tasks/import)

```python
@app.route("/api/tasks/import", methods=["POST"])
def import_tasks():
    file = request.files.get("file")
    if not file:
        return jsonify({"success": False, "error": "No file"}), 400
    ext = file.filename.rsplit(".", 1)[-1].lower() if "." in file.filename else ""
    if ext == "csv":
        df = pd.read_csv(file)
    elif ext == "xlsx":
        df = pd.read_excel(file, engine="openpyxl")
    else:
        return jsonify({"success": False, "error": "CSV or XLSX only"}), 400
    # Columns: A=project_name, B=raw_input, C=project_type (optional)
    results, errors = [], []
    for i, row in df.iterrows():
        name = str(row.iloc[0]) if pd.notna(row.iloc[0]) else f"Import_{i}"
        raw = str(row.iloc[1]) if len(row) > 1 and pd.notna(row.iloc[1]) else ""
        ptype = str(row.iloc[2]) if len(row) > 2 and pd.notna(row.iloc[2]) else ""
        task = RequirementTask(project_name=name, raw_input=raw, project_type=ptype)
        base.save(task)
        # ... run pipeline
        results.append(task.task_id)
    return jsonify({"success": True, "count": len(results), "errors": errors, "task_ids": results})
```

Dependencies: `pandas`, `openpyxl` (pip install).

## 2. Project Compare (POST /api/tasks/compare)

Returns two task documents side-by-side:
```python
@app.route("/api/tasks/compare", methods=["POST"])
def compare_tasks():
    data = request.get_json(force=True)
    ids = data.get("ids", [])
    if len(ids) != 2:
        return jsonify({"success": False, "error": "Need exactly 2 IDs"}), 400
    t1, t2 = base.load(ids[0]), base.load(ids[1])
    if not t1 or not t2:
        return jsonify({"success": False, "error": "Task not found"}), 404
    return jsonify({
        "success": True,
        "task1": {"name": t1.project_name, "docs": t1.cleaned_requirement},
        "task2": {"name": t2.project_name, "docs": t2.cleaned_requirement},
    })
```

## 3. Template Library (CRUD /api/templates)

Templates stored as JSON files in a `templates_lib/` directory:
```python
TEMPLATES_DIR = "/path/to/templates_lib/"
os.makedirs(TEMPLATES_DIR, exist_ok=True)

@app.route("/api/templates", methods=["GET"])
def list_templates():
    templates = []
    for fn in sorted(os.listdir(TEMPLATES_DIR)):
        if fn.endswith(".json"):
            with open(os.path.join(TEMPLATES_DIR, fn)) as f:
                t = json.load(f)
            templates.append({"name": t.get("name"), "raw_input": t.get("raw_input",""),
                              "project_type": t.get("project_type",""),
                              "budget": t.get("budget",""), "duration": t.get("duration",""),
                              "created_at": t.get("created_at","")})
    return jsonify({"success": True, "templates": templates, "count": len(templates)})

@app.route("/api/templates", methods=["POST"])
def save_template():
    data = request.get_json(force=True)
    name = data.get("name", "").strip()
    if not name: return jsonify({"success": False, "error": "Name required"}), 400
    safe_name = name.replace("/", "_").replace("\\", "_")
    fpath = os.path.join(TEMPLATES_DIR, f"{safe_name}.json")
    data["created_at"] = datetime.now().isoformat()
    with open(fpath, "w") as f: json.dump(data, f, ensure_ascii=False)
    return jsonify({"success": True, "name": name})

@app.route("/api/templates/<name>", methods=["DELETE"])
def delete_template(name):
    fpath = os.path.join(TEMPLATES_DIR, f"{name}.json")
    if os.path.exists(fpath): os.remove(fpath)
    return jsonify({"success": True})
```

## 4. Data Backup (POST /api/backup)

Creates timestamped ZIP of all data files:
```python
@app.route("/api/backup", methods=["POST"])
def do_backup():
    import shutil, zipfile
    backup_dir = "/path/to/backups/"
    os.makedirs(backup_dir, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    zip_path = os.path.join(backup_dir, f"zhixiang_backup_{ts}.zip")
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for fn in os.listdir(base.storage_dir):
            if fn.endswith(".json"):
                zf.write(os.path.join(base.storage_dir, fn), fn)
    # Prune to last 30
    backups = sorted([os.path.join(backup_dir, f) for f in os.listdir(backup_dir) if f.endswith(".zip")])
    for old in backups[:-30]: os.remove(old)
    return jsonify({"success": True, "path": zip_path, "size_bytes": os.path.getsize(zip_path)})
```

## 5. Operation Logs (GET/POST /api/logs)

JSON-array log storage with 500-entry cap:
```python
LOGS_PATH = "/path/to/data/operation_logs.json"

def _load_logs():
    if os.path.exists(LOGS_PATH):
        with open(LOGS_PATH) as f:
            return json.load(f)
    return []

@app.route("/api/logs", methods=["GET"])
def get_logs():
    logs = _load_logs()
    logs.reverse()  # newest first
    return jsonify({"success": True, "logs": logs[:100], "count": min(100, len(logs))})

@app.route("/api/logs", methods=["POST"])
def add_log():
    data = request.get_json(force=True)
    logs = _load_logs()
    logs.append({
        "action": data.get("action", ""),
        "task_id": data.get("task_id", ""),
        "detail": data.get("detail", ""),
        "timestamp": datetime.now().isoformat(),
    })
    if len(logs) > 500:
        logs = logs[-500:]
    os.makedirs(os.path.dirname(LOGS_PATH), exist_ok=True)
    with open(LOGS_PATH, "w") as f:
        json.dump(logs, f, ensure_ascii=False, default=str)
    return jsonify({"success": True, "count": len(logs)})
```

## Frontend Modal Pattern

All utility features use the same modal-overlay pattern:
```html
<div id="xxx-modal" class="modal-overlay" style="display:none;position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.5);z-index:200;align-items:center;justify-content:center">
  <div style="background:var(--card);border-radius:12px;padding:24px;max-width:500px;width:90%">
    ... content ...
  </div>
</div>
```

Toggle: `document.getElementById('modal').style.display = 'flex'` / `'none'`
