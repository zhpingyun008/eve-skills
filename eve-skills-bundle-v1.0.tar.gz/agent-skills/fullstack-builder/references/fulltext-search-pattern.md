# Full-Text Content Search Pattern

Search across task/entity document content (not just names). Useful for AI-generated document systems where content matters more than titles.

## Architecture

```
?q=关键词 → search project_name + last 50 tasks' document content →
  returns results with 匹配摘要 field (snippet with surrounding context)
```

## Backend Implementation

```python
@app.route("/api/tasks", methods=["GET"])
def list_tasks():
    search = request.args.get("q", "").strip().lower()
    tasks = base.list_all()  # summary dicts
    tasks.reverse()  # newest first
    
    if not search:
        return jsonify({"success": True, "tasks": tasks, "count": len(tasks)})
    
    # First: match by project_name (existing behavior)
    result = [t for t in tasks if search in (t.get("project_name","") or "").lower()]
    
    # Second: match by document content (full-text)
    seen_ids = {t.get("task_id") for t in result}
    for t in tasks[:50]:  # performance limit
        tid = t.get("task_id")
        if tid in seen_ids:
            continue
        task_obj = base.load(tid)
        if not task_obj:
            continue
        docs = task_obj.cleaned_requirement or {}
        for dtype in ["proposal", "checklist", "srs"]:
            content = docs.get(dtype, "")
            if search in content.lower():
                # Extract snippet with context
                idx = content.lower().index(search)
                start = max(0, idx - 40)
                end = min(len(content), idx + len(search) + 40)
                snippet = ("..." if start > 0 else "") + content[start:end] + ("..." if end < len(content) else "")
                t["匹配摘要"] = snippet
                result.append(t)
                break
    
    return jsonify({"success": True, "tasks": result, "count": len(result)})
```

## Key Design Decisions

| Decision | Choice | Rationale |
|----------|--------|-----------|
| Search scope | project_name + document body | Users search for content, not titles |
| Performance limit | 50 most recent | Full-text requires loading full task objects — expensive |
| Snippet context | 40 chars each side | Enough to show relevance, not too large |
| Dedup | `seen_ids` set | Avoid showing same task twice |
| Content types | proposal, checklist, srs | All three document types |

## Frontend Integration

```javascript
function filterTasks() {
    const q = document.getElementById('search_input').value;
    fetch('/api/tasks?q=' + encodeURIComponent(q))
        .then(r => r.json()).then(d => renderTaskTable(d.tasks));
}
```

Display matching content snippet in table:
```javascript
if (t.匹配摘要) {
    html += `<div style="font-size:11px;color:var(--dim)">🔍 ${t.匹配摘要.slice(0,60)}...</div>`;
}
```

## Pitfalls

1. **Task object loading**: `base.list_all()` returns lightweight dicts. Full-text needs `base.load(tid)` which is slower. Always limit to N recent tasks.
2. **Encoding**: Chinese characters must be URL-encoded. Frontend must use `encodeURIComponent()`. Backend receives decoded UTF-8.
3. **Case sensitivity**: Use `.lower()` on both sides for case-insensitive match. Chinese text is unaffected by `.lower()` so it's safe.
4. **Empty results**: Return empty array, not error. Let frontend render "无匹配" message.
