# System Diagnostics Pattern (Flask)

For any Flask-based admin tool built via fullstack-builder, add a `/api/diagnose` endpoint to enable health-checking and troubleshooting without SSH access.

## API Pattern

```python
@app.route("/api/diagnose", methods=["GET"])
def system_diagnose():
    import time
    start = time.time()
    
    # 1. Count tasks by status (adapt to your data source)
    tasks = base.list_all()  # or data_store.get_all()
    by_status = {}
    errors = []
    durations = []
    
    for t in tasks:
        s = t.get("status", "unknown") or (t.status if hasattr(t, 'status') else "unknown")
        by_status[s] = by_status.get(s, 0) + 1
        
        # Collect failed tasks with errors
        if s in ("failed", "partial"):
            err = t.get("error", "") or str(t)[:80] or "详见任务详情"
            errors.append({
                "id": t.get("task_id", t.get("id", "?")),
                "name": t.get("project_name", t.get("name", "未命名")),
                "status": s,
                "error": err[:120]
            })
        
        # Track durations
        dur = t.get("duration", 0) or getattr(t, 'duration', 0)
        if dur: durations.append(dur)
    
    # 2. Check component health
    skills = dispatcher.list_skills() if has_dispatcher else []
    
    elapsed = round(time.time() - start, 3)
    return jsonify({
        "system": {
            "status": "ok",
            "version": "v2",
            "tasks_total": len(tasks),
            "tasks_by_status": by_status,
            "avg_duration": round(sum(durations)/len(durations), 1) if durations else 0,
        },
        "skills": {"total": len(skills), "names": skills},
        "errors": errors,
        "elapsed_ms": round(elapsed * 1000),
    })
```

## Web UI Integration

### Alert-based (simple)

```javascript
async function showDiagnose() {
    const resp = await fetch('/api/diagnose');
    const data = await resp.json();
    const s = data.system;
    let msg = `🔍 系统诊断\n`;
    msg += `状态: ${s.status}\n`;
    msg += `总任务: ${s.tasks_total} | ${Object.entries(s.tasks_by_status||{}).map(([k,v]) => `${k}:${v}`).join(' · ')}\n`;
    msg += `平均耗时: ${s.avg_duration || 'N/A'}s\n`;
    msg += `技能模块: ${data.skills.total}个\n`;
    if (data.errors?.length > 0) {
        msg += `\n❌ 失败任务:\n`;
        data.errors.slice(0,5).forEach(e => msg += `  ${e.name}: ${e.error.slice(0,50)}\n`);
    }
    alert(msg);
}
```

### Status bar (passive)

```javascript
fetch('/api/diagnose').then(r=>r.json()).then(d => {
    const s = d.system;
    const parts = Object.entries(s.tasks_by_status||{})
        .map(([k,v]) => `${k}:${v}`).join(' · ');
    statusEl.textContent = `${s.tasks_total}任务 · ${parts}`;
});
```

## Button in Search Bar

```html
<button class="btn btn-sm btn-outline" onclick="showDiagnose()">🔍 诊断</button>
```

## Retry-Failed Pattern

```python
@app.route("/api/tasks/retry-failed", methods=["POST"])
def retry_failed_tasks():
    tasks = base.list_all()
    failed = [t for t in tasks if t.get("status") in ("failed", "partial")]
    retried = 0
    for ft in failed:
        tid = ft.get("task_id")
        if not tid: continue
        t = base.load(tid)
        if t:
            t.status = "pending"  # dataclass attribute, not dict
            base.save(t)          # single object parameter
            retried += 1
    return jsonify({"success": True, "retried": retried, "total_failed": len(failed)})
```

## Key Lessons

1. **Dataclass objects** returned by `base.load()` are NOT dicts — use attribute assignment (`.status =`), not dict brackets (`["status"] =`)
2. **Method names**: Don't assume `list_tasks()` — check actual names via `dir(base)`
3. **Save signature**: `base.save(task)` not `base.save(task_id, task)`
4. **Path-based file cleanup**: Use `Path(storage_dir).glob(f"*{task_id}*")` to match JSON files by embedded ID
5. **Always test**: Run a test client against each new API before declaring it done
