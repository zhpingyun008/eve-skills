# Flask Health Check + SMTP Retry System

Pattern for adding production-grade reliability to Flask SaaS tools.

## Health Check Module (`src/health.py`)

6-dimension health check endpoint:

| Dimension | What it checks | Output |
|-----------|---------------|--------|
| **Service** | Flask process alive, systemd status | active/inactive |
| **Database** | SQLite/PostgreSQL connectivity, table counts | ok/error + counts |
| **SMTP** | Provider reachability + password configured | per-provider status |
| **Disk** | Free space, total space | GB values |
| **Files** | Data file count, directory health | counts |
| **API** | Key endpoints return 200 | latency |

### Implementation Pattern

```python
@app.route("/api/health")
def health_check():
    return jsonify({
        "service": {"active": True, "service": "eve-bidding-tool"},
        "database": {
            "status": "ok",
            "table_counts": {"followups": N, "templates": N}
        },
        "smtp": {
            "status": "ok",
            "providers": {
                "smtp.qq.com": {"reachable": True, "has_password": True},
                "smtp.163.com": {"reachable": True, "has_password": True}
            }
        },
        "disk": {"status": "ok", "total_gb": N, "free_gb": N},
        "files": {"bids_count": N}
    })
```

### Best Practices
- Return structured JSON, not just "ok" — consumer can render detailed UI
- Database check should do a live `SELECT 1` query, not just file-exists
- SMTP check should attempt a TCP socket connect (not send email), and verify password env var is set
- Return within 500ms — health check is called frequently

## SMTP Send Retry Pattern

### Dual-Provider with Per-Provider Retry

```yaml
QQ SMTP:  host=smtp.qq.com:465  max_retries=3  rate_limit=8/2h
163 SMTP: host=smtp.163.com:465  max_retries=2  rate_limit=30/2h
```

### Retry Logic

```
for each SMTP provider (ordered by preference):
    skip if no password configured
    for attempt in range(max_retries):
        try:
            connect → login → send → quit
            return True
        except Exception:
            log error
            sleep 2s before retry
    ...try next provider
return False
```

### Rate Limit Handling
- Track sent count per window (2h sliding window)
- Switch provider when approaching limit
- Log rate limit hits for capacity planning

### Failure Log
```python
FAILURE_LOG = []
# Each failure records: timestamp, provider, email, error[:60]
# Display in system panel for diagnosis
```
