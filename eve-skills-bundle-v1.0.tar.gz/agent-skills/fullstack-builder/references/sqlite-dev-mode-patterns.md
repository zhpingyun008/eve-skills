# SQLite Dev Mode Patterns for FastAPI + SQLAlchemy

## When to Use

- Solo developer / OPC building MVP without installing PostgreSQL
- Quick demo / PoC that needs working CRUD in minutes
- Projects where `docker-compose up` overhead is too heavy for iteration
- Transition plan: SQLite for dev, PostgreSQL for production (switch via config)

## Config Pattern

In `config.py` (pydantic-settings based):

```python
class Settings(BaseSettings):
    database_url: str = "sqlite+aiosqlite:///./eve_dev.db"   # dev default
    database_url_sync: str = "sqlite:///./eve_dev.db"
    use_sqlite: bool = True   # toggles production features
    debug: bool = True        # SQLAlchemy echo=True
```

## Database Engine Setup

`database.py` — must handle both SQLite and PostgreSQL engines:

```python
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession

_engines = {}

def get_engine(database_url: str = None):
    from app.core.config import settings
    url = database_url or settings.database_url
    if url not in _engines:
        # Ensure SQLite directory exists
        if url.startswith("sqlite"):
            db_path = url.replace("sqlite+aiosqlite:///", "").replace("sqlite:///", "")
            db_dir = os.path.dirname(db_path)
            if db_dir and not os.path.exists(db_dir):
                os.makedirs(db_dir, exist_ok=True)
        engine = create_async_engine(url, echo=settings.debug, future=True)
        _engines[url] = engine
    return _engines[url]

async def get_session():
    engine = get_engine()
    async with AsyncSession(engine, expire_on_commit=False) as session:
        yield session
```

## Critical SQLite Compatibility Fixes

### 1. `metadata` column name is reserved

SQLAlchemy's DeclarativeBase reserves `metadata` as a class attribute. **Do NOT name any column `metadata`**.

```python
# ❌ WRONG — raises: "Attribute name 'metadata' is reserved"
class Conversation(Base):
    metadata = Column(JSON, default=dict)

# ✅ CORRECT — use trailing underscore
class Conversation(Base):
    metadata_ = Column(JSON, default=dict)
```

Search your models for any `metadata = Column(...)` and rename to `metadata_ = Column(...)`.

### 2. Explicit `__tablename__` required

SQLAlchemy's auto-generated table names (from CamelCase to snake_case via `__tablename__` descriptor) can produce unexpected singular names (e.g., `Chatbot` → `chatbot`), while ForeignKey references use plural (`chatbots.id`). **Always set explicit `__tablename__`**:

```python
class Chatbot(Base):
    __tablename__ = "chatbots"    # explicit, not auto-generated
    id = Column(Integer, primary_key=True)
    conversations = relationship("Conversation", back_populates="chatbot")

class Conversation(Base):
    __tablename__ = "conversations"
    chatbot_id = Column(Integer, ForeignKey("chatbots.id"), nullable=False)
```

Auto-generated table name mapping (for reference — do NOT rely on):
| Class | Auto name | Recommended explicit |
|-------|-----------|---------------------|
| Tenant | tenant | tenants |
| User | user | users |
| Chatbot | chatbot | chatbots |
| Conversation | conversation | conversations |
| Message | message | messages |
| Ticket | ticket | tickets |
| KnowledgeBase | knowledge_base | knowledge_bases |
| Document | document | documents |
| Chunk | chunk | chunks |
| QARecord | qa_record | qa_records |
| OrderPlatform | order_platform | order_platforms |
| Order | order | orders |

### 3. flush+refresh for auto-increment IDs

SQLite's aiosqlite driver may not populate auto-increment IDs after a simple `flush()`. **Always flush THEN refresh before using the ID**:

```python
db.add(conv)
await db.flush()
await db.refresh(conv)           # ← REQUIRED for SQLite
msg = Message(conversation_id=conv.id, ...)  # now conv.id is guaranteed populated
db.add(msg)
await db.commit()
```

Without `refresh()`, `conv.id` is `None`, causing `NOT NULL constraint failed` on the foreign key column.

### 4. `JSON` column type becomes TEXT

SQLite has no native JSON column — SQLAlchemy stores it as TEXT internally. This works transparently for `Column(JSON, default=dict)` and `Column(JSON, default=list)`. No code changes needed.

### 5. No `schema` support

SQLite does not support PostgreSQL schemas. Remove any `schema="public"` or `schema="tenant_xxx"` references from model definitions when using SQLite.

## Switching to PostgreSQL

When ready for production, flip config:

```python
# config.py — production settings
database_url = "postgresql+asyncpg://user:pass@host:5432/dbname"
database_url_sync = "postgresql+psycopg2://user:pass@host:5432/dbname"
use_sqlite = False
```

No code changes needed if you followed the patterns above. Test before deploy:

```bash
# Verify tables created correctly
curl -s http://localhost:8000/api/v1/health
# Expected: {"status":"ok","version":"0.1.0","service":"..."}
```

## Pitfalls

- **Don't use SQLite for production** — no concurrent writes, no schema migrations without downtime
- **Don't use `--reload` with SQLite in async mode** — race conditions on DB file access
- **Don't mix `sync` and `async` engines on the same SQLite file** — use separate DB files for dev/test
- **Don't forget `aiosqlite` in requirements.txt** — `pip install aiosqlite` if using async SQLAlchemy
- **Don't name a column `metadata`** it's a reserved attribute on DeclarativeBase
