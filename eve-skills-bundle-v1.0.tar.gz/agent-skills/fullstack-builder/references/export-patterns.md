# 导出模式 (Export Patterns)

## CSV 导出

### 后端模式

```python
import csv, io
from fastapi.responses import Response

@router.get("/resource/{id}/export/csv")
def export_csv(id: int, db: Session = Depends(get_db)):
    data = db.query(...).all()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["列1", "列2", "列3"])  # header
    for row in data:
        writer.writerow([row.field1, row.field2, row.field3])
    output.seek(0)
    return Response(
        content=output.getvalue(),
        media_type="text/csv; charset=utf-8-sig",  # BOM for Chinese Excel
        headers={"Content-Disposition": f"attachment; filename=export_{id}.csv"},
    )
```

### 关键点
- `charset=utf-8-sig` — BOM头，确保Excel正确识别UTF-8中文
- `Content-Disposition: attachment` — 强制下载而非浏览器打开
- `io.StringIO` — 内存中构建CSV，避免写磁盘

### 前端触发

```js
function downloadCsv() {
  const a = document.createElement('a')
  a.href = `/api/resource/${id}/export/csv`
  a.download = `导出_${id}.csv`
  a.click()
}
```

---

## ZIP 批量导出

### 后端模式

```python
import io, zipfile
from fastapi.responses import Response

@router.get("/reports/export/zip")
def export_zip(db: Session = Depends(get_db)):
    batches = db.query(...).all()
    zip_buffer = io.BytesIO()
    with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zf:
        for batch in batches:
            pdf_bytes = generate_pdf(batch)
            # 文件名消毒：只保留字母数字._-
            filename = "".join(c if c.isalnum() or c in "._- " else "_" for c in f"report_{batch.name}.pdf")
            zf.writestr(filename, pdf_bytes)
    zip_buffer.seek(0)
    return Response(
        content=zip_buffer.getvalue(),
        media_type="application/zip",
        headers={"Content-Disposition": f"attachment; filename=全部报告_{datetime.now():%Y%m%d}.zip"},
    )
```

### 关键点
- `zipfile.ZIP_DEFLATED` — 启用压缩（需zlib）
- `io.BytesIO` — 内存打包
- 文件名消毒 — 避免非法文件名字符导致ZIP损坏
- 单个文件失败用 `try/except continue` 跳过，不中断整个ZIP

### 前端触发

```js
async function downloadZip() {
  const res = await fetch('/api/reports/export/zip')
  if (!res.ok) throw new Error((await res.json()).detail)
  const blob = await res.blob()
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url; a.download = `export.zip`; a.click()
  URL.revokeObjectURL(url)
}
```

---

## PDF 单文件导出 (weasyprint)

### 安装
```bash
pip install weasyprint
```

### 后端模式

```python
import weasyprint
from fastapi.responses import Response

styled_html = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8">
<style>
body {{ font-family: 'Noto Sans SC', 'Microsoft YaHei', sans-serif; font-size: 11pt; }}
table {{ border-collapse: collapse; width: 100%; }}
th, td {{ border: 1px solid #ccc; padding: 5px 8px; }}
th {{ background: #f0f0f0; }}
</style></head><body>
{html_content}
</body></html>"""

pdf_bytes = weasyprint.HTML(string=styled_html).write_pdf()
return Response(
    content=pdf_bytes,
    media_type="application/pdf",
    headers={"Content-Disposition": f"attachment; filename=报告_{id}.pdf"},
)
```

### 关键点
- HTML内容必须包含完整的 `<html>` + `<style>` 结构
- 中文字体需指定 `Noto Sans SC` 或 `Microsoft YaHei`
- `weasyprint.HTML(string=...).write_pdf()` 比文件路径版本更稳定
- 大批量生成时注意内存，考虑逐条生成后写入ZIP
