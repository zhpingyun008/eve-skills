# 跨语言校验清单 (Python→JS→HTML全栈)

## JS语法校验 (HTML内嵌Script)

修改HTML后必须校验所有 `<script>` 块的JS语法：

```bash
node -e "
const fs=require('fs');
const s=fs.readFileSync('index.html','utf-8');
const m=s.match(/<script>([\s\S]*?)<\/script>/g);
const allJs=m.map(x=>x.replace(/<\/?script>/g,'')).join('\n');
fs.writeFileSync('/tmp/check.js', allJs);
" && node --check /tmp/check.js
```

## Python编译校验
```bash
python3 -c "import py_compile; py_compile.compile('web/app.py', doraise=True)"
```

## HTTP 200 Smoke Test
```bash
curl -s -o /dev/null -w '%{http_code}' http://localhost:5900/
```

## 三层全通过才算一次完整迭代
修改 → Python compile → JS syntax → HTTP smoke → (通过则完成)
