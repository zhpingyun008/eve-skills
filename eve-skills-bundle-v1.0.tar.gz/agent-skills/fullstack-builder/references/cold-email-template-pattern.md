# Cold Email Template Pattern

Manage email templates in SQLite with CRUD from Web UI, and send via loaded SMTP credentials.

## SQLite Schema
```sql
CREATE TABLE email_templates(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT, subject TEXT, body TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);
```

## API Endpoints
- `GET /api/email/templates` — list all
- `POST /api/email/templates/create` — create {name, subject, body}
- `PUT /api/email/templates/<id>` — update
- `DELETE /api/email/templates/<id>` — delete

## Web UI Integration
- Templates list: clickable items that open editor
- Send form: email + subject + body + template selector
- On template select: populate subject and body fields
- Send button: POST to /api/email/send-cold + status feedback

## Key Detail
Load SMTP credentials from `~/.hermes/.eve_env` at send time, not at app startup. This avoids exposing passwords in the process environment permanently.

## UnboundLocalError Fix
When using variables assigned inside `if os.path.exists(env_file):` block, initialize them before the `if`:
```python
qq_user = qq_pass = n163_user = n163_pass = ""
if os.path.exists(env_file):
    with open(env_file) as f:
        for line in f:
            if "QQ_MAIL_SENDER" in line: qq_user = parse(line)
```
Without this, Python raises `UnboundLocalError: cannot access local variable 'qq_user' where it is not associated with a value`.

## Send API Pattern
```python
@app.route("/api/email/send-cold", methods=["POST"])
def api_send_cold_email():
    data = request.get_json(force=True)
    email, subject, body = data.get(k,"") for k in ["email","subject","body"]
    if not all([email, subject, body]): return jsonify({"error":"缺少参数"}),400
    
    # Load creds from ~/.hermes/.eve_env
    # Try providers in order: QQ SMTP_SSL(465), then 163 SMTP_SSL(465)
    # Return first success {"success":True,"via":"smtp.qq.com"}
    # On all failures: return jsonify({"error":last_error}),500
```
