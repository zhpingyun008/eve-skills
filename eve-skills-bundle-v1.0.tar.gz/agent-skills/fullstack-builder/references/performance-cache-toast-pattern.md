# Vanilla JS Performance + UX Pattern (v2.15+)

Pattern for adding frontend caching, loading overlay, and enhanced toast to any Vanilla JS admin dashboard after 10+ feature iterations.

## Caching Layer

```javascript
const _cache = {};
const CACHE_TTL = 30000; // 30 seconds

async function cachedApi(url, forceRefresh=false) {
    const now = Date.now();
    if (!forceRefresh && _cache[url] && (now - _cache[url].time < CACHE_TTL))
        return _cache[url].data;
    const data = await api(url);
    _cache[url] = {data, time: now};
    return data;
}

function clearCache(...keys) {
    if (keys.length === 0) Object.keys(_cache).forEach(k => delete _cache[k]);
    else keys.forEach(k => delete _cache[k]);
}
```

Usage: replace `await api('/api/stats')` with `await cachedApi('/api/stats')`. Call `clearCache()` after mutations (send/generate/delete).

## Loading Overlay

HTML (insert before toast):
```html
<div id="loading-overlay"><div class="loading-spinner"></div></div>
```

CSS:
```css
#loading-overlay {
    display:none; position:fixed; top:0; left:0; width:100%; height:100%;
    background:rgba(0,0,0,.5); z-index:9999; justify-content:center; align-items:center;
}
#loading-overlay.show { display:flex; }
.loading-spinner {
    width:48px; height:48px; border:4px solid #fff; border-top-color:transparent;
    border-radius:50%; animation:spin .8s linear infinite;
}
@keyframes spin { to { transform:rotate(360deg); } }
```

JS:
```javascript
function showGlobalLoading() { document.getElementById('loading-overlay').classList.add('show'); }
function hideGlobalLoading() { document.getElementById('loading-overlay').classList.remove('show'); }

async function withLoading(fn) {
    showGlobalLoading();
    try { return await fn(); }
    finally { hideGlobalLoading(); }
}
```

## Enhanced Toast

```javascript
function toast(msg, type) {
    const t = document.getElementById('toast');
    t.textContent = msg;
    t.className = 'toast ' + (type || 'info');
    t.style.display = 'block';
    t.style.opacity = '1';
    clearTimeout(t._hide);
    t._hide = setTimeout(() => {
        t.style.opacity = '0';
        setTimeout(() => t.style.display = 'none', 300);
    }, type === 'error' ? 4000 : 2500);
}
```

Differences from basic toast:
- `opacity` transition for smooth fade-out (300ms)
- `className` swap instead of inline style (for different toast types via CSS)
- Error messages stay 4s vs success 2.5s
- Clear previous timer on new toast
- 300ms delay before `display:none` to let opacity transition complete

## switchTab Loading

```javascript
function switchTab(name) {
    // ... existing tab switch logic ...
    showGlobalLoading();
    setTimeout(() => {
        if (name === 'dashboard') loadPipeline();
        if (name === 'replies') loadReplies();
        // ... other tabs ...
        setTimeout(hideGlobalLoading, 500);
    }, 50);
}
```

The 50ms timeout ensures DOM has repainted before data load starts.
The 500ms delay gives rendered content time to appear before hiding spinner.
