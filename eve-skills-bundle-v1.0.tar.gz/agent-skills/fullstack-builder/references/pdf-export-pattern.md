# FastAPI + Vue PDF导出模式

## 场景

在全栈项目中为报告/凭证/对账单等数据内容添加PDF导出功能。后端生成PDF，前端触发下载。

---

## 架构

```
前端(Vue) fetch(GET /api/.../report/pdf)
  → 后端(FastAPI) 查询数据
  → 组装带样式的HTML
  → weasyprint.HTML(string=html).write_pdf()
  → FastAPI Response(content=pdf_bytes, media_type="application/pdf")
  → 前端收到blob → URL.createObjectURL → a.click() 触发下载
```

## 后端实现

### 1. 安装依赖

```bash
pip install weasyprint
```

### 2. FastAPI端点

```python
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import Response
from sqlalchemy.orm import Session
from datetime import datetime
import weasyprint

@router.get("/batches/{batch_id}/report/pdf")
def export_pdf(batch_id: int, db: Session = Depends(get_db)):
    """导出PDF报告"""
    # 1. 获取数据
    record = db.query(ReportModel).filter(...).first()
    if not record or not record.html_content:
        raise HTTPException(status_code=404, detail="报告未生成")

    # 2. 组装带样式的HTML（关键：PDF样式需独立定义，不能依赖前端CSS）
    styled_html = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8">
<style>
body {{
    font-family: 'Noto Sans SC', 'Microsoft YaHei', sans-serif;
    font-size: 11pt; line-height: 1.7; color: #333; padding: 20px;
}}
table {{ width: 100%; border-collapse: collapse; margin: 10px 0; }}
th, td {{ border: 1px solid #ccc; padding: 5px 8px; text-align: left; }}
th {{ background: #f0f0f0; }}
h1 {{ font-size: 18pt; }}
h2 {{ font-size: 14pt; }}
.footer {{ margin-top: 30px; border-top: 1px solid #ddd; font-size: 9pt; color: #999; }}
</style></head><body>
{record.html_content}
<div class="footer">系统自动生成 — {datetime.now().strftime('%Y-%m-%d %H:%M')}</div>
</body></html>"""

    # 3. 转换PDF
    pdf_bytes = weasyprint.HTML(string=styled_html).write_pdf()

    # 4. 返回PDF
    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={"Content-Disposition": f"attachment; filename=报告_{batch_id}.pdf"},
    )
```

### 3. 注意事项

- **f-string大括号转义**: 在f-string中CSS的`{}`需要写成`{{}}`，否则SyntaxError
- **weasyprint import**: 放在函数内部延迟导入可避免启动时找不到模块
- **样式独立**: PDF样式必须内联或在HTML内定义，不能依赖外部CSS文件
- **中文字体**: 确保系统安装了中文字体（如Noto Sans SC）

### 4. 验证命令

```bash
curl -s -o /tmp/test.pdf -w '%{http_code} %{size_download}bytes' \
  http://localhost:8001/api/batches/{id}/report/pdf
file /tmp/test.pdf  # 应该显示 "PDF document"
```

---

## 前端实现

### 1. API函数（api/index.js）

```javascript
/**
 * 获取PDF下载URL
 * @param {number|string} id
 * @returns {string}
 */
export function getReportPdfUrl(id) {
  return `/api/batches/${id}/report/pdf`
}
```

### 2. Vue组件触发下载

```javascript
import { getReportPdfUrl } from '../api/index.js'

async function downloadPdf(batchId) {
  const pdfUrl = getReportPdfUrl(batchId)
  const response = await fetch(pdfUrl)
  if (!response.ok) {
    const err = await response.json().catch(() => ({}))
    throw new Error(err.detail || 'PDF生成失败')
  }
  const blob = await response.blob()
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `报告_${batchId}_${new Date().toISOString().slice(0, 10)}.pdf`
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  URL.revokeObjectURL(url)
}
```

### 3. 按钮模板（Element Plus）

```html
<el-button size="small" @click="downloadPdf" :loading="pdfLoading" :disabled="!id">
  <el-icon><Download /></el-icon> PDF导出
</el-button>
```

---

## 陷阱

- **weasyprint系统依赖**: Linux上需要libpango和libcairo。如缺失报`OSError: cannot load library 'libpango'`，需安装：
  ```bash
  sudo apt install libpango-1.0-0 libpangocairo-1.0-0 libgdk-pixbuf2.0-0
  ```
- **Vite代理路径**: 前端通过Vite dev server请求时，URL需以`/api/`开头（对应proxy配置），不能用完整`http://localhost:8001/api/...`
- **blob命名编码**: 下载文件名含中文需要用ISO编码，直接blob.download设置即可
- **PDF大小控制**: 大量表格/图片时PDF可能较大，可考虑分页

---

## 替代方案对比

| 方案 | 优点 | 缺点 | 适用场景 |
|------|------|------|---------|
| **weasyprint（推荐）** | 纯Python, CSS支持好, 质量高 | 首次安装稍慢 | 标准报告PDF |
| fpdf2 | 零系统依赖 | 需要手写布局 | 简单表格/票证 |
| pdfkit | 简单直接 | 依赖wkhtmltopdf系统包 | 复杂HTML转PDF |
| 前端html2canvas+jsPDF | 无后端开销 | 质量不如后端生成 | 简单截图导出 |
