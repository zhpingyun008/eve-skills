# JS模板字面量转义深度 — Python→JS跨语言陷阱

## 问题描述

当通过Python（`execute_code`/`write_file`/`patch`/终端heredoc）生成包含JS模板字面量（backtick字符串）的HTML文件时，转义深度极易出错。

## 转义链

```
Python源文件 → Python字符串解析 → 写入文件 → Node.js解析
```

每一层都会消费一层转义。

## 核心规则

### 1. 模板字面量内 `\n` 是新行字符

```js
// 模板字面量内 \n = 实际换行符
let msg = `第一行\n第二行`;  
// 等价于:
let msg = `第一行
第二行`;
```

- JS模板字面量中 `\n` **不是** 字面量反斜杠+n，而是换行符
- 如果需要字面量输出 `\n` 字符串，需写 `\\n`

### 2. 模板字面量内引号无需转义

```js
// 模板字面量内 " 和 ' 都是合法字符，无需反斜杠
let html = `<div class="modal"><p>内容</p></div>`;  // ✅ 正确
let html = `<div class=\"modal\"><p>内容</p></div>`; // ❌ 反斜杠多余但不报错
```

### 3. `\u{XXXXX}` Unicode转义仅限模板字面量

```js
// ✅ 模板字面量中有效
let emoji = `\u{1F3F7}`;  // 🏷

// ❌ new Function() 中无效
new Function('return `\u{1F3F7}`');  // SyntaxError: Invalid or unexpected token

// ✅ 推荐：直接使用实际Unicode字符
let emoji = '🏷';
```

### 4. Python `execute_code` 中的转义深度

| Python源 | → 写入文件 | → JS解析结果 |
|----------|-----------|-------------|
| `\\n` | `\n` | JS模板字面量内: 换行符 |
| `\\\\n` | `\\n` | JS普通字符串内: 字面量 `\n` |
| `\\\\\\"` | `\\"` | JS模板字面量内: 多余反斜杠+引号(不建议) |

### 5. `new Function()` 与模板字面量的兼容性

`new Function(jsCode)` 在Node.js中解析代码时，`\u{XXXXX}` 风格的Unicode转义**只在模板字面量和正则中出现有效**。如果代码通过 `new Function()` 执行，且包含模板字面量外的 `\u{XXXXX}`，会报 `SyntaxError`。

**最佳实践**：在JS代码中使用实际Unicode字符而非转义序列。

## 验证方法

```bash
# 提取HTML中所有<script>块并校验JS语法
node -e "
const fs=require('fs');
const s=fs.readFileSync('index.html','utf-8');
const m=s.match(/<script>([\\s\\S]*?)<\\/script>/g);
const allJs=m.map(x=>x.replace(/<\\/?script>/g,'')).join('\\n');
fs.writeFileSync('/tmp/check.js', allJs);
"
node --check /tmp/check.js
```

## 常见错误模式

### 错误: `\\n` 在模板字面量中产生字面量 `\n`

```js
// 本想输出换行，实际得到字面量字符串 "\n"
let msg = `第一行\\n第二行`;  
// 显示: "第一行\n第二行"
```

### 错误: 在Python heredoc中忘记对Shell转义

```python
# bash heredoc中的 $ 和 ` 需要转义
cat << 'HEREDOC'  # 单引号HEREDOC阻止变量展开
${variable}  # 保持字面量
`backtick`   # 保持字面量
HEREDOC
```

### 错误: `\\\\n` 在Python f-string中变成 `\\n`

```python
# Python f-string中不能有反斜杠!
# ❌ 错误
f"let msg = `行1\\\\n行2`;"
# ✅ 正确: 使用变量
nl = "\\n"
f"let msg = `行1{nl}行2`;"
```
