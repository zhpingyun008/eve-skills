# Paywall + Usage Tier Pattern (付费墙+用量分层模式)

> 通用模式：FastAPI产品在5分钟内接入三级定价+用量追踪+402付费墙

## 架构

```
用户请求 → 速率限制(10req/min) → 用量检查(SQLite) → 付费墙(402) → 功能逻辑
                         ↓
                ┌─── 免费: 基础功能, 3次/月
                ├─── Pro:   无限量+AI功能, ¥19-49/月
                └─── Enterprise: API接入+私有部署, ¥99-199/月
```

## SQLite用量追踪

```python
import sqlite3, time
from functools import wraps

def init_usage_db():
    conn = sqlite3.connect("data/usage.db")
    conn.execute("""
        CREATE TABLE IF NOT EXISTS usage (
            client_ip TEXT,
            endpoint TEXT,
            timestamp INTEGER,
            month TEXT,
            PRIMARY KEY (client_ip, endpoint, month)
        )
    """)
    conn.commit()
    conn.close()

def check_usage(client_ip: str, endpoint: str, tier: str = "free"):
    """Return (allowed: bool, monthly_count: int, limit: int)"""
    month = time.strftime("%Y-%m")
    conn = sqlite3.connect("data/usage.db")
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM usage WHERE client_ip=? AND month=? AND endpoint=?",
                (client_ip, month, endpoint))
    count = cur.fetchone()[0]
    
    LIMITS = {"free": 3, "pro": 1000, "enterprise": 999999}
    limit = LIMITS.get(tier, 3)
    allowed = count < limit
    
    # Track usage
    if allowed:
        cur.execute("INSERT INTO usage (client_ip, endpoint, timestamp, month) VALUES (?,?,?,?)",
                    (client_ip, endpoint, int(time.time()), month))
    conn.commit()
    conn.close()
    return allowed, count, limit
```

## 402付费墙装饰器

```python
from fastapi import HTTPException, Request
from functools import wraps

def paywall(endpoint_name: str, tier: str = "free"):
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            # Extract client IP
            request = next((a for a in args if isinstance(a, Request)), None)
            client_ip = request.client.host if request else "unknown"
            
            allowed, count, limit = check_usage(client_ip, endpoint_name, tier)
            if not allowed:
                raise HTTPException(
                    status_code=402,
                    detail=f"需要Pro订阅 (免费仅{limit}次/月)"
                )
            return await func(*args, **kwargs)
        return wrapper
    return decorator

# 使用
@app.post("/api/rewrite")
@paywall("rewrite", tier="free")
async def rewrite_text(request: Request, data: RewriteRequest):
    # ... 只有付费用户才能访问
    pass
```

## 定价API

```python
PRICING_TIERS = {
    "免费版": {
        "price": 0, "currency": "CNY",
        "features": ["基础功能", "每日3次", "Simhash+编辑距离"],
        "limits": {"detect": 100, "dedup": 3, "rewrite": 0, "batch": 0}
    },
    "Pro": {
        "price": 1900, "currency": "CNY", "interval": "month",
        "features": ["无限量", "AI精修", "批量处理", "优先支持"],
        "limits": {"detect": 99999, "dedup": 99999, "rewrite": 99999, "batch": 99999}
    },
    "Enterprise": {
        "price": 9900, "currency": "CNY", "interval": "month",
        "features": ["全部Pro", "API接入", "私有部署", "SLA保障"],
        "limits": None  # 无限
    }
}

@app.get("/api/pricing")
async def get_pricing():
    return {"tiers": [{"name": k, **v} for k, v in PRICING_TIERS.items()]}
```

## 用量查询API

```python
@app.get("/api/usage")
async def get_usage(request: Request):
    client_ip = request.client.host
    month = time.strftime("%Y-%m")
    conn = sqlite3.connect("data/usage.db")
    cur = conn.cursor()
    cur.execute("SELECT endpoint, COUNT(*) FROM usage WHERE client_ip=? AND month=? GROUP BY endpoint",
                (client_ip, month))
    usage = dict(cur.fetchall())
    conn.close()
    return {
        "month": month,
        "usage": usage,
        "limits": {k: v["limits"] for k, v in PRICING_TIERS["免费版"].items()},
        "remaining": {k: PRICING_TIERS["免费版"]["limits"].get(k, 0) - usage.get(k, 0) for k in PRICING_TIERS["免费版"]["limits"]}
    }
```

## 速率限制

```python
from collections import defaultdict
import time

rate_limits = defaultdict(list)  # client_ip -> [timestamps]

@app.middleware("http")
async def rate_limit_middleware(request: Request, call_next):
    if request.url.path.startswith("/api/"):
        client_ip = request.client.host
        now = time.time()
        # 清理10秒前的记录
        rate_limits[client_ip] = [t for t in rate_limits[client_ip] if now - t < 10]
        if len(rate_limits[client_ip]) >= 10:
            return JSONResponse(status_code=429, content={"detail": "请求过于频繁, 请稍后再试"})
        rate_limits[client_ip].append(now)
    return await call_next(request)
```

## Cloudflare Tunnel公网部署

```bash
# 安装
sudo wget -q https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 -O /usr/local/bin/cloudflared && sudo chmod +x /usr/local/bin/cloudflared

# 启动隧道 (后台)
cloudflared tunnel --url http://localhost:PORT > /tmp/cloudflared_NAME.log 2>&1 &

# 查看URL (几秒后)
grep -E "trycloudflare\\.com|Your quick" /tmp/cloudflared_NAME.log

# 验证
curl -s https://RANDOM-NAME.trycloudflare.com/health
```

## 完整产品模板

```bash
# 项目结构
product/
├── api/server.py      # FastAPI: 端点+付费墙+用量+速率限制
├── engine/engine.py   # 核心算法
├── models/schemas.py  # Pydantic模型
├── static/index.html  # Web UI
├── static/pricing.html # 定价页
└── data/usage.db      # 自动创建

# 启动
kill $(lsof -ti:PORT) 2>/dev/null
cd ~/product && source ~/.hermes/.env && nohup python -m uvicorn api.server:app --host 0.0.0.0 --port PORT &

# 公网
cloudflared tunnel --url http://localhost:PORT > /tmp/cf.log 2>&1 &
```

## 定价模板 (适用于所有产品)

| 产品 | 免费 | Pro | Enterprise |
|------|------|-----|------------|
| 去重工具 | 3次/月 | ¥19/月 无限 | ¥99/月 API接入 |
| 跨境电商Listing | 3条/月 | ¥49/月 50条 | ¥199/月 无限 |
| 智账AI | 3次 | ¥29/月 | ¥99/月 |
| freelancer | 3次 | ¥29/月 | — |

## 验证脚本

```bash
# 全链路验证
PUBLIC="https://RANDOM-NAME.trycloudflare.com"

# 1. 健康检查
curl -s $PUBLIC/health

# 2. Web UI可访问
curl -s -o /dev/null -w "%{http_code}" $PUBLIC/

# 3. 免费功能正常
curl -s -X POST $PUBLIC/api/detect -H 'Content-Type: application/json' \
  -d '{"text1":"今天天气真好","text2":"今天天气真不错"}'

# 4. 付费墙生效 (返回402)
curl -s -o /dev/null -w "%{http_code}" -X POST $PUBLIC/api/pro-feature \
  -H 'Content-Type: application/json' -d '{"text":"test"}'

# 5. 定价页
curl -s $PUBLIC/api/pricing

# 6. 用量追踪
curl -s $PUBLIC/api/usage
```
