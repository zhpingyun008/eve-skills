# AI Extract-Then-Generate SaaS Pattern

## Archetype

A common SaaS product pattern: take unstructured input (URL/text), extract structured data via LLM/rule-based parsing, then generate a formatted output document.

```
Input (URL/Text) → [Extractor] → Structured JSON → [Generator] → Output Document
                       ↕                            ↕
                 LLM + Rule Fallback          LLM + Template Fallback
```

## When to use

- Bid announcement → bid response document
- Job posting → tailored cover letter
- Product specification → quote proposal
- Meeting transcript → meeting minutes
- Legal document → summary + risk assessment

## Architecture

### CLI + Web dual mode

Build with two entry points from day one — CLI for automation (cron/batch), web for interactive use:

```
project/
├── main.py           # CLI entry (argparse)
├── app.py            # Flask web server
├── src/
│   ├── extractor.py  # Input → Structured JSON
│   └── generator.py  # JSON → Output Document
├── scripts/
│   ├── batch_process.py  # Batch mode for cron
│   └── search_new.py     # Auto-discover new inputs
├── static/
│   └── index.html    # Single-page UI
├── data/             # Generated outputs
└── requirements.txt
```

### Extractor patterns

Two-tier approach — try LLM first, fall back to rule-based:

```python
def extract(text):
    if DEEPSEEK_KEY:
        try:
            return llm_extract(text)  # structured JSON via API
        except:
            pass
    return rule_based_extract(text)   # regex + keyword matching
```

**Rule-based fallback fields** (for when API is unavailable):
- Buyer: regex for "采购人"/"招标人"/"项目业主"
- Budget: regex for "预算金额"/"资金" + amount
- Deadline: regex for "截止日期"/"开标日期"
- Contact/Phone: regex patterns
- Requirements: keyword matching (AI/人工智能/大数据/etc.)

---

## Phase 2: Generator Evolution — From Template to LLM

### v1: Static Template

Simple f-string template with keyword-based logic branching:

```python
TEMPLATE = """# {title} ..."""
def generate(info):
    has_ai = any(kw in str(info) for kw in ["ai", "人工智能", "智能"])
    if has_ai:
        return TEMPLATE.format(tech_arch="AI方案", ...)
    else:
        return TEMPLATE.format(tech_arch="传统方案", ...)
```

**Limitations**: Generic, no customization per client, ~1200 chars typical length.

### v2: LLM-Powered Generation with Template Fallback

Use DeepSeek API to generate high-quality, customized content. Fall back to template on failure.

#### Architecture

```python
def generate(info, use_llm=True):
    if use_llm:
        result = generate_llm(info)
        if result and len(result) > 500:  # Quality gate
            return result
        # Fall through to template
    return template_fallback(info)
```

**Quality gate**: LLM output must exceed 500 chars to be accepted. Short outputs (API errors, refusals) fall through silently.

#### LLM System Prompt Design

The system prompt is critical for output quality. Structure it with:

```
1. Role definition (你是谁)
2. Task description (你要做什么)
3. Quality requirements (内容定制化/专业严谨/格式规整)
4. Output outline (输出结构模板)
5. Constraint (只输出内容，不要额外说明)
```

Example system prompt:

```python
BID_SYSTEM_PROMPT = """你是一位专业的投标方案撰写专家...

要求：
1. **内容定制化**：根据具体的采购需求、预算、行业特点编写
2. **专业严谨**：技术方案要具体、可实施
3. **突出优势**：自然融入公司独特优势
4. **格式规整**：使用Markdown标题层级、表格、列表

输出结构：
# 标题
## 一、公司简介
## 二、需求理解  (用表格逐条对应)
## 三、技术方案  (详细技术架构)
## 四、实施计划  (含里程碑时间表)
..."""
```

#### User Prompt Construction

Build a rich prompt from structured info:

```python
user_prompt = f"""请根据以下招标信息，生成一份完整的投标响应文件。

**项目名称**: {info.get('title', '未指定')}
**采购单位**: {info.get('buyer', '未指定')}
**预算金额**: {info.get('budget', '未公开')}
**关键技术需求**: {req_text or '详见招标文件'}

## 我方信息
- 公司名称：{COMPANY['name']}
- 定位：{COMPANY['slogan']}
- 资质：{COMPANY['certification']}
- 交付周期：{COMPANY['delivery_cycle']}
"""
```

#### LLM API Call

```python
def generate_llm(info):
    key = _get_deepseek_key()
    if not key:
        return ""
    
    import requests
    resp = requests.post(
        "https://api.deepseek.com/v1/chat/completions",
        headers={"Authorization": f"Bearer {key}"},
        json={
            "model": "deepseek-chat",
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": user_prompt}
            ],
            "temperature": 0.7,
            "max_tokens": 4000
        },
        timeout=60
    )
    data = resp.json()
    return data["choices"][0]["message"]["content"].strip()
```

**Timeout**: 60s (generation takes longer than extraction)

#### Results Comparison

| Metric | v1 Template | v2 LLM | Improvement |
|--------|------------|--------|-------------|
| Length | ~1,200 chars | ~4,800 chars | 4x |
| Customization | None | Per-client (buyer/industry/requirements) | ✓ |
| Requirements table | Missing | Present (逐条对应) | ✓ |
| Technical depth | Generic | Project-specific | ✓ |
| Fallback safety | N/A | Template fallback on API failure | ✓ |

---

## Phase 3: Batch Pipeline + Tracking

### Standard Flow

```
1. Load data (JSON/CSV/DB) with dedup by org name
2. Filter by criteria (tier, status, email presence)
3. Sort by priority (deadline, value)
4. For each item:
   a. Generate output (LLM → template fallback)
   b. Record in tracking JSON
   c. Optionally send (SMTP/API)
5. Report summary
```

### CLI Argument Design

```python
parser.add_argument("--tier", type=int, nargs="+", default=[1])
parser.add_argument("--send", action="store_true")  # Live mode
parser.add_argument("--force", action="store_true") # Regenerate existing
parser.add_argument("--max", type=int, default=0)    # Limit count
parser.add_argument("--lead-id", type=int, default=None)  # Single item
```

### Tracking Pattern

Maintain a JSON tracking file for pipeline progress. Dedup by primary key (e.g. lead_id):

```python
def load_tracking(path):
    if os.path.exists(path):
        with open(path) as f:
            return json.load(f)
    return {"bids": [], "total": 0, "sent": 0}

def save_tracking(tracking, path):
    tracking["updated_at"] = datetime.now().isoformat()
    tracking["total"] = len(tracking["bids"])
    tracking["sent"] = sum(1 for b in tracking["bids"] if b.get("sent"))
    with open(path, "w", encoding="utf-8") as f:
        json.dump(tracking, f, ensure_ascii=False, indent=2)
```

**Critical**: In test/dry-run mode, send function must return `False` not `True`:

```python
if test_mode:
    return False  # ← NOT True! Keeps tracking accurate
```

---

## DeepSeek API Key Multi-Source Discovery

The API key can exist in multiple locations. Search in priority order:

```python
def _get_deepseek_key():
    """Get DeepSeek API key from env, .env file, or config."""
    # 1. Process env (set by Hermes runtime)
    key = os.environ.get("DEEPSEEK_API_KEY", "")
    if key:
        return key
    
    # 2. Hermes .env file (persistent storage)
    env_file = os.path.expanduser("~/.hermes/.env")
    if os.path.exists(env_file):
        with open(env_file) as f:
            for line in f:
                line = line.strip()
                if line.startswith("DEEPSEEK_API_KEY="):
                    val = line.split("=", 1)[1].strip().strip("'\"")
                    if val:
                        return val
    
    # 3. Hermes config.yaml
    cfg = os.path.expanduser("~/.hermes/config.yaml")
    if os.path.exists(cfg):
        with open(cfg) as f:
            for line in f:
                if "api_key" in line and "deepseek" in line.lower():
                    m = re.search(r'api_key:\s*[\'"]?([^\'"\s]+)', line)
                    if m:
                        return m.group(1)
    return ""
```

**Why multi-source**: 
- Process env may not be available in cron/standalone Python processes
- Hermes .env file is a persistent location for secrets
- config.yaml is the fallback (Hermes internal format)

---

## Web UI Evolution

### v1: Basic Input/Output

Single page with:
- URL input + textarea
- Extract button / Generate button
- Result box (preformatted text)

### v2: Dashboard + Pipeline Visualization

Add:
- **Stats grid**: Total documents, sent status, pending count, reply count
- **Tabs**: Generator / Pipeline / Replies / Data Browser
- **LLM toggle**: Switch between AI-enhanced and template mode
- **Item actions**: Preview (modal), Download (file), Status indicators (sent/pending dots)
- **Progress bar**: Pipeline completion percentage
- **Filter bar**: Text search + tier/category filter for data browser

**Key UX patterns**:
- Preview modal (overlay with scrollable content + close)
- Status dots (green=sent, yellow=pending)  
- Responsive table wrapper (overflow-x:auto for wide tables)
- Toast notifications (3s auto-dismiss)

### API endpoints

```python
POST /api/extract           # {text: "..."} → JSON of extracted fields
POST /api/generate          # {..., use_llm: true} → document text
POST /api/run               # {text: "..."} → extract + generate
GET  /api/recent            # list of recently generated files (with sent status)
GET  /api/stats             # aggregated stats: total/sent/pending/replies
GET  /api/pipeline          # full tracking data
GET  /api/bid-content?path= # raw file content (for preview)
GET  /api/download?path=    # file download
GET  /api/leads             # source data browser
GET  /api/replies           # email reply tracking
```

---

## Deployment

```ini
# ~/.config/systemd/user/project.service — USER service (NOT system)
[Unit]
Description=Project Web Server
After=network.target

[Service]
Type=simple
ExecStart=/home/user/.venv/bin/python3 /home/user/project/app.py  # Use VENV python!
Restart=always
RestartSec=10

[Install]
WantedBy=default.target
```

**Critical**: Do NOT use `User=username` in user-mode services — it causes 216/GROUP error.

### Cron (no_agent mode)

Create wrapper in `~/.hermes/scripts/`:

```bash
#!/bin/bash
cd /home/user/project
source ~/.hermes/.eve_env 2>/dev/null
python3 scripts/batch_process.py --tier 1 --send
```

Register: `hermes cron create --name "Daily Pipeline" --schedule "0 9 * * *" --script "wrapper.sh" --no-agent`

---

## Pitfalls

1. **API key management**: Don't hardcode. Multi-source discovery (env → .env → config.yaml). LLM.js calls need timeout (60s).
2. **Test mode tracking**: `send_email()` must return `False` in test mode, not `True` — otherwise tracking JSON will show false "sent" counts.
3. **HTML-to-text**: Parsing pages from URLs needs HTML tag stripping. Use HTMLParser or trafilatura, not bs4.
4. **Template state**: Keep templates as module-level f-strings, not separate files — faster iteration.
5. **File naming**: Sanitize filenames from user input — remove special chars, limit to 50 chars.
6. **Port conflict**: Choose a port not used by other services (8850 is safe in Eve ecosystem).
7. **LLM quality gate**: Always check LLM output length > 500 chars before accepting — short outputs are errors.
8. **Stale .env source**: When reading `.hermes/.env` in a standalone process, remember the `export KEY='val'` format — strip quotes and `export` prefix.

## Evolution path

```
v1: CLI + Web MVP (extract → generate → export)
v2: DeepSeek API + template fallback for generation
v3: Batch mode + JSON tracking pipeline
v4: Dashboard UI + pipeline visualization + preview/download
v5: Multi-format export (PDF/DOCX via pandoc)
v6: User accounts + history + SaaS multi-tenant
```
