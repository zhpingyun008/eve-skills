# 后端API模式

## 1. 统计仪表盘 API

**用途：** 系统首页展示总批次、成功率、检查项分布、最近活动等关键指标。

**实现模式：**

```python
@router.get("/stats")
def get_stats(db: Session = Depends(get_db)):
    # 批次统计 — 注意状态枚举兼容
    total = db.query(CheckBatch).count()
    completed = db.query(CheckBatch).filter(
        CheckBatch.status.in_(["done", "completed"])
    ).count()
    failed = db.query(CheckBatch).filter(
        CheckBatch.status.in_(["failed", "error"])
    ).count()
    running = db.query(CheckBatch).filter(
        CheckBatch.status.in_(["running", "checking", "parsing"])
    ).count()

    # 材料/人员/检查项/问题统计
    total_materials = db.query(Material).count()
    pass_checks = db.query(CheckResult).filter(CheckResult.status == "pass").count()

    # 成功率计算
    finished = completed + failed
    success_rate = round(completed / finished * 100, 1) if finished > 0 else 0

    # 最近活动（limit 5）
    recent = db.query(CheckBatch).order_by(CheckBatch.created_at.desc()).limit(5).all()

    return {
        "batches": {"total": total, "completed": completed, "failed": failed, ...},
        "success_rate": success_rate,
        "recent_activity": [{"id": r.id, "batch_no": r.batch_no, ...} for r in recent],
    }
```

**关键点：**
- 状态筛选用 `in_(["done", "completed"])` 而非单值匹配
- `success_rate` 在无完成批次时返回 0 而非除以零
- 最近活动表同时用于前端"查看全部→历史记录"导航

**前端Dashboard核心布局：**

```
el-row → 4个metric卡片 (总批次/已完成/成功率/材料数)
el-row → 14col检查项进度条 + 10col问题分布
el-row → 24col最近活动表格
```

---

## 2. PDF导出（weasyprint HTML→PDF）

**用途：** 将后台生成的HTML报告转换为可下载的PDF文件。

**依赖安装：**

```bash
pip3 install weasyprint
```

**后端端点模式：**

```python
from fastapi.responses import Response
import weasyprint
from datetime import datetime

@router.get("/batches/{batch_id}/report/pdf")
def export_pdf(batch_id: int, db: Session = Depends(get_db)):
    # 1. 校验批次存在
    batch = db.query(CheckBatch).filter(CheckBatch.id == batch_id).first()
    if not batch:
        raise HTTPException(status_code=404, detail="批次不存在")

    # 2. 获取HTML报告
    html_report = db.query(Report).filter(
        Report.batch_id == batch_id,
        Report.report_type == "html"
    ).first()
    if not html_report or not html_report.content:
        raise HTTPException(status_code=404, detail="报告尚未生成")

    # 3. 添加打印样式
    styled_html = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8">
<style>
body {{ font-family: 'Noto Sans SC', sans-serif; font-size: 11pt; }}
table {{ width: 100%; border-collapse: collapse; }}
th, td {{ border: 1px solid #ccc; padding: 5px 8px; }}
h1 {{ font-size: 18pt; }}
.pass {{ color: #67c23a; }}
.warn {{ color: #e6a23c; }}
.error {{ color: #f56c6c; }}
.footer {{ margin-top: 30px; font-size: 9pt; color: #999; text-align: center; }}
</style></head><body>
{html_report.content}
<div class="footer">由系统自动生成 — {datetime.now().strftime('%Y-%m-%d %H:%M')}</div>
</body></html>"""

    # 4. 生成PDF并返回
    pdf_bytes = weasyprint.HTML(string=styled_html).write_pdf()
    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={"Content-Disposition": f"attachment; filename=报告_{batch_id}.pdf"},
    )
```

**前端PDF下载模式（axios-free，直接fetch）：**

```js
async function downloadPdf(batchId) {
  const pdfUrl = `/api/batches/${batchId}/report/pdf`
  const response = await fetch(pdfUrl)
  const blob = await response.blob()
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `报告_${batchId}_${new Date().toISOString().slice(0,10)}.pdf`
  a.click()
  URL.revokeObjectURL(url)
}
```

**关键点：**
- 使用 `fetch` 而非 `axios` 避免拦截器干扰（axios拦截器可能自动解包JSON，而PDF需要blob）
- PDF样式需独立设置（打印版，无需交互效果）
- 中文需要 `Noto Sans SC` 或 `Microsoft YaHei` 等中文字体
- 文件头要有 `<!DOCTYPE html>` 和 `<meta charset="utf-8">`

---

## 3. 失败操作重试模式

**用途：** 后端异步操作（如LLM核对）失败后，前端提供"重试"按钮重新启动。

**后端前提：** `POST /batches/{id}/check` 端点需支持重复调用——仅当 `status in ("checking", "parsing")` 时拒绝，其他状态（含 `failed` / `error` / `done`）均允许重试：

```python
if batch.status in ("checking", "parsing"):
    raise HTTPException(status_code=400, detail="该批次正在核对中")
```

**前端重试UI模式：**

```html
<el-card v-if="checkStatus?.status === 'failed' || checkStatus?.status === 'error'" class="retry-card">
  <div class="retry-content">
    <el-icon :size="40" color="#f56c6c"><WarningFilled /></el-icon>
    <div class="retry-text">
      <div class="retry-title">核对失败</div>
      <div class="retry-desc">{{ checkStatus.message || 'LLM核对过程中出现错误，请重试' }}</div>
    </div>
    <el-button type="primary" :loading="retrying" @click="handleRetry">
      <el-icon><Refresh /></el-icon> 重新核对
    </el-button>
  </div>
</el-card>
```

**重试逻辑：**

```js
async function handleRetry() {
  retrying.value = true
  try {
    await startCheck(batchId.value)
    // 重置前端状态
    checkStatus.value = { status: 'parsing', progress: 0, message: '重新启动...' }
    results.value = null
    reportContent.value = ''
    startPolling()  // 开始轮询新进度
    ElMessage.success('已重新启动核对')
  } catch (err) {
    ElMessage.error('启动失败: ' + err.message)
  } finally {
    retrying.value = false
  }
}
```

**关键点：**
- 重试前必须重置 `results` 和 `reportContent`，否则旧结果会残留在页面上
- 重试后立即开始轮询，不等待用户操作
- 失败卡片带 `border: 1px solid #f56c6c` 红色边框增强视觉提示
- 轮询端点检测到 `error/failed` 时应自动停止轮询

---

## 4. 异步操作轮询模式

**用途：** 后端异步处理（LLM核对）需要前端轮询进度。

```js
let pollTimer = null
const POLL_INTERVAL = 2000  // 2秒

function startPolling() {
  stopPolling()
  pollTimer = setInterval(async () => {
    try {
      const status = await getCheckStatus(batchId.value)
      checkStatus.value = status
      if (status?.status === 'done' || status?.status === 'completed') {
        stopPolling()
        await loadResults()     // 自动加载结果
      } else if (status?.status === 'error' || status?.status === 'failed') {
        stopPolling()
        pollError.value = `核对失败: ${status.message || '未知错误'}`
      }
    } catch (e) { /* 静默处理轮询错误 */ }
  }, POLL_INTERVAL)
}

// 清理
onUnmounted(() => stopPolling())
```

**关键点：**
- 必须 `onUnmounted` 清理定时器，防止组件销毁后继续轮询
- `stopPolling()` 先检查 `pollTimer` 再 `clearInterval`
- 轮询错误静默处理，避免连续弹出错误提示
- `done/completed` 时自动加载结果，无需用户操作

---

## 5. 数据聚合统计的SQLite注意事项

- 多个 `db.query().count()` 调用会各自产生SQL查询 → 大批量数据时建议用一次聚合查询
- SQLite的 `in_()` 性能良好，不需要担心
- 日期过滤用字符串比较（`>= 'YYYY-MM-DD'`）在SQLite中直接可用
- `LIMIT` 子句不需要占位符参数
