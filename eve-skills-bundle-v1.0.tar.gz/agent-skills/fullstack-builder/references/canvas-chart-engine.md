# Zero-Dependency Canvas Chart Engine

A pure HTML5 Canvas chart engine that renders pie, bar, and line charts without ANY external library (no Chart.js, ECharts, D3.js). Ideal for Flask-based single-page apps where minimizing dependencies matters.

## Architecture

```javascript
// Color palette (12 colors)
const CHART_COLORS = ['#3b82f6','#10b981','#f59e0b','#ef4444','#8b5cf6','#ec4899','#06b6d4','#84cc16','#f97316','#6366f1','#14b8a6','#e11d48'];
```

## Chart Functions

### drawPie(canvasId, data, labels, legendId)
- **Purpose**: Doughnut/pie chart with percentage labels on large slices
- **Canvas**: typically 200x200
- **Features**: 
  - Each slice: concentric arc from center, colored fill, dark border
  - Percentage label on slices > 17% (angle > 0.3 rad)
  - Interactive legend below chart (clickable items, no highlight logic yet)
  - Empty data fallback: "无数据" centered text
- **Algorithm**: 
  ```
  start = -PI/2  // start from top
  for each value:
    angle = (value/total) * 2*PI
    ctx.arc(cx, cy, R, start, start+angle)
    if angle > 0.3: draw percentage label at 60% radius
    start += angle
  ```

### drawBar(canvasId, data, labels, color)
- **Purpose**: Vertical bar chart
- **Canvas**: typically 350x180
- **Features**:
  - Gradient fill (solid → 40% opacity downward)
  - Rounded top corners via `ctx.roundRect()`
  - Data value above each bar
  - Truncated labels below bars (>6 chars → "first5..")
  - Supports per-bar colors when `color` is an array
  - Empty data fallback
- **Layout**: 
  ```
  padding: {t:10, b:20, l:30, r:10}
  barWidth = (W - pad.l - pad.r) / data.length
  ```

### drawLine(canvasId, data, labels)
- **Purpose**: Line/area chart for trend data
- **Canvas**: typically 350x180
- **Features**:
  - Grid lines (4 horizontal, dashed)
  - Area fill gradient below line (blue → transparent)
  - Smooth line with rounded joins
  - Data point dots (blue fill, dark border)
  - Data values above each dot
  - Truncated X-axis labels (>7 chars → slice from index 2)
  - Empty data fallback: "无趋势数据"
- **Layout**:
  ```
  xStep = (W - pad.l - pad.r) / max(data.length-1, 1)
  ```

## Usage Pattern (Flask SPA)

1. Add `<canvas>` elements with IDs in HTML:
```html
<div class="chart-canvas-wrap"><canvas id="c-status" width="200" height="200"></canvas></div>
<div class="chart-legend" id="legend-status"></div>
```

2. Fetch data from API and draw on DOMContentLoaded:
```javascript
async function loadDashV2() {
  const r = await fetch('/api/dashboard/v2').then(r=>r.json());
  drawPie('c-status', stData, stLabels, 'legend-status');
  drawBar('c-tags', tags.map(t=>t.count), tags.map(t=>t.name), CHART_COLORS);
  drawLine('c-trend', trend.map(t=>t.count), trend.map(t=>t.month));
}
```

## Pitfalls

1. **Canvas resolution**: Default 200x200 works for small cards. For high-DPI screens, scale with `canvas.width = rect.width * devicePixelRatio` and `ctx.scale(dpr, dpr)`.

2. **`ctx.roundRect` availability**: Available in Chrome 99+, Firefox 112+, Safari 15.4+. For older browsers, use `ctx.arcTo()` as fallback.

3. **Label overlap in pie chart**: When many small slices exist, labels overlap. Mitigation: only show labels on slices > 17%.

4. **Bar chart overflow**: Data values > max*2 will overflow the canvas. The bar max is clamped to `Math.max(...data, 1)`.

5. **Line chart single point**: If only 1 data point, `xStep` becomes infinite (division by zero). Fix: `Math.max(data.length-1, 1)`.

6. **Canvas re-render on tab switch**: If canvas is in a hidden tab when drawn, dimensions may be 0. Use `loadDashV2()` lazy-loaded on tab activation.

## Practical Example (from 智项智造 v2.20)

```
6 Canvas charts on one dashboard card:
├── c-status  (pie)     — 项目状态分布 (done/processing/failed)
├── c-budget  (pie)     — 预算分档 (≤50万/50-100万/100-500万/≥500万)
├── c-type    (pie)     — 项目类型分布 (研发/信息化/采购/运维)
├── c-tags    (bar)     — 标签使用频率分布
├── c-trend   (line)    — 月度项目创建趋势
└── dash-metrics        — (div-based, 4 KPI cards: 总项目/完成率/平均工期/总预算)
```

Total: ~150 lines of JS, zero external dependencies.
