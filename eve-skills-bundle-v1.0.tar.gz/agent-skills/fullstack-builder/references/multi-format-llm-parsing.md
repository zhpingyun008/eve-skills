# Multi-Format LLM Response Parsing Pattern

When different prompts/templates cause the same LLM API to return different output formats (JSON, Markdown sections, plain text), use a **detector + parser** pattern rather than a single rigid parser.

## The Problem

```
Template A (General) → LLM returns Markdown with ## 变更说明 + ## 改进指标 sections
Template B (Engineering) → LLM returns JSON code block (```json {...})
Template C (Agent) → LLM returns custom sections (## Role, ## Context, ## Instructions)

Single parser fails on templates B and C
```

## Solution: Format Detector + Multi-Parser

```python
def parse_optimization_result(response_text, template="general"):
    """
    Detect output format and dispatch to the right parser.
    Returns {"changes": [...], "metrics": {...}} regardless of input format.
    """
    text = response_text.strip()
    
    # Step 1: Detect format
    if text.startswith("```json") or "```json" in text:
        return _parse_json_format(text)
    elif _has_agent_sections(text):
        return _parse_agent_format(text)
    else:
        return _parse_general_format(text)
```

## Detection Strategy (Decision Tree)

```
LLM Response Text
    │
    ├─ Contains ```json or starts with { → JSON Format
    │     └─ Extract JSON block → parse → standardize
    │
    ├─ Contains ## Role, ## 角色, ## Context, ## 上下文 → Agent Format
    │     └─ Parse by section headers → extract changes/metrics
    │
    └─ Has ## 变更说明, ## 改进指标 → General Format
          └─ Regex extract sections → structured output
```

## Key Parsers

### JSON Format Parser
```python
def _parse_json_format(text):
    import re, json
    match = re.search(r"```json\s*\n?(.*?)\n?```", text, re.DOTALL)
    if match:
        try:
            data = json.loads(match.group(1))
            return _json_to_standard(data)
        except json.JSONDecodeError:
            pass
    return _fallback()
```

### Agent Format Parser
```python
def _parse_agent_format(text):
    sections = {}
    current_section = None
    for line in text.split("\n"):
        if line.startswith("## "):
            current_section = line.strip("# ")
            sections[current_section] = []
        elif current_section:
            sections[current_section].append(line)
    
    changes = []
    for section_name, lines in sections.items():
        if any(kw in section_name.lower() for kw in ["change", "变更", "improve", "改进"]):
            changes.append("\n".join(lines).strip())
    
    return {
        "changes": changes or ["优化完成，请查看优化后的 Prompt"],
        "metrics": {"clarity": 7, "completeness": 7, "executability": 7}
    }
```

### General Format Parser
```python
def _parse_general_format(text):
    import re
    changes = []
    change_match = re.search(r"##\s*变更说明\s*\n(.*?)(?=\n##|\Z)", text, re.DOTALL)
    if change_match:
        changes = [line.strip("-* ") for line in change_match.group(1).split("\n") if line.strip()]
    
    metrics = {"clarity": 7, "completeness": 7, "executability": 7}
    metrics_match = re.search(r"##\s*改进指标\s*\n(.*?)(?=\n##|\Z)", text, re.DOTALL)
    if metrics_match:
        for line in metrics_match.group(1).split("\n"):
            for key in metrics:
                if key in line.lower():
                    nums = re.findall(r"\d+", line)
                    if nums:
                        metrics[key] = int(nums[0])
    
    return {"changes": changes or ["优化完成"], "metrics": metrics}
```

## Fallback Pattern
```python
def _fallback():
    return {
        "changes": ["优化完成，请查看优化后的 Prompt"],
        "metrics": {"clarity": 7, "completeness": 7, "executability": 7}
    }
```

## When to Use This Pattern

| Scenario | Example |
|----------|---------|
| Multiple system prompts produce different output formats | General/Engineering/Agent templates |
| LLM may or may not return JSON depending on context | `response_format=json_object` vs free text |
| Parsing needs to survive LLM format drift | LLM adds/removes Markdown headers mid-conversation |
| Different LLM providers use different output conventions | DeepSeek→Markdown, GPT→JSON, Claude→XML |

## Pitfalls

- **Detection order matters**: Check JSON first (most specific), then Agent headers, then General. If General is checked first, a JSON block containing "## " would be mis-parsed.
- **Fallback is critical**: Every parser path should end with a sensible fallback rather than raising an exception or returning empty.
- **Monitor format drift**: If certain templates consistently hit the fallback, the LLM's output format may have changed.
- **JSON extraction regex**: Use `re.DOTALL` flag; without it the regex won't match multi-line JSON.
- **Section ordering**: The "changes" section may appear at the bottom of Agent format. Always scan the full text.
