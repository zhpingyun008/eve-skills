# Email System Integration Pattern (冷邮件 + 标书邮件统一看板)

## Architecture

```
Cold Email (send-cold-email.py) ─┐
                                  ├── lead-tracking.json ──┬── /api/email/analytics ── Web UI
Bid Email (batch_bid.py) ─────────┘                        │
                                                           ├── /api/email/status
                                                           └── /api/email/analyze-reply
```

## Key Components

### Unified Analytics API
```python
def get_combined_analytics():
    """Merge cold email + bid email data into single response."""
    bids = load_json(bid_tracking_file)   # bid-tracking.json
    cold = load_json(lead_tracking_file)  # lead-tracking.json
    replies = load_json(reply_log)        # email-replies.json
    return {
        "cold_email": {
            "sent_ok", "total_smtp_sends", "replies_detected",
            "smtp_breakdown": {"163": N, "qq_ssl": N, "qq_tls": N},
            "last_reply", "reply_details"
        },
        "bids": {"total", "sent", "pending"},
        "leads": {"total", "with_email", "without_email"},
        "total_outgoing": cold_sent + bid_sent,
        "total_replies": cold_replies + bid_replies,
    }
```

### Reply Intent Analysis (Keyword-based, no LLM cost)
```python
keywords_high   = ["报价","价格","方案","见面","电话","进一步","合作","感兴趣","洽谈"]
keywords_medium = ["了解","咨询","信息","介绍","看看","评估","考虑"]
keywords_low    = ["谢谢","收到","不需要","没兴趣","暂时","不用","停止"]

def analyze_reply_intent(text):
    counts = {level: sum(1 for kw in kws if kw in text) for level, kws in ...}
    if high_count >= 2 or (high_count >= 1 and low_count == 0): return "high"
    if medium_count >= 2 or high_count >= 1: return "medium"
    if low_count >= 1: return "low"
    return "medium"
```

### Cold Email Reply Detector
- POP3 protocol (163 email, since 163 doesn't enable IMAP)
- Cron: every 30 minutes
- Stores results in `email-replies.json`
- Posts to discussion board when new reply detected

## Web UI Integration
- Replies tab shows combined stats grid (sent + bids + replies + pending)
- SMTP breakdown table (163 / QQ SSL / QQ TLS)
- Follow-up reminders for each sent bid

## API Endpoints
| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/api/email/status` | GET | Cold email status |
| `/api/email/analytics` | GET | Combined analytics |
| `/api/email/analyze-reply` | POST | Analyze reply intent |

## Pitfalls
1. **SMTP breakdown zero**: lead-tracking.json may be empty if script hasn't run yet. Initialize with reasonable defaults to avoid empty UI.
2. **POP3 vs IMAP**: 163 only supports POP3. IMAP-based detectors won't work with 163.
3. **Lead-tracking staleness**: lead-tracking.json is generated during the 8:00 AM cron run. Between cron runs, the data is stale — display `generated_at` timestamp to inform users.
4. **Reply log format**: email-replies.json may store replies in unexpected formats (nested dicts, list of dicts). Handle both in the analytics endpoint.
