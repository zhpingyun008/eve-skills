# 配置页前后端字段对齐模式

## 问题场景

配置管理页面（ConfigView）是最容易产生前后端字段名漂移的地方：

| 场景 | 表现 |
|------|------|
| 后端重构 | 改了字段名但前端没同步更新 |
| 前后端各自独立开发 | 前端用`work_days`，后端用`working_days` |
| 新增字段不同步 | 后端新增了字段，前端表单没加 |
| 类型不匹配 | 后端布尔值存为`"true"`(字符串)，前端期望`true`(布尔) |

## 检测方法

```bash
# 1. 列出后端 schema 字段
grep -E "^\s+\w+:" backend/app/schemas/__init__.py | grep -v "class "

# 2. 列出前端 form reactive 字段
grep -A 10 "const form = reactive" frontend/src/views/ConfigView.vue | grep -E "\w+:" | sed 's/.*\.//'

# 3. 比对差异
```

## 修复模式

### 步骤1：统一后端Schema

```python
# backend/app/schemas/__init__.py
class ConfigUpdate(BaseModel):
    working_days: Optional[int] = None
    amount_tolerance: Optional[float] = None
    overtime_rate: Optional[float] = None
    enable_amount_check: Optional[bool] = None

class ConfigOut(BaseModel):
    working_days: int = 30
    amount_tolerance: float = 0.02
    overtime_rate: float = 1.5
    enable_amount_check: bool = True
```

### 步骤2：前端reactive字段名与后端一致

```js
// frontend/src/views/ConfigView.vue
const form = reactive({
  working_days: 30,          // ← 不是 work_days
  amount_tolerance: 0.02,    // ← 不是 tolerance
  overtime_rate: 1.5,
  enable_amount_check: true,
})
```

### 步骤3：后端setter处理全部新字段

```python
# backend/app/routers/config.py
if config.overtime_rate is not None:
    update_map["overtime_rate"] = str(config.overtime_rate)  # 存为字符串
if config.enable_amount_check is not None:
    update_map["enable_amount_check"] = str(config.enable_amount_check).lower()
```

### 步骤4：getter返回全部字段

```python
return ConfigOut(
    working_days=config.get("working_days", 30),
    overtime_rate=config.get("overtime_rate", 1.5),  # 新字段有默认值
    enable_amount_check=config.get("enable_amount_check", True),
    ...
)
```

## 预防

1. **API-first** — 先在schema定义好所有字段，然后前后端同时实现
2. **配置快照测试** — 每次变更后curl配置API，与前端期望字段列表diff
3. **字段注册表** — 在项目根目录维护一个`config-fields.json`，前后端都引用
