# Async Task with Status Polling Pattern

When a backend operation takes 30+ seconds (LLM generation, batch email, bulk data processing), **do not make the client wait**. Use an async pattern: POST triggers a background thread, returns immediately, and the client polls a status endpoint.

## Architecture

```
Client                    Server
  |                         |
  |--- POST /api/action --->|  ← 立即返回 {"status":"started","total":N}
  |   202 Accepted          |
  |                         |  ← 后台线程开始处理
  |--- GET /api/status ---->|  ← {"status":"running","progress":5,"total":100}
  |   200 OK                |
  |--- GET /api/status ---->|  ← {"status":"running","progress":42,"total":100}
  |   200 OK                |
  |--- GET /api/status ---->|  ← {"status":"done","results":{...}}
  |   200 OK                |     或 {"status":"error","error":"..."}
```

## Server Implementation (Flask)

```python
import threading

_regenerate_result = None
_regenerate_lock = threading.Lock()

@app.route("/api/regenerate", methods=["POST"])
def api_regenerate():
    global _regenerate_result
    bids = load_bids()
    with _regenerate_lock:
        if _regenerate_result and _regenerate_result.get("status") == "running":
            return jsonify({"error": "already running"}), 409
        _regenerate_result = {"status": "running", "progress": 0, "total": len(bids), "results": None}
    
    def _run():
        global _regenerate_result
        results = []
        for i, bid in enumerate(bids):
            try:
                result = process_bid(bid)
                results.append({"bid": bid, "result": result})
            except Exception as e:
                results.append({"bid": bid, "error": str(e)})
            with _regenerate_lock:
                _regenerate_result["progress"] = i + 1
        with _regenerate_lock:
            _regenerate_result["status"] = "done"
            _regenerate_result["results"] = results
    
    thread = threading.Thread(target=_run, daemon=True)
    thread.start()
    return jsonify({"status": "started", "total": len(bids)})

@app.route("/api/regenerate/status")
def api_regenerate_status():
    global _regenerate_result
    if _regenerate_result is None:
        return jsonify({"status": "idle"})
    with _regenerate_lock:
        return jsonify(dict(_regenerate_result))
```

## Client Implementation (Vanilla JS)

```javascript
const POLL_INTERVAL = 2000;
let pollTimer = null;

function startAction() {
    fetch('/api/regenerate', { method: 'POST' })
        .then(r => r.json())
        .then(d => {
            if (d.status === 'started') startPolling();
        });
}

function startPolling() {
    pollTimer = setInterval(async () => {
        const r = await fetch('/api/regenerate/status');
        const d = await r.json();
        updateProgress(d);
        if (d.status !== 'running') {
            clearInterval(pollTimer);
            pollTimer = null;
            onComplete(d);
        }
    }, POLL_INTERVAL);
}

function updateProgress(d) {
    const pct = d.total > 0 ? Math.round(d.progress / d.total * 100) : 0;
    document.getElementById('progress-bar').style.width = pct + '%';
    document.getElementById('progress-text').textContent = `${d.progress}/${d.total}`;
}
```

## Key Design Decisions

| Decision | Choice | Rationale |
|----------|--------|-----------|
| Thread vs Queue | `threading.Thread` | Simplest for single-server Flask; Queue/Celery if multi-worker |
| Lock scope | Only around `_regenerate_result` read/write | Minimize contention; the background thread holds it only for ~1ms per iteration |
| Status object lifetime | Keep after completion until next start | Allows client to see final result; next POST replaces it |
| Error handling | Per-item try/except, not global | One failing item doesn't kill the whole batch |
| Poll interval | 2 seconds | Balances responsiveness vs server load; longer for very long jobs (30s+) |

## Common Pitfalls

- **Thread safety**: Always use a `threading.Lock()` around shared mutable state read/writes. Without it, the client may see a partially-written status object.
- **Daemon threads**: Set `daemon=True` so the thread doesn't block server shutdown. But this means in-progress work is lost on restart — acceptable for atomic-per-item operations.
- **Multiple triggers**: Guard against a second POST while one is running (return 409). Without this, two threads race on shared state.
- **Client recovery**: On page load, check status endpoint. If a job was running when the user navigated away, pick it back up:
  ```javascript
  function checkStatusOnLoad() {
      fetch('/api/regenerate/status')
          .then(r => r.json())
          .then(d => {
              if (d.status === 'running') startPolling();
          });
  }
  ```
- **Progress granularity**: For N items, increment progress after each item. For streaming operations, estimate total steps upfront.
- **Client timeout**: `setInterval` continues even if the server is unreachable. Add a timeout counter that stops polling after N consecutive failures.

## When NOT to Use This Pattern

| Scenario | Better Approach |
|----------|----------------|
| Operation < 5 seconds | Synchronous endpoint with generous timeout |
| Need real-time updates (per-second) | WebSocket / Server-Sent Events |
| Multi-worker deployment | Redis Queue / Celery / SQS |
| Need durability (survive restart) | Database-backed job queue |
