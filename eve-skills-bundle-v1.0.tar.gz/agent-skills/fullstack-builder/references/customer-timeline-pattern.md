# Customer Interaction Timeline Pattern (客户互动历史)

For products that interact with customers via multiple channels (bids + cold emails + replies), aggregate all interactions by customer name into a unified timeline view.

## API

```
GET /api/customer/<org_name>  → {org, total, interactions[]}
```

## Implementation

```python
@app.route("/api/customer/<path:org>")
def api_customer_timeline(org):
    org_lower = org.lower()
    
    # 1. Bid interactions (from bid-tracking.json)
    bid_interactions = []
    for b in bids:
        if org_lower in b.get("org","").lower() or org_lower in b.get("project","").lower():
            bid_interactions.append({
                "type": "bid",
                "org": b.get("org"),
                "project": b.get("project"),
                "sent": b.get("sent"),
                "time": b.get("generated_at", ""),
            })
    
    # 2. Cold email interactions (from cold-email-send-log.json)
    email_interactions = []
    for e in emails:
        if org_lower in e.get("org","").lower() or org_lower in e.get("email","").lower():
            email_interactions.append({
                "type": "email",
                "org": e.get("org"),
                "sent": e.get("sent"),
                "reply": e.get("reply", False),
                "time": e.get("sent_at", ""),
            })
    
    # 3. Merge & sort by time (newest first)
    all_ints = bid_interactions + email_interactions
    all_ints.sort(key=lambda x: x.get("time",""), reverse=True)
    
    return {"org": org, "total": len(all_ints), "interactions": all_ints}
```

## Web UI Integration

Trigger from a leads table row (click or context menu):
```javascript
async function viewCustomer(org) {
    const r = await api(`/api/customer/${encodeURIComponent(org)}`);
    const msg = r.interactions.map(i => 
        `${i.type==='bid'?'📄':'📧'} ${i.sent?'✅':'⏳'} ${i.time||''}`
    ).join('\n');
    alert(`📋 ${org}\n共${r.total}次互动\n\n${msg}`);
}
```

## Data Sources

| Source | File | Fields |
|--------|------|--------|
| Bids | `bid-tracking.json` | org, project, sent, generated_at |
| Cold emails | `cold-email-send-log.json` | org, email, sent, reply, sent_at |

## Design Notes

- Use `.lower()` matching for fuzzy org name matching
- Sort newest-first for most relevant context
- Each interaction is lightweight (no full content loaded)
- Extendable to include: follow-ups, deal records, phone calls
