# Eve AI Bidding Tool Architecture

## Overview

A complete SaaS pipeline for automatic bid generation, quality scoring, multi-channel email delivery, follow-up tracking, and revenue pipeline management. Built for Eve (伊芙科技), an AI-native software factory.

## Architecture Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                    Web UI (Single HTML)                      │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐       │
│  │ 生成标书  │ │ 标书管道  │ │ 邮件回复  │ │ 线索库    │       │
│  │ Generator │ │ Pipeline │ │ Replies  │ │ Leads    │       │
│  └────┬─────┘ └────┬─────┘ └────┬─────┘ └────┬─────┘       │
│       │            │            │            │             │
└───────┼────────────┼────────────┼────────────┼─────────────┘
        │            │            │            │
        ▼            ▼            ▼            ▼
┌─────────────────────────────────────────────────────────────┐
│                    Flask API (app.py)                        │
│  /api/generate  /api/send-bid  /api/score-bid              │
│  /api/batch-send  /api/search-bids-text  /api/print-bid    │
│  /api/revenue  /api/followups  /api/templates              │
└───────┬───────────────┬──────────────┬──────────────────────┘
        │               │              │
        ▼               ▼              ▼
┌────────────┐  ┌──────────────┐  ┌─────────┐
│ Generator  │  │  Database    │  │ Leads   │
│ (LLM+Temp) │  │ (SQLite)     │  │ (JSON)  │
├────────────┤  ├──────────────┤  ├─────────┤
│ scoring    │  │ followups    │  │ 62 leads│
│ 3 templates│  │ revenue      │  │ 50 email│
└───────┬────┘  │ templates    │  │ ¥4286万 │
        │       └──────────────┘  └─────────┘
        ▼
┌──────────────┐
│ SMTP Sender  │
│ QQ ↔ 163     │
│ Dual-Channel │
└──────────────┘
```

## Core Modules

### 1. Generator (`src/generator.py`)
- **LLM mode**: DeepSeek API generates 4000+ char custom bids with real company info
- **Template fallback**: Static markdown template ~1200 chars (when API fails)
- **3 templates**: 标准商务版 / 技术方案版 / 快速响应版
- **Quality scoring**: 4-dimension (length/structure/customization/professionalism)
- **Output**: ~87/100 (LLM) vs ~65/100 (template)

### 2. Extractor (`src/extractor.py`)
- URL crawling → HTML parsing → DeepSeek extraction
- Direct text → DeepSeek extraction
- Rule-based fallback (regex)

### 3. Web UI (`static/index.html`)
- Zero-dependency vanilla JS (no React, no build step)
- 4 tabs: 生成标书 / 标书管道 / 邮件回复 / 线索库
- Dark theme (#0f172a background)
- Action buttons per bid: 📤send / 📖preview / ⬇️download / 🖨️print / 📊score / ⏰follow-up
- Modal for preview and scoring
- LocalStorage for client state, SQLite for server state
- 15s auto-refresh on stats

### 4. SMTP Pipeline (`scripts/batch_bid.py`)
- Dual-channel: QQ Mail (smtp.qq.com:465) → 8封/2h → 163 Mail (smtp.163.com:465)
- Batch mode: `--send --lead-id N` for single, `--tier 1 --send` for batch
- Tracking JSON: `bid-tracking.json` with per-bid sent/email/org/timestamp
- Failover: auto-try next provider on connection error

### 5. Database (`src/database.py`)
- SQLite with WAL mode for concurrent reads
- Tables: followups, revenue_tracking, templates
- Functions: add/get/mark-done followup, calculate pipeline, manage templates

### 6. Searches (`scripts/bid_searcher.py`)
- Multi-keyword search across procurement platforms
- Incremental dedup against existing leads
- Domain heuristic contact discovery

## Key Numbers (after v2.3)

| Metric | Value |
|--------|-------|
| Bids generated | 66 |
| Bids sent | 39 |
| Leads total | 62 |
| Leads with email | 50 |
| Pipeline value | ¥4,286万 |
| Top deal | ¥922万 |
| Email replies | 1 |

## Cron Jobs

| Name | Schedule | Function |
|------|----------|----------|
| Eve Bid Engine | 9:00 daily | Generate + send bids for new leads |
| Cold Email | 8:00 daily | P0 lead outreach |
| Scout | Every 2h | Market intel scanning |

## File Structure

```
~/company/product/bidding-tool/
├── app.py                    # Flask Web API (15+ endpoints)
├── src/
│   ├── generator.py          # LLM+Template bid generation + scoring
│   ├── extractor.py          # Bid info extraction
│   └── database.py           # SQLite persistence layer
├── scripts/
│   ├── batch_bid.py          # Batch send pipeline (dual SMTP)
│   ├── bid_searcher.py       # Procurement platform crawler
│   └── find_contacts.py      # Contact info discovery
├── static/
│   └── index.html            # Web UI (zero-dependency SPA)
├── data/
│   ├── eve.db                # SQLite (followups/templates/revenue)
│   ├── 66 bid .md files      # Generated bids
│   └── bid-tracking.json     # Send status tracking
└── requirements.txt
```

## Common Patterns

### Generating and Sending in One Click
```javascript
// Web UI: generate then immediately offer send
const data = await api('/api/run', {text, url, use_llm: true});
if (data.success) {
  // Show bid with send button
  showBidWithSendButton(data.path, data.bid);
}
```

### Quality Check Before Send
```javascript
// Score first, then decide to send
const score = await api('/api/score-bid', {path});
if (score.score >= 70) {
  await api('/api/send-bid', {path, email});
} else {
  alert('标书质量不足，建议先用AI增强重新生成');
}
```

### Revenue Calculation
```python
# Extract budget from lead match text
import re
match = lead.get("match", "")
m = re.search(r'(\d+\.?\d*)\s*万', match)
if m:
    budget = float(m.group(1))
```
