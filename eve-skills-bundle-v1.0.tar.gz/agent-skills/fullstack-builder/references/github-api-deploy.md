# GitHub API Deployment (bypass git push)

**Use when**: `github.com` is unreachable (blocked by GFW/proxy) but `api.github.com` works. Git protocol (SSH/HTTPS) fails but the REST API succeeds.

## Architecture

```
┌─────────────────────────────────────────────────────┐
│  WSL/China (github.com blocked)                     │
│                                                     │
│  git push ✗ (github.com:443 timeout)                │
│  gh CLI  ✗ (same github.com dependency)             │
│  curl api.github.com ✅ (0.5s response)              │
│                                                      │
│  Solution: GitHub Contents API + Releases API        │
└─────────────────────────────────────────────────────┘
```

## Step 1: Create Repository

```python
import json, urllib.request
headers = {'Authorization': f'Bearer {token}', 'Accept': 'application/vnd.github.v3+json'}

data = json.dumps({
    "name": "repo-name",
    "private": False,
    "auto_init": False,  # We'll add files manually
}).encode()

req = urllib.request.Request(
    'https://api.github.com/user/repos', data=data,
    headers={**headers, 'Content-Type': 'application/json'}, method='POST'
)
resp = json.loads(urllib.request.urlopen(req).read())
print(resp['html_url'])  # https://github.com/username/repo-name
```

## Step 2: Upload Files via Contents API

Use `PUT /repos/{owner}/{repo}/contents/{path}`. Each file requires base64 encoding.

```python
import base64, os

def upload_file(api_base, fname, fpath, headers):
    with open(fpath, 'rb') as f:
        content = base64.b64encode(f.read()).decode()
    data = json.dumps({
        'message': f'Add {fname}',
        'content': content,
        'branch': 'master',
    }).encode()
    req = urllib.request.Request(
        f'{api_base}/{fname}', data=data,
        headers={**headers, 'Content-Type': 'application/json'}, method='PUT'
    )
    resp = urllib.request.urlopen(req, timeout=30)
    return json.loads(resp.read())

api_base = 'https://api.github.com/repos/username/repo-name/contents'
result = upload_file(api_base, 'README.md', '/path/to/README.md', headers)
```

**Important**: GitHub enforces rate limits (~5000/hr). Add `time.sleep(0.5)` between file uploads.

## Step 3: Create Release

```python
release_data = {
    "tag_name": "v1.0.0",
    "name": "Release v1.0.0",
    "body": "Release notes in markdown",
    "draft": False,
    "prerelease": False,
}
req = urllib.request.Request(
    'https://api.github.com/repos/username/repo-name/releases',
    data=json.dumps(release_data).encode(),
    headers={**headers, 'Content-Type': 'application/json'}, method='POST'
)
release = json.loads(urllib.request.urlopen(req).read())
release_id = release['id']
```

## Step 4: Upload Release Asset (ZIP)

```python
upload_url = f'https://uploads.github.com/repos/username/repo-name/releases/{release_id}/assets?name=file.zip'
with open('/path/to/file.zip', 'rb') as f:
    zip_data = f.read()

req = urllib.request.Request(
    upload_url, data=zip_data,
    headers={**headers, 'Content-Type': 'application/zip'}, method='POST'
)
asset = json.loads(urllib.request.urlopen(req, timeout=60).read())
print(asset['browser_download_url'])
```

## Step 5: Enable GitHub Pages

```python
pages_data = json.dumps({
    'source': {'branch': 'gh-pages', 'path': '/'}
}).encode()

# First create the gh-pages branch using git API (create ref + tree + commit)
# Then enable Pages:
req = urllib.request.Request(
    f'{api_base.replace("/contents","")}/pages',
    data=pages_data,
    headers={**headers, 'Content-Type': 'application/json'}, method='POST'
)
```

## ⚠️ Pitfalls

### 1. Token with special characters in shell
Tokens like `github_pat_...` often contain `)`, `!`, `$` etc. that break shell variable expansion:
```bash
# ❌ Breaks
TOKEN=$(cat ~/.token)
curl -H "Authorization: Bearer $TOKEN" ...

# ✅ Use Python to avoid shell escaping entirely
import os, urllib.request
token = open(os.path.expanduser('~/.hermes/.github_token')).read().strip()
```

### 2. Empty repo prevents Release creation
GitHub requires at least one commit before creating a Release:
```
"message":"Validation Failed","errors":[{"message":"Repository is empty."}]
```
**Fix**: Upload files via Contents API first, THEN create the release.

### 3. Base64 encoding
Contents API requires base64 content. Use Python's `base64.b64encode()`:
```python
with open(file_path, 'rb') as f:
    encoded = base64.b64encode(f.read()).decode()
```

### 4. `json.load()` vs `json.loads(strict=False)`
GitHub API responses may contain control characters in description/topic fields:
```python
# ✅ Safe
raw = open('/tmp/gh_response.json').read()
data = json.loads(raw, strict=False)
# ❌ json.load() does NOT accept strict=False
```

### 5. Rate limiting
- Unauthenticated: 60 req/hr
- With token: 5000 req/hr
- Add `time.sleep(0.5)` between Contents API calls
- Releases API is separate from the 5000/hr general rate limit

### 6. Pages 409 "Already enabled"
If Pages is already configured, POST returns 409. Check state first with `GET /repos/{owner}/{repo}/pages`.

## Quick-start template

```python
#!/usr/bin/env python3
"""Publish project to GitHub via API (bypasses git protocol)"""
import json, os, base64, urllib.request, urllib.error, time

TOKEN = open(os.path.expanduser('~/.github_token')).read().strip()
HEADERS = {
    'Authorization': f'Bearer {TOKEN}',
    'Accept': 'application/vnd.github.v3+json',
}
REPO_API = 'https://api.github.com/repos/username/repo-name'

def upload_file(fname, fpath):
    data = json.dumps({
        'message': f'Add {fname}',
        'content': base64.b64encode(open(fpath, 'rb').read()).decode(),
        'branch': 'master',
    }).encode()
    req = urllib.request.Request(
        f'{REPO_API}/contents/{fname}', data=data,
        headers={**HEADERS, 'Content-Type': 'application/json'}, method='PUT'
    )
    try:
        urllib.request.urlopen(req, timeout=30)
        print(f'✅ {fname}')
    except urllib.error.HTTPError as e:
        print(f'❌ {fname}: HTTP {e.code}')
    time.sleep(0.3)

# Usage:
for fname in ['README.md', 'main.py', 'config.yaml']:
    upload_file(fname, f'/path/to/{fname}')
```
