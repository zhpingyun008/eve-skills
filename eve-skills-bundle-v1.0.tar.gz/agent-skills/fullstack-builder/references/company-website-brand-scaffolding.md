# Company Website + Brand Scaffolding

**Reference**: 2026-05-30 Eve company setup — one-person AI company website and brand design.

## Pattern: One-Page Company Website

When creating a company website for an AI-native consultancy, use this template structure:

### Structure (1432 lines, 83KB HTML)

```
HTML page sections (in order):
├─ Navigation (fixed top, mobile hamburger)
├─ Hero (big headline + subtitle + CTA)
├─ Pain/Solution (3 pain points → AI solution)
├─ Services (3 pricing tiers)
├─ Team (17 AI employees grid)
├─ Process (4-step timeline)
├─ Why Us (3 core advantages + stats)
├─ Case Studies (placeholder cards)
├─ FAQ (fold/expand interactions)
└─ Contact (form + email + social)
```

### Tech Stack

```html
<!-- Pure HTML + Tailwind CDN — zero build step, instant preview -->
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800" rel="stylesheet">

<!-- Custom tailwind config for brand colors -->
<script>
tailwind.config = {
    theme: {
        extend: {
            colors: {
                brand: { purple: '#6C5CE7', cyan: '#00CEC9', ... }
            },
            fontFamily: {
                sans: ['Inter', '"Source Han Sans SC"', 'sans-serif'],
            }
        }
    }
}
</script>
```

### Key Design Decisions

| Decision | Choice | Why |
|----------|--------|-----|
| Framework | None (HTML+Tailwind CDN) | Zero build, instant edit, deploy anywhere |
| Dark mode | Hardcoded dark theme (#0A0A0F bg) | AI/tech companies look better dark |
| Animations | CSS-only (IntersectionObserver) | No JS framework needed |
| FAQ | Pure CSS fold/expand | Zero JS, works without hydration |
| Contact form | Simulated (JS alert on submit) | Until backend is built |

### Deploy

```bash
# Option 1: Vercel/Cloudflare Pages (free)
# Just drag-drop the HTML file

# Option 2: Custom domain
# Point eve.build to Vercel → set custom domain

# Option 3: Simple serve
npx serve company/website/ -l 3000
```

## Pattern: Brand Asset Generation

Generate SVG logos programmatically when image tools aren't available:

### Standard Logo Set

```
brand/
├── logo-horizontal.svg      ← Main logo (icon + text + tagline)
├── logo-icon.svg             ← Icon only (avatar/favicon)
├── logo-dark.svg             ← Dark background variant
├── favicon.svg               ← Website icon (32x32 viewBox)
└── brand-guidelines.md       ← Colors + fonts + usage rules
```

### SVG Logo Template

```svg
<svg viewBox="0 0 400 120">
  <defs>
    <linearGradient id="accent" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#6C5CE7"/>
      <stop offset="100%" style="stop-color:#00CEC9"/>
    </linearGradient>
  </defs>
  <!-- Brand mark: gradient circle + letter -->
  <circle cx="55" cy="60" r="42" fill="url(#accent)" opacity="0.95"/>
  <text x="55" y="77" font-size="56" font-weight="700" fill="#FFF"
        font-family="'Inter',sans-serif" text-anchor="middle">E</text>
  <!-- Company name + tagline -->
  <text x="115" y="70" font-size="40" font-weight="700" fill="#2D3436"
        letter-spacing="1">Eve</text>
  <text x="115" y="88" font-size="11" fill="#636E72" letter-spacing="3"
        font-weight="500">AI-NATIVE  SOFTWARE  FACTORY</text>
</svg>
```

### Brand Color Palette

```css
/* Primary gradient: Purple → Cyan */
--brand-primary: #6C5CE7;
--brand-secondary: #00CEC9;

/* Neutrals */
--text-dark: #2D3436;
--text-gray: #636E72;
--text-light: #DFE6E9;
--bg-dark: #0A0A0F;
```

### Domain Strategy for 1-Person AI Company

When short `.com` is taken, target these TLDs in order:

| TLD | Suitability | Example |
|-----|-------------|---------|
| `.build` | Best fit (verb = build products) | eve.build |
| `.work` | Good (factory/workshop vibe) | eve.work |
| `.sh` | Great (developer community) | eve.sh |
| `.so` | Good (short, memorable) | eve.so |
| `.tech` | Direct (tech company) | eve.tech |
| `-ai.com` | Falls back to .com authority | eve-ai.com |

## See Also

- `self-healer/references/gateway-autoheal-lockfile.md` — Mutex lock pattern
- `self-healer/references/cron-script-integrity.md` — Cron script recovery
