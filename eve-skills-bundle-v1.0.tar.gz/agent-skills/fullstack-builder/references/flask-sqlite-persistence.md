# Flask SQLite Persistence + Revenue Pipeline

Pattern for adding SQLite persistence layer to Flask SaaS tools for cross-session durability and business metrics.

## SQLite Database Module (`src/database.py`)

Standard structure for a Flask tool's database module:

### Schema

```sql
CREATE TABLE followups (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    lead_name TEXT NOT NULL,
    bid_path TEXT,
    days INTEGER NOT NULL DEFAULT 7,
    due_date TEXT NOT NULL,  -- ISO datetime
    completed INTEGER DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE templates (
    name TEXT PRIMARY KEY,
    description TEXT,
    content TEXT NOT NULL,
    is_default INTEGER DEFAULT 0
);

-- Optional: tracking table for sent states
CREATE TABLE tracking (
    lead_id INTEGER,
    sent INTEGER DEFAULT 0,
    sent_to TEXT,
    sent_at TEXT,
    channel TEXT  -- 'smtp.qq.com' or 'smtp.163.com'
);
```

### CRUD API Endpoints Pattern

| Method | Endpoint | Purpose |
|--------|----------|---------|
| GET | `/api/followups` | List all with status (overdue/soon/ok) |
| POST | `/api/followups` | Create new follow-up |
| PUT | `/api/followups/<id>` | Update (mark completed) |
| DELETE | `/api/followups/<id>` | Remove |

### Follow-up Status Logic

```python
def get_followup_status(due_date_str):
    due = datetime.fromisoformat(due_date_str)
    now = datetime.now()
    if now > due:
        return "overdue"
    elif (due - now).days <= 3:
        return "soon"
    else:
        return "ok"
```

Web UI rendering: overdue=🔴, soon=🟡, ok=🟢

## Revenue Pipeline Calculation

From `leads.json` budget data:

```python
def calculate_revenue():
    budget_total = sum(l.get('budget_wan', 0) for l in leads if l.get('budget_wan'))
    return {
        "total_budget_wan": budget_total,
        "leads_with_budget": count,
        "avg_budget": budget_total / max(count, 1),
        "max_budget": max(...),
        "max_lead": the lead with highest budget,
        "top_5": sorted(...)[:5]  # top 5 by value
    }
```

### Seed Data Templates

Always seed the DB with default data on first run:

```python
def seed_defaults():
    templates = [
        {"name": "标准商务版", "description": "适合政府/国企采购...", "is_default": True},
        {"name": "技术方案版", "description": "突出技术架构细节...", "is_default": False},
        {"name": "快速响应版", "description": "简洁有力，小额采购...", "is_default": False},
    ]
    for t in templates:
        cursor.execute("INSERT OR IGNORE INTO templates (name, description, is_default) VALUES (?, ?, ?)",
                      (t["name"], t["description"], t["is_default"]))
```

### Best Practices
- Use WAL mode for better concurrent read performance: `PRAGMA journal_mode=WAL`
- Always use `INSERT OR IGNORE` for seed data to handle re-runs
- Use ISO datetime strings for portability
- Return counts in health endpoint for at-a-glance monitoring
