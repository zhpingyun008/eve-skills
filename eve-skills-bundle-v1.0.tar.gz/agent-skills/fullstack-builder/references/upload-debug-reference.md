# 全栈项目：上传接口对齐检查参考

## 前端[object Object]错误排查清单

当用户上传文件时报 `[object Object],[object Object]`：

### 第1步：检查FormData字段对齐

后端期望：
```python
def create_batch(
    supplier_name: str = Form(...),
    settlement_period: str = Form(...),
    files: List[UploadFile] = File(...),
):
```

前端必须：
```javascript
const formData = new FormData()
formData.append('supplier_name', batchForm.value.supplier_name)
formData.append('settlement_period', batchForm.value.settlement_period)
for (const file of uploadedFiles.value) {
    formData.append('files', file.raw || file)
}
```

**常见遗漏**：只append了 `files`，漏了 `supplier_name` 和 `settlement_period`。

### 第2步：检查response_model字段对齐

前端读 `result.batch_id` → 后端返回 `id`（ORM模型字段名）
前端读 `result.files` → 后端返回 `materials`（数据库表名）

**修复**：统一使用前端期望的字段名，或在response_model中添加别名。

```python
class BatchOut(BaseModel):
    id: int        # 不是 batch_id
    batch_no: str  # 批次编号（前端用来展示）

class BatchWithMaterials(BatchOut):
    materials: List[MaterialOut] = []  # 不是 files
```

### 第3步：axios拦截器检查

```javascript
// api/index.js
request.interceptors.response.use(
  (response) => response.data,  // 解包后组件直接访问 result.id
  (error) => {
    const msg = error.response?.data?.detail || error.message
    return Promise.reject(new Error(msg))  // 确保Error.message是字符串
  }
)
```

### 第4步：catch块显示

```javascript
catch (err) {
    const msg = err.message || '请求失败'
    ElMessage.error(msg)  // 不要用 '上传失败: ' + err.message
}
```

**根因**：如果 `err` 不是Error对象（如axios错误），`err.message` 可能是对象，字符串拼接变 `[object Object]`。

## 材料类型检测策略

用关键词模糊匹配代替精确中文名匹配：

```python
keyword_map = [
    ("结算工作量", "settlement"),
    ("账单汇总", "settlement"),
    ("考勤", "attendance"),
    ("考核评分", "assessment"),
    ("付款确认单", "confirmation"),
    ("离场", "departure"),
    ("发票", "invoice"),
    ("审核表", "audit_form"),
]
```

文件名包含任意关键词即匹配，优先级从高到低。`.xlsx` 后缀默认视为审核表。

## 并行子Agent模式参考

```
主任务
 ├── delegate_task #1: 数据提取引擎 (7种材料Extractor, 6文件)
 ├── delegate_task #2: 核对引擎 (24项检查, 7文件)
 └── 主线程继续写: 配置文件, 数据库模型, API路由
     ↓ 等待全部完成
     合并 → 启动验证 → 冒烟测试
```

**约束**：
- 每个子任务必须自包含（不能依赖另一个子任务的输出）
- 数据结构契约（dict格式）必须在启动前约定
- 子任务完成时运行 `python3 -c "from package import module"` 验证导入
