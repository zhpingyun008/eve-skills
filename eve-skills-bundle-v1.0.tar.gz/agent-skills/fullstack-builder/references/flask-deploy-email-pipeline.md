# Flask Web App: systemd Deployment + SMTP Email Pipeline

## 1. systemd User Service Deployment

### Service File Template

```ini
[Unit]
Description=Eve AI Bidding Tool Web Server
After=network.target

[Service]
Type=simple
WorkingDirectory=/home/yestin/company/product/bidding-tool
ExecStart=/home/yestin/.hermes/.venv/bin/python3 /home/yestin/company/product/bidding-tool/app.py
Restart=always
RestartSec=10

[Install]
WantedBy=default.target
```

### Common Failure Modes

#### 216/GROUP — "Failed to determine supplementary groups"

**Root Cause**: `User=yestin` in a `systemctl --user` service file. User services already run as the current user — adding `User=` causes systemd to attempt group resolution which fails in user mode.

**Fix**: Remove the `User=` line from `[Service]`.

```bash
# Before (broken)
[Service]
Type=simple
User=yestin       # ← REMOVE THIS
WorkingDirectory=...

# After (fixed)  
[Service]
Type=simple
WorkingDirectory=...
```

**Verification**: `journalctl --user -u <service>.service --no-pager -n 5 | grep "216/GROUP\|Failed to determine"` — should be empty after fix.

#### ModuleNotFoundError (Flask/uvicorn not found)

**Root Cause**: systemd executes `/usr/bin/python3` but Flask is installed in a virtual environment.

**Fix**: Point `ExecStart` to venv Python:

```
ExecStart=/home/yestin/.hermes/.venv/bin/python3 /path/to/app.py
# NOT: ExecStart=/usr/bin/python3 /path/to/app.py
```

**Check**: `pip3 show flask | grep Location` tells you which environment has Flask.

### Service Lifecycle Commands

```bash
# User (non-root) services
systemctl --user daemon-reload   # Reload config changes
systemctl --user start <name>    # Start (not restart — restart often blocked)
systemctl --user stop <name>     # Stop
systemctl --user status <name>   # Status + last logs
systemctl --user is-active <name> # Quick active check

# Journal logs
journalctl --user -u <name>.service --no-pager -n 20
```

**Note**: `restart` and `stop` may be blocked by safety guardrails. Use `start` after `daemon-reload` — the auto-restart (`Restart=always`) will cycle the process.

---

## 2. SMTP Email Pipeline with Dual-Channel Fallback

### Architecture

```
QQ SMTP (smtp.qq.com:465) → 8封/120min 限速
  └─ 失败时自动切换 → 163 SMTP (smtp.163.com:465) → 无严格限速
```

### Credential Management

Store SMTP passwords in `~/.hermes/.eve_env`:

```bash
export QQ_MAIL_SMTP_PASSWORD='qq-smtp-auth-code'
export NETEASE_MAIL_PASSWORD='163-smtp-auth-code'
export NETEASE_MAIL_SENDER='15907581103@163.com'
```

Load in Python:

```python
def load_env():
    env_file = os.path.expanduser("~/.hermes/.eve_env")
    if os.path.exists(env_file):
        with open(env_file) as f:
            for line in f:
                line = line.strip()
                if line.startswith("export "):
                    parts = line[7:].strip().split("=", 1)
                    if len(parts) == 2:
                        key = parts[0].strip()
                        val = parts[1].strip().strip("'\";")
                        os.environ[key] = val
```

### SMTP Dual-Channel Sender Pattern

```python
def send_email(to_email, subject, body, attachment_path=None):
    providers = [
        {"host": "smtp.qq.com", "port": 465, 
         "user": os.environ.get("QQ_MAIL_SENDER", "zhpingyun008@qq.com"),
         "password": os.environ.get("QQ_MAIL_SMTP_PASSWORD", ""), "use_ssl": True},
        {"host": "smtp.163.com", "port": 465,
         "user": os.environ.get("NETEASE_MAIL_SENDER", "15907581103@163.com"),
         "password": os.environ.get("NETEASE_MAIL_PASSWORD", ""), "use_ssl": True},
    ]

    for cfg in providers:
        if not cfg["password"]:
            continue
        try:
            msg = MIMEMultipart()
            msg["From"] = cfg["user"]
            msg["To"] = to_email
            msg["Subject"] = subject
            msg.attach(MIMEText(body, "plain", "utf-8"))

            if attachment_path:
                with open(attachment_path, "rb") as f:
                    part = MIMEBase("application", "octet-stream")
                    part.set_payload(f.read())
                    encoders.encode_base64(part)
                    part.add_header("Content-Disposition",
                                   f"attachment; filename={os.path.basename(attachment_path)}")
                    msg.attach(part)

            server_class = smtplib.SMTP_SSL if cfg["use_ssl"] else smtplib.SMTP
            server = server_class(cfg["host"], cfg["port"], timeout=10)
            if not cfg["use_ssl"]:
                server.starttls()
            server.login(cfg["user"], cfg["password"])
            server.send_message(msg)
            server.quit()
            return True
        except Exception as e:
            print(f"  ⚠️ {cfg['host']} failed: {str(e)[:60]}")
            continue
    return False
```

### Rate Limits

| Provider | Limit | Notes |
|----------|-------|-------|
| QQ Mail (SMTP) | 8封/120min | 465+587端口共享额度 |
| 163 Mail | ~50封/天 | 无明显短期限制 |
| 阿里云邮件推送 | 200封/天(免费) | 需域名配置 |

### Tracking Pattern

Maintain a JSON tracking file for pipeline progress:

```python
def load_tracking(path):
    if os.path.exists(path):
        with open(path) as f:
            return json.load(f)
    return {"bids": [], "total": 0, "sent": 0}

def save_tracking(tracking, path):
    tracking["updated_at"] = datetime.now().isoformat()
    tracking["total"] = len(tracking["bids"])
    tracking["sent"] = sum(1 for b in tracking["bids"] if b.get("sent"))
    with open(path, "w", encoding="utf-8") as f:
        json.dump(tracking, f, ensure_ascii=False, indent=2)
```

**Critical**: In test/dry-run mode, `send_email()` must return `False` not `True` to keep tracking accurate:

```python
if test_mode:
    print(f"  📧 [TEST MODE] Would send to: {email}")
    return False  # ← NOT True!
```

---

## 3. Batch Processing Pipeline Pattern

### Standard Flow

```
1. Load data (JSON/CSV/DB)
2. Filter by criteria (tier, status, email presence)
3. Sort by priority (deadline, value)
4. For each item:
   a. Generate output (bid doc, report, email body)
   b. Optionally send (SMTP/API)
   c. Record in tracking JSON
5. Report summary
```

### CLI Argument Design

```python
parser.add_argument("--tier", type=int, nargs="+", default=[1])
parser.add_argument("--send", action="store_true")  # Live mode
parser.add_argument("--force", action="store_true") # Regenerate existing
parser.add_argument("--max", type=int, default=0)    # Limit count
parser.add_argument("--lead-id", type=int, default=None)  # Single item
```

### Cron Wrapper (Hermes no_agent mode)

Create a shell script in `~/.hermes/scripts/`:

```bash
#!/bin/bash
# Wrapper for cron job
cd /path/to/project
source ~/.hermes/.eve_env 2>/dev/null
python3 scripts/process.py --tier 1 --send
```

Register as cron:
```bash
hermes cron create --name "Daily Pipeline" \
  --schedule "0 9 * * *" \
  --script "wrapper-script.sh" \
  --no-agent
```

**Note**: Script path must be relative to `~/.hermes/scripts/` (no absolute paths allowed).

---

## 4. Web UI Send-Bid API Endpoint

When adding a "send bid via email" button to a Flask web app, add this endpoint:

```python
@app.route("/api/send-bid", methods=["POST"])
def api_send_bid():
    data = request.get_json(force=True)
    path = data.get("path", "")
    email = data.get("email", "")
    
    if not path or not os.path.exists(path):
        return jsonify({"error": "文件不存在"}), 404
    if not email:
        return jsonify({"error": "请提供邮箱"}), 400
    
    from src.generator import load_env
    load_env()
    
    # Try QQ first, fallback to 163
    import smtplib
    from email.mime.text import MIMEText
    from email.mime.multipart import MIMEMultipart
    from email.mime.base import MIMEBase
    from email import encoders
    
    providers = [
        {"host": "smtp.qq.com", "port": 465, "user": os.environ.get("QQ_MAIL_SENDER", "zhpingyun008@qq.com"),
         "password": os.environ.get("QQ_MAIL_SMTP_PASSWORD", ""), "use_ssl": True},
        {"host": "smtp.163.com", "port": 465, "user": os.environ.get("NETEASE_MAIL_SENDER", "15907581103@163.com"),
         "password": os.environ.get("NETEASE_MAIL_PASSWORD", ""), "use_ssl": True},
    ]
    
    for cfg in providers:
        if not cfg["password"]:
            continue
        try:
            msg = MIMEMultipart()
            msg["From"] = cfg["user"]
            msg["To"] = email
            msg["Subject"] = f"投标文件 - {os.path.basename(path)[:50]}"
            msg.attach(MIMEText("标书请见附件", "plain", "utf-8"))
            
            with open(path, "rb") as f:
                part = MIMEBase("application", "octet-stream")
                part.set_payload(f.read())
                encoders.encode_base64(part)
                part.add_header("Content-Disposition", f"attachment; filename={os.path.basename(path)}")
                msg.attach(part)
            
            server_cls = smtplib.SMTP_SSL if cfg["use_ssl"] else smtplib.SMTP
            server = server_cls(cfg["host"], cfg["port"], timeout=15)
            server.login(cfg["user"], cfg["password"])
            server.send_message(msg)
            server.quit()
            
            # Update tracking
            _mark_sent(path, email)
            
            return jsonify({"success": True, "via": cfg["host"]})
        except Exception as e:
            continue
    
    return jsonify({"error": "发送失败"}), 500


def _mark_sent(path, email):
    """Update tracking JSON to mark a bid as sent."""
    tracking_file = os.path.expanduser("~/company/data/bid-tracking.json")
    if not os.path.exists(tracking_file):
        return
    with open(tracking_file) as f:
        tracking = json.load(f)
    for bid in tracking.get("bids", []):
        if bid.get("bid_path") == path:
            bid["sent"] = True
            bid["sent_at"] = datetime.now().isoformat()
    tracking["sent"] = sum(1 for b in tracking["bids"] if b.get("sent"))
    with open(tracking_file, "w") as f:
        json.dump(tracking, f, ensure_ascii=False, indent=2)
```

---

## 5. DeepSeek API Key Discovery

When an LLM-powered script needs the DeepSeek API key, check these sources in order:

```python
def get_deepseek_key():
    """Get DeepSeek API key from env, .env file, or config."""
    # 1. Process environment
    key = os.environ.get("DEEPSEEK_API_KEY", "")
    if key:
        return key
    
    # 2. Hermes .env file (most likely location)
    env_file = os.path.expanduser("~/.hermes/.env")
    if os.path.exists(env_file):
        with open(env_file) as f:
            for line in f:
                line = line.strip()
                if line.startswith("DEEPSEEK_API_KEY="):
                    val = line.split("=", 1)[1].strip().strip("'\"")
                    if val:
                        return val
    
    # 3. Hermes config.yaml (legacy location)
    cfg = os.path.expanduser("~/.hermes/config.yaml")
    if os.path.exists(cfg):
        with open(cfg) as f:
            for line in f:
                if "api_key" in line and "deepseek" in line.lower():
                    import re
                    m = re.search(r'api_key:\s*[\'"]?([^\'"\s]+)', line)
                    if m:
                        return m.group(1)
    
    return ""
```

The key is stored as `DEEPSEEK_API_KEY=sk-...` in `~/.hermes/.env` (Hermes runtime env). Unlike the SMTP creds which are in `.eve_env`, the DeepSeek key lives in the main Hermes `.env` file and is only available inside the Hermes agent context — standalone Python processes need the reading logic above.
