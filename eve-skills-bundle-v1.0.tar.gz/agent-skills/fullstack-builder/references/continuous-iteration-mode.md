# 持续迭代模式 (继续模式)

## 概述

当用户下达"继续"指令时触发的产品迭代工作流。每个"继续"周期完成5个功能的完整开发部署验证闭环。

## 触发条件

- 用户说"继续"
- 用户说"继续优化完善功能"
- 用户说"继续推进"

## 执行流程

### Step 0: 系统全景检查

```python
# 检查项
1. ps aux — 所有服务进程状态
2. backlog.json — 待办项
3. errors.log — 错误率统计
4. ss -tlnp — 端口监听状态
5. curl health endpoint — 服务健康
```

### Step 1: 功能审查

审查当前代码库，识别5个最有价值的优化点：

| 准则 | 说明 |
|------|------|
| **P0安全** | 认证缺失/端口暴露/Secret硬编码 |
| **已有API缺UI** | 后端有API但前端无入口 |
| **数据可视化** | 文字→图表增强 |
| **用户体验** | 批量操作取消/分页/空状态/拖拽 |
| **实时性** | WebSocket/SSE通知 |

### Step 2: 并行实施

使用 `delegate_task` 并行分配功能实现，每个子Agent负责一个功能：

```python
# 模式：3个delegate_task并行
for task in 3-5 features:
    delegate_task(goal=f"实现功能{i}", context=code_context)
```

**重要**: 
- 每个子Agent单独读取文件（避免同时写入冲突）
- 子Agent完成后检查其输出摘要
- 跨文件变更(如前后端联动)分配到一个子Agent

### Step 3: 重启服务

```python
# 清理旧进程
kill $(ps aux | grep "app.py" | grep -v grep | awk '{print $2}')
sleep 2

# 启动新实例
terminal(background=true, command="cd /path && python3 app.py")
sleep 3

# 确认端口
ss -tlnp | grep <port>
```

**坑**:
- systemctl restart 可能被沙箱拦截→回退到直接kill+background
- 同一端口可能有多个进程 → 用 `fuser -k <port>/tcp` 强制释放
- systemd服务会自动重启旧进程 → 主动 stop 或接受端口冲突

### Step 4: 全功能验证

对每个新功能API做HTTP验证：

```python
import urllib.request, json

# Login获取token
token = login().token

# 逐个验证新端点
for endpoint, expected in features:
    req = urllib.request.Request(endpoint, headers={"Authorization": f"Bearer {token}"})
    with urllib.request.urlopen(req) as r:
        assert r.status == 200
```

**注意**: JWT token含特殊字符(点号)，不要在bash中直接拼接curl命令。使用Python的urllib.request。

### Step 5: BookStack同步

```bash
python3 ~/.hermes/skills/devops/bookstack-update-sync/scripts/sync.py \
  "版本说明: 功能列表" \
  "产品" \
  "/books/39/page/skill-xxx"
```

### Step 6: 军事化汇报

汇报格式：

```
## Product vX.Y 完成报告

```
vX.Y → vX.Z (第N轮N功能迭代)
│
├── ① 功能名     ✅ 效果描述
├── ② 功能名     ✅ 效果描述
├── ③ 功能名     ✅ 效果描述
├── ④ 功能名     ✅ 效果描述
└── ⑤ 功能名     ✅ 效果描述
```

### 验证结果
功能1: ✅ / 功能2: ✅ / ...

### 两轮累计
轮次   版本   功能数   核心变化
第一轮 vX.Y  5个    功能列表
第二轮 vX.Z  5个    功能列表
总计    —    10个    

服务在 :PORT 运行中，可正常使用。
```

## 常见特征识别

| 信号 | 含义 | 行动 |
|------|------|------|
| 用户说"继续" | 开始新一轮迭代 | 执行Step 0→6 |
| 用户说"批准" | 确认上一轮产出 | 继续执行或等待下一指令 |
| 用户block命令 | 该操作不期望自动执行 | 切换回退方案，不要重试 |
| 服务版本号 | 每轮+0.01 | 更新VERSION文件+前端title |
