# System Log Viewer for Flask Web Apps

## Overview
Embed a live log viewer in a Flask app's Web UI using `journalctl` for systemd services. Enables operations staff to view service logs without SSH access.

## Flask Endpoint

```python
import subprocess

@app.route("/api/logs")
def api_logs():
    lines = request.args.get("lines", 50, type=int)
    level = request.args.get("level", "all")  # all / error / warn / info
    
    try:
        result = subprocess.run(
            ["journalctl", "--user", "-u", "eve-bidding-tool", "--no-pager", 
             f"-n{lines}", "--output=short-iso"],
            capture_output=True, text=True, timeout=5
        )
        log_text = result.stdout
    except:
        log_text = ""
    
    entries = []
    for line in log_text.splitlines():
        if not line.strip():
            continue
        entry = {"raw": line[:200], "level": "info"}
        if "error" in line.lower() or "traceback" in line.lower() or "exception" in line.lower():
            entry["level"] = "error"
        elif "warn" in line.lower():
            entry["level"] = "warn"
        
        if level != "all" and entry["level"] != level:
            continue
        entries.append(entry)
    
    return jsonify({
        "total": len(entries),
        "errors": sum(1 for e in entries if e["level"] == "error"),
        "warnings": sum(1 for e in entries if e["level"] == "warn"),
        "entries": entries[:lines],
    })
```

## Web UI Implementation

### HTML (toggle-able panel in system tab)
```html
<button onclick="toggleLogs()">📋 查看日志</button>
<div id="log-container" style="display:none;max-height:300px;overflow-y:auto;...">
    <div id="log-content">加载中...</div>
</div>
```

### JavaScript
```javascript
async function toggleLogs() {
    const c = document.getElementById('log-container');
    if (c.style.display !== 'none') { c.style.display = 'none'; return; }
    c.style.display = 'block';
    try {
        const r = await api('/api/logs?lines=100');
        let html = `<div>共${r.total}条 | ⚠️${r.warnings}警告 | ❌${r.errors}错误</div>`;
        r.entries.forEach(e => {
            const color = e.level === 'error' ? 'var(--danger)' : 
                         e.level === 'warn' ? 'var(--warning)' : 'var(--muted)';
            html += `<div style="color:${color}">${e.level === 'error' ? '❌' : e.level === 'warn' ? '⚠️' : '  '} ${e.raw.slice(0,160)}</div>`;
        });
        el.innerHTML = html;
    } catch(e) { /* error display */ }
}
```

## Key Points
- Requires `import subprocess` at top of app.py
- journalctl only works on systemd-based Linux — no Docker/macOS/Windows
- For Docker: mount app log file and read directly instead
- Trim lines to 160-200 chars to avoid overwhelming the Web UI
- Error/warning detection is keyword-based (not log level field) — catches Python tracebacks
