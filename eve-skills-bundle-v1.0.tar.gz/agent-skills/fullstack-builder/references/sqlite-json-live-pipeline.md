# SQLite → JSON → Live Dashboard Pipeline

## 场景

已有SQLite数据库(employee_activity.db, discuss.db)存有员工状态和讨论数据，需要在浏览器中实时展示。

## 管道架构

```
┌─────────────┐    ┌────────────┐    ┌──────────────────┐    ┌──────────────┐
│ SQLite      │ →  │ Python     │ →  │ website/data/    │ →  │ Browser      │
│ .db         │    │ JSON导出   │    │ .json            │    │ fetch()      │
└─────────────┘    └────────────┘    └──────────────────┘    └──────────────┘
   ↑ 实时写入          ↑ cron           ↑ http.server            ↑ 15s interval
   (consciousness/     (每3分钟)         (端口8765)               (setInterval)
    activity引擎)
```

## 📦 关键模式: 单文件前端

### 文件结构
- `office.html` — 单文件，零依赖，直接通过http.server提供
- 无npm、无build step、无框架

### 数据加载
```javascript
async function loadData() {
  const [empRes, postRes] = await Promise.all([
    fetch('/data/employees.json?t='+Date.now()),
    fetch('/data/discuss-posts.json?t='+Date.now())
  ]);
  return { employees: (await empRes.json()).employees, posts: await postRes.json() };
}
```

### 自动刷新
```javascript
async function init() {
  await refresh();
  setInterval(refresh, 15000);
}
```

## 📦 关键模式: Cron数据管道

### SQLite → JSON 导出

```python
import subprocess, json, os

# Employee status
db = '~/company/data/employee_activity.db'
r = subprocess.run(['sqlite3', db, 
    "SELECT json_group_array(json_object('role',employee,'status',current_status,'task',coalesce(current_task,''),'last_heartbeat',last_heartbeat)) FROM employee_status"],
    capture_output=True, text=True, timeout=5)
employees = json.loads(r.stdout.strip())

# Discuss posts
r2 = subprocess.run(['sqlite3', '~/company/data/discuss.db', '-separator', '|||',
    "SELECT id,channel,author_role,replace(title,char(10),' '),coalesce(substr(replace(content,char(10),' '),1,200),''),coalesce(emotion,'neutral'),timestamp FROM posts ORDER BY id DESC LIMIT 50"],
    capture_output=True, text=True, timeout=5)

output = {
    'generated_at': subprocess.run(['date','+%Y-%m-%d %H:%M:%S'],capture_output=True,text=True).stdout.strip(),
    'total': len(employees),
    'summary': counts,
    'employees': employees
}
with open('~/company/website/data/employees.json', 'w') as f:
    json.dump(output, f, ensure_ascii=False, indent=2)
```

### cron配置（本场景）
```
eve-office-employees-sync → */3 * * * * → 同步employees.json + discuss-posts.json
eve-office-posts-sync     → */5 * * * * → 同步discuss-posts.json (冗余保护)
```

## ⚠️ 已知Pitfall: 数据源校验缺失

**出过的问题**: 前端从 `/reports/ceo-dashboard-live.json` 拿数据，但该端点不包含员工状态字段。页面渲染了但全部显示"待命中"。

**根因**: 没验证JSON实际返回的key就写fetch。名称暗示不等于数据结构。

**铁律 — 先验数据源，再写fetch**:
```bash
curl -s http://localhost:PORT/path/to/data.json | python3 -c "
import json,sys
d=json.load(sys.stdin)
print(f'类型: {type(d).__name__}, keys={list(d.keys()) if isinstance(d,dict) else \"list({len(d)}条)\"}')
"
```

**深层教训**:
- 不要假设端点名代表数据结构（`ceo-dashboard-live.json` 不代表有员工状态）
- `.catch(()=>({}))` 是坏模式 — 沉默吞掉HTTP错误，后续 `obj.employees` 返回 `undefined`
- 客户端侧错误的fallback应保留错误追踪能力

**修复模式**:
```javascript
// ❌ 坏模式: 沉默fallback
fetch('/reports/foo.json').then(r=>r.json()).catch(()=>({}))

// ✅ 好模式: 显式验证
fetch('/data/employees.json')
  .then(r => r.ok ? r.json() : Promise.reject('HTTP '+r.status))
  .catch(e => { console.error('数据加载失败', e); return {employees:[]}; })
```

## 🏢 员工状态办公桌可视化模式

在基础数据管道之上，构建"办公桌"式员工状态看板——每个员工一张"桌子"，按部门分区。

### 核心UI模式

```
┌─────────────────────────────────────────┐
│  Header: 图标+标题 | 统计栏(工作中/学习/休眠) │
├─────────────────────────────────────────┤
│  📢 会议室: 最新N条讨论帖                  │
├─────────────────────────────────────────┤
│  💼 商务中心                              │
│  ┌──────┐ ┌──────┐ ┌──────┐             │
│  │🔍scout│ │✍️scribe│ │💼closer│             │
│  │工作中  │ │工作中  │ │工作中  │             │
│  └──────┘ └──────┘ └──────┘             │
│  ⚙️ 交付中心                              │
│  ┌──────┐ ┌──────┐ ┌──────┐             │
│  │📋lead │ │⚙️maker│ │🏗️arch │             │
│  │工作中  │ │工作中  │ │学习中  │             │
│  └──────┘ └──────┘ └──────┘             │
│  ...（更多部门）                           │
├─────────────────────────────────────────┤
│  📋 实时动态 LIVE (滚动活动流)              │
│  18:43 lead 站会已开始                    │
│  18:42 maker 修复CMMI5引擎                │
└─────────────────────────────────────────┘
```

### 员工卡片设计

每个员工渲染为一个圆角卡片，含：
- **3px顶部色条** — 状态指示（绿=工作中, 蓝=学习中, 黄=待命, 灰=休眠）
- **Emoji图标** — 角色映射表（在JS常量中预定义）
- **角色名 + 中文职位**
- **状态圆点 + 状态文字** — 颜色与色条一致
- **当前任务** — 截取60字，溢出省略
- **活跃时间** — 相对时间（"4分钟前"）

### 会议室讨论区

从讨论数据库取最新帖子，渲染为消息列表：
- 发言者 + 帖子频道（颜色标记：general紫/leads绿/projects蓝/alerts红）
- 情绪emoji前缀（🔥兴奋/🤔困惑/💪自信/😊开心等）
- 点击可查看完整内容

### 实时动态流

活动feed区显示最新的讨论帖，格式：
```
时间 | 角色 | #频道 | 标题
```

### 关键数据结构（前端JS映射表）

```javascript
const EMOJI = {
  scout:'🔍', scribe:'✍️', closer:'💼', lead:'📋', maker:'⚙️',
  arch:'🏗️', guard:'🛡️', dev1:'💻', ...};

const ROLE_NAME = {
  scout:'侦察兵', scribe:'内容营销', closer:'成交手', lead:'项目组长', ...};

const DEPARTMENTS = {
  '商务中心': { barColor:'#22c55e', roles:['scout','scribe','closer'] },
  '交付中心': { barColor:'#3b82f6', roles:['lead','maker','arch','guard','dev1',...] },
  ...};

const STATUS_COLOR = {
  working:'#22c55e', learning:'#3b82f6', idle:'#eab308',
  sleeping:'#475569', running:'#06b6d4', completed:'#8b5cf6'};

const CHANNEL_COLORS = {
  general:'#a78bfa', leads:'#22c55e', projects:'#3b82f6',
  standup:'#eab308', alerts:'#ef4444', random:'#64748b'};
```

### 自动刷新

```javascript
async function init() {
  await refresh();       // 首次加载
  setInterval(refresh, 15000);  // 每15秒自动刷新
}
```

### 综合数据源处理

看板需要多个数据源时，并行fetch：

```javascript
async function loadData() {
  const [empRes, postRes] = await Promise.all([
    fetch('/data/employees.json?t='+Date.now()),
    fetch('/data/discuss-posts.json?t='+Date.now())
  ]);
  return {
    employees: (await empRes.json()).employees || [],
    posts: await postRes.json()
  };
}
```

每个数据源由其独立的cron管道维护（如 employees.json 每3分钟, discuss-posts.json 每5分钟）。

---

## 🐍 Flask路由技巧: 尾部斜杠不匹配

### 问题
登录API重定向到 `/portal/`（带斜杠），但Flask Blueprint路由定义为 `@bp.route("/portal")`（无斜杠）→ 302跳转后404 Not Found。

### 根因
Flask的Blueprint注册路由时，尾部斜杠必须精确匹配。`@bp.route("/portal")` 只匹配 `/portal`（无斜杠），不匹配 `/portal/`。而Flask默认不自动补齐（不同于 `@app.route("/portal/")` 会自动重定向 `/portal` → `/portal/`）。

### 修复
```python
# 在login API的返回值中，确保redirect指向正确的路由
return jsonify({"status": "ok", "redirect": "/portal"})  # 无尾部斜杠
# 而不是:
return jsonify({"status": "ok", "redirect": "/portal/"})  # ❌ 404
```

### 预防
- Flask路由定义时，蓝图中统一使用无尾部斜杠（`@bp.route("/portal")`）
- 所有重定向URL必须与路由定义精确一致
- 测试方式：登录后检查浏览器地址栏URL是否无斜杠

---

## 🎨 视觉规范

| 元素 | 值 |
|------|-----|
| 背景 | `#0a0e1a` (深蓝黑) |
| 卡片背景 | `linear-gradient(160deg,#111827,#0d1320)` |
| 卡片边框 | `1px solid #1e293b` |
| 毛玻璃 | `.header{backdrop-filter:blur(12px)}` |
| 状态顶条 | 3px渐变(绿/蓝/黄/灰) |
| 动画 | pulse / float / slideMsg / slideUp / glow |
| 状态颜色 | working `#22c55e` / learning `#3b82f6` / idle `#eab308` / sleeping `#475569` |
| 部门色条 | 商务`#22c55e` / 交付`#3b82f6` / 产品`#a78bfa` / 能力`#eab308` / 管理`#f97316` |

## 🧩 员工角色映射表模式

构建员工看板时，前端需要角色→emoji/名称/部门的静态映射表。维护方式：

```javascript
const EMOJI = {
  scout:'🔍', scribe:'✍️', closer:'💼', lead:'📋', maker:'⚙️',
  arch:'🏗️', guard:'🛡️', dev1:'💻', dev2:'💻', dev3:'💻',
  test:'🧪', doc:'📖', pm:'📊', yestin:'👑', orchestrator:'🎛️'
};

const ROLE_NAME = {
  scout:'侦察兵', scribe:'内容营销', closer:'成交手', lead:'项目组长',
  maker:'全栈工程', arch:'架构师', guard:'质量工程', pm:'项目管理',
  yestin:'全栈指挥官'
};

const DEPARTMENTS = {
  '商务中心': { barColor:'#22c55e', roles:['scout','scribe','closer'] },
  '交付中心': { barColor:'#3b82f6', roles:['lead','maker','arch','guard','dev1','dev2','dev3','test','doc','cm','sa','sec','devops'] },
  '产品增长中心': { barColor:'#a78bfa', roles:['pm','product','analyst','cs','da','ux'] },
  '能力中心': { barColor:'#eab308', roles:['evolver','qm','qa','req','spi','trainer'] },
};
```

## 🔄 Cron管道创建模式

使用 `cronjob()` 设置数据同步：

```javascript
// 创建定时同步（每3分钟）
cronjob(action='create',
  name='eve-office-employees-sync',
  schedule='*/3 * * * *',
  enabled_toolsets=['terminal','file'],
  prompt='python3 -c "import subprocess,json,os; ... sqlite3 json_group_array ... write to employees.json"')

// 验证
cronjob(action='list')  // 检查状态
cronjob(action='run', job_id='xxx')  // 立即执行验证
```

**关键路径**: DB是规范数据源（authoritative source），JSON是缓存视图。永远从DB导出，不要依赖可能过期的预生成JSON文件。
