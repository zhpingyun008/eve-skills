# Flask PDF Export via Print CSS

Browser-native PDF generation using HTML + CSS print rules. Zero library dependency.

## Architecture

```
Flask: /api/export/<id>/<type>/pdf →
  Response(html, mimetype='text/html') →
  Browser renders → setTimeout(print, 500) → Print dialog → "Save as PDF"
```

## Backend Implementation

```python
from flask import Response

@app.route("/api/export/<task_id>/<doc_type>/pdf", methods=["GET"])
def export_doc_pdf(task_id, doc_type):
    task = base.load(task_id)
    content = task.cleaned_requirement.get(doc_type, "")
    
    html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title>{safe_name} - {doc_type}</title>
<style>
@page {{
  size: A4;
  margin: 20mm;
  @top-center {{ content: "系统名称"; font-size: 10pt; color: #666; }}
  @bottom-center {{ content: counter(page) " / " counter(pages); font-size: 10pt; color: #666; }}
}}
body {{ font-size: 12pt; font-family: "SimSun", "Noto Sans CJK SC", serif; line-height: 1.8; color: #333; }}
h1,h2,h3 {{ page-break-after: avoid; }}
pre {{ white-space: pre-wrap; word-break: break-all; }}
</style>
</head>
<body>
{content}
<script>setTimeout(()=>window.print(),500)</script>
</body>
</html>"""
    return Response(html, mimetype='text/html')
```

## Frontend Button

```html
<button class="btn btn-sm btn-primary" onclick="window.open('/api/export/'+taskId+'/'+type+'/pdf')">
  📄 PDF
</button>
```

## Key Design Decisions

| Decision | Choice | Rationale |
|----------|--------|-----------|
| Library | None (native) | Zero dependency, works everywhere |
| Trigger | `setTimeout(window.print, 500)` | Gives CSS time to apply before dialog |
| MIME type | `text/html` | Browser renders, not downloads |
| Margins | 20mm | Standard A4 document |
| Page numbers | CSS `@page` counter | No JS needed |
| Header | `@top-center` | Hidden during actual print in most browsers |

## Pitfalls

1. **Font fallback**: Chinese fonts need explicit fallback chain. Use `"SimSun", "Noto Sans CJK SC", serif`.
2. **Print cancellation**: If user cancels print dialog, the tab stays open with the print CSS layout. Add a "关闭" button or rely on browser tab management.
3. **Content overflow**: Long tables/wide content breaks A4 layout. Add `table { page-break-inside: avoid; }` and `overflow-wrap: break-word`.
4. **Browser differences**: Chrome applies `@page` correctly; Firefox may need `size: A4` in `@page` without quotes. Test both.
