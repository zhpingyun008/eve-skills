# 外包结算材料核对系统 — 项目速查

> FastAPI + Vue3 + Element Plus + SQLite + DeepSeek LLM
> 路径: `/home/yestin/projects/settlement-check/`

## 架构

```
settlement-check/
├── backend/app/
│   ├── main.py              # FastAPI入口, 注册路由
│   ├── routers/             # API路由
│   │   ├── upload.py        # 上传+删除+编辑+批量删除
│   │   ├── check.py         # 核对启动+状态+结果+报告+CSV/PDF导出
│   │   ├── history.py       # 历史记录列表+详情
│   │   ├── config.py        # 系统配置
│   │   ├── stats.py         # 统计仪表盘
│   │   └── reports.py       # ZIP批量导出
│   ├── services/
│   │   ├── file_service.py  # 文件处理+材料类型检测
│   │   ├── llm_service.py   # DeepSeek LLM调用
│   │   └── check_engine/
│   │       ├── engine.py    # 基础引擎(进度追踪)
│   │       ├── llm_check_engine.py  # LLM驱动24项核对
│   │       └── rules/       # 规则检查器
│   └── models/              # SQLAlchemy模型
├── frontend/src/
│   ├── views/
│   │   ├── DashboardView.vue  # 仪表盘+快速查询+批量导出
│   │   ├── UploadView.vue     # 上传材料(含上传并核对一键按钮)
│   │   ├── CheckView.vue      # 核对结果(导航/编辑/轮次分组/重试/CSV)
│   │   ├── HistoryView.vue    # 历史记录(筛选/删除/多选批量删除/刷新)
│   │   └── ConfigView.vue     # 系统配置(工作日/税率/误差等)
│   └── components/
│       ├── FileUploader.vue   # 拖拽上传+材料类型检测预览
│       ├── CheckTable.vue     # 按轮次分组折叠展示
│       ├── IssueList.vue      # 问题列表+建议栏
│       └── ProgressBar.vue    # 进度条
└── settlement_check.db        # SQLite
```

## 关键端口
- 后端: 8001
- 前端: 5173

## API端点速查

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | /api/health | 健康检查 |
| POST | /api/batches | 上传材料 |
| DELETE | /api/batches/{id} | 删除批次 |
| PUT | /api/batches/{id} | 编辑批次 |
| POST | /api/batches/batch-delete | 批量删除 |
| POST | /api/batches/{id}/check | 启动核对 |
| GET | /api/batches/{id}/check/status | 核对状态 |
| GET | /api/batches/{id}/check/results | 核对结果 |
| GET | /api/batches/{id}/report/pdf | 导出PDF报告 |
| GET | /api/batches/{id}/results/csv | 导出CSV |
| GET | /api/reports/export/zip | 批量导出ZIP |
| GET | /api/history | 历史记录(含筛选) |
| GET | /api/history/{id} | 批次详情 |
| GET | /api/config | 配置 |
| PUT | /api/config | 更新配置 |
| GET | /api/stats | 仪表盘统计 |

## 迭代历史 (v1.0 → v2.5, 15轮, 28项优化)
- v1.0: 基础上传+LLM核对+报告
- v1.1: PDF导出+报告卡片+历史筛选
- v1.2: 数据契约对齐+最近批次+上传刷新
- v1.3: 轮次分组+状态一致性
- v1.4: IssueList增强+建议字段补全
- v1.5: CheckView重构(跳转/导航/错误)
- v1.6: 仪表盘+统计API+侧边栏升级
- v1.7: 失败重试机制
- v1.8: 配置页字段对齐修复
- v1.9: CSV导出+HistoryView自动刷新
- v2.0: 批次删除+确认弹窗
- v2.1: 材料类型检测预览
- v2.2: Dashboard快速查询
- v2.3: 批次编辑API+直编
- v2.4: HistoryView重新核对+代码清理
- v2.5: ZIP批量导出+上传流程简化(Codox批量删除)
