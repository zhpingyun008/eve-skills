# Vanilla JS Dashboard Pattern (Tabs + Modal + Stats)

Lightweight single-page dashboard with zero framework dependencies. Suitable for internal tools, admin panels, and monitoring dashboards.

## Architecture

```
Single HTML file (index.html)
├── CSS: CSS variables for theming, component classes
├── HTML: Tab panels, cards, modal overlay
└── JS: fetch() → render() cycle, event delegation
```

## Key Components

### 1. Stats Grid
```html
<div class="stats-grid">
  <div class="stat-card">
    <div class="num">65</div>
    <div class="label">累计标书</div>
  </div>
  <div class="stat-card success">
    <div class="num">38</div>
    <div class="label">已发送</div>
  </div>
</div>
```

Color variants: `.stat-card` (default blue), `.stat-card.success` (green), `.stat-card.warning` (yellow).

### 2. Tab Navigation
```html
<div class="tabs">
  <div class="tab active" onclick="switchTab('generator')">📝 面板一</div>
  <div class="tab" onclick="switchTab('dashboard')">📊 面板二</div>
</div>

<div id="panel-generator" class="panel active">...</div>
<div id="panel-dashboard" class="panel">...</div>
```

```javascript
function switchTab(name) {
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  document.querySelector(`.tab[onclick*="${name}"]`).classList.add('active');
  document.getElementById(`panel-${name}`).classList.add('active');
}
```

### 3. Bid/Item List with Status Dots
```html
<div class="bid-item">
  <div class="info">
    <div class="name"><span class="status-dot sent"></span>项目名称</div>
    <div class="meta">06-11 12:00 | 2.3KB | 已发送</div>
  </div>
  <div class="actions">
    <button onclick="preview(...)">📖</button>
    <button onclick="download(...)">⬇️</button>
    <button onclick="send(...)">📤</button>
  </div>
</div>
```

Status dots: `.status-dot.sent` (green), `.status-dot.pending` (yellow), `.status-dot.failed` (red).

### 4. Modal Overlay
```html
<div class="modal-overlay" id="modal" onclick="if(event.target===this)closeModal()">
  <div class="modal-content">
    <div class="modal-header">
      <h3 id="modal-title">标题</h3>
      <button class="modal-close" onclick="closeModal()">&times;</button>
    </div>
    <div class="modal-body" id="modal-body"></div>
  </div>
</div>
```

```javascript
function preview(path) {
  document.getElementById('modal').classList.add('show');
  fetch(`/api/content?path=${encodeURIComponent(path)}`)
    .then(r => r.json())
    .then(d => { document.getElementById('modal-body').innerHTML = `<pre>${escapeHtml(d.content)}</pre>`; });
}
```

### 5. Progress Bar
```html
<div class="progress-bar">
  <div class="progress-fill" style="width: 58%"></div>
</div>
```
```css
.progress-bar { height: 6px; background: var(--border); border-radius: 3px; overflow: hidden; }
.progress-fill { height: 100%; background: var(--success); border-radius: 3px; transition: width .5s; }
```

### 6. Toast Notification
```javascript
function toast(msg, type = 'success') {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.style.background = type === 'error' ? '#ef4444' : type === 'warn' ? '#f59e0b' : '#10b981';
  t.style.display = 'block';
  clearTimeout(t._timer);
  t._timer = setTimeout(() => t.style.display = 'none', 3000);
}
```

### 7. Loading Indicator
```html
<div class="loading"></div>
```
```css
.loading {
  display: inline-block; width: 16px; height: 16px;
  border: 2px solid rgba(255,255,255,0.3); border-top-color: white;
  border-radius: 50%; animation: spin .6s linear infinite;
}
@keyframes spin { to { transform: rotate(360deg); } }
```

## Data Flow Pattern

```javascript
function api(url, body) {
  return fetch(url, body ? {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)} : {})
    .then(r => r.json());
}

async function loadData() {
  const data = await api('/api/stats');
  document.getElementById('stat-total').textContent = data.total;
}
```

## CSS Theme System

```css
:root {
  --primary: #2563eb; --success: #10b981; --warning: #f59e0b; --danger: #ef4444;
  --bg: #0f172a; --card: #1e293b; --text: #e2e8f0; --muted: #94a3b8; --border: #334155;
}
```

## Pattern Summary

| Component | Use | JS Complexity |
|-----------|-----|---------------|
| Stats Grid | KPIs at a glance | None (pure HTML) |
| Tabs | Multi-panel navigation | ~10 lines |
| Bid/Item List | Scrollable data rows | ~20 lines |
| Modal | Detail/preview/score overlays | ~15 lines |
| Progress Bar | Percentage visualization | None (pure CSS) |
| Toast | Transient feedback | ~10 lines |
| Loading Spinner | Async state indicator | None (pure CSS) |

## Extended Components

### 8. Action Buttons (Send / Score / Print / Follow-up)

Each data row carries multiple action buttons with async state handling:

```html
<div class="actions">
  <button onclick="sendItem(path)" title="发送">📤</button>
  <button onclick="previewItem(path)">📖</button>
  <button onclick="downloadItem(path)">⬇️</button>
  <button onclick="printItem(path)" title="PDF导出" style="background:#7c3aed">🖨️</button>
  <button onclick="scoreItem(path)" title="评分">📊</button>
  <button onclick="scheduleFollowup(path,name)" title="跟进">⏰</button>
</div>
```

Disable button during async to prevent double-click:

```javascript
async function sendItem(path) {
  const btn = event.target;
  btn.disabled = true; btn.textContent = '⏳';
  try {
    const r = await api('/api/send', {path, email});
    toast(r.success ? '✅ 成功' : '❌ 失败');
  } catch(e) { toast('❌ 错误', 'error'); }
  btn.disabled = false; btn.innerHTML = '📤';
}
```

### 9. Binary Toggle Switch

```html
<div class="toggle-wrap">
  <span>模式A</span>
  <div class="toggle active" id="my-toggle" onclick="this.classList.toggle('active')"></div>
  <span>模式B</span>
</div>
```
```css
.toggle { width:40px; height:22px; background:var(--border); border-radius:11px; cursor:pointer; transition:.3s; }
.toggle.active { background:var(--primary); }
.toggle::after { content:''; position:absolute; top:2px; left:2px; width:18px; height:18px; border-radius:50%; background:white; transition:.3s; }
.toggle.active::after { left:20px; }
```

Read state: `document.getElementById('my-toggle').classList.contains('active')`

### 10. Follow-up Reminder System (localStorage)

No backend needed — pure browser-side scheduling:

```javascript
function scheduleFollowup(path, name) {
  const days = prompt('跟进天后?', '7');
  if (!days || isNaN(days)) return;
  const date = new Date();
  date.setDate(date.getDate() + parseInt(days));
  const reminders = JSON.parse(localStorage.getItem('reminders') || '[]');
  reminders.push({path, name: name.slice(0,30), date: date.toISOString(),
    dateStr: date.toLocaleDateString('zh-CN'), done: false});
  localStorage.setItem('reminders', JSON.stringify(reminders));
  toast(`⏰ ${dateStr}`);
}

function checkFollowups() {
  const now = new Date();
  const overdue = JSON.parse(localStorage.getItem('reminders') || '[]')
    .filter(r => !r.done && new Date(r.date) <= now);
  if (overdue.length > 0) toast(`⏰ ${overdue.length} 过期`, 'warn');
}
```

### 11. Search Bar with Results

```html
<div class="row grow">
  <input type="text" id="search-q" placeholder="搜索..." onkeydown="if(event.key==='Enter')doSearch()">
  <button onclick="doSearch()">搜索</button>
</div>
<div id="search-results" class="result-box" style="display:none"></div>
```

```javascript
async function doSearch() {
  const q = document.getElementById('search-q').value.trim();
  if (!q || q.length < 2) return;
  const el = document.getElementById('search-results');
  el.style.display = 'block'; el.innerHTML = '<div class="loading"></div>';
  const r = await api('/api/search', {query: q});
  el.innerHTML = r.total === 0 ? `<div class="empty-state">未找到 "${q}"</div>`
    : `<div>找到 ${r.total} 条</div>` + r.results.slice(0,15).map(res =>
      `<div class="bid-item" style="cursor:pointer" onclick="preview('${res.path}')">
         <div class="name">${res.name}</div>
         <div class="meta">匹配 ${res.match_count} 处</div>
       </div>`).join('');
}
```

### 12. Quality Score Modal

Per-dimension scores with color-coded progress bars:

```javascript
async function showScore(path) {
  const r = await api('/api/score', {path});
  showModal('📊 评分', `
    <div style="text-align:center;font-size:3rem;font-weight:700;color:${r.score>=85?'green':r.score>=70?'blue':'orange'}">${r.score}<span style="font-size:1rem;color:gray">/100 ${r.rating}</span></div>
    ${Object.entries(r.details||{}).map(([k,v]) => `
      <div><div style="display:flex;justify-content:space-between">${k}<span>${v}/100</span></div>
      <div class="progress-bar"><div class="progress-fill" style="width:${v}%;background:${v>=80?'green':v>=60?'blue':'orange'}"></div></div></div>
    `).join('')}
    <div style="margin-top:12px">${r.rating==='优秀'?'🎯 可直接发送':r.rating==='良好'?'👍 建议增强':'⚠️ 需改进'}</div>
  `);
}
```

### 13. Batch Action Button

```javascript
async function batchSend() {
  if (!confirm('确认批量操作？')) return;
  const r = await api('/api/batch-send', {});
  toast(`✅ ${r.sent}/${r.total}`);
  refreshAll();
}
```

## Pitfalls

- **Discoverability**: Every button in an action bar MUST have a `title` attribute. Icon-only buttons (📖, 📤, 📊) mean nothing to first-time users. The most prominent text in a list item (the item name) should be clickable for the primary action (preview/view).
  
  ```javascript
  // ✅ Good — name is clickable, buttons have titles
  `<div class=\"bid-item\">
    <div class=\"info\">
      <div class=\"name\"><a href=\"javascript:preview('${path}')\" style=\"color:var(--text)\">${name}</a></div>
    </div>
    <div class=\"actions\">
      <button onclick=\"preview('${path}')\" title=\"预览标书\">📖</button>
    </div>
  </div>`
  ```

- **Actionable error messages**: Never just say "请先预览". Tell the user what to DO: "📖 请先点击标书名称或📖按钮预览".

- **HTML escaping in modals**: When showing content in a `<textarea>` for editing, NEVER embed content via `${content}` in innerHTML. Always:
  ```javascript
  el.innerHTML = '<textarea id=\"editor\"></textarea>';
  document.getElementById('editor').value = content; // Safe from HTML escaping
  ```

- **Double-click prevention**: Disable buttons during async operations, re-enable after completion.

- **Large datasets**: For lists >100 items, paginate or use virtual scrolling.
