# 系统仪表盘/统计聚合模式

## 场景

CRUD类全栈应用需要一个首页仪表盘，展示系统运行概览（总数据量、成功率、最近活动等）。

## 核心模式：后端统计聚合 API

### 后端：单端点聚合多表

```python
# backend/app/routers/stats.py
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import CheckBatch, CheckResult, Issue, Material

router = APIRouter()

@router.get("/stats")
def get_stats(db: Session = Depends(get_db)):
    # 1. 各表独立聚合计数
    total_batches = db.query(CheckBatch).count()
    completed = db.query(CheckBatch).filter(CheckBatch.status.in_(["done", "completed"])).count()
    failed = db.query(CheckBatch).filter(CheckBatch.status.in_(["failed", "error"])).count()
    
    pass_checks = db.query(CheckResult).filter(CheckResult.status == "pass").count()
    warn_checks = db.query(CheckResult).filter(CheckResult.status == "warning").count()
    error_checks = db.query(CheckResult).filter(CheckResult.status == "error").count()
    
    # 2. 计算派生指标
    finished = completed + failed
    success_rate = round(completed / finished * 100, 1) if finished > 0 else 0
    
    # 3. 最近活动（排序+限制）
    recent = db.query(CheckBatch).order_by(CheckBatch.created_at.desc()).limit(5).all()
    
    # 4. 注册路由
    return {
        "batches": {"total": total_batches, "completed": completed, ...},
        "checks": {"total": total_checks, "pass": pass_checks, ...},
        "success_rate": success_rate,
        "recent_activity": [...],
    }

# 在 main.py 注册
app.include_router(stats.router, prefix="/api", tags=["统计"])
```

### 前端：仪表盘视图

```
DashboardView.vue          # 页面容器
├── Metric Cards            # 4个指标卡片 (el-row :gutter=16)
│   ├── 总批次数 (蓝色)
│   ├── 已完成 (绿色)
│   ├── 成功率% (橙色)
│   └── 材料总数 (紫色)
├── 检查项统计 + 问题分布  # 双列布局 (14:10)
│   ├── 进度条 (el-progress): 通过/警告/错误
│   └── 问题卡片: 错误/警告/总问题/涉及人员
└── 最近活动表格           # 可点击跳转 (@row-click)
```

### API结构设计原则

1. **单端点聚合**：一个`/stats`返回所有概览数据，避免前端多次请求
2. **COUNT vs SELECT**：只用`query.count()`而非`query.all()`取数，SQLite性能好
3. **派生字段在后端计算**：`success_rate`在后端算好，前端直接展示
4. **最近活动嵌入**：直接塞入stats响应而非单独端点
5. **状态兼容**：使用`in_(["done", "completed"])`一次查两个状态值

## 常见陷阱

### 陷阱1：前端期望`pass_count`但复杂聚合用`pass`

**修复：** 后端统一字段名，或前端用 `d.pass_count || d.pass` 兜底

### 陷阱2：最近活动数据过多导致响应慢

**修复：** `.limit(5)` 硬限制，数据量大时加索引

### 陷阱3：多表JOIN统计性能差

**修复：** 不要JOIN — 各表独立`count()`再组装，SQLite上快一个数量级

## 验证命令

```bash
# 确认统计数据正确
curl -s http://localhost:8001/api/stats | python3 -m json.tool

# 确认数字和实际数据匹配
curl -s http://localhost:8001/api/history?page=1\&page_size=100 | python3 -c "
import sys,json; d=json.load(sys.stdin)
print(f'API总数: {d[\"total\"]}')
"
```
