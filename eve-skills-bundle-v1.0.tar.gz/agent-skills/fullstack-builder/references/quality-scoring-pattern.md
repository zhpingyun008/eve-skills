# AI Content Quality Scoring Pattern

When generating AI content (bids, reports, summaries), add a quality scoring step to evaluate output on multiple dimensions. This enables automated quality gates before sending/using content.

## Architecture

```
generate() → score() → gate(score >= threshold) → send/use
                         ↓ score < threshold
                    regenerate or flag for review
```

## Scoring Dimensions

### 1. Length Score (min 500 chars, ideal 2000+)
```python
if length > 3000: score = 100
elif length > 2000: score = 80
elif length > 1000: score = 60
elif length > 500:  score = 40
else:               score = 20
```

### 2. Structure Score (checks for key sections)
```python
sections = ["公司简介", "需求理解", "技术方案", "实施计划", "质量保证", "商务条款"]
found = sum(1 for s in sections if s in content)
score = int(found / len(sections) * 100)
```

### 3. Customization Score (mentions buyer/requirements in content)
```python
customization = 50
if info:
    buyer = info.get("buyer", "")
    if buyer and buyer in content:
        customization += 25
    requirements = info.get("requirements", [])
    if isinstance(requirements, list):
        matched = sum(1 for r in requirements if str(r)[:8] in content)
        if requirements and matched > 0:
            customization += min(25, int(matched / len(requirements) * 25))
score = min(customization, 100)
```

### 4. Professionalism Score (formatting quality)
```python
professionalism = 50
if "|" in content:        professionalism += 15  # tables
if "- **" in content:     professionalism += 15  # formatted lists
if "## " in content:       professionalism += 10  # headings
if "**" in content:       professionalism += 10  # bold text
score = min(professionalism, 100)
```

## Overall Score & Rating

```python
overall = int(sum(scores.values()) / len(scores))
if overall >= 85:  rating = "优秀"
elif overall >= 70: rating = "良好"
elif overall >= 50: rating = "一般"
else:               rating = "需改进"
```

## Typical Results

| Generation Mode | Avg Score | Avg Length |
|----------------|-----------|------------|
| LLM-powered (DeepSeek) | 85-90 | 4000-5000 chars |
| Static template | 60-70 | 1000-1300 chars |

## Integration

### Web UI Display Modal

Show score with per-dimension progress bars. Color-coded: green >=80, blue >=60, yellow >=50, red <50. Include actionable suggestion text per rating tier.

### When to Score
- After LLM generation → confirm quality vs template fallback
- Before email send → gate low-quality content
- Batch processing → identify outliers needing review
- Dashboard stats → track quality trends

## Pitfalls
- Empty content returns score 0 — gate blocks sending
- Template fallback always scores lower than LLM (expected — template is baseline)
- Customization floor (50/100) when buyer name not matched — flag for improvement
- Section keywords are Chinese — adapt for other languages
