# Responsive CSS for Internal Admin Tools

## Overview
Minimal responsive CSS for internal admin/operations Web UIs. Two breakpoints: 768px (tablet) and 480px (phone). Zero JS, pure CSS.

## CSS (append to existing styles)

```css
/* Tablet & below */
@media (max-width: 768px) {
    body { padding: 8px; margin: 0; }
    .container { padding: 8px; }
    .tabs { overflow-x: auto; gap: 3px; }
    .tab { font-size: 0.65rem; padding: 6px 8px; white-space: nowrap; }
    .stats-grid { grid-template-columns: repeat(2, 1fr); gap: 6px; }
    .card { padding: 10px; }
    .table-wrap { overflow-x: auto; }
    .lead-table { font-size: 0.6rem; }
    .lead-table th, .lead-table td { padding: 3px 4px; }
    .filter-bar { flex-wrap: wrap; }
    .filter-bar input { width: 100%; }
    .bid-item { flex-direction: column; gap: 4px; }
    .btn { padding: 4px 8px; font-size: 0.65rem; }
    h3 { font-size: 0.9rem; }
    .modal-content { width: 95%; margin: 10% auto; }
}

/* Phone & below */
@media (max-width: 480px) {
    .stats-grid { grid-template-columns: repeat(2, 1fr); }
    .tab { font-size: 0.6rem; padding: 4px 6px; }
    .lead-table { font-size: 0.55rem; }
}
```

## What Each Rule Does

| Rule | Purpose |
|------|---------|
| `overflow-x: auto` on tabs | Tabs scroll horizontally instead of wrapping |
| `white-space: nowrap` on tabs | Prevents tab text from wrapping |
| `stats-grid: 2 columns` vs desktop 4 | More readable on small screens |
| `bid-item: flex-column` | Stacks action buttons below content |
| `filter-bar: flex-wrap` | Search/select/buttons wrap to new lines |
| `filter-bar input: 100%` | Search bar fills available width |
| Smaller font/padding everywhere | Fits more content on screen |
| `overflow-x: auto` on tables | Tables scroll horizontally |

## Key Design Principles
- **Zero JS** — Pure CSS, no matchMedia listeners
- **Last in CSS** — Put at bottom of stylesheet to override all other rules
- **Same file** — Keep in same HTML/CSS file, no separate .css needed
- **Progressive enhancement** — Desktop-first, degrade gracefully
- **Admin tools only** — Don't overthink it; internal tools just need to be *usable* on mobile, not *beautiful*
