# 外包结算材料核对系统 — 全栈项目参考架构

## 项目概况

业务领域：IT人力资源外包结算材料自动化核对
SOP规则：24项检查（三轮+补充），基于《结算材料核对SOP V2.0》和《易航科技外包管理办法》
技术栈：FastAPI + SQLAlchemy + SQLite + Vue 3 + Element Plus + Docker

## 架构要点

```
用户上传(7份PDF/XLSX) → 数据提取引擎(文字型PDF/OCR/Excel) → 核对引擎(24项检查) → 报告生成(Markdown/HTML)
```

### 后端分层
- **API层**: FastAPI routers (4组路由, 11个端点)
- **服务层**: file_service, config_service, report_generator
- **提取引擎**: 7种材料各自独立的extractor (pdf_text.py, pdf_ocr.py, excel_parser.py)
- **核对引擎**: 24项检查, 分4轮 (round1.py, round2.py, round3.py, supplement.py)
- **数据层**: SQLAlchemy 10张ORM表 + SQLite

### 关键实现模式

1. **每项检查独立函数** — 每个check接收 `(materials_data, config)`, 返回 `{status, detail, errors, warnings}`
2. **Decimal精确计算** — 所有金额用 `decimal.Decimal`, 不允许 float
3. **OCR回退链** — pdfplumber → pdf2image + pytesseract, 含模糊匹配
4. **报告双版本** — 同时生成 Markdown 和 HTML
5. **并行子Agent生成** — 用 `delegate_task` 并行编写提取引擎和核对引擎, 互不依赖

### 配置文件
- `config.py`: 全局 Settings 类 (含 DEFAULT_CONFIG)
- `config_params` 数据库表: 可覆盖默认值
- 参数优先级: DB配置 > DEFAULT_CONFIG > 硬编码

### 24项检查分布
- Round1 (7项): 姓名/岗位级别/系数比例/考勤天数/金额验证/说明文字/PDF可读性
- Round2 (5项): 账单vs发票/税额/审核表vs发票/主体信息/项目名称
- Round3 (7项): 付款时间/时间逻辑/发票对应/结算周期/出勤说明/考核系数联动/扣减规则
- Supplement (5项): 离场天数/确认金额/非空检查/签署合规/附件完整性
