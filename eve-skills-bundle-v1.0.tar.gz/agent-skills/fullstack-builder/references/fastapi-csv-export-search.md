# FastAPI Product: Search + CSV Export Implementation Pattern

适用于为已有FastAPI产品快速添加数据搜索和CSV导出功能。

## 三层架构

```
engine/booker.py  →  search_transactions()    # SQL动态WHERE
api/server.py     →  POST /api/<资源>/search   # 搜索API
api/server.py     →  GET  /api/<资源>/export   # CSV导出
static/index.html →  搜索栏 + 导出按钮          # 前端
```

## Step 1: Models (api/models.py)

```python
class TxSearchRequest(BaseModel):
    query: str = ""
    date_from: str = ""
    date_to: str = ""
    category: str = ""
    type: str = ""       # 注意: 'type'是Python保留字，这里用作字段名
    limit: int = 50
    offset: int = 0

class TxListResponse(BaseModel):
    transactions: List[TransactionResponse]
    count: int
    total: int = 0       # 新增: 匹配总数(用于前端显示"共N条")
```

⚠️ **陷阱**: 新增model后必须在server.py的import中显式导入。漏导入会报 `NameError: name 'TxSearchRequest' is not defined`。

## Step 2: Engine (engine/booker.py)

```python
def search_transactions(self, query="", date_from="", date_to="",
                        category="", tx_type="",
                        limit=50, offset=0) -> Dict:
    conditions = []
    params = []

    if query:
        conditions.append("(description LIKE ? OR note LIKE ?)")
        params.extend([f'%{query}%', f'%{query}%'])
    if date_from:
        conditions.append("date >= ?")
        params.append(date_from)
    if date_to:
        conditions.append("date <= ?")
        params.append(date_to)
    if category:
        conditions.append("category = ?")
        params.append(category)
    if tx_type:
        conditions.append("type = ?")
        params.append(tx_type)

    where_clause = " AND ".join(conditions) if conditions else "1=1"

    # 先COUNT再SELECT
    count = conn.execute(f"SELECT COUNT(*) FROM t WHERE {where_clause}", params)
    rows = conn.execute(f"SELECT * FROM t WHERE {where_clause} ORDER BY date DESC LIMIT ? OFFSET ?",
                        params + [limit, offset])

    return {"transactions": [...], "total": count}
```

**关键设计点**:
- 动态SQL WHERE拼接，无过滤器时 `1=1` 返回全部
- LIKE用于模糊搜索，date范围用 `>=`/`<=`，精确匹配用 `=`
- 先COUNT再SELECT — 前端需要总记录数显示"共N条"
- 参数列表(params)保持顺序一致，最后追加limit/offset

## Step 3: API (api/server.py)

**搜索 — POST（推荐）**:

```python
@app.post("/api/transactions/search", response_model=TxListResponse)
async def search_transactions(req: TxSearchRequest):
    result = engine.search_transactions(
        query=req.query, date_from=req.date_from, date_to=req.date_to,
        category=req.category, tx_type=req.type,
        limit=req.limit, offset=req.offset
    )
    return TxListResponse(
        transactions=[TransactionResponse(**t) for t in result["transactions"]],
        count=len(result["transactions"]),
        total=result["total"],
    )
```

为什么POST而非GET：过滤器参数多(5+)，GET URL易超长且URL编码复杂。POST body更清晰。

**CSV导出 — GET**:

```python
@app.get("/api/transactions/export")
async def export_transactions(query="", date_from="", date_to="", category="", type=""):
    result = engine.search_transactions(
        query=query, date_from=date_from, date_to=date_to,
        category=category, tx_type=type,
        limit=10000, offset=0
    )
    import csv, io
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["ID", "日期", "描述", "金额", "类型", ...])
    for t in result["transactions"]:
        writer.writerow([t.get("id",""), t.get("date",""), ...])
    csv_content = output.getvalue()
    from fastapi.responses import Response
    return Response(
        content=csv_content,
        media_type="text/csv; charset=utf-8-sig",
        headers={"Content-Disposition": "attachment; filename=export.csv"},
    )
```

**关键**:
- `utf-8-sig` BOM — Excel打开中文CSV不乱码
- `Content-Disposition: attachment` — 浏览器触发下载而非直接显示
- limit=10000作为上限（可根据实际数据量调整）
- 导出参数查TODO：当filter无值时导出全部，有值时导出筛选结果

## Step 4: Frontend (HTML + JS)

**搜索栏**:

```html
<input type="text" id="searchQuery" placeholder="搜索描述..."
       onkeydown="if(event.key==='Enter')loadTransactions()">
<input type="date" id="searchDateFrom">
<input type="date" id="searchDateTo">
<select id="searchType">
    <option value="">全部类型</option>
    <option value="income">收入</option>
    <option value="expense">支出</option>
</select>
<button onclick="loadTransactions()">🔍 搜索</button>
<button onclick="exportCSV()">📥 导出CSV</button>
```

**JS — 条件搜索**:

```javascript
async function loadTransactions() {
    const q = document.getElementById('searchQuery').value.trim();
    const df = document.getElementById('searchDateFrom').value;
    const dt = document.getElementById('searchDateTo').value;
    const tp = document.getElementById('searchType').value;

    if (q || df || dt || tp) {
        // 有过滤器 → 调search API
        const r = await fetch('/api/transactions/search', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({query: q, date_from: df, date_to: dt, type: tp, limit: 100})
        });
    } else {
        // 无过滤器 → 调list API (兼容无搜索数据模式)
        const r = await fetch('/api/transactions?limit=100');
    }
}
```

**JS — CSV导出**:

```javascript
async function exportCSV() {
    const params = new URLSearchParams();
    if (q) params.set('query', q);
    if (df) params.set('date_from', df);
    if (dt) params.set('date_to', dt);
    if (tp) params.set('type', tp);

    const r = await fetch(`/api/transactions/export?${params}`);
    const blob = await r.blob();
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'zhizhang-export.csv';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(a.href);
}
```

**关键设计决策**:
- 搜索使用 `URLSearchParams` 动态构建export URL(复用搜索栏当前状态)
- 无过滤器时export导出全部；有过滤器时导出筛选结果
- 使用 `createObjectURL` 而非base64编码blob

## 已知陷阱

| # | 问题 | 症状 | 修复 |
|---|------|------|------|
| 1 | New model未import | `NameError: name 'TxSearchRequest' is not defined` | 在server.py顶部import新model |
| 2 | `type`是Python保留字 | 前端JSON key用`type`，后端参数名也用`type` | Pydantic model字段名用`type`没问题，FastAPI会自动映射 |
| 3 | CSV中文乱码 | Excel打开中文显示为乱码 | 用 `utf-8-sig` (BOM) 而非 `utf-8` |
| 4 | 前端搜索时无内容 | 首次加载时 `document.getElementById('searchQuery')` 可能为null | 在tab切换时初始化加载，确保DOM已渲染 |
