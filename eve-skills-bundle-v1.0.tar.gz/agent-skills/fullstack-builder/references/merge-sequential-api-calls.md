# 合并顺序API调用 — 前端流程简化模式

## 场景

用户操作流程中包含多个必须串行执行的API调用（如先上传、再核对），
但用户期望一次点击完成全流程。典型例子：上传材料 + 立即启动核对。

## 模式

将原本分离的`handleUpload()` + `handleStartCheck()`合并为单个`handleUploadAndCheck()`。
用户点击一次按钮，前端自动串联调用，完成后跳转到结果页。

## 实现步骤

### 1. 模板层：合并按钮

```html
<!-- ❌ 之前：两个独立按钮 -->
<el-button @click="handleUpload">上传材料</el-button>
<el-button @click="handleStartCheck" :disabled="!uploaded">开始核对</el-button>

<!-- ✅ 之后：单按钮 -->
<el-button @click="handleUploadAndCheck" :loading="processing">
  {{ processing ? '处理中...' : '上传并核对' }}
</el-button>
```

### 2. 逻辑层：串联调用

```js
async function handleUploadAndCheck() {
  if (!validate()) return  // 前端校验

  processing.value = true
  try {
    // Step 1: 调用第一个API
    const result = await firstApi(formData)
    const id = result.id

    // Step 2: 立即调用第二个API
    await secondApi(id)

    // Step 3: 跳转到结果页
    successMessage('操作成功')
    router.push(`/result/${id}`)
  } catch (err) {
    // 区分：Step1失败 vs Step2失败
    errorMessage('操作失败: ' + err.message)
  } finally {
    processing.value = false
  }
}
```

### 3. 移除废弃代码

删除不再使用的独立函数和跟踪变量：

```js
// ❌ 删除
const uploading = ref(false)
const checking = ref(false)
async function handleUpload() { ... }
async function handleStartCheck() { ... }

// ✅ 保留
const processing = ref(false)
async function handleUploadAndCheck() { ... }
```

## 适用条件

| 条件 | 说明 |
|------|------|
| API独立 | 两个端点不相互依赖（或依赖关系是Step1→Step2的单向链） |
| 无中间状态 | 用户不需要在两个步骤之间做任何操作 |
| 错误可合并 | Step2失败时不需要回滚Step1（幂等或可忽略） |

## 常见变体

### 变体A：上传 → 处理 → 跳转
```js
result = await create()      // POST /api/batches
await startCheck(result.id)  // POST /api/batches/{id}/check
router.push(`/check/${id}`)
```

### 变体B：创建 → 跳转（无需第二步）
```js
result = await create()
router.push(`/detail/${result.id}`)
```

### 变体C：多文件上传 → 批量处理
```js
results = await Promise.all(files.map(f => upload(f)))
await batchProcess(results.map(r => r.id))
```

## 陷阱

1. **中间状态丢失** — 如果Step2的API不需要依赖Step1返回的全部字段，确保`id`已经正确提取
2. **错误覆盖** — 不要用同一个catch处理两个步骤的错误。如需区分，用嵌套try/catch或自定义错误类型
3. **loading状态** — 用一个状态变量（`processing`）替代两个（`uploading` + `checking`），简化模板逻辑
4. **禁用条件迁移** — 之前"开始核对"按钮需要等上传完成才可用（`allUploaded`），合并后直接以`files.length > 0`为启用条件
