# Bid-Lead Association Pattern (标书关联线索)

For products that generate documents for leads/opportunities, associate each document with its source lead through filename conventions. This creates a traceable link between leads → generated documents → sending without needing a relational database.

## Pattern: File-Name Entity Linking

Use the filename as the association mechanism — zero schema changes, zero migration needed. When a document is generated for a lead, prefix the filename with `[OrgName]`.

### Backend: save_bid with org

```python
def save_bid(content: str, output_dir: str = None, org: str = "") -> str:
    # ... standard save logic ...
    safe_org = "".join(c if c.isalnum() or c in ' _-' else '_' for c in str(org))[:20]
    prefix = f"[{safe_org}] " if safe_org else ""
    filename = f"标书_{prefix}{safe_name}_{timestamp}.md"
    filepath = os.path.join(output_dir, filename)
    with open(filepath, "w") as f:
        f.write(content)
    return filepath
```

### Backend: Extract org from existing filenames (in recent/listing API)

```python
base = os.path.basename(f)
org = ""
match = re.match(r"标书_\[(.+?)\] (.+)", base)
if match:
    org = match.group(1)
```

### Frontend: Lead Selector in Generate Form

Add a dropdown to the generate form that lists all available leads:

```html
<select id="lead-select" style="...">
    <option value="">自由生成</option>
    <!-- populated by JavaScript on load -->
</select>
```

Populate on page load:

```javascript
async function loadLeadSelector() {
    const leads = await api('/api/leads');
    const sel = document.getElementById('lead-select');
    if (!sel) return;
    sel.innerHTML = '<option value="">自由生成</option>';
    leads.forEach(l => {
        if (l.org) {
            const opt = document.createElement('option');
            opt.value = l.org;
            opt.textContent = `${l.org}${l.email ? ' 📧' : ''}`;
            sel.appendChild(opt);
        }
    });
}
```

Pass org when generating:

```javascript
async function generateBid() {
    const org = document.getElementById('lead-select')?.value || '';
    const data = await api('/api/run', {text, url, use_llm, org: org || undefined});
    // data.org will be in the response
}
```

### Frontend: Bid List Display

Show the associated org in the bid list metadata:

```javascript
`<div class="meta">${b.time} | ${b.size}KB | ${b.org ? '| 🏢 ' + b.org : ''}</div>`
```

### Frontend: Leads Tab Quick-Generate

Add a "生成标书" button in the leads tab that jumps to the generate tab with the org pre-selected:

```javascript
function generateBidForLead() {
    // Check if a lead is checked/selected in the leads table
    const firstChecked = document.querySelector('#leads-table-wrapper input[type=checkbox]:checked');
    if (firstChecked) {
        const row = firstChecked.closest('tr');
        const org = row?.querySelector('td:nth-child(2)')?.textContent?.trim() || '';
        if (org) {
            const sel = document.getElementById('lead-select');
            if (sel) { sel.value = org; }
            switchTab('dashboard');
            toast(`🏢 已选择: ${org}`);
            return;
        }
    }
    switchTab('dashboard');
    toast('请在生成页选择线索组织', 'warn');
}
```

### API Flow

```
/api/run POST {text, org: "北京大学"}
  → generator.py: save_bid(content, org="北京大学")
  → filename: "标书_[北京大学] AI大模型项目_20260611_170901.md"

/api/recent GET
  → file parse: "标书_[北京大学] ..." → org: "北京大学"
  → response: {name, path, org: "北京大学", ...}
```

### Benefits

- **Zero schema migration**: No DB changes needed
- **Backward compatible**: Old files without `[Org]` prefix work identically
- **Human-readable**: Filenames show org context naturally
- **Searchable**: `ls *[北京大学]*` finds all bids for a given org
- **No join logic**: Org is extracted from the filename, not from a foreign key

### Pitfalls

- Org names in filenames need sanitization (remove special chars that break file systems)
- Keep org prefix short (20 chars max) to avoid overly long filenames
- When renaming a lead org, old bid filenames won't automatically update
- HTML entity display: org names with `&` or `<` need safe rendering in Web UI
