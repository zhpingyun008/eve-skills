# Combined Init API Pattern

## Problem
A Web UI with 6+ tabs needs to make 6-8 separate API calls on page load (stats, reports, queue, cold email, leads, bids, etc.). Each call adds ~200ms latency. On slow connections, the page feels sluggish.

## Solution
Create a single `/api/init` endpoint that aggregates all independent data sources into one response.

## Implementation

### Flask Backend

```python
@app.route("/api/init")
def api_init():
    """Combined init data - single call to load everything."""
    from src.reports import generate_daily_report
    from src.ops import get_send_queue
    from src.email_integration import get_cold_email_status
    
    stats = json.loads(api_stats().get_data(as_text=True))
    report = generate_daily_report()
    queue = get_send_queue()
    cold = get_cold_email_status()
    
    return jsonify({
        "stats": stats,
        "report": report,
        "queue": queue,
        "cold": cold,
    })
```

### Frontend Usage

```javascript
// Single init call replaces multiple calls for speed
async function fastInit() {
    try {
        const init = await api('/api/init');
        window._initData = init;  // Cache globally
        renderStats(init.stats);
        renderReport(init.report);
        // ... other renders
    } catch(e) { /* fallback to individual calls */ }
}
```

### What to Combine
Only combine **independent** data sources — ones that don't depend on each other and are always needed on page load:

| Endpoint | Data | Frequency |
|----------|------|-----------|
| `/api/stats` | Counts (total/active) | Every load |
| `/api/reports/daily` | Summary stats | Every load |
| `/api/send-queue` | Queue status | Every load |
| `/api/leads` | Lead list | On leads tab open |

### Avoid Combining
Don't combine endpoints that:
- Are rarely used (admin logs, debug info)
- Depend on user input (search queries)
- Return large datasets (>100KB)
- Are only needed on specific tabs

### Performance Impact
- Before: 6 API calls, ~1200ms total (6 × 200ms network latency)
- After: 1 API call, ~300ms total (1 × 200ms + 100ms server aggregation)
- Improvement: ~60-75% faster initial load
