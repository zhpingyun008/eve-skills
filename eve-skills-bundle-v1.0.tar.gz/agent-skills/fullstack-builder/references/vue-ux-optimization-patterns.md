# Vue+FastAPI UX Optimization Patterns

## Source: 外包结算材料核对系统 (Settlement Check System) — 5轮迭代优化

---

## 1. Detail View Auto-Redirect (+ Skeleton + Empty State)

**Problem:** User clicks sidebar "核对结果" → navigates to `/check` (no ID) → sees empty page.

**Solution:** Auto-redirect to latest record, with skeleton loading + empty state CTA:

```vue
<template>
  <!-- Loading state -->
  <el-skeleton :rows="3" animated v-if="loading && !batchId" />

  <!-- Empty state (no data at all) -->
  <el-empty v-if="!loading && !results && !batchId" description="暂无数据">
    <el-button type="primary" @click="$router.push('/upload')">去创建</el-button>
  </el-empty>

  <!-- Normal content -->
  <template v-if="results">
    ...
  </template>
</template>

<script setup>
onMounted(async () => {
  if (!batchId.value) {
    loading.value = true
    try {
      const result = await getHistoryList({ page: 1, page_size: 1 })
      const items = result.items || []
      if (items.length > 0) {
        router.replace(`/check/${items[0].id}`)
      }
    } catch (e) { /* no data */ }
    finally { loading.value = false }
  }
})
</script>
```

**Three states:**
1. `loading && !id` → Skeleton (data being fetched)
2. `!loading && !id && no data` → Empty (no records exist)
3. `id` or `data` → Normal render

---

## 2. Navigation Bar on Detail View

**Problem:** After navigating to a detail page, user has no quick way to go back to upload or history.

**Solution:** Top navigation bar with key actions:

```vue
<div class="nav-bar">
  <el-button size="small" @click="$router.push('/upload')">
    <el-icon><Upload /></el-icon> 上传材料
  </el-button>
  <el-button size="small" @click="$router.push('/history')">
    <el-icon><Timer /></el-icon> 历史记录
  </el-button>
  <div style="margin-left: auto;">
    <span>批次 #{{ batchId }}</span>
    <span>{{ supplier }} · {{ period }}</span>
    <el-tag>{{ status }}</el-tag>
    <span>{{ createdAt }}</span>
  </div>
</div>
```

---

## 3. Collapsible Round Grouping Cards

**Problem:** 24 check items in a flat table is overwhelming. Backend has `round_no` field but it's not used in the UI.

**Solution:** Group items by `round_no` into collapsible cards with per-round summary:

See `references/frontend-backend-contract-alignment.md` Trap 5 for full implementation.

**Key points:**
- Each round gets its own card with header showing round name + 🟢🟡🔴 counts
- Default: first round expanded, others collapsed
- Click header to toggle
- Fallback: flat table when no round_no data

```vue
<el-card v-for="group in groupedItems" :key="group.round_no">
  <template #header>
    <div @click="toggleRound(group.round_no)">
      <el-icon>{{ expanded ? ArrowDown : ArrowRight }}</el-icon>
      第{{ cn(group.round_no) }}轮 · {{ group.round_name }}
      <span>🟢{{ group.passCount }} 🟡{{ group.warnCount }} 🔴{{ group.errorCount }}</span>
    </div>
  </template>
  <el-table v-if="expandedRounds[group.round_no]" :data="group.items">...</el-table>
</el-card>
```

---

## 4. Frontend Error Alert for Async Operations

**Problem:** Asynchronous operations (LLM calls, background checks) fail silently — user sees no feedback.

**Solution:** Dedicated error state variable + `el-alert`:

```vue
<div v-if="pollError" class="error-banner">
  <el-alert
    :title="pollError"
    type="error"
    show-icon
    :closable="true"
    @close="pollError = ''"
  />
</div>
```

**In polling logic:**
```js
if (status?.status === 'error' || status?.status === 'failed') {
  stopPolling()
  pollError.value = `操作失败: ${status.message || '未知错误'}`
}
```

---

## 5. Computed Adapter Pattern (Response Shape Normalization)

Rather than changing backend or individual components, use a view-layer `computed` to normalize the backend response shape once, then pass the normalized data to child components.

See `references/frontend-backend-contract-alignment.md` Trap 4 for the complete pattern.

---

## Decision Record: Why computed adapters over backend changes

| Approach | Pros | Cons | Chosen? |
|----------|------|------|:-------:|
| Change backend to match frontend | Simple rename | Breaks existing API consumers, tests, other frontends | ❌ |
| Change frontend components to match backend | Backend stays clean | Requires updating N components → N places to maintain | ❌ |
| **View-level computed adapter** | Single transformation point, backend + components untouched | Requires awareness in view layer | ✅ |

---

## Common UX Patterns Index

| Pattern | Use Case | El-Plus Component |
|---------|----------|-------------------|
| Skeleton loading | Initial data fetch, no cached state | `<el-skeleton>` |
| Empty state with CTA | Page has no data at all, user needs direction | `<el-empty>` + `<el-button>` |
| Collapsible cards | Grouped data that should be expandable | `<el-card>` with `<template #header>` |
| Error banner | Async operation failure, recoverable | `<el-alert type="error" :closable>` |
| Navigation bar | Detail page needs context + quick actions | Custom `<div>` with `<el-button>`s |
| Status tag | Real-time status indicator | `<el-tag>` |
| Progress bar | Long-running operation progress | `<el-progress>` inside `<el-card>` |
