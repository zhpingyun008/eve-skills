# Zero-Dependency Canvas Chart Engine

## Overview
Pure JavaScript Canvas chart engine with zero external dependencies. Supports pie charts, bar charts (with gradient fill), and line charts. Built for 智项智造 v2.20 analytics dashboard.

## Architecture
```
Chart Engine (global functions, no classes needed)
├── drawPie(canvasId, data, labels, legendId)
│   ├── Segment calculation from data ratios
│   ├── Percentage labels on slices > 0.3 rad
│   ├── Legend generation with color dots
│   └── Interactive legend (click to highlight)
├── drawBar(canvasId, data, labels, color)
│   ├── Gradient fill (linear top→bottom)
│   ├── Data value labels above bars
│   ├── Truncated x-axis labels (6 char max)
│   └── Support per-bar colors via array
└── drawLine(canvasId, data, labels)
    ├── Grid lines (dashed)
    ├── Area fill gradient under the line
    ├── Data point circles with value labels
    └── X-axis labels with smart truncation
```

## Color Palette
```javascript
const CHART_COLORS = [
  '#3b82f6','#10b981','#f59e0b','#ef4444','#8b5cf6',
  '#ec4899','#06b6d4','#84cc16','#f97316','#6366f1',
  '#14b8a6','#e11d48'
];
```

## Quick Reference

### Pie Chart
```javascript
drawPie('canvas-id', [30, 20, 50], ['Done', 'Failed', 'Pending'], 'legend-id');
```
- Canvas size: `width=200, height=200`
- Center: cx=W/2, cy=H/2, Radius = min(W,H)/2 - 10
- Slices drawn from -π/2 (12 o'clock)
- Auto-hides percentage label for slices < 0.3 rad
- Empty state: "无数据" centered text

### Bar Chart
```javascript
drawBar('canvas-id', [5, 3, 8, 2], ['A', 'B', 'C', 'D'], CHART_COLORS);
```
- Canvas size: `width=350, height=180`
- Gradient fill per bar (color → color+66 alpha)
- `roundRect` with [3,3,0,0] radius (rounded top corners)
- Value label above bar, truncated x-label below
- Empty state: "无数据" centered text

### Line Chart
```javascript
drawLine('canvas-id', [10, 25, 18, 30], ['Jan', 'Feb', 'Mar', 'Apr']);
```
- Canvas size: `width=350, height=180`
- 4 dashed horizontal grid lines
- Area fill (gradient rgba(59,130,246,0.3) → rgba(59,130,246,0.02))
- 2.5px line, 4px radius data dot
- Value label above data point
- Empty state: "无趋势数据" centered text

## Integration Pattern
```javascript
// 1. Add canvas elements to HTML
// 2. Load chart engine in <script>
// 3. Call draws on DOMContentLoaded or tab switch
document.addEventListener('DOMContentLoaded', function() {
  drawPie('c-status', [40,10], ['Done','Processing'], 'legend-status');
  drawBar('c-tags', [5,3], ['政府','园区'], CHART_COLORS);
  drawLine('c-trend', [10,20], ['06月','07月']);
});
```

## Pitfalls
- Canvas `roundRect` requires modern browsers (Chrome 99+). Fallback: use `ctx.fillRect` + separately drawn arcs.
- Safari may not support `roundRect`. Test before production deploy.
- Canvas DPI: on Retina displays, set canvas.width = cssWidth * devicePixelRatio for sharp rendering.
- Legend text may overflow if labels are long — truncate to 6-8 chars.
- Line chart with single point: set xStep=0 guard with `Math.max(data.length-1, 1)`.
