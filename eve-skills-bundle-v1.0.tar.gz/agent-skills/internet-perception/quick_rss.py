#!/usr/bin/env python3
import feedparser
import time
from datetime import datetime, timezone

# Most reliable feeds for security/AI/DevOps
reliable_feeds = [
    "https://hnrss.org/frontpage?count=20",  # Hacker News - tech/security
    "https://techcrunch.com/feed/",           # Tech news - AI/startups
    "https://github.blog/feed/",              # GitHub - DevOps/development
    "https://openai.com/blog/rss.xml",        # OpenAI - AI
    "https://krebsonsecurity.com/feed/",      # Security
    "https://blog.cloudflare.com/rss/",       # Security/Cloud
]

def scan_reliable_feeds():
    print("🔍 RSS Intelligence - Security/AI/DevOps Focus")
    print("=" * 50)
    
    all_entries = []
    
    for feed_url in reliable_feeds:
        try:
            print(f"📡 Scanning: {feed_url.split('/')[-1]}")
            parsed = feedparser.parse(feed_url, timeout=15)
            
            if parsed.bozo and not parsed.entries:
                print(f"❌ Parse error")
                continue
                
            feed_title = parsed.feed.get('title', 'Unknown')
            
            # Get latest 2 entries only
            for entry in parsed.entries[:2]:
                title = entry.get('title', '')
                link = entry.get('link', '')
                
                # Check if relevant to security/AI/DevOps
                if any(keyword in title.lower() for keyword in ['security', 'vulnerability', 'threat', 'cyber', 'ai', 'openai', 'google ai', 'machine learning', 'docker', 'kubernetes', 'aws', 'hack', 'breach', 'vuln']):
                    all_entries.append({
                        'feed': feed_title,
                        'title': title,
                        'link': link
                    })
                    
            time.sleep(1)  # Short delay
            
        except Exception as e:
            print(f"❌ Error: {str(e)[:50]}")
            continue
    
    # Sort by title and show top results
    all_entries.sort(key=lambda x: x['title'].lower())
    
    print(f"\n📰 Found {len(all_entries)} relevant entries:")
    print("-" * 50)
    
    for i, entry in enumerate(all_entries[:6], 1):
        print(f"{i}. {entry['title']}")
        print(f"   📰 {entry['feed']}")
        print()
    
    return all_entries

if __name__ == "__main__":
    scan_reliable_feeds()