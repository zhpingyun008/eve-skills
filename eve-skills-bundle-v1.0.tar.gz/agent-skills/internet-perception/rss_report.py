#!/usr/bin/env python3
"""
RSS Intelligence Report - Security/AI/DevOps Highlights
Refreshed for 2026-06-16 scan.
"""

import feedparser
from datetime import datetime, timezone

FEEDS = {
    "techcrunch": "https://techcrunch.com/feed/",
    "cloudflare": "https://blog.cloudflare.com/rss/",
    "github": "https://github.blog/feed/",
}

def fetch_titles():
    results = {}
    for name, url in FEEDS.items():
        parsed = feedparser.parse(url)
        titles = []
        for e in parsed.entries[:3]:
            titles.append(e.get('title', ''))
        results[name] = titles
    return results

if __name__ == "__main__":
    data = fetch_titles()
    for k, v in data.items():
        print(f"\n=== {k} ===")
        for t in v:
            print(f"  • {t}")
