#!/usr/bin/env python3
"""Identify which RSS feeds hang by testing each individually."""
import sys
sys.path.insert(0, 'scripts')
import yaml
import time
from urllib.request import Request, urlopen
from io import BytesIO
import feedparser
from pathlib import Path

config_path = Path('config/sources.yaml')
with open(config_path) as f:
    config = yaml.safe_load(f)

feeds = config['rss']['feeds']

for url in feeds:
    try:
        start = time.time()
        req = Request(url, headers={'User-Agent': 'Hermes/1.0'})
        resp = urlopen(req, timeout=5)
        data = resp.read()
        parsed = feedparser.parse(BytesIO(data))
        elapsed = time.time() - start
        status = "✅" if parsed.entries else "⚠️"
        print(f"{status} {elapsed:.1f}s | {len(parsed.entries)} entries | {url}")
    except Exception as e:
        elapsed = time.time() - start
        print(f"❌ {elapsed:.1f}s | {type(e).__name__}: {e} | {url}")
