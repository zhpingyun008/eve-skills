#!/usr/bin/env python3
"""
Hermes Internet Perception Engine v2.0
7-channel internet awareness: RSS | GitHub | CVE | Trends | Watch | Deep | Diff
Zero external services — pure Python libraries directly.

Usage:
  perception.py --scan all              # All 5 scan channels
  perception.py --rss                   # RSS only
  perception.py --github                # GitHub only
  perception.py --cve                   # CVE only
  perception.py --trends                # Tech trends only
  perception.py --watch                 # Page change watch only
  perception.py --deep URL              # Deep extract article (trafilatura)
  perception.py --deep                  # Interactive: paste URLs
  perception.py --deep-file FILE        # Batch: URLs from file
  perception.py --diff URL              # Smart diff: compare vs last fetch
  perception.py --report                # Unified Commander report
  perception.py --watch-add URL         # Add URL to watch list
  perception.py --json                  # JSON output (with any command)
"""

import argparse
import hashlib
import json
import os
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional
from urllib.parse import urlparse

# ── Paths ───────────────────────────────────────────────────────────
SKILL_DIR = Path(__file__).resolve().parent.parent  # internet-perception/
CONFIG_PATH = SKILL_DIR / "config" / "sources.yaml"
DATA_DIR = SKILL_DIR / "data"
CACHE_DIR = DATA_DIR / "cache"
WATCH_DIR = DATA_DIR / "watch"

# ── Config loader ───────────────────────────────────────────────────
def load_config():
    """Load sources.yaml with env var substitution."""
    try:
        import yaml
        with open(CONFIG_PATH) as f:
            raw = f.read()
        # Substitute ${ENV_VAR}
        for key, val in os.environ.items():
            raw = raw.replace(f"${{{key}}}", val)
        return yaml.safe_load(raw)
    except ImportError:
        # Fallback: manual parsing for simple YAML (no PyYAML)
        return _simple_yaml_load(CONFIG_PATH)

def _simple_yaml_load(path):
    """Minimal YAML loader for sources.yaml structure."""
    config = {}
    current_section = None
    current_list = None
    with open(path) as f:
        for line in f:
            stripped = line.rstrip()
            if not stripped or stripped.startswith('#'):
                continue
            # Substitute env vars
            for key, val in os.environ.items():
                stripped = stripped.replace(f"${{{key}}}", val)
            indent = len(line) - len(line.lstrip())
            if indent == 0 and stripped.endswith(':'):
                current_section = stripped[:-1]
                config[current_section] = {}
                current_list = None
            elif indent == 2 and stripped.endswith(':') and not stripped.startswith('-'):
                key = stripped[:-1].strip()
                if current_section:
                    config[current_section][key] = {}
                    current_list = key
            elif stripped.startswith('- ') and indent > 0:
                value = stripped[2:].strip().strip('"').strip("'")
                if current_list and current_list in config.get(current_section, {}):
                    if isinstance(config[current_section][current_list], dict):
                        pass
                # For list items in feeds/watch_repos etc
                if current_section:
                    section = config[current_section]
                    # Find the list being built
                    list_key = _find_list_key(section, indent)
                    if list_key is None:
                        list_key = _last_scalar_key(section)
                    if list_key:
                        if list_key not in section:
                            section[list_key] = []
                        if isinstance(section[list_key], list):
                            section[list_key].append(value)
            elif ':' in stripped and indent == 2:
                key, _, val = stripped.partition(':')
                key = key.strip()
                val = val.strip().strip('"').strip("'")
                if current_section:
                    config[current_section][key] = _parse_value(val)
    return config

def _find_list_key(section, indent):
    """Find the most recently added list key."""
    keys = list(section.keys())
    for k in reversed(keys):
        if isinstance(section[k], list):
            return k
    return None

def _last_scalar_key(section):
    keys = [k for k in section if isinstance(section[k], list) or isinstance(section[k], str)]
    return keys[-1] if keys else None

def _parse_value(val):
    if val.lower() in ('true', 'yes'):
        return True
    if val.lower() in ('false', 'no'):
        return False
    try:
        return int(val)
    except ValueError:
        try:
            return float(val)
        except ValueError:
            return val

# ── Helpers ─────────────────────────────────────────────────────────
def ensure_dirs():
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    WATCH_DIR.mkdir(parents=True, exist_ok=True)

def load_cache(filename):
    path = CACHE_DIR / filename
    if path.exists():
        with open(path) as f:
            return json.load(f)
    return {}

def save_cache(filename, data):
    path = CACHE_DIR / filename
    with open(path, 'w') as f:
        json.dump(data, f, indent=2, default=str)

def retry(func, max_attempts=3, delay=2):
    for attempt in range(max_attempts):
        try:
            return func()
        except Exception as e:
            if attempt == max_attempts - 1:
                raise
            time.sleep(delay * (2 ** attempt))

# ═══════════════════════════════════════════════════════════════════
# CHANNEL 1: RSS Intelligence
# ═══════════════════════════════════════════════════════════════════
def _fetch_single_feed(feed_url, last_scan):
    """Fetch and parse a single RSS feed. Uses urllib with 10s timeout to avoid hanging on blocked domains."""
    import feedparser
    from urllib.request import Request, urlopen
    import ssl
    from io import BytesIO
    try:
        # WSL SSL workaround: create unverified context (feeds verified via curl)
        ctx = ssl._create_unverified_context()
        req = Request(feed_url, headers={'User-Agent': 'Hermes/1.0'})
        resp = urlopen(req, timeout=10, context=ctx)
        data = resp.read()
        parsed = feedparser.parse(BytesIO(data))
        if parsed.bozo and not parsed.entries:
            return (feed_url, [], '', f"parse error (bozo)")
        
        feed_title = parsed.feed.get('title', feed_url)
        entries = []
        for entry in parsed.entries[:20]:
            entry_time = _get_entry_time(entry)
            if entry_time and entry_time > last_scan:
                entries.append({
                    'feed': feed_title,
                    'feed_url': feed_url,
                    'title': entry.get('title', ''),
                    'link': entry.get('link', ''),
                    'summary': (entry.get('summary', '') or '')[:300],
                    'published': entry_time,
                    'source': 'rss'
                })
        return (feed_url, entries, feed_title, None)
    except Exception as e:
        return (feed_url, [], '', str(e))


def scan_rss(config, timeout=60):
    """Parse all configured RSS feeds in parallel, return new entries since last scan."""
    feeds = config.get('rss', {}).get('feeds', [])
    max_entries = config.get('rss', {}).get('max_entries_per_scan', 50)
    max_workers = min(len(feeds), 8)  # Max 8 parallel
    cache = load_cache('rss_last_scan.json')
    last_scan = cache.get('timestamp', '1970-01-01T00:00:00')
    feed_states = cache.get('feed_states', {})

    all_entries = []
    errors = []
    scanned = 0

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(_fetch_single_feed, url, last_scan): url for url in feeds}
        for future in as_completed(futures, timeout=timeout + 10):
            try:
                feed_url, entries, feed_title, error = future.result(timeout=timeout)
                scanned += 1
                if error:
                    errors.append(f"{feed_url}: {error}")
                else:
                    all_entries.extend(entries)
                    feed_states[feed_url] = {
                        'last_checked': datetime.now(timezone.utc).isoformat(),
                        'title': feed_title
                    }
            except Exception as e:
                feed_url = futures[future]
                errors.append(f"{feed_url}: timeout/exception")

    # Sort by time, newest first
    all_entries.sort(key=lambda x: x.get('published', ''), reverse=True)
    all_entries = all_entries[:max_entries]

    # Update cache
    save_cache('rss_last_scan.json', {
        'timestamp': datetime.now(timezone.utc).isoformat(),
        'entry_count': len(all_entries),
        'feed_states': feed_states
    })

    return {
        'channel': 'rss',
        'status': 'ok' if not errors else 'partial',
        'feeds_scanned': scanned,
        'feeds_total': len(feeds),
        'feeds_failed': len(errors),
        'new_entries': len(all_entries),
        'entries': all_entries,
        'errors': errors
    }

def _get_entry_time(entry):
    """Extract datetime from feed entry."""
    for attr in ('published_parsed', 'updated_parsed'):
        tp = entry.get(attr)
        if tp:
            try:
                from datetime import datetime as dt
                return dt(*tp[:6]).isoformat()
            except:
                pass
    # Fallback to string
    for attr in ('published', 'updated'):
        ts = entry.get(attr, '')
        if ts:
            return ts
    return None

# ═══════════════════════════════════════════════════════════════════
# CHANNEL 2: GitHub Open-Source Awareness
# ═══════════════════════════════════════════════════════════════════
def scan_github(config):
    """Monitor trending repos, releases, and security advisories."""
    import github
    gh_config = config.get('github', {})
    token = gh_config.get('token') or os.environ.get('GITHUB_TOKEN', '')
    
    # Resolve env var placeholder
    if token and token.startswith('${') and token.endswith('}'):
        env_var = token[2:-1]
        token = os.environ.get(env_var, '')
    
    # Fallback: read from token file
    if not token:
        token_file = gh_config.get('token_file', '')
        if token_file:
            token_file = os.path.expanduser(token_file)
            if os.path.exists(token_file):
                with open(token_file) as f:
                    token = f.read().strip()
    watch_repos = gh_config.get('watch_repos', [])
    trending_cfg = gh_config.get('trending', {})
    check_deps = gh_config.get('releases', {}).get('check_deps', True)

    results = {'channel': 'github', 'trending': [], 'releases': [], 'advisories': [], 'errors': []}

    if not token:
        results['errors'].append('GITHUB_TOKEN not set — skipping GitHub scan')
        results['status'] = 'skipped'
        return results

    try:
        g = github.Github(auth=github.Auth.Token(token))
        cache = load_cache('github_last_scan.json')
        last_scan = cache.get('timestamp', '1970-01-01T00:00:00')

        # Trending repos
        min_stars = trending_cfg.get('min_stars', 50)
        days_back = trending_cfg.get('days_back', 7)
        since_date = (datetime.now() - timedelta(days=days_back)).strftime('%Y-%m-%d')

        query = f"stars:>={min_stars} created:>={since_date}"
        try:
            repos = g.search_repositories(query=query, sort='stars', order='desc')
            for repo in repos[:10]:
                results['trending'].append({
                    'full_name': repo.full_name,
                    'stars': repo.stargazers_count,
                    'description': (repo.description or '')[:200],
                    'language': repo.language or 'Unknown',
                    'url': repo.html_url,
                    'created': repo.created_at.isoformat() if repo.created_at else ''
                })
        except Exception as e:
            results['errors'].append(f"Trending search failed: {e}")

        # Watched repo releases
        if check_deps:
            for repo_name in watch_repos:
                try:
                    repo = g.get_repo(repo_name)
                    releases = repo.get_releases()
                    for rel in releases[:3]:
                        rel_time = rel.created_at.isoformat() if rel.created_at else ''
                        if rel_time > last_scan:
                            results['releases'].append({
                                'repo': repo_name,
                                'tag': rel.tag_name,
                                'name': rel.title or rel.tag_name,
                                'url': rel.html_url,
                                'published': rel_time,
                                'prerelease': rel.prerelease
                            })
                except Exception as e:
                    results['errors'].append(f"Release check {repo_name}: {e}")

        save_cache('github_last_scan.json', {
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'trending_count': len(results['trending']),
            'release_count': len(results['releases'])
        })

        results['status'] = 'ok' if not results['errors'] else 'partial'
    except Exception as e:
        results['status'] = 'error'
        results['errors'].append(str(e))

    return results

# ═══════════════════════════════════════════════════════════════════
# CHANNEL 3: CVE/NVD Security Advisories
# ═══════════════════════════════════════════════════════════════════
def scan_cve(config):
    """Query NVD API for recent high-severity CVEs."""
    import httpx
    cve_config = config.get('cve', {})
    api_base = cve_config.get('nvd_api_base', 'https://services.nvd.nist.gov/rest/json/cves/2.0')
    min_cvss = cve_config.get('min_cvss', 7.0)
    hours_back = cve_config.get('hours_back', 72)  # Wider window for better coverage
    max_results = cve_config.get('max_results', 100)
    match_deps = cve_config.get('match_local_deps', True)

    results = {'channel': 'cve', 'cves': [], 'matched_deps': [], 'errors': []}

    try:
        now = datetime.now(timezone.utc)
        since = now - timedelta(hours=hours_back)

        # NVD API parameters (no cvssV3Severity filter — API rejects CSV multi-value)
        params = {
            'pubStartDate': since.strftime('%Y-%m-%dT%H:%M:%S.000'),
            'pubEndDate': now.strftime('%Y-%m-%dT%H:%M:%S.000'),
            'resultsPerPage': min(max_results, 100)
        }

        with httpx.Client(timeout=30) as client:
            for attempt in range(3):
                try:
                    resp = client.get(api_base, params=params)
                    # NVD may return 404 — log warning, don't silently swallow
                    if resp.status_code == 404:
                        results['errors'].append(f"NVD API 404: {resp.url} — check parameters")
                        data = {'vulnerabilities': []}
                        break
                    # NVD may return 403/429 when rate-limited
                    if resp.status_code in (403, 429):
                        if attempt == 2:
                            resp.raise_for_status()
                        time.sleep(8)  # NVD: 6 req/30s max
                        continue
                    resp.raise_for_status()
                    data = resp.json()
                    break
                except httpx.HTTPStatusError as e:
                    if attempt == 2:
                        raise
                    time.sleep(8)
                except Exception:
                    if attempt == 2:
                        raise
                    time.sleep(4)

        for vuln in data.get('vulnerabilities', []):
            cve_data = vuln.get('cve', {})
            cve_id = cve_data.get('id', '')
            desc = ''
            for d in cve_data.get('descriptions', []):
                if d.get('lang') == 'en':
                    desc = d.get('value', '')[:300]
                    break

            # Extract CVSS score
            metrics = cve_data.get('metrics', {})
            cvss_v3 = metrics.get('cvssMetricV31', [{}])[0]
            cvss_data = cvss_v3.get('cvssData', {})
            score = cvss_data.get('baseScore', 0)
            severity = cvss_data.get('baseSeverity', 'UNKNOWN')

            if score >= min_cvss:
                cve_entry = {
                    'id': cve_id,
                    'score': score,
                    'severity': severity,
                    'description': desc,
                    'published': cve_data.get('published', ''),
                    'url': f'https://nvd.nist.gov/vuln/detail/{cve_id}'
                }
                results['cves'].append(cve_entry)

                # Match against local dependencies
                if match_deps:
                    matched = _match_local_deps(cve_entry)
                    if matched:
                        results['matched_deps'].append({**cve_entry, 'matched_packages': matched})

        save_cache('cve_last_scan.json', {
            'timestamp': now.isoformat(),
            'cve_count': len(results['cves']),
            'matched_count': len(results['matched_deps'])
        })

        results['status'] = 'ok'
    except Exception as e:
        results['status'] = 'error'
        results['errors'].append(str(e))

    return results

def _match_local_deps(cve_entry):
    """Check if a CVE matches any locally installed packages."""
    matched = []
    desc_lower = (cve_entry.get('description', '') + ' ' + cve_entry.get('id', '')).lower()

    # Check Python packages
    try:
        import pkg_resources
        for dist in pkg_resources.working_set:
            pkg_name = dist.project_name.lower()
            if pkg_name in desc_lower and len(pkg_name) > 3:
                matched.append(f"python:{dist.project_name}=={dist.version}")
    except:
        pass

    # Check for well-known package names in description
    known_packages = [
        'django', 'flask', 'react', 'vue', 'angular', 'kubernetes', 'docker',
        'pytorch', 'tensorflow', 'transformers', 'langchain', 'next.js',
        'node.js', 'express', 'fastapi', 'spring', 'laravel', 'rails',
        'redis', 'postgresql', 'mysql', 'mongodb', 'elasticsearch',
        'nginx', 'apache', 'tomcat', 'log4j', 'openssl', 'curl', 'git'
    ]
    for pkg in known_packages:
        if pkg in desc_lower and pkg not in [m.split(':')[-1].split('==')[0] for m in matched]:
            matched.append(f"known:{pkg}")

    return matched

# ═══════════════════════════════════════════════════════════════════
# CHANNEL 4: Technology Trend Detection (Free Multi-Source)
# ═══════════════════════════════════════════════════════════════════
def scan_trends(config):
    """Aggregate trending tech signals from free sources: RSS + GitHub."""
    trends_config = config.get('trends', {})
    max_items = trends_config.get('max_items', 30)
    
    results = {'channel': 'trends', 'topics': [], 'errors': [], 'sources': {}}
    all_signals = []

    # === Source 1: RSS feeds (replaces HN Firebase — blocked from WSL/China) ===
    try:
        rss_result = scan_rss(config, timeout=15)
        if rss_result.get('status') == 'ok' or rss_result.get('status') == 'partial':
            for entry in rss_result.get('entries', []):
                all_signals.append({
                    'title': entry.get('title', ''),
                    'url': entry.get('url', ''),
                    'description': (entry.get('description', '') or '')[:200],
                    'query': 'rss'
                })
            results['sources']['rss'] = {'count': len(rss_result.get('entries', []))}
    except Exception as e:
        results['errors'].append(f'RSS source: {e}')
    
    # === Source 2: GitHub Trending Repos (via API) ===
    try:
        gh_config = config.get('github', {})
        token = gh_config.get('token') or os.environ.get('GITHUB_TOKEN', '')
        if token and token.startswith('${'):
            token = os.environ.get(token[2:-1], '')
        if not token:
            token_file = gh_config.get('token_file', '')
            if token_file:
                token_file = os.path.expanduser(token_file)
                if os.path.exists(token_file):
                    with open(token_file) as f:
                        token = f.read().strip()
        
        if token:
            # Use requests instead of PyGithub (PyGithub search_repositories hangs from WSL)
            import requests as req
            headers = {'Authorization': f'token {token}', 'User-Agent': 'Hermes/1.0', 'Accept': 'application/vnd.github.v3+json'}
            since = (datetime.now() - timedelta(days=7)).strftime('%Y-%m-%d')
            search_url = f'https://api.github.com/search/repositories?q=created:>={since}+stars:>50&sort=stars&order=desc&per_page=15'
            try:
                resp = req.get(search_url, headers=headers, timeout=10)
                if resp.status_code == 200:
                    gh_repos = resp.json().get('items', [])
                    for repo in gh_repos[:15]:
                        all_signals.append({
                            'title': repo.get('full_name', ''),
                            'url': repo.get('html_url', ''),
                            'description': (repo.get('description', '') or '')[:200],
                            'query': 'github-trending'
                        })
                    results['sources']['github_trending'] = {'count': len(gh_repos), 'query': f'created:>={since} stars:>50'}
                else:
                    results['errors'].append(f'GitHub API: HTTP {resp.status_code}')
            except Exception as api_e:
                results['errors'].append(f'GitHub API: {api_e}')
        else:
            results['errors'].append('GitHub source: no token configured')
    except Exception as e:
        results['errors'].append(f'GitHub source: {e}')
    
    # === Synthesize topics ===
    topic_scores = _extract_topics(all_signals)
    results['topics'] = sorted(topic_scores, key=lambda x: x['score'], reverse=True)[:10]
    results['total_signals'] = len(all_signals)
    
    save_cache('trends_last_scan.json', {
        'timestamp': datetime.now(timezone.utc).isoformat(),
        'signals': len(all_signals),
        'topics': results['topics'],
        'sources': results['sources']
    })
    
    results['status'] = 'ok' if not results['errors'] else 'partial'
    return results

def _extract_topics(signals):
    """Extract trending topics from search results."""
    from collections import Counter
    keywords = Counter()

    tech_terms = [
        'ai', 'machine learning', 'deep learning', 'llm', 'gpt', 'claude',
        'rust', 'go', 'typescript', 'python', 'javascript', 'kotlin', 'swift',
        'webassembly', 'wasm', 'edge computing', 'serverless', 'microservices',
        'kubernetes', 'docker', 'terraform', 'devops', 'mlops',
        'langchain', 'crewai', 'autogen', 'langgraph', 'agents', 'rag',
        'react', 'vue', 'svelte', 'next.js', 'nuxt', 'astro',
        'open source', 'security', 'zero trust', 'supply chain',
        'blockchain', 'web3', 'quantum', 'iot',
        'graphql', 'grpc', 'rest api', 'websocket',
        'postgres', 'sqlite', 'redis', 'mongodb', 'clickhouse',
        'playwright', 'cypress', 'jest', 'vitest',
        'github copilot', 'cursor', 'claude code', 'devin'
    ]

    for signal in signals:
        text = (signal.get('title', '') + ' ' + signal.get('description', '')).lower()
        for term in tech_terms:
            if term in text:
                keywords[term] += 1

    return [{'term': term, 'score': count} for term, count in keywords.most_common(15)]

# ═══════════════════════════════════════════════════════════════════
# CHANNEL 5: Custom Page Watch (Change Detection)
# ═══════════════════════════════════════════════════════════════════
def scan_watch(config):
    """Check watched URLs for content changes using Playwright + hashing."""
    watch_config = config.get('watch', {})
    
    # GBrain P1: Support loading URLs from external watchlist file
    urls = watch_config.get('urls', [])
    watchlist_file = watch_config.get('watchlist_file', '')
    if watchlist_file and not urls:
        watchlist_path = Path(os.path.expanduser(watchlist_file))
        if watchlist_path.exists():
            try:
                import yaml
                with open(watchlist_path) as f:
                    wl_data = yaml.safe_load(f)
                urls = wl_data.get('watch', {}).get('urls', [])
            except Exception as e:
                results = {'channel': 'watch', 'changes': [], 'unchanged': [], 'errors': [f"watchlist load failed: {e}"]}
                results['status'] = 'error'
                return results
    state_file = CACHE_DIR / 'watch_states.json'

    results = {'channel': 'watch', 'changes': [], 'unchanged': [], 'errors': []}

    if not urls:
        results['status'] = 'empty'
        return results

    states = {}
    if state_file.exists():
        with open(state_file) as f:
            states = json.load(f)

    try:
        from playwright.sync_api import sync_playwright

        with sync_playwright() as pw:
            browser = pw.chromium.launch(headless=True)
            context = browser.new_context(
                user_agent='Hermes-Internet-Perception/1.0'
            )

            for watch_entry in urls:
                url = watch_entry.get('url', '')
                selector = watch_entry.get('selector', 'body')
                name = watch_entry.get('name', url)

                try:
                    page = context.new_page()
                    # domcontentloaded is fast even on slow WSL; 20s is enough
                    page.goto(url, wait_until='domcontentloaded', timeout=20000)

                    # Extract text content
                    try:
                        element = page.locator(selector).first
                        content = element.inner_text(timeout=5000)
                    except:
                        content = page.content()

                    content_hash = hashlib.sha256(content.encode()).hexdigest()
                    prev_state = states.get(url, {})

                    if prev_state.get('hash') != content_hash:
                        results['changes'].append({
                            'name': name,
                            'url': url,
                            'hash': content_hash,
                            'prev_hash': prev_state.get('hash', 'new'),
                            'checked_at': datetime.now(timezone.utc).isoformat()
                        })

                        # Save screenshot
                        screenshot_dir = WATCH_DIR / hashlib.md5(url.encode()).hexdigest()[:12]
                        screenshot_dir.mkdir(parents=True, exist_ok=True)
                        screenshot_path = screenshot_dir / f"{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
                        page.screenshot(path=str(screenshot_path), full_page=True)
                    else:
                        results['unchanged'].append({'name': name, 'url': url})

                    states[url] = {
                        'hash': content_hash,
                        'last_checked': datetime.now(timezone.utc).isoformat(),
                        'name': name
                    }

                    page.close()
                except Exception as e:
                    results['errors'].append(f"Watch {url}: {e}")

            browser.close()

        with open(state_file, 'w') as f:
            json.dump(states, f, indent=2, default=str)

        results['status'] = 'ok'
    except Exception as e:
        results['status'] = 'error'
        results['errors'].append(str(e))

    return results

# ═══════════════════════════════════════════════════════════════════
# CHANNEL: Add Watch Target
# ═══════════════════════════════════════════════════════════════════
def add_watch(url, selector=None, name=None):
    """Add a URL to the watch list in sources.yaml."""
    watch_entry = {'url': url}
    if selector:
        watch_entry['selector'] = selector
    if name:
        watch_entry['name'] = name
    else:
        watch_entry['name'] = urlparse(url).netloc

    # Append to sources.yaml
    with open(CONFIG_PATH, 'a') as f:
        f.write(f"    - url: {url}\n")
        if selector:
            f.write(f"      selector: \"{selector}\"\n")
        f.write(f"      name: \"{watch_entry['name']}\"\n")
        f.write(f"      interval_minutes: 60\n")

    return watch_entry

# ═══════════════════════════════════════════════════════════════════
# CHANNEL 6: Deep Article Extraction (trafilatura)
# ═══════════════════════════════════════════════════════════════════
def scan_deep_article(urls, max_chars=5000):
    """Fetch full article content via trafilatura + summarize.
    
    Args:
        urls: List of URL strings or a single URL string
        max_chars: Max characters to extract per article
    """
    import trafilatura
    
    if isinstance(urls, str):
        urls = [urls]
    
    results = {'channel': 'deep', 'articles': [], 'errors': []}
    
    for url in urls:
        try:
            html = trafilatura.fetch_url(url)
            if not html:
                results['errors'].append(f'{url}: fetch failed (empty response)')
                continue
            
            text = trafilatura.extract(html, output_format='markdown',
                                       include_links=True, include_images=False,
                                       include_tables=True)
            if not text:
                results['errors'].append(f'{url}: extraction yielded no content')
                continue
            
            # Extract metadata
            metadata = trafilatura.extract(html, output_format='xml')
            title = ''
            if metadata:
                import re
                m = re.search(r'<title>(.*?)</title>', metadata)
                if m:
                    title = m.group(1)
            
            article = {
                'url': url,
                'title': title or urlparse(url).path.split('/')[-1] or url,
                'content': text[:max_chars],
                'char_count': len(text),
                'truncated': len(text) > max_chars
            }
            results['articles'].append(article)
            
        except Exception as e:
            results['errors'].append(f'{url}: {e}')
    
    results['status'] = 'ok' if not results['errors'] else 'partial'
    if not urls:
        results['status'] = 'empty'
    
    return results


# ═══════════════════════════════════════════════════════════════════
# CHANNEL 7: Smart Content Differ (trafilatura)
# ═══════════════════════════════════════════════════════════════════
def scan_smart_diff(url):
    """Fetch a URL, compare against last fetch, return content diff.
    
    Pure Python alternative to changedetection.io Docker service.
    """
    import difflib
    import trafilatura
    
    state_file = CACHE_DIR / 'smart_diff_states.json'
    states = {}
    if state_file.exists():
        with open(state_file) as f:
            states = json.load(f)
    
    results = {'channel': 'diff', 'url': url, 'changed': False, 'diff_summary': '', 'errors': []}
    
    try:
        html = trafilatura.fetch_url(url)
        if not html:
            results['errors'].append('fetch failed')
            results['status'] = 'error'
            return results
        
        text = trafilatura.extract(html, output_format='markdown',
                                    include_links=False, include_images=False)
        if not text:
            results['errors'].append('extraction failed')
            results['status'] = 'error'
            return results
        
        content_hash = hashlib.sha256(text.encode()).hexdigest()
        prev = states.get(url, {})
        
        if prev.get('hash') != content_hash:
            results['changed'] = True
            
            if prev.get('content'):
                old_lines = prev['content'].splitlines()
                new_lines = text.splitlines()
                diff = list(difflib.unified_diff(
                    old_lines, new_lines,
                    fromfile='previous', tofile='current',
                    lineterm=''
                ))
                
                added = sum(1 for l in diff if l.startswith('+') and not l.startswith('+++'))
                removed = sum(1 for l in diff if l.startswith('-') and not l.startswith('---'))
                results['diff_summary'] = f'+{added}/-{removed} lines changed'
                results['diff_preview'] = '\n'.join(diff[:50])  # first 50 lines
            else:
                results['diff_summary'] = 'first capture'
        
        # Save state
        states[url] = {
            'hash': content_hash,
            'length': len(text),
            'content': text[:50000],  # Cap at 50KB
            'checked_at': datetime.now(timezone.utc).isoformat()
        }
        with open(state_file, 'w') as f:
            json.dump(states, f, indent=2, default=str)
        
        results['status'] = 'ok'
    
    except Exception as e:
        results['status'] = 'error'
        results['errors'].append(str(e))
    
    return results

# ═══════════════════════════════════════════════════════════════════
# SYNTHESIS: Unified Commander Report
# ═══════════════════════════════════════════════════════════════════
def generate_report(all_results):
    """Generate a human-readable commander report from all channel results."""

    lines = []
    lines.append("╔══════════════════════════════════════════════════════════╗")
    lines.append("║  HERMES INTERNET PERCEPTION REPORT                      ║")
    lines.append(f"║  Time: {datetime.now().strftime('%Y-%m-%d %H:%M UTC')}                         ║")
    lines.append("╠══════════════════════════════════════════════════════════╣")

    for result in all_results:
        channel = result.get('channel', 'unknown')
        status = result.get('status', 'unknown')

        if channel == 'rss':
            lines.append(f"║  📰 RSS Intelligence                                   ║")
            lines.append(f"║     Feeds: {result.get('feeds_scanned',0)}/{result.get('feeds_total',0)} scanned, {result.get('feeds_failed',0)} failed            ║")
            lines.append(f"║     New entries: {result.get('new_entries',0)}                                 ║")
            for entry in result.get('entries', [])[:5]:
                title = (entry.get('title', '') or '')[:45].ljust(45)
                lines.append(f"║     · {title} ║")
            if result.get('new_entries', 0) > 5:
                lines.append(f"║     ... and {result.get('new_entries',0)-5} more                             ║")

        elif channel == 'github':
            lines.append(f"║  🐙 GitHub Open-Source Awareness                       ║")
            lines.append(f"║     Trending repos: {len(result.get('trending',[]))}                            ║")
            for repo in result.get('trending', [])[:5]:
                name = (f"{repo.get('full_name','')} ★{repo.get('stars',0)}")[:45].ljust(45)
                lines.append(f"║     · {name} ║")
            releases = result.get('releases', [])
            if releases:
                lines.append(f"║     New releases: {len(releases)}                                    ║")
                for rel in releases[:3]:
                    tag = (f"{rel.get('repo','')} → {rel.get('tag','')}")[:45].ljust(45)
                    lines.append(f"║       {tag} ║")

        elif channel == 'cve':
            lines.append(f"║  🛡️  CVE Security Advisories                           ║")
            lines.append(f"║     HIGH/CRITICAL CVEs: {len(result.get('cves',[]))}                            ║")
            for cve in result.get('cves', [])[:5]:
                cve_str = f"{cve.get('id','')} [{cve.get('severity','')} {cve.get('score',0)}]"[:45].ljust(45)
                lines.append(f"║     · {cve_str} ║")
            matched = result.get('matched_deps', [])
            if matched:
                lines.append(f"║     ⚠ MATCHED LOCAL DEPS: {len(matched)}                           ║")

        elif channel == 'trends':
            lines.append(f"║  📈 Technology Trends                                   ║")
            topics = result.get('topics', [])
            for topic in topics[:8]:
                term = f"{topic.get('term','')} (score:{topic.get('score',0)})"[:45].ljust(45)
                lines.append(f"║     · {term} ║")

        elif channel == 'watch':
            lines.append(f"║  🔔 Page Watch                                         ║")
            lines.append(f"║     Changes detected: {len(result.get('changes',[]))}                              ║")
            for change in result.get('changes', [])[:3]:
                name = (change.get('name','') or change.get('url',''))[:45].ljust(45)
                lines.append(f"║     · {name} ║")

        elif channel == 'deep':
            lines.append(f"║  📖 Deep Article Extraction                            ║")
            lines.append(f"║     Articles: {len(result.get('articles',[]))} extracted                          ║")
            for art in result.get('articles', [])[:5]:
                title = (art.get('title','') or art.get('url',''))[:45].ljust(45)
                chars = art.get('char_count', 0)
                lines.append(f"║     · {title} ║")
                lines.append(f"║       {chars} chars {'[TRUNCATED]' if art.get('truncated') else ''}".ljust(55) + "║")

        elif channel == 'diff':
            lines.append(f"║  🔍 Smart Content Differ                               ║")
            changed = '✅ CHANGED' if result.get('changed') else '⏺ UNCHANGED'
            url = (result.get('url','') or '')[:40]
            lines.append(f"║     {changed}: {url}".ljust(55) + "║")
            summary = result.get('diff_summary', '')
            if summary:
                lines.append(f"║     {summary[:50]}".ljust(55) + "║")

        elif channel == 'search':
            lines.append(f"║  🔎 Search: {result.get('query','')[:40]}".ljust(55) + "║")
            items = result.get('items', [])
            for item in items[:10]:
                source = f"[{item.get('source','?')}]"
                title = item.get('title','')[:42]
                lines.append(f"║     {source} {title}".ljust(55) + "║")
            if not items:
                lines.append(f"║     No results found".ljust(55) + "║")

        # Errors
        errors = result.get('errors', [])
        if errors:
            for err in errors[:2]:
                err_str = str(err)[:50].ljust(50)
                lines.append(f"║     ⚠ {err_str} ║")

    lines.append("╚══════════════════════════════════════════════════════════╝")

    return '\n'.join(lines)

# ═══════════════════════════════════════════════════════════════════
# CHANNEL 5: Multi-Source Search Aggregator (Free, Zero-Install)
# ═══════════════════════════════════════════════════════════════════
def scan_search(query, config=None):
    """Aggregate search results from HN, StackOverflow, GitHub, Wikipedia."""
    import urllib.request as ulib
    import concurrent.futures
    
    # Cache check: reuse results for same query within 24h
    cache_key = f"search_{hashlib.md5(query.encode()).hexdigest()[:8]}.json"
    cached = load_cache(cache_key)
    if cached and cached.get('query') == query:
        age = (datetime.now(timezone.utc) - datetime.fromisoformat(cached['timestamp'])).total_seconds()
        if age < 86400:  # 24h
            cached['channel'] = 'search'
            cached['status'] = 'ok'
            return cached
    
    results = {'channel': 'search', 'query': query, 'sources': {}, 'items': [], 'errors': []}
    
    def fetch_hn():
        try:
            url = f'https://hn.algolia.com/api/v1/search?query={ulib.quote(query)}&hitsPerPage=5'
            resp = ulib.urlopen(ulib.Request(url, headers={'User-Agent': 'Hermes/1.0'}), timeout=10)
            data = json.loads(resp.read())
            items = []
            for hit in data.get('hits', [])[:5]:
                title = hit.get('title', '') or hit.get('story_title', '')
                if not title:
                    continue
                items.append({
                    'title': title,
                    'url': hit.get('url', f'https://news.ycombinator.com/item?id={hit.get("objectID")}'),
                    'snippet': (hit.get('story_text') or hit.get('comment_text') or '')[:150],
                    'source': 'HN',
                    'score': hit.get('points', 0) or 0
                })
            return {'count': len(items), 'items': items}
        except Exception as e:
            return {'count': 0, 'items': [], 'error': str(e)}
    
    def fetch_so():
        try:
            url = f'https://api.stackexchange.com/2.3/search?order=desc&sort=votes&intitle={ulib.quote(query)}&site=stackoverflow&pagesize=5'
            resp = ulib.urlopen(ulib.Request(url, headers={'User-Agent': 'Hermes/1.0'}), timeout=10)
            data = json.loads(resp.read())
            items = []
            for item in data.get('items', [])[:5]:
                items.append({
                    'title': item.get('title', ''),
                    'url': item.get('link', ''),
                    'snippet': '',
                    'source': 'SO',
                    'score': item.get('score', 0)
                })
            return {'count': len(items), 'items': items}
        except Exception as e:
            return {'count': 0, 'items': [], 'error': str(e)}
    
    def fetch_github():
        try:
            if config:
                gh_config = config.get('github', {})
                token = gh_config.get('token') or os.environ.get('GITHUB_TOKEN', '')
                if token and token.startswith('${'):
                    token = os.environ.get(token[2:-1], '')
                if not token:
                    token_file = gh_config.get('token_file', '')
                    if token_file:
                        token_file = os.path.expanduser(token_file)
                        if os.path.exists(token_file):
                            with open(token_file) as f:
                                token = f.read().strip()
                if token:
                    import github
                    g = github.Github(auth=github.Auth.Token(token))
                    repos = g.search_repositories(query=query, sort='stars', order='desc')[:5]
                    items = []
                    for repo in repos:
                        items.append({
                            'title': repo.full_name,
                            'url': repo.html_url,
                            'snippet': (repo.description or '')[:150],
                            'source': 'GH',
                            'score': repo.stargazers_count
                        })
                    return {'count': len(items), 'items': items}
            return {'count': 0, 'items': [], 'error': 'No token'}
        except Exception as e:
            return {'count': 0, 'items': [], 'error': str(e)}
    
    # Parallel fetch
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
        futures = {
            executor.submit(fetch_hn): 'hackernews',
            executor.submit(fetch_so): 'stackoverflow',
            executor.submit(fetch_github): 'github',
        }
        for future in concurrent.futures.as_completed(futures, timeout=20):
            source = futures[future]
            try:
                data = future.result(timeout=15)
                results['sources'][source] = data
                results['items'].extend(data.get('items', []))
                if data.get('error'):
                    results['errors'].append(f'{source}: {data["error"]}')
            except Exception as e:
                results['errors'].append(f'{source}: {e}')
    
    # Sort by score descending
    results['items'].sort(key=lambda x: x.get('score', 0), reverse=True)
    results['total'] = len(results['items'])
    results['status'] = 'ok' if results['items'] else 'empty'
    results['timestamp'] = datetime.now(timezone.utc).isoformat()
    
    # Cache result (24h TTL)
    save_cache(cache_key, results)
    
    return results
# ═══════════════════════════════════════════════════════════════════
def main():
    parser = argparse.ArgumentParser(description='Hermes Internet Perception Engine')
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--scan', choices=['all', 'rss', 'github', 'cve', 'trends', 'watch', 'deep', 'diff'],
                       help='Scan channel(s)')
    group.add_argument('--rss', action='store_true', help='Scan RSS only')
    group.add_argument('--github', action='store_true', help='Scan GitHub only')
    group.add_argument('--cve', action='store_true', help='Scan CVE only')
    group.add_argument('--trends', action='store_true', help='Scan trends only')
    group.add_argument('--watch', action='store_true', help='Scan page watch only')
    group.add_argument('--deep', type=str, nargs='?', const='__prompt__', metavar='URL',
                       help='Deep extract article content from URL(s)')
    group.add_argument('--deep-file', type=str, metavar='FILE',
                       help='Deep extract URLs from file (one per line)')
    group.add_argument('--diff', type=str, metavar='URL',
                       help='Smart diff: compare current vs last fetch of URL')
    group.add_argument('--search', type=str, metavar='QUERY',
                       help='Multi-source search: HN + StackOverflow + GitHub')
    group.add_argument('--report', action='store_true', help='Generate unified report from last scans')
    group.add_argument('--watch-add', type=str, metavar='URL', help='Add URL to watch list')
    parser.add_argument('--selector', type=str, help='CSS selector for watch')
    parser.add_argument('--name', type=str, help='Name for watch target')
    parser.add_argument('--max-chars', type=int, default=5000, help='Max chars per article (deep mode)')
    parser.add_argument('--json', action='store_true', help='Output as JSON')

    args = parser.parse_args()

    ensure_dirs()

    # Handle --watch-add
    if args.watch_add:
        result = add_watch(args.watch_add, args.selector, args.name)
        if args.json:
            print(json.dumps(result, indent=2))
        else:
            print(f"✅ Added watch: {result['name']} ({result['url']})")
        return

    # Handle --deep (single URL or interactive)
    if args.deep:
        if args.deep == '__prompt__':
            print("Enter URLs (one per line, empty line to finish):")
            urls = []
            while True:
                line = sys.stdin.readline().strip()
                if not line:
                    break
                urls.append(line)
        else:
            urls = [args.deep]
        result = scan_deep_article(urls, max_chars=args.max_chars)
        if args.json:
            print(json.dumps(result, indent=2, default=str))
        else:
            print(generate_report([result]))
        return

    # Handle --deep-file
    if args.deep_file:
        with open(args.deep_file) as f:
            urls = [line.strip() for line in f if line.strip()]
        result = scan_deep_article(urls, max_chars=args.max_chars)
        if args.json:
            print(json.dumps(result, indent=2, default=str))
        else:
            print(generate_report([result]))
        return

    # Handle --diff
    if args.diff:
        result = scan_smart_diff(args.diff)
        if args.json:
            print(json.dumps(result, indent=2, default=str))
        else:
            print(generate_report([result]))
        return

    # Handle --search
    if args.search:
        config = load_config()
        result = scan_search(args.search, config)
        if args.json:
            print(json.dumps(result, indent=2, default=str))
        else:
            print(generate_report([result]))
        return

    # Determine which channels to scan
    all_channels = ['rss', 'github', 'cve', 'trends', 'watch']
    if args.scan:
        channels = [args.scan] if args.scan != 'all' else all_channels
    elif args.report:
        channels = all_channels
    else:
        channels = []
        if args.rss: channels.append('rss')
        if args.github: channels.append('github')
        if args.cve: channels.append('cve')
        if args.trends: channels.append('trends')
        if args.watch: channels.append('watch')

    config = load_config()
    results = []

    for channel in channels:
        if channel == 'rss':
            results.append(scan_rss(config))
        elif channel == 'github':
            results.append(scan_github(config))
        elif channel == 'cve':
            results.append(scan_cve(config))
        elif channel == 'trends':
            results.append(scan_trends(config))
        elif channel == 'watch':
            results.append(scan_watch(config))

    if args.json:
        print(json.dumps(results, indent=2, default=str))
    else:
        print(generate_report(results))


if __name__ == '__main__':
    main()
