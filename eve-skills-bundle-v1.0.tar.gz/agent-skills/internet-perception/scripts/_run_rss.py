#!/usr/bin/env python3
"""Wrapper: run RSS scan with higher timeout."""
import sys
sys.path.insert(0, '.')
from scripts.perception import load_config, scan_rss, generate_report

config = load_config()
results = scan_rss(config, timeout=120)
print(generate_report(results))
