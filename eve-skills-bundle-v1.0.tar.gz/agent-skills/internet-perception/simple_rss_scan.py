#!/usr/bin/env python3
"""
Simple RSS scanner focusing on reliable feeds for security/AI/DevOps content
"""

import feedparser
import sys
from datetime import datetime, timezone
import time

# Most reliable feeds from WSL/China environment
RELIABLE_FEEDS = [
    "https://hnrss.org/frontpage?count=20",  # HackerNews (mirror)
    "https://techcrunch.com/feed/",           # Tech news
    "https://github.blog/feed/",              # GitHub releases
    "https://threatpost.com/feed/",            # Security news
    "https://blog.cloudflare.com/rss/",       # Security/Infrastructure
]

def fetch_feed(feed_url):
    """Fetch a single RSS feed with timeout"""
    try:
        print(f"Fetching: {feed_url}")
        parsed = feedparser.parse(feed_url)
        
        if parsed.bozo and not parsed.entries:
            return None, f"Parse error"
        
        feed_title = parsed.feed.get('title', 'Unknown')
        entries = []
        
        for entry in parsed.entries[:5]:  # Limit to 5 entries per feed
            entry_time = entry.get('published_parsed')
            if entry_time:
                entry_time = datetime(*entry_time[:6], tzinfo=timezone.utc)
                if (datetime.now(timezone.utc) - entry_time).days <= 7:  # Last 7 days
                    entries.append({
                        'feed': feed_title,
                        'title': entry.get('title', ''),
                        'link': entry.get('link', ''),
                        'summary': (entry.get('summary', '') or '')[:200],
                        'published': entry_time.isoformat() if entry_time else ''
                    })
        
        return feed_title, entries
    except Exception as e:
        return None, str(e)

def main():
    """Main function to scan reliable feeds"""
    all_entries = []
    
    for feed_url in RELIABLE_FEEDS:
        feed_title, entries_or_error = fetch_feed(feed_url)
        
        if isinstance(entries_or_error, list) and entries_or_error:
            all_entries.extend(entries_or_error)
            print(f"✓ {feed_title}: {len(entries_or_error)} entries")
        else:
            print(f"✗ {feed_url}: {entries_or_error}")
        
        time.sleep(1)  # Small delay between requests
    
    # Sort by time, newest first
    all_entries.sort(key=lambda x: x.get('published', ''), reverse=True)
    all_entries = all_entries[:10]  # Limit to top 10 entries
    
    # Output results
    print(f"\n=== RSS Intelligence Report ===")
    print(f"Total entries: {len(all_entries)}")
    print(f"Scan time: {datetime.now(timezone.utc).isoformat()}")
    
    for i, entry in enumerate(all_entries[:5], 1):  # Show top 5
        print(f"\n{i}. [{entry['feed']}] {entry['title']}")
        print(f"   Link: {entry['link']}")
        if entry['summary']:
            print(f"   Summary: {entry['summary']}...")
    
    return all_entries[:5]

if __name__ == "__main__":
    main()