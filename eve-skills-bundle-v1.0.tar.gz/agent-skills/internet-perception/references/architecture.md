# Internet Perception — Architecture Reference

## Design Philosophy

Pure Python, zero external services. Every channel uses a Python library directly:
- No Docker dependency (WSL-friendly)
- No external REST services beyond public APIs
- All state stored in local JSON cache files
- Stateless scans: each `--scan` invocation is independent

## Competitive Analysis

| Feature | Claude Code | Cursor | Devin | Aider | Codex CLI | **Hermes** |
|---------|------------|--------|-------|-------|-----------|------------|
| RSS Monitoring | ❌ | ❌ | ❌ | ❌ | ❌ | **✅ feedparser** |
| GitHub Trending | ❌ | ❌ | ❌ | ❌ | ❌ | **✅ PyGithub** |
| CVE/NVD Alerts | ❌ | ❌ | ❌ | ❌ | ❌ | **✅ NVD API** |
| Tech Trend Detect | ❌ | ❌ | ❌ | ❌ | ❌ | **✅ HN+GH Dual-Source** |
| Multi-Source Search | ❌ | ❌ | ❌ | ❌ | ❌ | **✅ HN+SO+GH Agg** |
| Deep Article Extract | ❌ | ❌ | ❌ | ❌ | ❌ | **✅ trafilatura** |
| Smart Content Diff | ❌ | ❌ | ❌ | ❌ | ❌ | **✅ trafilatura+difflib** |
| Page Change Watch | ❌ | ❌ | ❌ | ❌ | ❌ | **✅ Playwright** |
| Scheduled Awareness | ✅ Routines | ❌ | ❌ | ❌ | ❌ | **✅ Cron** |
| Web Browsing | ✅ Chrome ext | ❌ | ✅ Built-in | ❌ | ❌ | ✅ Playwright |
| Real-time Push | ✅ Channels | ❌ | ❌ | ❌ | ❌ | ❌ (future) |

## Data Flow

```
Cron Trigger
    │
    ▼
perception.py --scan <channel>
    │
    ├── Load config (sources.yaml + env vars)
    ├── Fetch data (feedparser / PyGithub / httpx / Playwright)
    ├── Cache results (JSON to data/cache/)
    ├── Diff against previous scan
    ├── LLM summary (via agent's model)
    └── Output report (text / JSON / write to file)
```

## Cache Structure

```
data/
├── cache/
│   ├── rss_last_scan.json      # {timestamp, entries: [...], feed_states: {...}}
│   ├── github_last_scan.json   # {timestamp, trending: [...], releases: [...]}
│   ├── cve_last_scan.json      # {timestamp, cves: [...], matched_deps: [...]}
│   ├── trends_last_scan.json   # {timestamp, topics: [{term, score, sources}]}
│   └── watch_states.json       # {url: {last_hash, last_checked, screenshot}}
└── watch/
    └── <url_hash>/             # Per-URL watch data (screenshots, diffs)
```

## Resource Budget

| Component | RAM | CPU (idle) | Disk | Network |
|-----------|-----|-----------|------|---------|
| feedparser | ~5MB | negligible | ~1MB cache | ~500KB/scan |
| PyGithub | ~10MB | negligible | ~100KB cache | ~50KB/scan |
| Playwright | ~150MB | negligible | ~1MB/scan | varies |
| HN/GitHub Trends | ~2MB | negligible | ~50KB cache | ~20KB/scan |
| Channel 8 (HN+SO+GH) | ~2MB | negligible | ~10KB cache | ~30KB/scan |
| trafilatura | ~50MB | negligible | ~5MB temp | ~100KB/article |
| **Total (typical scan)** | **~170MB** | **<5%** | **~5MB** | **<1MB/scan** |

No Docker overhead. Entire module runs in-process with the agent.

## Error Handling

Each channel has:
1. 10s timeout per external request
2. 3 retries with exponential backoff (1s, 2s, 4s)
3. Graceful degradation: if one channel fails, others still run
4. Self-healer integration: errors logged to healer incident journal

## Extension Points

- **New RSS feeds**: Add to `sources.yaml` → `rss.feeds`, no code change
- **New watch repos**: Add to `sources.yaml` → `github.watch_repos`
- **New search queries**: Add to `sources.yaml` → `trends.queries`
- **New watch URLs**: `perception.py --watch-add URL --selector SELECTOR`
- **New channels**: Subclass `PerceptionChannel` base class

## Future Roadmap

- P1: Multi-agent perception → one agent per channel, parallel execution
- P1: Discord/Telegram push notifications on critical alerts
- P2: Historical trend analysis → detect acceleration/deceleration of topics
- P2: Cross-channel correlation → "RSS + GitHub + Trends all signal X"
- P3: Real-time push (WebSocket/SSE) → replace polling for time-sensitive sources
