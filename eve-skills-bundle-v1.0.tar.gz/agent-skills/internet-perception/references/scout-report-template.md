# Scout Report Template — Classification & Structure

## Report Sections (in order)

```
# 🕵️ Scout Report — <Topic Area>
**Generated:** <timestamp> UTC
**Source:** Internet Perception (Tier 2 HN Algolia + Tier 3 GitHub REST API + Trends)

---

## 🔥 Top 3 Findings

Each finding:
- **Title + Key Metric** (point score / star count / timestamps)
- 1-2 line description
- **Signal:** Strategic relevance to our position (comp, partner, lead, tech watch)

---

## 📊 Market Intelligence

Table: Signal | Source | Relevance

Relevance classifications (use these emoji prefixes):

| Tag | Meaning | When to use |
|-----|---------|-------------|
| 💰 **Lead** | Partner / outreach target | YC-funded startups, adjacent products for integration, potential clients |
| 📋 **Comp** | Competitor | Direct overlap with our offering, same problem space being solved |
| 🔬 **Tech** | Technology to watch | Interesting architecture choice, new framework, research paper |
| 📊 **Sentiment** | Market sentiment signal | HN debates, questions about ROI, pain points discussed |
| 📈 **Trend** | Rising/falling metric | Score changes, star velocity, new entries on trends heat map |

---

## 🎯 Lead Opportunities

Numbered actionable steps. Each should reference a specific finding above and propose a concrete next action (partner evaluation, competitor analysis, outreach).

---

## 📈 Trends (Topic Heat Map)

```
- **ai** ████████████ (9)
- **claude code** ██ (2)
- **agents** ██ (2)
```

Track delta (Δ) from previous report. New appearance = rising attention. Score drop = cooling topic.
```

## Lead Scoring Rubric

| Criterion | High (3pts) | Medium (2pts) | Low (1pt) |
|-----------|-------------|---------------|-----------|
| **Relevance to CMMI5** | Directly overlaps pipeline/orchestration | Adjacent (observability, quality) | Tangential (general AI tooling) |
| **Funding/Momentum** | YC-backed, 100+ HN pts, 5K+ GH stars | 50+ HN pts, 500+ GH stars | <50 pts/stars |
| **Openness to partnership** | Open source, clear API/docs | Open source but limited API | Closed source/commercial |
| **Urgency** | Growing rapidly (stars doubling vs last scan) | Stable growth | Flat/declining |

- 9-12pts: **Immediate action** (evaluate partnership or counter-strategy)
- 5-8pts: **Monitor** (add to watchlist, check next scan)
- 1-4pts: **Log only** (background awareness)

## Previous Report Delta

Always read `scout-report-latest.md` before writing:
- Compare Trends heat map scores
- Check if previously flagged leads have grown/changed
- Note any competitors that disappeared from results (may signal pivot/demise)
- Carry forward still-relevant findings with updated scores
