# Cron-Mode Competitive Intel Scan Recipe

## When to Use

Running a full-scope competitive intelligence scan from **cron context** where:
- `execute_code` is blocked (Hermes `approvals.cron_mode` denies it)
- No interactive prompts possible
- Channel 2 (`--github`, PyGithub) always times out
- Channel 8 (`--search`) may crash with `⚠ github: list index out of range`
- RSS returns "New entries: 0" (normal cache behavior)
- Need results under 5 min total

## Parallel Dispatch Pattern

Fire all queries via **separate `terminal()` calls** (shell-level `&` backgrounding is blocked in foreground terminal mode — use one terminal() per HTTP request):

```bash
# Terminal call 1: Trends (~5s)
python3 perception.py --trends

# Terminal call 2: RSS (~3s)
python3 perception.py --rss

# Terminal call 3-8: HN Algolia direct queries (Tier 2, ~15s total)
curl -s -o /tmp/hn_q1.json 'https://hn.algolia.com/api/v1/search?query=AI+coding+agent&tags=story&hitsPerPage=10'
curl -s -o /tmp/hn_q2.json 'https://hn.algolia.com/api/v1/search?query=agent+sandbox+security&tags=story&hitsPerPage=10'
curl -s -o /tmp/hn_q3.json 'https://hn.algolia.com/api/v1/search?query=coding+agent+guardrails+sandbox&tags=story&hitsPerPage=10'
curl -s -o /tmp/hn_q4.json 'https://hn.algolia.com/api/v1/search?query=AI+agent+orchestration+loop&tags=story&hitsPerPage=10'
curl -s -o /tmp/hn_q5.json 'https://hn.algolia.com/api/v1/search?query=agent+skill+learning+code+generation&tags=story&hitsPerPage=10'
curl -s -o /tmp/hn_q6.json 'https://hn.algolia.com/api/v1/search?query=software+factory+SDLC+automation&tags=story&hitsPerPage=10'

# Terminal call 9-13: GitHub REST API (Tier 3, ~15s total)
TOKEN=$(python3 -c "import os; print(open(os.path.expanduser('~/.hermes/.github_token')).read().strip())")
curl -s -o /tmp/gh_q1.json -H "Authorization: Bearer $TOKEN" 'https://api.github.com/search/repositories?q=AI+coding+agent+created:>2026-06-01&sort=stars&order=desc&per_page=15'
curl -s -o /tmp/gh_q2.json -H "Authorization: Bearer $TOKEN" 'https://api.github.com/search/repositories?q=agent+sandbox+coding+guardrails&sort=stars&order=desc&per_page=10'
curl -s -o /tmp/gh_q3.json -H "Authorization: Bearer $TOKEN" 'https://api.github.com/search/repositories?q=SDLC+automation+pipeline&sort=stars&order=desc&per_page=10'
curl -s -o /tmp/gh_q4.json -H "Authorization: Bearer $TOKEN" 'https://api.github.com/search/repositories?q=coding+agent+orchestration+loop&sort=stars&order=desc&per_page=10'
curl -s -o /tmp/gh_q5.json -H "Authorization: Bearer $TOKEN" 'https://api.github.com/search/repositories?q=agent+skill+learning+code+generation&sort=stars&order=desc&per_page=10'
```

## After Parallel Dispatch — Batch Parse

Once all HN and GH files are downloaded, parse them in single `python3 -c` calls:

### Parse HN Algolia (Tier 2)
```bash
python3 -c "
import json
queries = ['AI coding agent','Agent sandbox security','Coding agent guardrails','Agent orchestration loop','Agent skill learning','Software factory SDLC']
files = ['/tmp/hn_q1.json','/tmp/hn_q2.json','/tmp/hn_q3.json','/tmp/hn_q4.json','/tmp/hn_q5.json','/tmp/hn_q6.json']
seen = set()
for fname,label in zip(files,queries):
    raw = open(fname).read(); d = json.loads(raw,strict=False)
    for h in d.get('hits',[]):
        key = h.get('url','') or h.get('objectID','')
        if key not in seen:
            seen.add(key); pts = h.get('points',0); title = h.get('title','')
            print(f'[{pts:>4}pts] {title[:90]}')
print(f'Total unique: {len(seen)}')
"
```

### Parse GitHub REST (Tier 3)
```bash
python3 -c "
import json
d = json.loads(open('/tmp/gh_q1.json').read(), strict=False)
print(f'AI coding agent repos: {d.get(\\\"total_count\\\",0)} total')
for r in d.get('items',[])[:15]:
    topics = ','.join(r.get('topics',[])[:4])
    print(f'★{r[\\\"stargazers_count\\\"]:>6} {r[\\\"full_name\\\"]} | {r.get(\\\"description\\\",\\\"\\\")[:90]}')
    print(f'    Lang:{r.get(\\\"language\\\",\\\"N/A\\\")} Created:{r[\\\"created_at\\\"][:10]} [{topics}]')
"
```

This batch-download-then-parse pattern is the fastest cron-compatible competitive intel scan — ~30s total for 6 HN + 5 GH queries vs minutes for sequential Channel 8 with fallbacks.

### If RSS returns "New entries: 0":
→ Normal (Pitfall #22). Feedparser tracks seen entries — nothing new published. Don't retry.

## Proven Query Patterns (curated 2026-07-02)

| Query | API | Result Count | Best For |
|-------|-----|-------------|----------|
| `AI+coding+agent+created:>2026-06-01&sort=stars&order=desc&per_page=10` | GitHub REST | 12,224 | *(Jul 23)* Broad AI dev tools sweep — richest single query, up from 11,989 (Jul 22), 11,728 (Jul 21) |
| `AI+coding+agent+guardrails+orchestration+created:>2026-06-01` | GitHub REST | 2 | Narrow orchestration — use for targeted scouting |
| `AI+coding+agent+skills+ecosystem+created:>2026-06-01` | GitHub REST | 9 | Skill ecosystem — guard-skills, self-learning-skills |
| `AI+agent+sandbox+security+created:>2026-06-01` | GitHub REST | 96 | Sandbox implementations — AgentProvenance, agent-lock, awesome-ai-coding-sandboxes |
| `AI+coding+agent+created:>2026-06-01` | GitHub REST | **11,728** *(Jul 21)* | Broad AI dev tools sweep — richest single query, growing |
| `AI+agent+orchestration+loop` | GitHub REST | 293 | *(Jul 2)* Orchestration layer — agentops, nexent, cc10x, figaro |
| `AI+agent+orchestration+workflow` | GitHub REST | 1,127 | *(Jul 22 UPDATED)* **Orchestration ecosystem explosion** — homerail, pi-workflow, Clutch, open-dynamic-workflow |
| `agent+skill+learning+code+generation` | GitHub REST | 5 | Skill ecosystem — narrow but targeted |
| `agent+sandbox+coding+guardrails` | GitHub REST | 23 | Sandbox/guardrail implementations — SoloDawn, agentjail |
| `terminal+coding+agent+created:>2026-06-01` | GitHub REST | 1,205 | *(Jul 22 NEW)* Terminal-native coding agents — dao-code, klaatcode, boring-computers, pagecast |
| `SDLC+automation+pipeline` | GitHub REST | 30 | SDLC pipeline tools — niche category |
| `AI+coding+agent` | HN Algolia | 10 hits | **Core query** — returns highest-point stories |
| `agent+sandbox+security` | HN Algolia | 10 hits | Sandbox/security launches — Runtime YC, Nucleus |
| `AI+agent+development+tools+automation` | HN Algolia | 10 hits | Market sentiment + startup launches |
| `AI+software+factory+SDLC+automation+platform` | HN Algolia | 8 hits | Factory terminology — still niche, only Klyve |

### Fresh Batch Results (2026-07-02 scan)

**Top repos by star count with 3-day growth deltas:**
| Repo | Stars (Jul 2) | Stars (Jun 29) | Delta (3 days) | Category |
|------|---------------|----------------|-------------|----------|
| ponytail | 70,445 | 64,336 | +6,109 (+9.5%) | Trend — crossed 70K inflection |
| MiMo-Code | 11,216 | 10,996 | +220 (+2%) | Comp — Xiaomi-backed, slowing |
| omnigent | 5,946 | 5,299 | +647 (+12%) | Comp — meta-orchestrator, steady |
| loop-engineering | 4,687 | 3,690 | +997 (+27% velocity) | Tech — still anomaly |
| baoyu-design | 2,223 | 2,117 | +106 (+5%) | Tech — Agent Skill design, steady |
| guard-skills | 942 | NEW | NEW | Lead — quality gates, CMMI5 alignment |
| fanbox | 838 | NEW | NEW | Tech — vibe coding cockpit |
| self-learning-skills | 742 | NEW | NEW | Lead — self-improving skills |
| sandboxd | 705 | NEW | NEW | Comp — self-hosted sandboxes, Go |

**New HN launches (pts):**
- Opencode (1,274pts) — OSS AI coding agent launch
- Crush/charmbracelet (367pts) — terminal AI agent
- Plandex v2 (257pts) — OSS agent for large projects

### Fresh Batch Results (2026-07-12 scan)

**Top repos by star count with 2-day growth deltas (vs Jul 11 report):**
| Repo | Stars (Jul 12) | Stars (Jul 11) | Delta (1 day) | Category |
|------|----------------|----------------|--------------|----------|
| ponytail | 80,766 | 80,149 | +617 (+0.8%) | Trend — decelerating (was +2.7%/2d) |
| MiMo-Code | 11,816 | 11,766 | +50 (+0.4%) | Comp — stable |
| loop-engineering | 7,092 | 6,948 | +144 (+2.1%) | Tech — still growing well |
| omnigent | 7,087 | 7,005 | +82 (+1.2%) | Comp — decelerating (was +3.4%/2d) |
| html-anything | 7,699 | 7,680 | +19 (+0.2%) | **📈 PLATEAUED** — was +8.6%/2d, now flat. **Reverse velocity anomaly.** |
| html-video | 3,932 | 3,920 | +12 (+0.3%) | Tech — plateaued with sibling |
| baoyu-design | 2,538 | 2,223 (Jul 2) | +315 (+14%/10d) | Tech — Claude Design Agent Skill, still accelerating |
| guard-skills | 981 | 975 | +6 (+0.6%) | Lead — quality gates, steady growth |
| fanbox | 913 | 904 | +9 (+1.0%) | Tech — vibe cockpit, overtaking guard-skills trajectory |
| self-learning-skills | 842 | 832 | +10 (+1.2%) | Lead — still growing |
| sandboxd | 717 | 705 | +12 (+1.7%) | Comp — dev sandbox infra, still growing |
| metaharness | 463 | NEW | NEW | Comp — scaffold agent harnesses with MCP |

**New HN stories (pts):**
- Opencode 319pts (2nd front-page story in 24h) + critical RCE vulnerability disclosed
- JACoB 40pts — open-source AI coding agent for productivity
- AI SDLC Scaffold 27pts — repo template for AI-assisted development
- ChatML 6pts — Run Claude Code parallel sessions in a desktop app
- OctopusGarden 8pts — autonomous software factory ("specs in, code out")
- Devplan 6pts — generate specs and coding prompts with deep context
- Agensi 1pt — curated marketplace for AI agent skills (SKILL.md!)
- Klyve 1pt — local-first software factory for solo devs

**Key deltas vs Jul 11 report:**
1. **html-anything plateau** — First validated "reverse velocity anomaly." Nov 11-12: acceleration collapsed from +8.6%/2d to +0.2%/1d. Narrative reversal — novelty spike fading. **Pattern**: when a repo posts a velocity anomaly (3×+), check again in 48h — if growth dropped below 1%/d, downgrade to "novelty spike."
2. **OpenCode ecosystem forming** — Two front-page HN stories in 24h (1,274pts + 319pts), plus 3+ third-party tools (OpenChamber desktop UI, HolyCode Docker, Remote-OpenCode Discord). High "ecosystem velocity" despite story decay. Track as separate metric: `★ ecosystem: N components`.
3. **ponytail ecosystem steady** — fanbox ★913 (+1%), guard-skills ★981, self-learning-skills ★842 all organic growth. Fanbox overtaking guard-skills trajectory.
4. **Software factory niche emerging** — OctopusGarden (8pts) + Klyve (1pt) = 2 entries in a single scan. Previously 0.
5. **baoyu-design ★2,538** — Still accelerating (+14% over 10 days). Claude Design as Agent Skill. Watch for continued growth.

### Fresh Batch Results (2026-07-21 scan)

**Top repos by 4-day growth deltas (vs Jul 17 scan):**
| Repo | Stars (Jul 21) | Stars (Jul 17) | Delta (4 days) | Category |
|------|----------------|----------------|----------------|----------|
| ponytail | 86,653 | 84,659 | +1,994 (+2.4%) | Trend — organic, decelerating gradually |
| MiMo-Code | 12,260 | 12,153 | +107 (+0.9%) | Comp — flatlining, losing steam |
| **loop-engineering** | **8,837** | **8,134** | **+703 (+8.6%)** | **Comp — ACCELERATING, gap over omnigent 1,286★** |
| omnigent | 7,551 | 7,388 | +163 (+2.2%) | Comp — slowing, losing to loop |
| baoyu-design | 2,733 | 2,629 | +104 (+4.0%) | Tech — steady |
| guard-skills | 1,076 | 1,026 | +50 (+4.9%) | Tech — steady acceleration |
| fanbox | 935 | 923 | +12 (+1.3%) | **📈 PLATEAUING** — novelty spike fading |
| self-learning-skills | 899 | 877 | +22 (+2.5%) | Lead — moderate growth |
| **nexent** | **5,751** | NEW | NEW | **🔥 Comp — zero-code agent generation, #5 in category** |
| **SoloDawn** | **302** | NEW | NEW | **🔥 Comp — 3 quality gates, 31 rules, direct guard-skills overlap** |
| **VulnHunter** | **598** | NEW | NEW | Tech — Capital One agentic security |
| **mantis (Google)** | **472** | NEW | NEW | Tech — Google security review skills for agents |
| **brain0** | **465** | NEW | NEW | Comp — audit/attestation decision graph |
| **agentops** | **414** | NEW | NEW | Comp — operating loop + multi-agent orchestration |
| **agentjail** | **63** | NEW | NEW | **🔥 Comp — policy guardrails, direct sandbox-exec overlap** |
| **cc10x** | **154** | NEW | NEW | Tech — 1 router · 9 agents loop engine |
| **Klyve** | **GONE** | existed (1pt) | **DELETED** | Sentiment — solo-dev SDLC concept couldn't sustain |

**New HN stories (pts):**
- OpenCode 1,274pts — still dominant terminal agent story (persistent since Jul 2)
- Crush 367pts — glamorous terminal AI agent
- Plandex v2 257pts — OSS agent for large projects
- **Cq 225pts** — "Stack Overflow for AI coding agents" — community model for agent knowledge base
- **Vibe Kanban 195pts** — Kanban board for AI coding agents — integration opportunity
- JetBrains AI 174pts — enterprise AI coding agent, free tier
- **ProofShot 161pts** — AI agent visual UI verification
- **Runtime (YC P26) 103pts** — sandboxed coding agents for teams (was 322pts on Jul 15)
- **Mcp-Agent 80pts** — build agents with MCP
- Nucleus 40pts — security-hardened container runtime
- Orloj 20pts — agent infrastructure as code (YAML + GitOps)
- Ash 16pts — Agent Sandbox for Mac

**Key deltas vs Jul 17 report:**
1. **loop-engineering accelerating** — Gap over omnigent doubled from 746★ to 1,286★. Loop patterns decisively dominant over meta-orchestration.
2. **nexent ★5,751 emerged** — Zero-code agent generation platform shot past omnigent as #5 AI-agent project. Harness-based scaffolding. Direct competitive threat.
3. **Quality+Sandbox category EXPLODING** — SoloDawn ★302 (3 quality gates, 31 rules), agentjail ★63 (policy guardrails), Runtime YC P26 (sandboxed agents). Three new tools, all 1:1 overlap with sandbox-exec + cmmi5 quality gates. Category forming.
4. **fanbox plateauing** — Confirmed second reverse velocity anomaly: +12 in 4 days (0.3%/d). Follows html-anything pattern from Jul 12.
5. **Klyve repo disappeared** — The direct software factory competitor vanished. Solo-dev SDLC concept unsustained.
6. **ponytail organic but decelerating** — +1,994 in 4 days (2.4%) — sustainable, no anomaly.
- **gpt trend fading** — Score dropped from 3 (Jul 17) to 1 (Jul 21). AI model-specific mania waning.
- **react:1 NEW trend signal** — Frontend ecosystem re-engagement. Watch for growth.

### Fresh Batch Results (2026-07-23 scan)

**Top repos by 1-day growth deltas (vs Jul 22 scan):**
| Repo | Stars (Jul 23) | Stars (Jul 22) | Delta (1 day) | Category |
|------|----------------|----------------|---------------|----------|
| ponytail | 87,886 | 87,407 | +479 (+0.5%) | Trend — **growth moderating** (was +0.9%/d) |
| MiMo-Code | 12,335 | 12,312 | +23 (+0.2%) | **🔥 Comp — emerged as #2 AI agent**, co-evolution paradigm |
| **loop-engineering** | **9,153** | **9,007** | **+146 (+1.6%)** | **Comp — gap over omnigent now 1,515★** |
| omnigent | 7,638 | 7,593 | +45 (+0.6%) | Comp — losing ground to loop |
| baoyu-design | 2,764 | 2,751 | +13 (+0.5%) | Tech — stable |
| guard-skills | 1,088 | 1,084 | +4 (+0.4%) | Tech — moderating |
| fanbox | 941 | 940 | +1 (+0.1%) | **📈 PLATEAU CONFIRMED** — fourth validated anomaly |
| self-learning-skills | 901 | 899 | +2 (+0.2%) | Lead — flat, entered top 10 |
| codeseek | 750 | NEW | NEW | **🔬 Tech — Rust code intelligence CLI for agents** |
| **VulnHunter** | **660** | ~598 (est) | ~+62 | **📋 Comp — CapitalOne agentic security scanner** |
| **agentlas-OS** | **973** | NEW | NEW | **🔬 Tech — Agent OS: hub+spoke temporary orchestrator** |
| **open-kritt** | **320** | NEW (Jul 20) | NEW | **📋 Comp — bug bounty agent orchestration** |
| **foreman** | **276** | NEW | NEW | **🔬 Tech — gated delivery pipeline TUI, aligns CMMI5 Q-GATE** |
| **ringer** | **168** | NEW | NEW | **🔬 Tech — parallel swarm orchestrator** |
| **awesome-ai-coding-sandboxes** | **7** | NEW (Jul 18) | NEW | **📈 Trend — curated list = category mainstreaming** |

**New HN stories (pts):**
- OpenCode 1,274pts — still dominant (persistent since Jul 2)
- "You need AI that reduces maintenance costs" 380pts — C-suite ROI framing
- Crush 367pts — terminal AI agent
- Plandex v2 257pts — OSS large-project coding agent
- "Google Scion" 230pts — Google open-sources agent orchestration testbed
- "Agent orchestration for the timid" 128pts — practical intro
- Hephaestus 81pts — autonomous multi-agent orchestration framework
- KAOS 26pts — Kubernetes Agent Orchestration System
- VT Code 16pts — Rust terminal coding agent (NEW)
- "Proxies, Sandboxes and Agent Security" 8pts — security analysis
- "Coding Agents Degrade Sandboxes to Security Theater" 5pts — sandbox skepticism
- Ouijit 4pts — command terminals for coding agents

**Key deltas vs Jul 22:**
1. **MiMo-Code ★12,335 emerged as #2 AI agent** — Co-evolution paradigm ("Where Models and Agents Co-Evolve"). Not in Jul 22 top 10; now #2 behind ponytail.
2. **Sandbox category 2.6× in 24h (36→96 repos)** — VulnHunter ★660, AgentProvenance ★46, agent-lock ★36, awesome-sandbox-list ★7. Category solidifying from concept to implementation.
3. **ponytail moderating** — +479/d (was +754/d). Still 5× nearest competitor but no longer accelerating.
4. **Agent OS / hub-spoke forming** — Agentlas-OS ★973 + foreman ★276 + ringer ★168. Pattern diversity beyond pure loop/meta.
5. **Enterprise security entering** — VulnHunter ★660 (CapitalOne) + open-kritt ★320 (bug bounty).
6. **Go re-entry in trends (go:2)** — VulnHunter in Go, AgentProvenance in Go. Infrastructure language shift.
7. **Sandbox confidence questioned** — HN posts (★5/★8) argue "sandboxes → security theater" alongside category growth.
8. **foreman ★276** — Boris-style gated pipeline TUI directly aligns CMMI5 Q-GATE.
9. **Trends: ai:11 (+83% from 6) | go:2 (NEW) | llm:2 | gpt:1 | rag:1 | claude:1 | claude code:1**

### Fresh Batch Results (2026-07-22 scan)

**Top repos by 1-day growth deltas (vs Jul 21 scan):**
| Repo | Stars (Jul 22) | Stars (Jul 21) | Delta (1 day) | Category |
|------|----------------|----------------|---------------|----------|
| ponytail | 87,407 | 86,653 | +754 (+0.9%) | Trend — accelerating (was +0.6%/d) |
| MiMo-Code | 12,312 | 12,260 | +52 (+0.4%) | Comp — stable/flat |
| **loop-engineering** | **9,007** | **8,837** | **+170 (+1.9%)** | **Comp — gap over omnigent now 1,414★** |
| omnigent | 7,593 | 7,551 | +42 (+0.6%) | Comp — slowing |
| baoyu-design | 2,751 | 2,733 | +18 (+0.7%) | Tech — steady |
| guard-skills | 1,084 | 1,076 | +8 (+0.7%) | Tech — moderating |
| fanbox | 940 | 935 | +5 (+0.5%) | **📈 PLATEAU CONFIRMED** — third anomaly validated |
| self-learning-skills | 899 | 899 | 0 | Lead — flat |
| **dao-code** | **1,376** | NEW (0→★★★) | NEW | **🔥 Comp — first major DeepSeek-V4 terminal coding agent** |
| **homerail** | **651** | NEW | NEW | **🔥 Tech — voice-first agent orchestration runtime** |
| **klaatcode** | **212** | NEW | NEW | **Lead — open-source Claude Code-grade terminal agent** |
| **boring-computers** | **273** | ~250 (est) | ~+23 | Tech — Firecracker microVMs for AI, steady |
| **pi-workflow** | **318** | NEW | NEW | **Tech — workflow orchestration for Pi ecosystem** |
| **Clutch** | **82** | NEW | NEW | Tech — local AI multi-agent desktop app (Tauri+LangGraph) |
| **open-dynamic-workflow** | **57** | NEW | NEW | Tech — local-first workflow runner for external coding agents |
| **specship** | **190** | NEW | NEW | **Lead — spec-driven autonomous engineering workflow** |
| **harness-all** | **23** | NEW | NEW | **Comp — local-first agent-agnostic R&D harness** |
| **agent-firewall** | **2** | NEW | NEW | **Comp — dry-run firewall for coding agents, direct overlap sandbox-exec** |
| **halt-core** | **2** | NEW | NEW | **Comp — zero-trust guardrail SDK, sub-ms middleware** |

**New HN stories (pts):**
- OpenCode 1,274pts — still the top story (persistent since Jul 2)
- "AI coding agent maintenance costs" 380pts — industry adoption signal: C-suite ROI framing
- Crush 367pts — terminal AI agent
- Plandex v2 257pts — OSS coding agent for large projects
- "Proxies, Sandboxes and Agent Security" 8pts — security layer discussion
- "Coding Agents Degrade Sandboxes to Security Theater" 5pts — sandbox skepticism
- YOPJ 1pt — 8-layer local security sandbox (no cloud)
- Bytechef 2pts — open-source AI agent orchestration platform
- Zenflow 2pts — multi-agent orchestration engine
- Konductor 4pts — AI orchestration framework for every dev
- Manas 3pts — multi-agent framework for complex LLM apps
- Core v2.2 2pts — autonomous coding agent with universal workflow orchestration
- Klyve 1pt — software factory for solo devs (reappeared after being reported "gone")

**Key deltas vs Jul 21 report:**
1. **dao-code ★1,376 emerged** — First major DeepSeek-V4 terminal coding agent, from zero in <24h. Signals DeepSeek cloud ecosystem viability as Claude Code alternative.
2. **homerail ★651 emerged** — Voice-first agent orchestration runtime (auditable DAG workflows). New UX paradigm.
3. **Orchestration ecosystem EXPLODING** — Previous narrow query returned 293 repos (Jul 2); now 1,127 repos for `agent+orchestration+workflow` query. pi-workflow ★318, Clutch ★82, open-dynamic-workflow ★57, Konductor 4pts HN — category entering growth phase.
4. **Terminal coding agents — new wave**: dao-code ★1,376 (DeepSeek) + klaatcode ★212 (Claude Code-grade) + boring-computers ★273 (Firecracker per-agent) + pagecast ★182 (terminal→Cloudflare publish). 1,205 repos in category.
5. **Sandbox/security solidifying** — agent-firewall ★2 + halt-core ★2 + YOPJ 1pt HN — category growing from "concepts" to "working implementations." 36 repos counted.
6. **loop-engineering gap widening** — 1,414★ over omnigent (was 746★ on Jul 17, then 1,286★ on Jul 21). Accelerating.
7. **ponytail accelerating** — +754 in 1d (0.9%) vs +1,994 in 4d (0.5%/d). Organic growth, sustainable.
8. **fanbox plateau confirmed** — Third validated "reverse velocity anomaly" after html-anything and fanbox. Pattern: tool projects plateau at 900-1,000★ when novelty fades.
9. **rag:1 trend signal** — RAG re-entering conversation after hiatus. Watch for growth.

### Sandbox Category Shift (detected 2026-07-02)
The sandbox/guardrail category shifted from **conceptual discussion** (Jun 29: "AI lies about sandbox guardrails" 8pts, Nono 4pts, Leash 1pt) to **working implementations** (Jul 2: sandboxd 705, AgentProvenance 23, ironclaw 13, agent-jail 3). If previous scan showed concept-stage projects but current shows code-first implementations, category tilted to maturity — update lead classification accordingly.

## Channel-Suitability by Terminology ("Term-Home" Mapping)

Some terminology has strong home bias across channels. Know where each term type lives:

| Term Type | Examples | Best Channel | Why |
|-----------|----------|-------------|-----|
| **Product/category** | "AI coding agent", "developer tools", "software factory" | GitHub REST (Tier 3) | Repos use product categories as topics/descriptions; HN tends to discuss specific launches, not categories |
| **Company/product names** | "ponytail", "omnigent", "fabro" | Both (Tier 2 HN + Tier 3 GH) | HN has launch stories; GH has star growth. Complementary |
| **Functional pain points** | "guardrails", "sandbox", "quality gates" | Channel 8 → Tier 2 | Turns up multi-type competitors (startups + OSS projects) from one search. Cross-pollination pattern |
| **Market sentiment** | "AI-first strategy", "enterprise AI adoption" | Tier 2 HN Algolia | HN discussion threads carry opinion/controversy; GitHub has no sentiment signal |
| **Technology stack** | "BPMN", "Rust", "vibe coding", "CLI agent" | Channel 8 | Cross-refs HN launches with GH repos naming the same tech — identifies platform plays |

Empirically validated 2026-06-20: "AI+software+factory+SDLC" returned 0 GH repos (created > 2026-06-01) and only 2 low-value HN hits. Same terms via Channel 8 triggered the known crash (Pitfall #18). **Lesson**: When a term class produces sparse results on its preferred channel, broaden the query or switch channels — don't retry the same combination.

## Delta Analysis Pattern

After gathering new data, read previous report for comparison:

```bash
cat ~/company/leads/scout-report-latest.md
```

Then compare:
- **Trend scores**: e.g., `ai:11 → 9` means AI topic attention cooling
- **New repos**: any repo with `created: > last_scan_date` and `stars > 100`
- **New HN stories**: any `[>50pts]` story on relevant topics
- **Lead status**: check if previous leads (comp, partner targets) changed
