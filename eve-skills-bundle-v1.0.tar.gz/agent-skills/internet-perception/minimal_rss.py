#!/usr/bin/env python3
import feedparser
import time
from datetime import datetime, timezone

# Key feeds for security/AI/DevOps
key_feeds = [
    "https://openai.com/blog/rss.xml",
    "https://ai.googleblog.com/feeds/posts/default", 
    "https://krebsonsecurity.com/feed/",
    "https://blog.cloudflare.com/rss/",
    "https://threatpost.com/feed/",
    "https://www.docker.com/blog/feed/",
    "https://kubernetes.io/feed.xml",
    "https://aws.amazon.com/blogs/aws/feed/"
]

def scan_key_feeds():
    print("🔍 RSS Intelligence - Security/AI/DevOps Focus")
    print("=" * 50)
    
    all_entries = []
    
    for feed_url in key_feeds:
        try:
            print(f"Scanning: {feed_url}")
            parsed = feedparser.parse(feed_url)
            
            if parsed.bozo and not parsed.entries:
                print(f"❌ Parse error")
                continue
                
            feed_title = parsed.feed.get('title', 'Unknown')
            
            # Get latest 3 entries
            for entry in parsed.entries[:3]:
                title = entry.get('title', '')
                link = entry.get('link', '')
                summary = entry.get('summary', '')[:200]
                
                # Check if relevant to security/AI/DevOps
                if any(keyword in title.lower() for keyword in ['security', 'vulnerability', 'threat', 'cyber', 'ai', 'openai', 'google ai', 'machine learning', 'docker', 'kubernetes', 'aws']):
                    all_entries.append({
                        'feed': feed_title,
                        'title': title,
                        'link': link,
                        'summary': summary
                    })
                    
            time.sleep(2)  # Be respectful to servers
            
        except Exception as e:
            print(f"❌ Error: {e}")
            continue
    
    # Sort by title and show top results
    all_entries.sort(key=lambda x: x['title'].lower())
    
    print(f"\n📰 Found {len(all_entries)} relevant entries:")
    print("-" * 50)
    
    for i, entry in enumerate(all_entries[:8], 1):
        print(f"{i}. {entry['title']}")
        print(f"   📰 {entry['feed']}")
        if entry['summary']:
            print(f"   💬 {entry['summary']}...")
        print()
    
    return all_entries

if __name__ == "__main__":
    scan_key_feeds()