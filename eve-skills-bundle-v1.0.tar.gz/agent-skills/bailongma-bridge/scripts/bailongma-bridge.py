#!/usr/bin/env python3
"""
Bailongma Bridge — 白龙马底层执行智能体 API 桥接
用于 Hermes Agent ↔ Bailongma 双向通信

用法:
  python3 bailongma-bridge.py send "你好"               # 发送消息
  python3 bailongma-bridge.py status                     # 查询状态
  python3 bailongma-bridge.py memories --limit 10        # 查询记忆
  python3 bailongma-bridge.py search "关键词"             # 搜索记忆
  python3 bailongma-bridge.py conversations --limit 20   # 查询对话
  python3 bailongma-bridge.py quota                      # 查询配额
  python3 bailongma-bridge.py stop                       # 暂停意识循环
  python3 bailongma-bridge.py start                      # 恢复意识循环
  python3 bailongma-bridge.py health                     # 健康检查
"""

import json
import sys
import time
import urllib.request
import urllib.error
import os

BAILONGMA_HOST = os.environ.get("BAILONGMA_HOST", "127.0.0.1")
BAILONGMA_PORT = int(os.environ.get("BAILONGMA_PORT", "3721"))
BASE_URL = f"http://{BAILONGMA_HOST}:{BAILONGMA_PORT}"


def api(method, path, data=None, timeout=10):
    """调用 Bailongma HTTP API"""
    body = json.dumps(data).encode() if data else None
    req = urllib.request.Request(
        f"{BASE_URL}{path}",
        data=body,
        headers={"Content-Type": "application/json; charset=utf-8"},
        method=method,
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode()
            if raw.strip():
                return json.loads(raw)
            return {"status": resp.status}
    except urllib.error.HTTPError as e:
        return {"error": f"HTTP {e.code}: {e.reason}"}
    except urllib.error.URLError as e:
        return {"error": f"Connection failed: {e.reason}"}
    except Exception as e:
        return {"error": str(e)}


def cmd_send(content, from_id="ID:000001", channel="Hermes"):
    """发送消息给Bailongma"""
    result = api("POST", "/message", {
        "from_id": from_id,
        "content": content,
        "channel": channel,
    })
    return result


def cmd_status():
    """查询Bailongma运行状态"""
    return api("GET", "/status")


def cmd_memories(limit=20, search=None):
    """查询/搜索记忆"""
    path = f"/memories?limit={limit}"
    if search:
        path += f"&search={urllib.parse.quote(search)}"
    import urllib.parse
    path = f"/memories?limit={limit}"
    if search:
        path += f"&search={urllib.parse.quote(search)}"
    return api("GET", path)


def cmd_conversations(limit=60):
    """查询最近对话"""
    return api("GET", f"/conversations?limit={limit}")


def cmd_quota():
    """查询配额占用"""
    return api("GET", "/quota")


def cmd_control(action):
    """控制意识循环: stop / start"""
    return api("POST", f"/admin/{action}")


def cmd_health():
    """健康检查 - 简易版"""
    try:
        req = urllib.request.Request(f"{BASE_URL}/status", method="GET")
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read().decode())
            return {
                "status": "OK",
                "action": data.get("action"),
                "task": data.get("task"),
                "sessionCounter": data.get("sessionCounter"),
                "recentActions": len(data.get("recentActions", [])),
                "thoughtStack": len(data.get("thoughtStack", [])),
            }
    except Exception as e:
        return {"status": "DOWN", "error": str(e)}


def main():
    if len(sys.argv) < 2:
        print("用法: python3 bailongma-bridge.py <command> [args]")
        print("命令: send, status, memories, search, conversations, quota, stop, start, health")
        sys.exit(1)

    command = sys.argv[1]

    if command == "send":
        content = " ".join(sys.argv[2:]) if len(sys.argv) > 2 else sys.stdin.read().strip()
        if not content:
            print("错误: 请输入消息内容")
            sys.exit(1)
        result = cmd_send(content)
        print(json.dumps(result, ensure_ascii=False, indent=2))

    elif command == "status":
        result = cmd_status()
        print(json.dumps(result, ensure_ascii=False, indent=2))

    elif command == "memories":
        limit = int(sys.argv[3]) if len(sys.argv) > 3 and sys.argv[2] == "--limit" else 20
        result = cmd_memories(limit=limit)
        print(json.dumps(result, ensure_ascii=False, indent=2))

    elif command == "search":
        query = " ".join(sys.argv[2:]) if len(sys.argv) > 2 else ""
        if not query:
            print("错误: 请输入搜索关键词")
            sys.exit(1)
        result = cmd_memories(search=query)
        print(json.dumps(result, ensure_ascii=False, indent=2))

    elif command == "conversations":
        limit = int(sys.argv[3]) if len(sys.argv) > 3 and sys.argv[2] == "--limit" else 60
        result = cmd_conversations(limit=limit)
        print(json.dumps(result, ensure_ascii=False, indent=2))

    elif command == "quota":
        result = cmd_quota()
        print(json.dumps(result, ensure_ascii=False, indent=2))

    elif command == "stop":
        result = cmd_control("stop")
        print(json.dumps(result, ensure_ascii=False, indent=2))

    elif command == "start":
        result = cmd_control("start")
        print(json.dumps(result, ensure_ascii=False, indent=2))

    elif command == "health":
        result = cmd_health()
        status_icon = "✅" if result.get("status") == "OK" else "❌"
        print(f"{status_icon} Bailongma Health Check")
        for k, v in result.items():
            print(f"  {k}: {v}")

    else:
        print(f"未知命令: {command}")
        sys.exit(1)


if __name__ == "__main__":
    main()
