#!/usr/bin/env python3
"""
Bailongma Social Bridge — Hermes↔Bailongma社交消息路由
利用Bailongma已有的社交接入能力，为Hermes提供多通道社交消息处理

架构:
  微信/飞书/Discord → Bailongma Connectors → SSE /events → Hermes Social Bridge → 处理 → Dispatch → 社交平台

用法:
  python3 bailongma-social.py status                    # 社交连接器状态
  python3 bailongma-social.py listen                    # 监听SSE社交事件（持续运行）
  python3 bailongma-social.py dispatch <channel> <msg>  # 通过Bailongma发送社交消息
  python3 bailongma-social.py wechat-qr                 # 获取微信ClawBot二维码
"""
import json
import os
import sqlite3
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone

BAILONGMA_API = "http://127.0.0.1:3721"
BAILONGMA_DB = os.path.expanduser("~/projects/bailongma/data/jarvis.db")
ACI_DB = os.path.expanduser("~/.hermes/data/bailongma-aci.db")
SOCIAL_DB = os.path.expanduser("~/.hermes/data/bailongma-social.db")


def _api(method, path, data=None, timeout=10):
    """Call Bailongma API"""
    url = f"{BAILONGMA_API}{path}"
    body = json.dumps(data).encode() if data else None
    req = urllib.request.Request(
        url, data=body,
        headers={"Content-Type": "application/json; charset=utf-8"},
        method=method,
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode()
            return json.loads(raw) if raw.strip() else {}
    except urllib.error.HTTPError as e:
        return {"error": f"HTTP {e.code}"}
    except Exception as e:
        return {"error": str(e)}


def init_db():
    """Initialize social message tracking DB"""
    os.makedirs(os.path.dirname(SOCIAL_DB), exist_ok=True)
    db = sqlite3.connect(SOCIAL_DB)
    db.execute("""
        CREATE TABLE IF NOT EXISTS social_messages (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            platform    TEXT NOT NULL,
            from_id     TEXT,
            content     TEXT NOT NULL,
            direction   TEXT NOT NULL,  -- 'inbound' | 'outbound'
            handled_by  TEXT DEFAULT 'bailongma',  -- 'bailongma' | 'hermes'
            ts          TEXT NOT NULL,
            created_at  TEXT NOT NULL DEFAULT (datetime('now'))
        )
    """)
    db.execute("""
        CREATE TABLE IF NOT EXISTS social_connectors (
            platform    TEXT PRIMARY KEY,
            status      TEXT DEFAULT 'disconnected',
            label       TEXT,
            connected_at TEXT,
            error       TEXT DEFAULT '',
            updated_at  TEXT NOT NULL DEFAULT (datetime('now'))
        )
    """)
    db.commit()
    db.close()


def get_social_status():
    """Get social connector status from Bailongma"""
    # Bailongma doesn't expose a social status API directly,
    # so we read from our tracking DB and Bailongma's config
    init_db()
    db = sqlite3.connect(SOCIAL_DB)
    rows = db.execute("SELECT * FROM social_connectors ORDER BY platform").fetchall()
    db.close()

    connectors = []
    for r in rows:
        connectors.append({
            "platform": r[0],
            "status": r[1],
            "label": r[2] or r[0],
            "connected_at": r[3] or "",
            "error": r[4] or "",
        })

    # Always include known platforms even if not tracked
    known = {"wechat-clawbot", "discord", "feishu", "wechat-official", "wecom"}
    existing = {c["platform"] for c in connectors}
    for p in known - existing:
        connectors.append({
            "platform": p,
            "status": "unknown",
            "label": p,
            "connected_at": "",
            "error": "",
        })

    return {
        "connectors": connectors,
        "total": len(connectors),
    }


def set_connector_status(platform, status, label=None, error=""):
    """Update connector status in tracking DB"""
    init_db()
    db = sqlite3.connect(SOCIAL_DB)
    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    db.execute("""
        INSERT INTO social_connectors (platform, status, label, connected_at, error, updated_at)
        VALUES (?, ?, ?, ?, ?, ?)
        ON CONFLICT(platform) DO UPDATE SET
            status=excluded.status,
            label=COALESCE(excluded.label, social_connectors.label),
            connected_at=CASE WHEN excluded.status='connected' THEN excluded.connected_at ELSE social_connectors.connected_at END,
            error=excluded.error,
            updated_at=excluded.updated_at
    """, (platform, status, label or platform, now if status == "connected" else "", error, now))
    db.commit()
    db.close()


def track_message(platform, from_id, content, direction, handled_by="bailongma"):
    """Track a social message in the monitoring DB"""
    init_db()
    db = sqlite3.connect(SOCIAL_DB)
    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    db.execute(
        "INSERT INTO social_messages (platform, from_id, content, direction, handled_by, ts) VALUES (?,?,?,?,?,?)",
        (platform, from_id or "", content[:500], direction, handled_by, now)
    )
    db.commit()
    db.close()


def get_recent_messages(limit=20):
    """Get recent social messages for dashboard"""
    init_db()
    db = sqlite3.connect(SOCIAL_DB)
    rows = db.execute(
        "SELECT * FROM social_messages ORDER BY id DESC LIMIT ?", (limit,)
    ).fetchall()
    db.close()
    return [
        {
            "id": r[0],
            "platform": r[1],
            "from_id": r[2] or "",
            "content": (r[3] or "")[:200],
            "direction": r[4],
            "handled_by": r[5],
            "ts": r[6],
        }
        for r in rows
    ]


def dispatch_social(platform, target_id, content):
    """
    Dispatch a message through Bailongma's social channels.
    Uses Bailongma's POST /message to inject, which triggers its dispatch system.
    For direct dispatch, we target the social platform via Bailongma's API.
    """
    channel_map = {
        "weixin": "wx",
        "wechat": "wx",
        "discord": "discord",
        "feishu": "feishu",
        "lark": "feishu",
        "telegram": "telegram",
    }

    channel = channel_map.get(platform.lower(), platform)

    # Send via Bailongma message API (Bailongma will dispatch)
    result = _api("POST", "/message", {
        "from_id": f"ID:{channel}:{target_id}",
        "content": content,
        "channel": f"social:{channel}",
    })

    track_message(platform, target_id, content, "outbound", "hermes")
    return result


def listen_events(duration=60):
    """
    Listen to Bailongma SSE events and extract social messages.
    Returns social events detected during the listening period.
    """
    import urllib.request as req_lib

    social_events = []
    try:
        resp = req_lib.urlopen(f"{BAILONGMA_API}/events", timeout=duration)
        start = time.time()
        buffer = ""

        while time.time() - start < duration:
            chunk = resp.read(4096)
            if not chunk:
                break
            buffer += chunk.decode("utf-8", errors="replace")

            # Parse SSE events
            while "\n\n" in buffer:
                event_str, buffer = buffer.split("\n\n", 1)
                for line in event_str.split("\n"):
                    if line.startswith("data: "):
                        try:
                            event_data = json.loads(line[6:])
                            event_type = event_data.get("type", "")
                            event_body = event_data.get("data", {})

                            # Detect social-related events
                            if event_type in ("social_status", "social_message", "message"):
                                social_events.append({
                                    "type": event_type,
                                    "data": event_body,
                                    "ts": event_data.get("ts", ""),
                                })

                                # Track the message
                                if event_type == "social_message":
                                    track_message(
                                        event_body.get("platform", "unknown"),
                                        event_body.get("from_id", ""),
                                        event_body.get("content", ""),
                                        "inbound",
                                        "bailongma"
                                    )
                        except json.JSONDecodeError:
                            pass

        resp.close()
    except Exception as e:
        social_events.append({"error": str(e)})

    return social_events


def get_wechat_qr():
    """Get WeChat ClawBot QR code URL"""
    result = _api("GET", "/social/wechat/qr")
    return result


# ── CLI ──

def main():
    if len(sys.argv) < 2:
        print("Bailongma Social Bridge — Hermes↔Bailongma社交消息路由")
        print()
        print("用法:")
        print("  social status                 # 社交连接器状态")
        print("  social listen [seconds]       # 监听SSE社交事件")
        print("  social dispatch <platform> <target_id> <msg>  # 发送消息")
        print("  social messages [limit]       # 最近社交消息")
        print("  social wechat-qr              # 微信ClawBot二维码")
        print("  social track <p> <id> <msg>   # 手动追踪一条消息")
        sys.exit(1)

    cmd = sys.argv[1]

    if cmd == "status":
        result = get_social_status()
        print(json.dumps(result, ensure_ascii=False, indent=2))

    elif cmd == "listen":
        duration = int(sys.argv[2]) if len(sys.argv) > 2 else 30
        print(f"监听Bailongma社交事件 {duration}秒...")
        events = listen_events(duration)
        print(f"检测到 {len(events)} 个社交事件:")
        for e in events:
            print(json.dumps(e, ensure_ascii=False, indent=2))

    elif cmd == "dispatch" and len(sys.argv) >= 5:
        platform = sys.argv[2]
        target_id = sys.argv[3]
        content = " ".join(sys.argv[4:])
        result = dispatch_social(platform, target_id, content)
        print(json.dumps(result, ensure_ascii=False, indent=2))

    elif cmd == "messages":
        limit = int(sys.argv[2]) if len(sys.argv) > 2 else 20
        msgs = get_recent_messages(limit)
        print(json.dumps(msgs, ensure_ascii=False, indent=2))

    elif cmd == "wechat-qr":
        result = get_wechat_qr()
        print(json.dumps(result, ensure_ascii=False, indent=2))

    elif cmd == "track" and len(sys.argv) >= 5:
        platform = sys.argv[2]
        from_id = sys.argv[3]
        content = " ".join(sys.argv[4:])
        track_message(platform, from_id, content, "inbound", "hermes")
        print(f"已追踪: {platform}/{from_id}: {content[:80]}")

    else:
        print(f"未知命令: {sys.argv[1]}")


if __name__ == "__main__":
    main()
