#!/usr/bin/env python3
"""
Hermes Prefetch Cache Updater
定期更新Bailongma prefetch_cache中的Hermes系统数据
供Bailongma L2注入器自动消费

用法:
  python3 hermes-prefetch-update.py            # 更新所有Hermes缓存
  python3 hermes-prefetch-update.py --oneshot  # 单次更新并报告
"""
import json
import os
import sqlite3
import sys
import urllib.error
import urllib.request
from datetime import datetime, timezone

BAILONGMA_DB = "/home/yestin/projects/bailongma/data/jarvis.db"

def fetch_url(url, timeout=10):
    """获取URL内容"""
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Hermes-ACI/1.0"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.read().decode("utf-8", errors="replace")[:2000]
    except Exception as e:
        return f"[unavailable: {e}]"

def write_prefetch(source, content, ttl_minutes=30, tags=None):
    """写入prefetch_cache"""
    tags = tags or []
    db = sqlite3.connect(BAILONGMA_DB)
    now = datetime.now(timezone.utc).isoformat()
    expires = datetime.fromtimestamp(
        datetime.now(timezone.utc).timestamp() + ttl_minutes * 60,
        tz=timezone.utc
    ).isoformat()
    db.execute("""
        INSERT INTO prefetch_cache (source, content, fetched_at, expires_at, tags)
        VALUES (?, ?, ?, ?, ?)
        ON CONFLICT(source) DO UPDATE SET
            content=excluded.content, fetched_at=excluded.fetched_at,
            expires_at=excluded.expires_at, tags=excluded.tags
    """, (source, content, now, expires, json.dumps(tags)))
    db.commit()
    db.close()
    return {"source": source, "expires_at": expires}

def update_hermes_cache():
    """更新所有Hermes相关的prefetch缓存"""
    updates = []

    # 1. Dashboard status
    dash = fetch_url("http://localhost:5000/")
    r = write_prefetch(
        "hermes:dashboard",
        f"[Hermes Dashboard] {dash[:1000]}",
        ttl_minutes=15,
        tags=["hermes", "dashboard", "status"]
    )
    updates.append(f"dashboard: {r['source']}")

    # 2. Gateway health
    gw = fetch_url("http://localhost:8642/health")
    r = write_prefetch(
        "hermes:gateway",
        f"[Gateway Health] {gw[:1000]}",
        ttl_minutes=15,
        tags=["hermes", "gateway", "health"]
    )
    updates.append(f"gateway: {r['source']}")

    # 3. BookStack status
    bs_status = "unknown"
    try:
        req = urllib.request.Request("http://localhost:8080/", method="HEAD")
        with urllib.request.urlopen(req, timeout=5) as resp:
            bs_status = str(resp.status)
    except Exception as e:
        bs_status = f"down: {e}"
    r = write_prefetch(
        "hermes:bookstack",
        f"[BookStack Status] HTTP {bs_status}",
        ttl_minutes=30,
        tags=["hermes", "bookstack", "wiki"]
    )
    updates.append(f"bookstack: {r['source']}")

    # 4. Bailongma self status
    blm = fetch_url("http://127.0.0.1:3721/status")
    r = write_prefetch(
        "hermes:bailongma_self",
        f"[Bailongma Self] {blm[:1000]}",
        ttl_minutes=5,
        tags=["hermes", "bailongma", "self"]
    )
    updates.append(f"bailongma: {r['source']}")

    # 5. System health (combined snapshot)
    import subprocess
    process_count = "?"
    try:
        rp = subprocess.run(
            "ps aux | grep -E 'python3|node' | grep -v grep | wc -l",
            shell=True, capture_output=True, text=True, timeout=5
        )
        process_count = rp.stdout.strip()
    except:
        pass
    r = write_prefetch(
        "hermes:system_snapshot",
        f"[System Snapshot] Running services: {process_count} (python3+node). Time: {datetime.now(timezone.utc).isoformat()}",
        ttl_minutes=10,
        tags=["hermes", "system", "snapshot"]
    )
    updates.append(f"system: {r['source']}")

    return updates

if __name__ == "__main__":
    updates = update_hermes_cache()
    if "--oneshot" in sys.argv:
        print("Hermes Prefetch Cache Updated:")
        for u in updates:
            print(f"  ✅ {u}")
    else:
        # Silent mode for cron
        pass
