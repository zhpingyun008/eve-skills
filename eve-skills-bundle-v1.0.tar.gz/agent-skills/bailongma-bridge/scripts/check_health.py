#!/usr/bin/env python3
"""
Bailongma Health Check — 白龙马健康巡检脚本
每5分钟cron调用，检测:3721服务是否存活，宕机自动自启。

用法:
  python3 check_health.py        # 检查+自动修复
  python3 check_health.py check  # 仅检查
  python3 check_health.py fix    # 仅修复
"""

import json
import os
import subprocess
import sys
import time
import urllib.error
import urllib.request

BAILONGMA_API = "http://127.0.0.1:3721"
BAILONGMA_DIR = os.path.expanduser("~/projects/bailongma")


def bailongma_alive(timeout=5):
    """检查Bailongma是否存活"""
    try:
        req = urllib.request.Request(f"{BAILONGMA_API}/status")
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = resp.read().decode()
            data = json.loads(body)
            return data.get("ok", False)
    except Exception:
        return False


def start_bailongma():
    """启动Bailongma后端服务"""
    try:
        env_file = os.path.join(BAILONGMA_DIR, ".env")
        env = os.environ.copy()
        if os.path.exists(env_file):
            with open(env_file) as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith("#") and "=" in line:
                        k, v = line.split("=", 1)
                        env[k.strip()] = v.strip()

        proc = subprocess.Popen(
            ["node", "src/index.js"],
            cwd=BAILONGMA_DIR,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            env=env,
        )
        # 等待3秒确认启动
        time.sleep(3)
        if bailongma_alive(timeout=3):
            return {"ok": True, "pid": proc.pid, "action": "started"}
        else:
            proc.kill()
            return {"ok": False, "action": "failed", "error": "Service did not become ready"}
    except Exception as e:
        return {"ok": False, "action": "failed", "error": str(e)}


def fix():
    """自动修复 — 尝试启动Bailongma"""
    print("🔧 Bailongma健康巡检: 自愈中...")
    result = start_bailongma()
    if result.get("ok"):
        print(f"✅ Bailongma已自愈 (PID={result['pid']})")
    else:
        print(f"❌ Bailongma自愈失败: {result.get('error', '未知错误')}")
    return result


def check(auto_fix=True):
    """检查Bailongma健康状态，可选自动修复"""
    alive = bailongma_alive()
    if alive:
        print("OK Bailongma is alive")
        return {"ok": True}
    else:
        print("FAIL Bailongma is not responding")
        if auto_fix:
            return fix()
        return {"ok": False}


def main():
    auto_fix = True
    if len(sys.argv) > 1:
        cmd = sys.argv[1]
        if cmd == "check":
            auto_fix = False
        elif cmd == "fix":
            result = fix()
            print(json.dumps(result, ensure_ascii=False))
            return
        else:
            print(f"Usage: {sys.argv[0]} [check|fix]")
            sys.exit(1)

    result = check(auto_fix=auto_fix)
    if not result.get("ok"):
        sys.exit(1)


if __name__ == "__main__":
    main()
