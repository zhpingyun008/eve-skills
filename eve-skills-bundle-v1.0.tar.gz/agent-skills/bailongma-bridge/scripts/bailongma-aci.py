#!/usr/bin/env python3
"""
Bailongma ACI (Anticipatory Context Injection) 引擎
Hermes 侧预判注入执行层 — 将Bailongma的ACI能力接入Hermes工具链

三层预判：
  A) 语义记忆预判 — 消息到达时自动检索相关记忆
  B) 工具链模式预判 — 意图匹配 → 并行预执行只读工具
  C) 定时预热注入 — 定时任务采集外部数据

用法:
  python3 bailongma-aci.py pattern list                    # 列出已知工具链模式
  python3 bailongma-aci.py pattern learn <intent> <tools>  # 学习新模式
  python3 bailongma-aci.py pattern match <user_message>    # 匹配意图并预执行
  python3 bailongma-aci.py prefetch list                   # 列出预热任务
  python3 bailongma-aci.py prefetch add <name> <url>       # 添加预热任务
  python3 bailongma-aci.py prefetch run                    # 运行所有预热任务
  python3 bailongma-aci.py inject <message>                # 模拟注入（获取预判上下文）
  python3 bailongma-aci.py status                          # ACI引擎状态
"""

import json
import os
import sqlite3
import subprocess
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone

# ── 路径配置 ──────────────────────────────────────────────────────────
BAILONGMA_DIR = os.path.expanduser("~/projects/bailongma")
BAILONGMA_DB = os.path.join(BAILONGMA_DIR, "data", "bailongma.db")
BAILONGMA_API = "http://127.0.0.1:3721"
HERMES_SKILLS = os.path.expanduser("~/.hermes/skills")

# ── 工具链模式表（Hermes自有SQLite，独立于Bailongma） ──────────────
ACI_DB = os.path.expanduser("~/.hermes/data/bailongma-aci.db")


def get_aci_db():
    """获取ACI模式数据库连接"""
    os.makedirs(os.path.dirname(ACI_DB), exist_ok=True)
    conn = sqlite3.connect(ACI_DB)
    conn.row_factory = sqlite3.Row
    conn.execute("""
        CREATE TABLE IF NOT EXISTS tool_patterns (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            intent      TEXT    NOT NULL UNIQUE,
            description TEXT,
            confidence  REAL    DEFAULT 1.0,
            tool_chain  TEXT    NOT NULL,  -- JSON: [{name, args_template, read_only}]
            hit_count   INTEGER DEFAULT 0,
            last_used   TEXT,
            created_at  TEXT    NOT NULL DEFAULT (datetime('now')),
            updated_at  TEXT    NOT NULL DEFAULT (datetime('now'))
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS pattern_log (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            pattern_id  INTEGER,
            message     TEXT,
            matched     INTEGER DEFAULT 1,
            pre_exec_ms INTEGER DEFAULT 0,
            created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
        )
    """)
    conn.commit()
    return conn


# ── Bailongma DB 直连操作 ────────────────────────────────────────────

def bailongma_db():
    """连接Bailongma数据库（只读操作）"""
    if not os.path.exists(BAILONGMA_DB):
        return None
    conn = sqlite3.connect(BAILONGMA_DB)
    conn.row_factory = sqlite3.Row
    return conn


def bailongma_api(method, path, data=None, timeout=10):
    """通过HTTP API与Bailongma通信"""
    url = f"{BAILONGMA_API}{path}"
    body = json.dumps(data).encode() if data else None
    req = urllib.request.Request(
        url, data=body,
        headers={"Content-Type": "application/json; charset=utf-8"},
        method=method,
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode()
            return json.loads(raw) if raw.strip() else {}
    except Exception as e:
        return {"error": str(e)}


def register_bailongma_prefetch(source, label, url, ttl_minutes=60, tags=None):
    """向Bailongma注册预热任务（直接写DB）"""
    db = bailongma_db()
    if not db:
        return {"error": "Bailongma DB not found"}
    tags = tags or []
    try:
        db.execute("""
            INSERT INTO prefetch_tasks (source, label, url, ttl_minutes, tags, enabled)
            VALUES (?, ?, ?, ?, ?, 1)
            ON CONFLICT(source) DO UPDATE SET
                label = excluded.label,
                url = excluded.url,
                ttl_minutes = excluded.ttl_minutes,
                tags = excluded.tags,
                enabled = 1,
                updated_at = datetime('now')
        """, (source, label, url, ttl_minutes, json.dumps(tags)))
        db.commit()
        return {"ok": True, "source": source, "action": "registered"}
    except Exception as e:
        return {"error": str(e)}


def write_prefetch_cache(source, content, ttl_minutes=60, tags=None):
    """直接向Bailongma prefetch_cache写入预取结果"""
    db = bailongma_db()
    if not db:
        return {"error": "Bailongma DB not found"}
    tags = tags or []
    now = datetime.now(timezone.utc).isoformat()
    expires = datetime.now(timezone.utc).timestamp() + ttl_minutes * 60
    expires_at = datetime.fromtimestamp(expires, tz=timezone.utc).isoformat()
    try:
        db.execute("""
            INSERT INTO prefetch_cache (source, content, fetched_at, expires_at, tags)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(source) DO UPDATE SET
                content = excluded.content,
                fetched_at = excluded.fetched_at,
                expires_at = excluded.expires_at,
                tags = excluded.tags
        """, (source, content, now, expires_at, json.dumps(tags)))
        db.commit()
        return {"ok": True, "source": source, "expires_at": expires_at}
    except Exception as e:
        return {"error": str(e)}


def read_bailongma_memories(search=None, limit=20):
    """从Bailongma读取记忆"""
    import urllib.parse
    path = f"/memories?limit={limit}"
    if search:
        path += f"&search={urllib.parse.quote(search)}"
    return bailongma_api("GET", path)


# ── 工具链模式学习 ──────────────────────────────────────────────────

BUILTIN_PATTERNS = [
    {
        "intent": "查询天气",
        "description": "用户查询某城市天气",
        "confidence": 0.95,
        "tool_chain": [
            {"name": "fetch_url", "args_template": {"url": "https://wttr.in/{city}?format=j1&lang=zh"}, "read_only": True}
        ]
    },
    {
        "intent": "搜索新闻",
        "description": "用户搜索最新新闻/资讯",
        "confidence": 0.85,
        "tool_chain": [
            {"name": "web_search", "args_template": {"query": "{query} 新闻"}, "read_only": True},
            {"name": "fetch_url", "args_template": {"url": "https://hacker-news.firebaseio.com/v0/topstories.json"}, "read_only": True}
        ]
    },
    {
        "intent": "查询GitHub项目",
        "description": "用户查询GitHub仓库信息",
        "confidence": 0.85,
        "tool_chain": [
            {"name": "web_search", "args_template": {"query": "github {query}"}, "read_only": True}
        ]
    },
    {
        "intent": "代码搜索",
        "description": "用户在代码库中搜索内容",
        "confidence": 0.80,
        "tool_chain": [
            {"name": "search_files", "args_template": {"pattern": "{query}", "target": "content"}, "read_only": True}
        ]
    },
    {
        "intent": "系统状态检查",
        "description": "用户查询系统运行状态",
        "confidence": 0.95,
        "tool_chain": [
            {"name": "cronjob", "args_template": {"action": "list"}, "read_only": True},
            {"name": "terminal", "args_template": {"command": "ps aux | grep python3 | grep -v grep | wc -l"}, "read_only": True}
        ]
    },
]


def init_builtin_patterns():
    """初始化内置工具链模式"""
    conn = get_aci_db()
    for pattern in BUILTIN_PATTERNS:
        conn.execute("""
            INSERT INTO tool_patterns (intent, description, confidence, tool_chain)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(intent) DO UPDATE SET
                description = excluded.description,
                confidence = excluded.confidence,
                tool_chain = excluded.tool_chain
        """, (pattern["intent"], pattern["description"], pattern["confidence"],
              json.dumps(pattern["tool_chain"], ensure_ascii=False)))
    conn.commit()
    conn.close()


def learn_pattern(intent, tool_chain_json, description=""):
    """学习新的工具链模式"""
    conn = get_aci_db()
    try:
        # Validate JSON
        chain = json.loads(tool_chain_json) if isinstance(tool_chain_json, str) else tool_chain_json
        conn.execute("""
            INSERT INTO tool_patterns (intent, description, confidence, tool_chain)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(intent) DO UPDATE SET
                description = excluded.description,
                tool_chain = excluded.tool_chain,
                updated_at = datetime('now')
        """, (intent, description, 0.7, json.dumps(chain, ensure_ascii=False)))
        conn.commit()
        return {"ok": True, "intent": intent}
    except Exception as e:
        return {"error": str(e)}
    finally:
        conn.close()


def match_pattern(message):
    """匹配用户消息与已知工具链模式"""
    conn = get_aci_db()
    patterns = conn.execute(
        "SELECT * FROM tool_patterns ORDER BY confidence DESC"
    ).fetchall()
    conn.close()

    hits = []
    for p in patterns:
        intent = p["intent"]
        # Multi-strategy matching: intent as phrase, individual keywords
        matched = False
        # Strategy 1: Exact phrase match (intent in message)
        if intent in message:
            matched = True
        # Strategy 2: Keyword-based (split intent into individual words)
        if not matched:
            keywords = [kw for kw in intent.split() if len(kw) >= 2]
            matched = all(kw in message for kw in keywords)
        # Strategy 3: Chinese word boundary - check if any 2+ char segment matches
        if not matched:
            for i in range(len(intent) - 1):
                segment = intent[i:i+2]
                if segment in message:
                    matched = True
                    break

        if matched:
            hits.append({
                "id": p["id"],
                "intent": p["intent"],
                "description": p["description"],
                "confidence": p["confidence"],
                "tool_chain": json.loads(p["tool_chain"]),
            })

    return hits


# ── 预执行引擎 ──────────────────────────────────────────────────────

def pre_execute_tool_chain(tool_chain, context_vars=None):
    """预执行只读工具链，返回结果"""
    context_vars = context_vars or {}
    results = []
    start = time.time()

    for tool in tool_chain:
        if not tool.get("read_only", False):
            continue

        name = tool["name"]
        args_tmpl = tool.get("args_template", {})

        # 替换参数模板中的变量
        resolved_args = {}
        for k, v in args_tmpl.items():
            if isinstance(v, str):
                for var_name, var_val in context_vars.items():
                    v = v.replace(f"{{{var_name}}}", str(var_val))
            resolved_args[k] = v

        result = _execute_readonly_tool(name, resolved_args)
        results.append({
            "tool": name,
            "args": resolved_args,
            "result": result,
            "duration_ms": int((time.time() - start) * 1000),
        })

    return results


def _execute_readonly_tool(name, args):
    """执行单个只读工具"""
    import urllib.parse
    try:
        if name == "web_search":
            query = args.get("query", "")
            req = urllib.request.Request(
                f"https://api.duckduckgo.com/?q={urllib.parse.quote(query)}&format=json&no_html=1",
                headers={"User-Agent": "Mozilla/5.0"},
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                return resp.read().decode()[:2000]

        elif name == "fetch_url":
            url = args.get("url", "")
            with urllib.request.urlopen(url, timeout=10) as resp:
                return resp.read().decode()[:3000]

        elif name == "search_files":
            pattern = args.get("pattern", "")
            target = args.get("target", "content")
            path = args.get("path", ".")
            result = subprocess.run(
                ["grep", "-r", "-l", pattern, path],
                capture_output=True, text=True, timeout=10
            )
            return result.stdout[:2000] or "No matches"

        elif name == "cronjob":
            result = subprocess.run(
                ["hermes", "cron", "list"],
                capture_output=True, text=True, timeout=10
            )
            return result.stdout[:2000]

        elif name == "terminal":
            cmd = args.get("command", "")
            result = subprocess.run(
                cmd, shell=True, capture_output=True, text=True, timeout=10
            )
            return result.stdout[:2000] + result.stderr[:1000]

        else:
            return f"[Unknown tool: {name}]"

    except Exception as e:
        return f"[Error: {e}]"


# ── ACI注入器 ──────────────────────────────────────────────────────

def run_aci_inject(message, context_vars=None):
    """
    完整ACI注入流程：
    1. 语义记忆预判 — 从Bailongma检索相关记忆
    2. 工具链模式匹配 → 预执行
    3. 写入prefetch_cache供Bailongma使用
    """
    context_vars = context_vars or {}
    injection_result = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "message": message,
        "layer_a_memories": [],
        "layer_b_patterns": [],
        "layer_b_prefetched": [],
        "layer_c_prefetch_cache": [],
    }

    # Layer A: 语义记忆
    memories = read_bailongma_memories(search=message, limit=10)
    if memories and isinstance(memories, list):
        injection_result["layer_a_memories"] = [
            {"id": m.get("id"), "content": m.get("content", "")[:200],
             "type": m.get("event_type"), "title": m.get("title")}
            for m in memories[:5]
        ]

    # Layer B: 工具链模式匹配
    patterns = match_pattern(message)
    for p in patterns[:2]:  # 最多匹配2个模式
        tool_results = pre_execute_tool_chain(p["tool_chain"], context_vars)
        injection_result["layer_b_patterns"].append({
            "intent": p["intent"],
            "confidence": p["confidence"],
            "tool_chain": p["tool_chain"],
            "pre_executed": tool_results,
        })

        # 将预执行结果写入prefetch_cache
        for tr in tool_results[:3]:
            cache_source = f"aci_prefetch:{p['intent']}:{tr['tool']}"
            cache_content = str(tr.get("result", ""))[:1000]
            write_result = write_prefetch_cache(
                source=cache_source,
                content=cache_content,
                ttl_minutes=15,
                tags=["aci", "prefetch", p["intent"]]
            )
            injection_result["layer_c_prefetch_cache"].append(cache_source)

    # 更新pattern命中计数
    conn = get_aci_db()
    for p in patterns:
        conn.execute(
            "UPDATE tool_patterns SET hit_count = hit_count + 1, last_used = datetime('now') WHERE id = ?",
            (p["id"],)
        )
        conn.execute(
            "INSERT INTO pattern_log (pattern_id, message) VALUES (?, ?)",
            (p["id"], message[:200])
        )
    conn.commit()
    conn.close()

    return injection_result


# ── CLI ─────────────────────────────────────────────────────────────

def cli_status():
    """ACI引擎状态"""
    conn = get_aci_db()
    pattern_count = conn.execute("SELECT COUNT(*) as c FROM tool_patterns").fetchone()["c"]
    hit_total = conn.execute("SELECT COALESCE(SUM(hit_count), 0) as c FROM tool_patterns").fetchone()["c"]
    recent_hits = conn.execute(
        "SELECT COUNT(*) as c FROM pattern_log WHERE created_at > datetime('now', '-1 hour')"
    ).fetchone()["c"]
    conn.close()

    # Check Bailongma status
    blm = bailongma_api("GET", "/status")

    # Check prefetch_cache stats
    cache_count = 0
    try:
        db = bailongma_db()
        if db:
            cache_count = db.execute("SELECT COUNT(*) as c FROM prefetch_cache").fetchone()["c"]
            db.close()
    except:
        pass

    return {
        "status": "OK",
        "bailongma": blm.get("ok", False),
        "patterns_known": pattern_count,
        "patterns_includes_builtins": len(BUILTIN_PATTERNS),
        "total_hits": hit_total,
        "recent_1h_hits": recent_hits,
        "prefetch_cache_entries": cache_count,
        "db_path": ACI_DB,
    }


def main():
    if len(sys.argv) < 2:
        print("ACI Engine — Bailongma Anticipatory Context Injection")
        print()
        print("用法:")
        print("  aci status                           # 引擎状态")
        print("  aci init                             # 初始化内置模式")
        print("  aci pattern list                     # 列出所有模式")
        print("  aci pattern learn <intent> <json>    # 学习新模式")
        print("  aci pattern match <message>          # 匹配并预执行")
        print("  aci inject <message>                 # 完整ACI注入")
        print("  aci prefetch list                    # 预热缓存列表")
        print("  aci prefetch add <src> <url> [ttl]   # 注册预热任务")
        sys.exit(1)

    cmd = sys.argv[1]

    if cmd == "status":
        s = cli_status()
        print(json.dumps(s, ensure_ascii=False, indent=2))

    elif cmd == "init":
        init_builtin_patterns()
        print(f"✅ 已初始化 {len(BUILTIN_PATTERNS)} 个内置工具链模式")

    elif cmd == "pattern" and len(sys.argv) >= 3:
        sub = sys.argv[2]
        if sub == "list":
            conn = get_aci_db()
            rows = conn.execute("SELECT * FROM tool_patterns ORDER BY confidence DESC").fetchall()
            conn.close()
            if not rows:
                print("暂无工具链模式。运行 'aci init' 初始化内置模式。")
            for r in rows:
                tools = json.loads(r["tool_chain"])
                tool_names = ", ".join(t["name"] for t in tools)
                print(f"  [{r['id']}] {r['intent']} (conf={r['confidence']}, hits={r['hit_count']})")
                print(f"       {r['description'] or ''}")
                print(f"       工具链: {tool_names}")
                print()

        elif sub == "learn" and len(sys.argv) >= 5:
            intent = sys.argv[3]
            tool_json = sys.argv[4]
            desc = sys.argv[5] if len(sys.argv) > 5 else ""
            result = learn_pattern(intent, tool_json, desc)
            print(json.dumps(result, ensure_ascii=False, indent=2))

        elif sub == "match" and len(sys.argv) >= 4:
            message = " ".join(sys.argv[3:])
            patterns = match_pattern(message)
            if not patterns:
                print(f"未匹配到已知模式: {message}")
            else:
                print(f"匹配到 {len(patterns)} 个模式:")
                for p in patterns:
                    print(f"  → {p['intent']} (conf={p['confidence']})")
                    print(f"    预执行工具链...")
                    results = pre_execute_tool_chain(p["tool_chain"])
                    for r in results[:3]:
                        preview = str(r.get("result", ""))[:150]
                        print(f"    ✅ {r['tool']} ({r['duration_ms']}ms): {preview}")

    elif cmd == "inject" and len(sys.argv) >= 3:
        message = " ".join(sys.argv[2:])
        result = run_aci_inject(message)
        print(json.dumps(result, ensure_ascii=False, indent=2))

    elif cmd == "prefetch" and len(sys.argv) >= 3:
        sub = sys.argv[2]
        if sub == "list":
            db = bailongma_db()
            if not db:
                print("Bailongma DB未找到")
                sys.exit(1)
            rows = db.execute("SELECT * FROM prefetch_cache ORDER BY fetched_at DESC").fetchall()
            if not rows:
                print("prefetch_cache为空")
            for r in rows:
                expires = r["expires_at"][:19]
                print(f"  [{r['source']}] expires={expires}")
                print(f"    {r['content'][:100]}")
            db.close()

        elif sub == "add" and len(sys.argv) >= 5:
            source = sys.argv[3]
            url = sys.argv[4]
            ttl = int(sys.argv[5]) if len(sys.argv) > 5 else 60
            result = register_bailongma_prefetch(source, source, url, ttl)
            print(json.dumps(result, ensure_ascii=False, indent=2))

        elif sub == "run":
            print("正在执行所有预热任务...")
            # Run prefetch via Bailongma API
            result = bailongma_api("POST", "/admin/prefetch-run")
            print(json.dumps(result, ensure_ascii=False, indent=2))

    else:
        print(f"未知命令: {sys.argv[1]}")


if __name__ == "__main__":
    main()
