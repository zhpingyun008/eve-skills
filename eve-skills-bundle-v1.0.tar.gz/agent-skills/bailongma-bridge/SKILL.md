---
name: bailongma-bridge
description: Bailongma (白龙马) 底层执行智能体集成桥 — 持续数字意识框架的HTTP API封装，支持TICK循环、ACI预判注入、记忆系统、社交通道、Dashboard面板
triggers: bailongma|白龙马|longma|底层执行智能体
category: agent-skills
version: 1.2.0
created: 2026-05-13
updated: 2026-05-13
author: Yestin
---

# Bailongma Bridge — 白龙马执行智能体集成桥

## 架构全景

```
社交平台(微信/Discord/飞书/企微)
  ↓ Bailongma connectors (native)
Bailongma v1.8.175 (:3721)
  ├─ TICK主循环 + L1/L2思考
  ├─ ACI预判注入引擎 (3层)
  ├─ 记忆系统 (FTS5 + 识别器)
  └─ HTTP API + SSE + ACUI WS
       ↓ bailongma-bridge skill
Hermes Agent + Dashboard (:5000)
  ├─ bailongma-aci.py — ACI注入
  ├─ bailongma-social.py — 社交路由
  └─ hermes-prefetch-update.py — 预热
```

## 桥接脚本

| 脚本 | 用途 |
|------|------|
| `bailongma-bridge.py` | 基础API桥接 (send/status/memories/search/quota/control) |
| `bailongma-aci.py` | ACI预判注入引擎 (三层: 语义/工具链/定时预热) |
| `bailongma-social.py` | 社交消息路由 (status/listen/dispatch/track) |
| `hermes-prefetch-update.py` | Hermes数据→Bailongma prefetch_cache |
| `check_health.py` | Bailongma健康巡检+自动自愈 (每5分钟cron调用) |

### ACI引擎

```bash
python3 scripts/bailongma-aci.py init        # 初始化5个内置模式
python3 scripts/bailongma-aci.py status      # 引擎状态
python3 scripts/bailongma-aci.py pattern list # 工具链模式列表
python3 scripts/bailongma-aci.py inject "天气" # 完整ACI注入
```

### 社交桥接

```bash
python3 scripts/bailongma-social.py status               # 社交连接器状态
python3 scripts/bailongma-social.py listen 30             # 监听SSE社交事件30s
python3 scripts/bailongma-social.py dispatch wechat user_id "msg"  # 发送消息
python3 scripts/bailongma-social.py messages              # 最近社交消息
python3 scripts/bailongma-social.py track wx uid "msg"   # 手动追踪消息
```

## Dashboard集成

| 面板 | 位置 | 内容 |
|------|------|------|
| Bailongma ACI | 子系统卡片行 | Running状态/Patterns/Prefetch/Memories |
| BLM指示器 | 命令中心 | 🐉 Online/Offline |
| Social指示器 | 命令中心 | 📱 connected channels |
| Social API | /api/bailongma/social | 5平台连接器状态 |

## Cron任务

| 类型 | 频率 | 用途 |
|------|------|------|
| Bailongma健康巡检 | 每5min | 检测:3721, 宕机自启 |
| ACI预热缓存更新 | 每15min | 刷新Hermes数据到prefetch_cache |

## Bailongma 核心能力

- TICK驱动主循环 (非问答式)
- L1/L2双层思考 (快速响应+深度处理)
- ACI预判注入 (记忆/工具链/定时预热)
- 记忆系统 (SQLite+FTS5+识别器)
- LLM Providers (MiniMax/DeepSeek/OpenAI)
- ACUI视觉通道 (卡片/模板/交互)
- **社交通道 (微信/Discord/飞书/企微)**
- 天气/提醒/TTS/专注模式

## Feedback Engine Patches
*自动生成于 2026-07-16 02:02:04*

## Tool Recommendations (from trajectory feedback)

### patch
Trajectory analysis shows **patch** strongly correlates with high session scores.
- Use `patch` for targeted find-and-replace edits instead of sed/awk.
- Supports fuzzy matching with 9 strategies for robust edits.
- Auto-runs syntax checks after modification.
- Preferred for surgical code changes over full file rewrites.

### Guardrails
- Ensure `old_string` is unique in the file unless `replace_all=True`.
- Include enough surrounding context to guarantee uniqueness.
- Use `mode='patch'` for V4A multi-file patches.

### Efficiency Tips
- Combine multiple edits into a single V4A patch when possible.
- Use `replace_all=True` for bulk replacements of the same pattern.
- Preview changes with `--dry-run` mode before applying.

---
## Feedback Engine Patches
*自动生成于 2026-07-17 02:02:37*

## Tool Recommendations (from trajectory feedback)

### patch
Trajectory analysis shows **patch** strongly correlates with high session scores.
- Use `patch` for targeted find-and-replace edits instead of sed/awk.
- Supports fuzzy matching with 9 strategies for robust edits.
- Auto-runs syntax checks after modification.
- Preferred for surgical code changes over full file rewrites.

### Guardrails
- Ensure `old_string` is unique in the file unless `replace_all=True`.
- Include enough surrounding context to guarantee uniqueness.
- Use `mode='patch'` for V4A multi-file patches.

### Efficiency Tips
- Combine multiple edits into a single V4A patch when possible.
- Use `replace_all=True` for bulk replacements of the same pattern.
- Preview changes with `--dry-run` mode before applying.

---
## Feedback Engine Patches
*自动生成于 2026-07-22 12:19:48*

## Tool Recommendations (from trajectory feedback)

### patch
Trajectory analysis shows **patch** strongly correlates with high session scores.
- Use `patch` for targeted find-and-replace edits instead of sed/awk.
- Supports fuzzy matching with 9 strategies for robust edits.
- Auto-runs syntax checks after modification.
- Preferred for surgical code changes over full file rewrites.

### Guardrails
- Ensure `old_string` is unique in the file unless `replace_all=True`.
- Include enough surrounding context to guarantee uniqueness.
- Use `mode='patch'` for V4A multi-file patches.

### Efficiency Tips
- Combine multiple edits into a single V4A patch when possible.
- Use `replace_all=True` for bulk replacements of the same pattern.
- Preview changes with `--dry-run` mode before applying.
