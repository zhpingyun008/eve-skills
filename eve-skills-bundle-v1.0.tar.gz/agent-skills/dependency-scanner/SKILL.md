---
name: dependency-scanner
description: Scans project dependencies for security vulnerabilities, license compliance, and outdated packages. Integrates with pip/npm/maven/gradle.
category: agent-skills
triggers:
  - "dependency-scanner"
  - "依赖扫描"
  - "dependency check"
  - "vulnerability scan"
  - "license audit"
  - "安全依赖"
  - "supply chain"
---

# Dependency Scanner — 供应链依赖扫描器

## Overview

扫描项目依赖中的安全漏洞、许可证合规性和过期包。集成 pip/npm/maven 等包管理器。支持 SBOM 生成和 CVE 关联分析。

## 核心功能

- **漏洞扫描** — 检测依赖中的已知CVE，CVSS分级
- **许可证合规** — 识别所有依赖的许可证类型，标记冲突
- **过期检测** — 检查是否有安全修复/功能更新的最新版本
- **SBOM 生成** — 输出 SPDX/CycloneDX 标准的软件物料清单

## 支持的包管理器

| 管理器 | 检测文件 | 扫描方法 |
|:------|:--------|:--------|
| pip | requirements.txt, pyproject.toml | pip-audit / safety |
| npm | package-lock.json | npm audit |
| maven | pom.xml | OWASP DC |
| gradle | build.gradle | OWASP DC |

## 使用方式

```bash
# 自动检测包管理器并扫描
python3 scripts/check.py --check

# 生成SBOM
python3 scripts/run.py --sbom > sbom.json

# 仅高危漏洞
python3 scripts/run.py --severity critical
```

## 适用场景

- CI/CD 门禁 — 阻断含高危漏洞的依赖引入
- 项目初始化 — 扫描已有项目的依赖安全性
- 合规审计 — 输出许可证清单满足审计要求
- 供应链安全 — 抵御依赖混淆/恶意包攻击

## 注意事项

- 需要网络访问获取CVE数据库
- 大项目首次扫描可能耗时30s+（因需下载漏洞数据库）
- license检测基于元数据，不保证100%准确（部分库缺失license声明）
