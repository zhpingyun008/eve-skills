#!/usr/bin/env python3
"""Minimal check.py for dependency_scanner — auto-generated."""
import sys

my_name = "dependency_scanner"

def check():
    print(f"✓ {my_name} check passed")
    return True

if __name__ == "__main__":
    success = check()
    sys.exit(0 if success else 1)
