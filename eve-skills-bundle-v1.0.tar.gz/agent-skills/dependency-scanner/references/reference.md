# Dependency Scanner Reference

## Overview
Auto-generated reference for dependency-scanner skill.

## Usage
See SKILL.md for full documentation.
