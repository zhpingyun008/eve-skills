---
name: migration-assistant
description: Framework/language migration assistance — analyze codebase for migration targets, generate step-by-step migration plans, auto-apply simple transformations (JS→TS, Vue2→Vue3, CJS→ESM), compatibility checking.
category: agent-skills
triggers:
  - "migrate code"
  - "upgrade framework"
  - "language migration"
  - "code transformation"
  - "tech stack migration"
  - "transpile"
  - "convert to"
  - "port to"
  - "rewrite in"
  - "version upgrade"
  - "CJS to ESM"
  - "JS to TS"
  - "Vue2 to Vue3"
  - "Python 2 to 3"
  - "React class to hooks"
---

# Migration-Assistant: Codebase & Framework Migration

## Purpose
Assist with any kind of codebase migration: language upgrades, framework version bumps, module system transitions, and tech stack swaps. Analyze the current state, generate a phased plan, auto-apply safe transformations, and verify compatibility.

## Triggers
- User says: "migrate code", "upgrade framework", "language migration", "code transformation", "tech stack migration", "transpile", "convert to", "port to", "rewrite in"
- Any request involving JS→TS, Vue2→Vue3, CJS→ESM, AngularJS→Angular, React class→hooks, Python 2→3, etc.

## Workflow

### Phase 1: Discovery — Analyze the Codebase

1. **Identify the source and target**
   - Ask the user explicitly: what are we migrating FROM and TO?
   - If not specified, detect current tech stack from package.json, pyproject.toml, Cargo.toml, go.mod, etc.

2. **Map the codebase surface**
   ```
   search_files(pattern='*.js', target='files')       # count files by extension
   search_files(pattern='require\\(', target='content')  # CJS imports
   search_files(pattern='new Vue\\(', target='content')  # Vue2 patterns
   search_files(pattern='class .* extends React.Component', target='content')  # class components
   ```

3. **Build a migration inventory** — produce a table:
```
📊 Migration Inventory: JS → TS

| Pattern                  | Count | Risk  | Auto? |
|--------------------------|-------|-------|-------|
| .js files (renamable)    | 127   | LOW   | YES   |
| require() calls → import | 843   | MED   | YES   |
| module.exports → export  | 89    | MED   | YES   |
| var/let without type     | 1204  | LOW   | YES   |
| any-typed holes          | ?     | HIGH  | MANUAL|
| Dynamic require()        | 3     | HIGH  | NO    |
```

### Phase 2: Plan — Generate Step-by-Step Instructions

Produce a structured, ordered migration plan:

```
📋 Migration Plan: CJS → ESM

Step 1: Update package.json
  - Add "type": "module"
  - Bump engines.node to >=16

Step 2: Rename files (.js → .mjs or keep .js)
  - 127 files to rename
  - Command: for f in $(find src -name '*.js'); do mv "$f" "${f%.js}.mjs"; done

Step 3: Transform import syntax (auto)
  - require('x') → import ... from 'x'
  - module.exports = → export default / export { }
  - __dirname → fileURLToPath(import.meta.url)

Step 4: Update internal references
  - Fix all require('./foo') to import './foo.mjs'

Step 5: Compatibility verification
  - Run lint, tests, build
  - Check for remaining CJS patterns

Step 6: Update CI/CD
  - Bump Node version in Dockerfile, CI config
```

Each step must include:
- **What** changes are made
- **Why** (rationale)
- **How** (exact commands or transformations)
- **Risk** level (LOW / MED / HIGH)
- **Rollback** instructions

### Phase 3: Execute — Auto-Apply Simple Transformations

For LOW and MED-risk transformations, apply automatically:

#### JS → TypeScript (Common Patterns)
```javascript
// CJS → ESM
// BEFORE:                          // AFTER:
const fs = require('fs');           import fs from 'fs';
const { join } = require('path');   import { join } from 'path';
module.exports = myFunc;            export default myFunc;
module.exports = { a, b };          export { a, b };
__dirname                          fileURLToPath(import.meta.url)
__filename                         fileURLToPath(import.meta.url)
require.main === module             import.meta.url === `file://${process.argv[1]}`
```

#### Vue 2 → Vue 3 (Common Patterns)
```javascript
// BEFORE:                          // AFTER:
new Vue({ el: '#app', ... })        createApp(App).mount('#app')
Vue.component('name', {...})        app.component('name', {...})
Vue.filter('name', fn)              // REMOVED — use computed/methods
Vue.prototype.$http = axios         app.config.globalProperties.$http = axios
this.$listeners                     // REMOVED — merged into $attrs
this.$on('event', fn)               // REMOVED — use mitt or composables
filters: { ... }                    // REMOVED — use computed properties
v-model="val" (on component)        v-model:modelValue="val"
template: '<slot name="x">'         <template v-slot:x>
```

#### React Class → Hooks
```javascript
// BEFORE:                          // AFTER:
class Comp extends Component {       function Comp() {
  state = { count: 0 };               const [count, setCount] = useState(0);
  componentDidMount() {               useEffect(() => {
    fetchData();                        fetchData();
  }                                   }, []);
  handleClick = () => {               const handleClick = () => {
    this.setState({ count: +1 });        setCount(c => c + 1);
  }                                   };
  render() {                          return (
    return <div>{this.state.x}</div>;    <div>{count}</div>
  }                                   );
}                                   }
```

#### Python 2 → 3
```python
# BEFORE:                      # AFTER:
print "hello"                  print("hello")
except Exception, e:           except Exception as e:
xrange(...)                    range(...)
raw_input(...)                 input(...)
# -*- coding: utf-8 -*-       # REMOVED (default in Python 3)
unicode(x)                     str(x)
dict.iteritems()               dict.items()
__metaclass__ = type           class Foo(metaclass=type):
```

### Phase 4: Verify — Compatibility Checking

After transformations, run:
1. **Syntax check**: `node --check`, `python -m py_compile`, `tsc --noEmit`
2. **Lint**: `eslint`, `pylint`, `cargo clippy`
3. **Tests**: `npm test`, `pytest`, `cargo test`
4. **Build**: `npm run build`, `make`
5. **Pattern scan** for leftover old syntax:

```
# Check for remaining CJS patterns after ESM migration
search_files(pattern='require\\(', target='content')

# Check for remaining Vue2 patterns after Vue3 migration
search_files(pattern='new Vue\\(', target='content')
search_files(pattern='Vue\\.component\\(', target='content')
search_files(pattern='\\$\\.listeners', target='content')
```

### Phase 5: Report

Produce a final report:
```
✅ Migration Complete: CJS → ESM

| Metric              | Before | After  |
|---------------------|--------|--------|
| .js files           | 127    | 0      |
| .mjs files          | 0      | 127    |
| require() calls     | 843    | 0      |
| import statements   | 12     | 843    |
| module.exports      | 89     | 0      |
| export statements   | 0      | 89     |

⚠️  Manual follow-ups (3 items):
  1. src/dynamic-loader.js — dynamic require() needs manual refactor
  2. config/runtime-plugins/ — __dirname usage in generated files
  3. tests/fixtures/ — test fixtures still reference .js extensions

📦 Dependencies updated: package.json, tsconfig.json, Dockerfile, CI config
🧪 Tests: 214/214 passing
```

## Rules & Best Practices

### Do
- Always run syntax/lint checks after each transformation batch
- Commit after each successful phase (git checkpoint)
- Keep the old code reachable via git history — never delete without commit
- Test at every intermediate step, not just at the end
- Use AST-based tools for complex transformations (jscodeshift, ts-morph)
- Preserve comments and formatting where possible

### Don't
- Migrate without a rollback plan
- Apply HIGH-risk transformations automatically without user approval
- Mix migration changes with feature changes in the same commit
- Skip the compatibility scan after migration
- Assume one tool works for all file types — verify per extension

## AST Transformation Tools

For complex, high-volume transformations, prefer AST-aware tools over regex:

| Tool            | Language  | Use Case                                    |
|-----------------|-----------|---------------------------------------------|
| jscodeshift     | JS/TS     | Bulk codemods: CJS→ESM, class→hooks         |
| ts-morph        | TS        | TypeScript-aware refactors, add types       |
| libcst          | Python    | Safe Python AST transforms                  |
| 2to3            | Python    | Python 2 → 3 migration                      |
| gofmt -r        | Go        | Go expression rewrites                      |
| semgrep         | Multi     | Pattern-based find-and-replace with context |
| ast-grep        | Multi     | Structural code search and replace          |
| comby           | Multi     | Structural search/replace for any language  |

### jscodeshift Example (CJS → ESM)
```javascript
// jscodeshift transform: cjs-to-esm.js
export default function transformer(file, api) {
  const j = api.jscodeshift;
  const root = j(file.source);

  // require('x') → import 'x'
  root.find(j.CallExpression, {
    callee: { name: 'require' }
  }).replaceWith(path => {
    const arg = path.node.arguments[0];
    return j.importDeclaration([], arg);
  });

  // const x = require('y') → import x from 'y'
  // const { a, b } = require('y') → import { a, b } from 'y'

  // module.exports = x → export default x
  root.find(j.AssignmentExpression, {
    left: {
      object: { name: 'module' },
      property: { name: 'exports' }
    }
  }).replaceWith(path => {
    return j.exportDefaultDeclaration(path.node.right);
  });

  return root.toSource();
}
```

## Common Migration Patterns Reference

See `references/reference.md` for a comprehensive catalog of migration patterns including:
- JS → TS type annotation strategies
- Vue2 → Vue3 breaking changes (full list)
- CJS → ESM edge cases (dynamic imports, circular deps)
- Python 2 → 3 known incompatibilities
- React class → hooks refactoring recipes
- AngularJS → Angular migration checklist
- Database migration patterns (SQL → NoSQL, schema changes)
- Configuration migration (Webpack → Vite, Babel → SWC)

## Integration with Other Skills
- Before migration: run `codebase-learner` to understand the codebase
- After each phase: run `code-review` on the changes
- For complex multi-file changes: use `multi-file-refactor`
- For git management: use `git-workflow` to create checkpoint commits
- Run `lint-test-loop` after each transformation batch

## Pitfalls

- Regex-based transformations can corrupt code with similar-looking but semantically different patterns — always prefer AST-based tools for complex changes
- Migration scripts that work on 95% of files can leave subtle bugs in the remaining 5% — never assume 100% automation; always budget for manual follow-ups
- Changing module systems (CJS→ESM) breaks all internal import paths — update every `require()` reference before running tests
- Vue 2 filters have no Vue 3 equivalent — every filter usage must be manually converted to computed properties or methods
- Python 2 `str` vs `unicode` semantics differ from Python 3 `str` — string handling code needs careful review, not blind transformation
- Dynamic `require()` calls cannot be mechanically converted to static `import` — these require architectural changes
- Running migration tools without version control checkpoints makes rollback impossible — commit after every automated phase
- TypeScript migration can introduce hundreds of `any`-typed holes that defeat the purpose — set `noImplicitAny: true` early and fix incrementally
- Framework version bumps may have undocumented breaking changes — always consult the official migration guide for the target version
- Test suites may pass after migration but cover different code paths due to changed semantics — review test coverage, not just test results

---
## Feedback Engine Patches
*自动生成于 2026-07-14 02:02:41*

## Tool Recommendations (from trajectory feedback)

### search_files
Trajectory analysis shows **search_files** strongly correlates with high session scores.
- Use instead of grep/rg/find in terminal.
- Content search: regex inside files (faster than shell grep).
- File search: glob patterns with results sorted by modification time.
- Supports output modes: `content`, `files_only`, `count`.

### Guardrails
- Regex patterns: ensure proper escaping for special characters.
- File globs: use simple patterns like `*.py`, `*config*`.
- For large directory trees, narrow with `path` parameter.

### Efficiency Tips
- Combine content search with `output_mode='files_only'` for fast file discovery.
- Use `context=N` for surrounding lines around matches.
- Limit results with `limit` parameter to avoid overwhelming output.

---
## Feedback Engine Patches
*自动生成于 2026-07-21 08:58:12*

## Tool Recommendations (from trajectory feedback)

### search_files
Trajectory analysis shows **search_files** strongly correlates with high session scores.
- Use instead of grep/rg/find in terminal.
- Content search: regex inside files (faster than shell grep).
- File search: glob patterns with results sorted by modification time.
- Supports output modes: `content`, `files_only`, `count`.

### Guardrails
- Regex patterns: ensure proper escaping for special characters.
- File globs: use simple patterns like `*.py`, `*config*`.
- For large directory trees, narrow with `path` parameter.

### Efficiency Tips
- Combine content search with `output_mode='files_only'` for fast file discovery.
- Use `context=N` for surrounding lines around matches.
- Limit results with `limit` parameter to avoid overwhelming output.

---
## Feedback Engine Patches
*自动生成于 2026-07-22 12:19:48*

## Tool Recommendations (from trajectory feedback)

### search_files
Trajectory analysis shows **search_files** strongly correlates with high session scores.
- Use instead of grep/rg/find in terminal.
- Content search: regex inside files (faster than shell grep).
- File search: glob patterns with results sorted by modification time.
- Supports output modes: `content`, `files_only`, `count`.

### Guardrails
- Regex patterns: ensure proper escaping for special characters.
- File globs: use simple patterns like `*.py`, `*config*`.
- For large directory trees, narrow with `path` parameter.

### Efficiency Tips
- Combine content search with `output_mode='files_only'` for fast file discovery.
- Use `context=N` for surrounding lines around matches.
- Limit results with `limit` parameter to avoid overwhelming output.
