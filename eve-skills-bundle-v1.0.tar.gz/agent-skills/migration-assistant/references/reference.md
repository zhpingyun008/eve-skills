# Migration Patterns Reference

Comprehensive catalog of common migration patterns, AST transformation tools,
and migration strategy best practices.

---

## 1. Common Migration Patterns

### 1.1 JavaScript → TypeScript

**File Renames**
- `.js` → `.ts`
- `.jsx` → `.tsx`

**Type Annotation Strategy**
- Start with `strict: false` in tsconfig, incrementally tighten
- Use `noImplicitAny: false` initially, then enable per file
- Add type stubs for third-party modules: `declare module 'foo';`

**Common Transformations**
```
// PropTypes → TypeScript interfaces
Button.propTypes = {              interface ButtonProps {
  label: PropTypes.string,    →     label: string;
  onClick: PropTypes.func,         onClick: () => void;
};                               }

// Default args in JS → default args in TS
function greet(name) {           function greet(name: string = 'World') {
  name = name || 'World';    →
}                                }

// JSDoc types → TS types (migrate annotations)
/** @type {string} */            const name: string = 'Alice';
const name = 'Alice';        →
```

**Pitfalls**
- `.js` and `.ts` files with the same name conflict — rename .js first
- Path aliases in tsconfig must match webpack/vite aliases
- `enum` compiles to IIFE — prefer `const enum` or union types
- Webpack resolve.extensions must include `.ts`, `.tsx` before `.js`

---

### 1.2 CJS → ESM

**Checklist**
1. Set `"type": "module"` in package.json OR use `.mjs` extension
2. Replace `require()` with `import`
3. Replace `module.exports` with `export default` / `export { }`
4. Replace `__dirname` with `fileURLToPath(import.meta.url)`
5. Replace `__filename` with `fileURLToPath(import.meta.url)`
6. Update dynamic `require()` to `await import()`
7. Move `require.extensions` to loader hooks (Node 18+)

**Edge Cases**
- **Circular deps**: ESM resolves exports statically — hoisted exports can mask circular deps that CJS handled at runtime
- **Conditional requires**: `if (cond) require('x')` → `if (cond) { await import('x') }` (async)
- **require.resolve()**: use `import.meta.resolve()` or `createRequire`
- **require.cache**: no direct ESM equivalent; use `import()` with query string for cache busting
- **JSON imports**: CJS `require('./data.json')` → ESM `import data from './data.json' with { type: 'json' }` (newer Node) or use `createRequire`

**Codemod Tools**
- `jscodeshift -t cjs-to-esm.js src/` (see SKILL.md for transform script)
- `cjs-to-esm` npm package: CLI wrapper around jscodeshift

---

### 1.3 Vue 2 → Vue 3

**Breaking Changes (Full List)**

| Vue 2 API                       | Vue 3 Equivalent                              |
|--------------------------------|-----------------------------------------------|
| `new Vue()`                    | `createApp()`                                 |
| `Vue.component()`              | `app.component()`                             |
| `Vue.directive()`              | `app.directive()`                             |
| `Vue.mixin()`                  | `app.mixin()`                                 |
| `Vue.use()`                    | `app.use()`                                   |
| `Vue.prototype.$x`             | `app.config.globalProperties.$x`              |
| `Vue.filter()`                 | REMOVED — use computed/methods                |
| `this.$listeners`              | REMOVED — merged into `$attrs`                |
| `this.$on/off/once`            | REMOVED — use mitt or composables             |
| `this.$children`               | REMOVED — use template refs                   |
| `filters` option               | REMOVED — use computed properties             |
| `v-model` on component         | `v-model:modelValue` + `emits: ['update:...']`|
| `.sync` modifier               | `v-model:propName`                            |
| `v-if`/`v-for` precedence      | `v-if` has higher precedence (was lower)      |
| `<slot name="x">`              | `<template v-slot:x>`                         |
| `keyCode` modifiers            | REMOVED — check `event.key` manually          |
| `$scopedSlots`                 | REMOVED — use `$slots`                        |
| `inline-template`              | REMOVED                                       |
| `Vue.set()` / `Vue.delete()`   | Not needed — Vue 3 reactivity detects changes |
| `destroyed` lifecycle          | `unmounted`                                   |
| `beforeDestroy` lifecycle      | `beforeUnmount`                               |
| `Vue.observable()`             | `reactive()`                                  |
| `render` function API          | `h()` import from 'vue' (not render arg)      |
| `functional` component option  | Plain function components                     |

**Migration Strategy**
1. Upgrade `vue` to 3.x (2.7 compatibility build first for gradual)
2. Install `@vue/compat` (migration build) — enables Vue 2 APIs with deprecation warnings
3. Resolve deprecation warnings one by one
4. Install `vue-router@4`, `vuex@4` (or pinia)
5. Run `npx vue-codemod` for automated transforms
6. Remove `@vue/compat` when clean

**Codemods**
- `npx vue-codemod` — official Vue migration tool
- Transforms: `new Vue` → `createApp`, filters removal, `v-model` migration

---

### 1.4 React Class → Hooks

**Lifecycle Mapping**

| Class Method              | Hook Equivalent                                    |
|---------------------------|---------------------------------------------------|
| `constructor()`           | `useState()` / `useRef()` initial values          |
| `componentDidMount()`     | `useEffect(() => {}, [])`                          |
| `componentDidUpdate()`    | `useEffect(() => {}, [deps])`                      |
| `componentWillUnmount()`  | `useEffect(() => { return () => {...} }, [])`      |
| `shouldComponentUpdate()` | `React.memo()` / `useMemo()` / `useCallback()`     |
| `this.state.x`            | `const [x, setX] = useState(init)`                |
| `this.setState({x: v})`   | `setX(v)`                                          |
| `this.forceUpdate()`      | `const [, tick] = useState(0); tick(c => c + 1)`  |

**Recipes**

PureComponent → React.memo:
```jsx
// BEFORE
class Greeting extends React.PureComponent {
  render() { return <h1>{this.props.name}</h1>; }
}
// AFTER
const Greeting = React.memo(({ name }) => <h1>{name}</h1>);
```

Error Boundary (no hook equivalent — must stay class):
```jsx
// Error boundaries still require class components in React
class ErrorBoundary extends React.Component { ... }
```

getDerivedStateFromProps → useEffect:
```jsx
// BEFORE
static getDerivedStateFromProps(nextProps, prevState) {
  if (nextProps.id !== prevState.prevId) {
    return { prevId: nextProps.id, derived: compute(nextProps.id) };
  }
  return null;
}
// AFTER
const [derived, setDerived] = useState(compute(props.id));
useEffect(() => setDerived(compute(props.id)), [props.id]);
```

---

### 1.5 Python 2 → 3

**High-Impact Changes**
- `print` statement → `print()` function
- `except ExcType, e:` → `except ExcType as e:`
- `raise ExcType, msg` → `raise ExcType(msg)`
- `xrange()` → `range()`
- `raw_input()` → `input()`
- `dict.iteritems/keys/values()` → `dict.items/keys/values()`
- `/` division → `//` for floor division (or `from __future__ import division`)
- `unicode` → `str`, `basestring` → `str`, `long` → `int`
- `__metaclass__` magic → `class Foo(metaclass=...)`
- `import __builtin__` → `import builtins`
- `reload(x)` → `importlib.reload(x)`
- String encoding: Python 3 is UTF-8 by default

**Tools**
- `2to3`: standard library tool, does ~95% of mechanical changes
- `futurize`: from `python-future` package, creates dual-compatible code
- `python-modernize`: thin wrapper around 2to3 with `__future__` imports
- `six`: compatibility library for dual-support during migration

**Strategy**
1. Run `2to3 -w -n .` for mechanical changes
2. Handle manual cases: bytes vs str, `cmp()` removal, `execfile()`
3. Test thoroughly — Python 3's stricter scoping, iteration semantics
4. Drop Python 2 support once all tests pass on 3

---

### 1.6 AngularJS → Angular

**Architecture Shift**
- Controllers → Components (classes with @Component)
- $scope → component properties + data binding
- ng-model → [(ngModel)] (banana-in-a-box)
- ng-click → (click)
- ng-if → *ngIf
- ng-repeat → *ngFor
- ng-class → [ngClass]
- Services (angular.service) → @Injectable() classes
- $http → HttpClient
- $q → Promises / async-await
- Filters → Pipes (with @Pipe decorator)
- ngRoute → @angular/router

**Migration Strategy (Incremental / ngUpgrade)**
1. Boot both AngularJS and Angular via `ngUpgrade`
2. Downgrade Angular components to use in AngularJS templates
3. Upgrade AngularJS services to inject into Angular
4. Convert leaf components first (bottom-up)
5. Convert routing last (or use hybrid router)
6. Drop AngularJS when no more downgraded code

---

### 1.7 Configuration & Build Tool Migration

**Webpack → Vite**
```
// webpack.config.js:            // vite.config.js:
module.exports = {               export default defineConfig({
  resolve: { alias: ... },   →     resolve: { alias: ... },
  module: { rules: ... },         // rules handled by plugins
  plugins: [...],                 plugins: [...],
};                              });
```
- Remove babel-loader, style-loader, file-loader (Vite does it natively)
- Replace `require.context` with `import.meta.glob`
- Replace `process.env.X` with `import.meta.env.X` (or VITE_ prefix)
- Build scripts: `webpack` → `vite build`, `webpack-dev-server` → `vite`

**Babel → SWC**
- `.babelrc` / `babel.config.js` → `.swcrc`
- Plugin ecosystem differences — verify all transforms are available
- SWC is ~20x faster, but less plugin coverage

**Jest → Vitest**
- Almost drop-in: same API (`describe`, `it`, `expect`)
- Jest globals → import from `vitest` or enable `globals: true`
- `jest.mock()` → `vi.mock()`, `jest.fn()` → `vi.fn()`

---

## 2. AST Transformation Tools

### jscodeshift (JavaScript / TypeScript)
```
npm install -g jscodeshift
jscodeshift -t transform.js src/ --parser tsx --extensions ts,tsx
```

**Transform Boilerplate:**
```javascript
export default function transformer(file, api) {
  const j = api.jscodeshift;
  const root = j(file.source);

  // Find nodes...
  root.find(j.CallExpression, { callee: { name: 'myFunc' } })
    .replaceWith(path => { /* ... */ });

  return root.toSource();
}
module.exports.parser = 'tsx'; // for TypeScript
```

**Common Patterns:**
- `root.find(j.CallExpression, ...)` — find function calls
- `root.find(j.ImportDeclaration, ...)` — find imports
- `root.find(j.VariableDeclaration, ...)` — find var/let/const
- `root.findJSXElements('Button')` — find JSX elements
- `j(path).replaceWith(...)` — replace node
- `j(path).insertBefore/After(...)` — insert siblings
- `root.toSource({ quote: 'single' })` — regenerate source

### ts-morph (TypeScript)
TypeScript-aware refactoring with full type information:

```typescript
import { Project } from 'ts-morph';

const project = new Project({ tsConfigFilePath: 'tsconfig.json' });

project.getSourceFiles().forEach(sourceFile => {
  // Find all function declarations
  sourceFile.getFunctions().forEach(fn => {
    // Add return type annotation
    if (!fn.getReturnTypeNode()) {
      fn.addReturnType(fn.getReturnType().getText());
    }
  });
});

await project.save();
```

**ts-morph advantages over jscodeshift:**
- Type-aware — can resolve generic types
- Symbol resolution across files
- Rename refactoring that respects type system
- Better handling of TS-specific syntax (decorators, enums, etc.)

### libcst (Python)
Concrete Syntax Tree for Python — preserves formatting:

```python
import libcst as cst

class PrintTransformer(cst.CSTTransformer):
    def leave_Call(self, original, updated):
        if (
            isinstance(updated.func, cst.Name)
            and updated.func.value == "print"
        ):
            # Already a function call in Python 2? No change needed
            return updated
        return updated

with open('file.py', 'r') as f:
    tree = cst.parse_module(f.read())

modified = tree.visit(PrintTransformer())
print(modified.code)
```

### semgrep (Multi-language)
Pattern-based search (and replace with semgrep --autofix):

```yaml
rules:
  - id: cjs-require-to-esm-import
    pattern: const $X = require($Y);
    fix: import $X from $Y;
    languages: [javascript, typescript]
```

**semgrep advantages:**
- 30+ languages supported
- Community rule registry (thousands of patterns)
- CI integration out of the box
- `--autofix` for automated replacements
- Metavariable matching (capture parts of patterns)

### ast-grep (Multi-language)
Structural search/replace like semgrep but with different ergonomics:

```yaml
# ast-grep rule
id: require-to-import
language: javascript
rule:
  pattern: const $X = require($Y);
fix: import $X from $Y;
```

### comby (Multi-language, regex-like)
```bash
# Replace require() with import (comby — structural but not AST-based)
comby 'const :[x] = require(:[y]);' 'import :[x] from :[y];' .js -i
```

---

## 3. Migration Strategy Best Practices

### 3.1 The Strangler Fig Pattern
Don't rewrite — gradually replace. Run old and new side by side, redirect traffic incrementally until the old system is unused.

1. Identify a seam (API boundary, route, component)
2. Build new implementation behind the seam
3. Route a percentage of traffic to the new
4. Monitor errors, performance
5. Increase percentage → 100%
6. Remove old code

**Applicable to:**
- Framework upgrades (Vue2 → Vue3 with `@vue/compat`)
- Monolith → Microservices
- REST → GraphQL (run both APIs, migrate queries incrementally)
- Database migrations (dual-write pattern)

### 3.2 Feature Flags
Wrap migrated code in feature flags:

```javascript
if (featureFlags.isEnabled('new-payment-service')) {
  return newPaymentService.process(order);
}
return oldPaymentService.process(order);
```

Benefits: instant rollback, A/B testing, gradual rollout.

### 3.3 The Expand-Contract Pattern (Database)
For schema migrations that can't have downtime:

1. **Expand**: Add new column/table (backward-compatible)
2. **Migrate**: Dual-write to old and new, backfill old data
3. **Contract**: Remove old column/table (after all consumers migrated)

### 3.4 Parallel Change (Continuous Delivery)
1. Add new interface (don't remove old)
2. Migrate consumers one by one
3. Monitor
4. Remove old interface when no consumers remain

### 3.5 Testing During Migration
- **Characterization tests**: Tests that capture CURRENT behavior (even bugs). Run before migration to detect regressions.
- **Approval tests**: Snapshot outputs before migration, compare after.
- **Diff testing**: Run old and new implementations side by side, diff responses.
- **Canary deployments**: Deploy migrated code to a subset of instances first.

### 3.6 Rollback Planning
Every migration step must have a rollback:

| Step                     | Rollback                           |
|--------------------------|------------------------------------|
| Rename files             | `git checkout -- .`                |
| jscodeshift transform    | `git checkout -- .`                |
| Package.json changes     | `git checkout package.json`        |
| Database migration       | Run down migration                 |
| Config change            | Revert config + restart            |
| Traffic shift            | Set weight to 0% for new           |

### 3.7 Metrics to Watch
- Error rate (should not spike)
- Latency p50/p95/p99 (should not regress)
- Build time (ESM can affect tree shaking, bundle size)
- Test pass rate (characterization tests must stay green)
- Bundle size (tree shaking should improve with ESM, but check)

### 3.8 Common Anti-Patterns
- **Big Bang migration**: "We'll rewrite everything and flip the switch." → Almost never works.
- **Migration + refactor in one PR**: "While we're migrating, let's also clean up..." → Untestable diff, impossible to bisect.
- **No characterization tests**: "We know what this code does." → You don't. Edge cases will bite.
- **Skipping the compat layer**: "We'll go straight to Vue 3 without @vue/compat." → Why make it harder?
- **Migrating without monitoring**: "Tests pass, ship it." → Production is where unknown unknowns live.
