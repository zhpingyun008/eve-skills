---
name: autonomous-pr
description: Fully autonomous PR workflow — GitHub Issue → branch → code → test → PR → review response → merge. End-to-end automation of the entire development cycle. Inspired by Devin autonomous PR and Claude Code PR generation.
category: agent-skills
triggers:
  - "autonomous PR"
  - "全自主PR"
  - "自动PR"
  - "fix issue"
  - "auto pr"
  - "自驱动开发"
  - "PR automation"
  - "pr review"
  - "pull request"
  - "generate pr"
---

# autonomous-pr — 全自主PR工作流


## Overview

autonomous-pr — 全自主PR工作流 skill - auto-validated.
对标: Devin "fix issue #123" | Claude Code PR automation | GitHub Copilot Workspace
评级: ★★★★★ (P0核心技能 — 端到端自动化)

## 作用

从GitHub Issue/GitLab Issue一句话到合并PR，全流程自动化：

```
Issue ─→ Branch ─→ Code ─→ Test ─→ PR ─→ Review ─→ Merge
  ↓        ↓        ↓       ↓      ↓       ↓        ↓
解析需求  创建分支  编写代码  运行测试  创建PR  响应评论  合并
req-analyzer git    smart-edit test-engine git  code-review git
```

## Trigger Conditions

- Commander says: autonomous PR / 全自主PR / fix issue / auto pr
- New issue assigned
- Routine maintenance tasks

## Workflow

### Step 1: Understand

```bash
python3 ~/.hermes/skills/agent-skills/autonomous-pr/scripts/autonomous_pr.py --issue "fix: login timeout bug"
```

### Step 2: Branch

```bash
python3 ~/.hermes/skills/agent-skills/autonomous-pr/scripts/autonomous_pr.py --branch
```

自动创建feature分支: `fix/issue-123-login-timeout`

### Step 3: Implement

```bash
python3 ~/.hermes/skills/agent-skills/autonomous-pr/scripts/autonomous_pr.py --implement
```

### Step 4: Test

```bash
python3 ~/.hermes/skills/agent-skills/autonomous-pr/scripts/autonomous_pr.py --test
```

### Step 5: PR

```bash
python3 ~/.hermes/skills/agent-skills/autonomous-pr/scripts/autonomous_pr.py --pr
```

- 生成PR标题和描述
- 关联Issue
- 添加reviewers

### Step 6: Review Response

```bash
python3 ~/.hermes/skills/agent-skills/autonomous-pr/scripts/autonomous_pr.py --respond-to-review
```

- 读取review comments
- 逐条响应/修改
- 推送新commit

## Integration

- **req-analyzer**: Issue需求解析
- **smart-edit**: 代码实现
- **test-engine**: 测试生成+运行
- **code-review**: 自审查
- **cicd-builder**: CI验证
- **git-workflow**: Git操作(未来)

## Pitfalls

- 复杂issue需人工确认方案
- PR review comments可能需人工判断
- 安全敏感改动必须人工审核
- 首次使用建议dry-run模式
- **Empty PR descriptions**: If no meaningful commits exist, the generated description may be sparse — review before publishing
- **Incorrect labels**: Path-based label detection can misfire on monorepos with unconventional layouts
- **Over-zealous review**: Auto-review may flag false positives; always sanity-check suggested changes
- **Auth tokens**: Requires `GITHUB_TOKEN` or `GITLAB_TOKEN` in environment; missing tokens cause silent failures
- **Large diffs**: PRs with >1000 changed lines may exceed context limits — consider splitting
