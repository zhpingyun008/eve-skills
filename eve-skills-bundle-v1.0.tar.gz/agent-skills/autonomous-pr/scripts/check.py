#!/usr/bin/env python3
"""Auto-generated skill validator."""
import sys, json
from pathlib import Path

SKILL_DIR = Path(__file__).resolve().parent.parent
SKILL_MD = SKILL_DIR / "SKILL.md"

def check():
    issues = []
    
    # 1. SKILL.md exists
    if not SKILL_MD.exists():
        issues.append("MISSING: SKILL.md not found")
        return {"status": "fail", "issues": issues}
    
    content = SKILL_MD.read_text()
    
    # 2. YAML frontmatter
    has_frontmatter = content.startswith("---")
    if not has_frontmatter:
        issues.append("MISSING: YAML frontmatter")
    
    # 3. Has h1 title
    has_h1 = any(line.startswith("# ") for line in content.split("\n"))
    if not has_h1:
        issues.append("MISSING: h1 title")
    
    # 4. Has Overview or Purpose
    has_overview = "## Overview" in content or "## Purpose" in content or "## 概述" in content
    if not has_overview:
        issues.append("MISSING: Overview/Purpose section")
    
    # 5. Non-empty (at least 100 chars beyond frontmatter)
    body_start = 0
    if has_frontmatter:
        end = content.find("---", 3)
        if end != -1:
            body_start = end + 3
    body = content[body_start:].strip()
    if len(body) < 100:
        issues.append(f"TOO_SHORT: body only {len(body)} chars")
    
    if issues:
        return {"status": "fail", "issues": issues, "skill_dir": str(SKILL_DIR)}
    return {"status": "pass", "skill_dir": str(SKILL_DIR)}

if __name__ == "__main__":
    result = check()
    print(json.dumps(result, indent=2))
    if result["status"] == "fail":
        sys.exit(1)
