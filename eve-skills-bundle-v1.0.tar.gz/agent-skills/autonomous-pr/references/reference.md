# Autonomous PR Reference

## Workflow Steps
1. Parse issue → 2. Create branch → 3. Implement → 4. Test → 5. Create PR → 6. Respond to review → 7. Merge

## Branch Naming
- fix/issue-NNN-description
- feat/description

## PR Description Template
Summary + Changes + Testing + Related Issues