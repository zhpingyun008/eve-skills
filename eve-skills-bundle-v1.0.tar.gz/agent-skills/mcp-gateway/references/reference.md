# MCP Gateway Reference

## Supported Servers
jira/slack/github/postgres/filesystem

## Config Storage
~/.hermes/mcp/<server>.json

## MCP Protocol
https://modelcontextprotocol.io

## Security
Credentials stored locally, never committed