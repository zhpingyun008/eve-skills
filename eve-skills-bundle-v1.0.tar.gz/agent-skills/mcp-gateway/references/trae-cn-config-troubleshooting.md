# Trae CN MCP配置故障排查记录

> 日期: 2026-06-09
> 环境: Trae CN v1.0.25 (基于VS Code 3.3.65), Windows 11, WSL2 Ubuntu

## 根因总结

**Trae CN不使用VS Code的 `mcp.servers` 设置项**。Trae CN拥有自己的MCP扩展市场系统和MCP服务管理UI，独立于VS Code的MCP配置。以下是完整的排查路径和已知配置格式均无效的事实。

---

## 问题1: settings.json配置MCP后Trae不显示MCP服务

**现象**: 在 `%APPDATA%/Trae CN/User/settings.json` 中写入 `mcp.servers` 配置后，重启Trae，MCP服务器列表不显示Hermes工具。

**已尝试且均无效的配置格式**:
1. `"mcp": { "servers": { "hermes-full": {...} } }` — VS Code nested格式 ❌
2. `"mcp.servers": { "hermes-full": {...} }` — VS Code flat键格式 ❌
3. 项目级 `.trae/mcp.json` — Trae项目级格式 ❌
4. 项目级 `.vscode/mcp.json` — VS Code项目级格式 ❌
5. 项目级 `.mcp.json` — Claude Code项目级格式 ❌
6. Claude Code全局配置 `.claude/mcp.json` ❌
7. `claudeCode.enableAllProjectMcpServers` + `enabledMcpjsonServers` 设置项 ❌

**根因**: Trae CN有自己的MCP Server管理系统，通过内置的MCP扩展市场加载MCP Server，不通过VS Code settings.json的 `mcp` key。

### 验证依据

反编译Trae CN源码发现的MCP架构：

1. Trae CN的MCP市场管理UI组件（在 `@byted-icube/ai-modules-chat` 包中）:
   - MCP服务器市场搜索、安装、管理完整UI
   - "Configure Manually"手动配置入口
   - 企业白名单管理
   - MCP服务器编辑/重启/删除/添加到Agent的操作菜单

2. Trae CN内置MCP Server使用自定义格式:
   ```
   .trae-cn/mcps/
     └── s_trae-ultimate-full-packa-480c271e/
         └── solo_coder/integrated_browser/
             ├── SERVER_METADATA.json
             └── tools/*.json  (每个工具独立JSON文件)
   ```
   **注意**: 此格式仅用于Trae内置的MCP Server，用户自定义MCP不能通过此方式添加。

3. Claude Code扩展（v2.1.168）是Trae CN中实际处理MCP的扩展，其MCP服务器配置读取来源:
   - `mcp-user`: 来自 `~/.claude.json`
   - `mcp-project`: 来自项目根目录 `.mcp.json`
   - 但Trae CN似乎没有让Claude Code扩展加载这些MCP配置

### 推荐的解决方向

**方向A: 通过Trae CN MCP市场手动添加（最可靠路径）**  

已知Trae CN有"Configure Manually"入口，具体操作路径：
```
Trae CN左侧栏 → 扩展(Extensions) → MCP → 搜索 → 没找到时底部"Configure Manually"
→ type: stdio → command: wsl.exe → args: ["/home/yestin/hermes-mcp.sh"] → 保存
```

**方向B: HTTP/SSE方式**  
如果Trae CN不支持stdio MCP但支持HTTP MCP协议，可让Hermes运行HTTP MCP Server：
```bash
python3 -m agent.transports.hermes_tools_mcp_server --transport http --port 9876
```
Trae CN中添加HTTP类型MCP Server：
- type: http
- url: http://localhost:9876

**方向C: 等待Trae CN后续版本支持**  
VS Code 1.80+已标准化`mcp.servers`配置，Trae CN作为VS Code fork后续版本可能支持。当前版本(1.0.25)实测不支持。

---

## 问题2: wsl.exe启动Python报ModuleNotFoundError

**现象**: 直接调用 `wsl.exe python3 script.py` 报找不到 `model_tools` 模块。

**原因**: `wsl.exe` 默认使用系统Python（/usr/bin/python3），非Hermes venv的Python。

**解决方案**: 使用wrapper脚本显式指定venv路径：
```bash
# /home/yestin/hermes-mcp.sh
#!/usr/bin/env bash
cd /home/yestin
export HERMES_HOME=/home/yestin/.hermes
export HERMES_QUIET=1
exec /home/yestin/.hermes/.venv/bin/python3 \
    /home/yestin/.hermes/scripts/hermes-full-mcp-server.py
```

已验证: `wsl.exe /home/yestin/hermes-mcp.sh` 可正常启动并注册35工具。

---

## 已确认有效的配置（可供参考）

以下配置虽然Trae CN不显示，但技术上已通过验证：

**wsl.exe启动Hermes MCP Server** ✅
```bash
# 从Windows命令行测试
wsl.exe /home/yestin/hermes-mcp.sh
# 输出: "Hermes-full MCP: 35 tools registered"
```

**Python测试脚本验证全量工具可用** ✅
```bash
python3 ~/.hermes/scripts/test-full-mcp-server.py
# 输出: "Tools: 35" "skills_list: PASS" "terminal: PASS" "OVERALL: PASS"
```

**CMMI5工作流脚本** ✅
```bash
python3 ~/company/scripts/cmmi5-pipeline.py --goal "xxx"
# 输出: 7阶段全流程结果
```

目前已知的缺失环节是：Trae CN到WSL Hermes的MCP配置通道。技术能力就绪，配置通道需通过Trae UI手动完成。
