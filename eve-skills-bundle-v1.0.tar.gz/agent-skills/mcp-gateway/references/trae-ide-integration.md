# Trae IDE集成参考

> 本文件记录Hermes Agent与字节跳动Trae IDE的集成细节。
> 最后更新: 2026-06-09

## Trae架构

| 产品 | 定位 | MCP支持 |
|------|------|---------|
| Trae IDE | AI原生IDE (VS Code基) | ✅ 项目级 .trae/mcp.json |
| Trae CLI | Code Agent CLI | ✅ 企业版，支持MCP+ACP |
| Trae Plugin | VS Code/JetBrains插件 | N/A (自身是插件) |
| Trae Work | AI工作台(网页/桌面/移动) | ✅ 通过后端连接 |

## 关键路径: Trae IDE连接Hermes

Trae CN安装在 `C:\Users\Administrator\AppData\Local\Programs\Trae CN\`
配置目录: `C:\Users\Administrator\.trae-cn\`
设置文件: `%APPDATA%/Trae CN/User/settings.json`

### MCP Server配置（三种方式）

#### 方式A: Trae CN全局设置（推荐）
写入 `%APPDATA%/Trae CN/User/settings.json`，重启后全局生效。

#### 方式B: 项目级 .trae/mcp.json
在项目根目录创建，仅对该项目生效。

#### 方式C: 手动在Trae IDE中配置
通过Trae的设置UI → MCP Server → 添加。

### WSL桥接注意点

1. **必须使用venv Python路径**：`wsl.exe` 默认调用系统Python，不加载Hermes venv
2. **推荐用wrapper脚本**：将环境变量设置+venv路径封装在shell脚本中
3. **stdin/stdout转发**：wsl.exe自动转发Windows到WSL的stdin/stdout，MCP协议在stdio上工作

### 验证连接

在Trae IDE对话中输入:
```
列出可用的MCP工具
```

如果看到 `hermes-full` 和 `hermes-tools`，连接成功。

## CMMI5工作流模板

在Trae对话中直接使用:
```
terminal: python3 ~/company/scripts/cmmi5-pipeline.py --goal "项目描述"
```

自动执行:
1. 需求分析 → SRS文档
2. 架构设计 → C4架构图
3. WBS → 任务分解
4. 编码指南
5. 代码审查清单
6. 测试策略
7. 项目总结
