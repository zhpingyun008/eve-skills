---
name: mcp-gateway
description: MCP (Model Context Protocol) gateway — standard protocol for connecting external tools. Connect Jira, Slack, PostgreSQL, GitHub, filesystem via MCP servers. Agent auto-discovers available tools.
category: agent-skills
triggers:
  - "MCP"
  - "连接外部工具"
  - "connect tool"
  - "mcp server"
  - "外部集成"
  - "jira"
  - "slack integration"
---

# mcp-gateway — MCP协议网关

## Overview

mcp-gateway — MCP协议网关 skill - auto-validated.
对标: Claude Code MCP servers | Anthropic MCP spec | OpenAI function calling
评级: ★★★★★ (P0核心技能 — 工具生态扩展)

## 两种模式

mcp-gateway 同时支持 **Client 模式**（连接外部MCP Server）和 **Server 模式**（向外部暴露Hermes工具）。

```
Client 模式（已有）              Server 模式（本次新增）
┌────────────┐     MCP          ┌────────────┐     MCP          ┌──────────┐
│  Hermes    │─────stdio──────► │  Jira/Git/ │     │  Trae IDE/ │─────stdio──────► │  Hermes  │
│  (Client)  │                  │  Slack等   │     │  CLI/其他  │                  │  (Server)│
└────────────┘                  └────────────┘     └────────────┘                  └──────────┘
```

## 作用

### Client 模式（连接外部工具）
通过MCP标准协议连接外部工具和服务，Agent自动发现和调用：

- **Jira MCP**: 读ticket/创建issue/更新状态
- **Slack MCP**: 发送消息/读频道
- **GitHub MCP**: PR/Issue/仓库操作
- **PostgreSQL MCP**: 数据库查询
- **Filesystem MCP**: 安全文件访问

### Server 模式（暴露Hermes给外部）
将Hermes的能力作为MCP Server暴露给外部IDE/CLI（如Trae、Cursor、VS Code），外部工具可直接调用Hermes的浏览器自动化、视觉分析、技能库等工具：

## Trigger Conditions

- Commander says: MCP / 连接外部工具 / connect / jira / slack
- Need to integrate Hermes with an external IDE (Trae, Cursor, VS Code)
- Need to expose Hermes tools to an external agent/client
- Tool discovery needed

## Server Mode: 将Hermes暴露为MCP Server

### 启动方式

Hermes提供两种启动MCP Server的方式：

| 方式 | 命令 | 状态 | 可用工具 |
|------|------|------|---------|
| **推荐** | `python3 -m agent.transports.hermes_tools_mcp_server` | ✅ 工作正常 | 14个核心工具 |
| 备选 | `hermes mcp serve` | ❌ Bug: `ModuleNotFoundError: No module named 'mcp_serve'` | N/A |

⚠️ `hermes mcp serve` 命令存在Python包导入bug，需等待修复。使用 `python3 -m` 方式或全量MCP Server脚本作为替代。

### 两种MCP Server实现

根据需求选择：

| 实现 | 工具数 | 传输 | 适用场景 |
|------|:------:|:----:|---------|
| **内置** `python3 -m agent.transports.hermes_tools_mcp_server` | 14 | FastMCP (stdio) | IDE基础集成(浏览器/视觉/技能) |
| **全量** `python3 ~/.hermes/scripts/hermes-full-mcp-server.py` | **35** | 低层MCP SDK (stdio) | 需要terminal/文件/任务编排等全量工具 |

#### 内置Server（14工具）
通过Hermes内置的FastMCP实现，适用于Codex/基本IDE集成。工具列表见下文。

#### 全量Server（35工具 — 推荐）
自定义实现，使用低层MCP SDK (`mcp.server.lowlevel.Server`) 避免FastMCP的类型推断限制。暴露所有Hermes工具（除 `clarify` 外）：

```
文件/终端: read_file / write_file / patch / search_files / terminal / process / execute_code
浏览器: navigate / click / type / press / snapshot / scroll / back / get_images / console / vision
任务编排: delegate_task / cronjob / todo / memory / session_search / mixture_of_agents
视觉/语音: vision_analyze / video_analyze / text_to_speech
技能库: skill_view / skills_list / skill_manage
消息: send_message / feishu_doc_read / feishu_drive_* (3)
```

**配置Trae IDE使用全量Server：**
```json
{
  "mcp_servers": [
    {
      "name": "hermes-full",
      "description": "Hermes Agent 全量工具 — 35 tools",
      "type": "stdio",
      "command": "python3",
      "args": ["/home/yestin/.hermes/scripts/hermes-full-mcp-server.py"],
      "env": {"HERMES_HOME": "/home/yestin/.hermes"}
    }
  ]
}
```

**工具过滤（环境变量控制）：**
- `HERMES_MCP_TOOLS` — 逗号分隔的允许列表（默认：全部）
- `HERMES_MCP_EXCLUDE` — 逗号分隔的排除列表（默认：clarify）

### 暴露的工具列表（14/26个Hermes工具 — 内置Server）

| 类别 | 工具 | 数量 |
|------|------|:----:|
| 🌐 浏览器自动化 | navigate, click, type, press, snapshot, scroll, back, get_images, console, vision | 10 |
| 👁️ 视觉分析 | vision_analyze | 1 |
| 📚 技能库 | skill_view, skills_list | 2 |
| 🔊 语音 | text_to_speech | 1 |

**不暴露的工具**（与Codex设计约束有关）：
- terminal / shell — 保留给Host环境
- read_file / write_file / patch / search_files — 外部工具自带
- delegate_task / memory / session_search / todo — 需AIAgent运行上下文
- web_search / web_extract — 已配置但被当前调用方过滤

工具列表在 `agent.transports.hermes_tools_mcp_server.EXPOSED_TOOLS` 中维护。

### 配置外部IDE连接

#### Trae IDE（项目级MCP）

> ⚠️ **Trae CN兼容性**: v1.0.25实测不支持VS Code标准的 `mcp.servers` 设置。配置无效时需通过Trae CN UI手动添加（见 `references/trae-cn-config-troubleshooting.md`）。

创建 `.trae/mcp.json` 文件在项目根目录：

```json
{
  "mcp_servers": [
    {
      "name": "hermes-agent",
      "description": "Hermes Agent — 浏览器自动化/视觉分析/技能库",
      "type": "stdio",
      "command": "python3",
      "args": ["-m", "agent.transports.hermes_tools_mcp_server"],
      "env": {
        "HERMES_HOME": "/home/yestin/.hermes"
      }
    }
  ]
}
```

Trae IDE 自动加载项目级 `.trae/mcp.json`，无需企业版。重启IDE后即可在对话中调用Hermes工具。

#### Trae CLI（企业版）

在全局配置文件 `~/.trae/trae_cli.yaml` 中添加MCP Server配置（同上格式）。

#### VS Code / Cursor

通过 `.vscode/mcp.json` 或 Claude Dev 扩展配置，使用相同的stdio配置。

### 验证MCP连接

```bash
# 使用测试脚本确认MCP Server正在运行并返回工具列表
python3 ~/.hermes/scripts/test-mcp-server.py
```

预期输出：
```
✅ MCP Server: hermes-tools v?
📦 Tools registered: 14
  🔧 browser_navigate: Navigate to a URL in the browser...
  🔧 browser_click: Click on an element...
  ...
```

### 已知问题

- `hermes mcp serve` 命令报 `ModuleNotFoundError: No module named 'mcp_serve'` — Python包依赖问题，`mcp_serve` 模块未被包含在发布的pip包中。使用 `python3 -m` 或全量脚本替代。
- 内置Server不暴露terminal/file工具是设计约束（为Codex集成而设计），如需全量工具使用 `hermes-full-mcp-server.py`。
- 重启IDE后MCP连接自动重建，无需手动干预。

### 低层MCP SDK vs FastMCP

当使用FastMCP (`mcp.server.fastmcp`) 注册工具时，它通过Python类型注解自动生成Pydantic校验模型。Hermes工具使用 `**kwargs` 签名，FastMCP会生成一个要求 `kwargs` 为必填字段的schema，导致空参数调用失败：

```
Error: 1 validation error for skills_listArguments
kwargs
  Field required [type=missing]
```

**解决方案**：使用低层MCP SDK (`mcp.server.lowlevel.Server`) 直接控制工具注册流程。低层SDK要求显式提供 `Tool` 对象（含 `name`/`description`/`inputSchema`），不进行类型推断，完全避免校验冲突。

```python
from mcp.server.lowlevel import Server
from mcp.types import Tool, CallToolResult, TextContent

server = Server("hermes-full")

@server.list_tools()
async def list_tools():
    return ListToolsResult(tools=[
        Tool(name="my_tool", description="...", inputSchema={...}),
    ])

@server.call_tool()
async def call_tool(name: str, arguments: dict | None):
    result = handle_function_call(name, arguments or {})
    return CallToolResult(content=[TextContent(type="text", text=str(result))])
```

**何时用FastMCP vs 低层SDK：**

| 场景 | 推荐 |
|------|------|
| 工具数量少（<20），参数固定 | FastMCP（开发快） |
| 工具数量多（20+），参数动态/通配 | **低层SDK**（避免校验冲突） |
| 需要精确控制每个工具的inputSchema | 低层SDK |
| 快速原型验证 | FastMCP |

### Windows WSL桥接模式

当IDE运行在Windows上而Hermes在WSL中时，需要通过 `wsl.exe` 桥接MCP stdio：

**方案：创建WSL启动脚本 → IDE引用该脚本**

```bash
# /home/yestin/hermes-mcp.sh
#!/usr/bin/env bash
cd /home/yestin
export HERMES_HOME=/home/yestin/.hermes
export HERMES_QUIET=1
export HERMES_REDACT_SECRETS=true
exec /home/yestin/.hermes/.venv/bin/python3 \
    /home/yestin/.hermes/scripts/hermes-full-mcp-server.py
```

**Trae CN全局配置（Windows）：**
```json
// %APPDATA%/Trae CN/User/settings.json
{
  "mcp": {
    "servers": {
      "hermes-full": {
        "name": "hermes-full",
        "type": "stdio",
        "command": "wsl.exe",
        "args": ["/home/yestin/hermes-mcp.sh"]
      }
    }
  }
}
```

**项目级配置（Windows路径）：**
```json
// C:\Users\<username>\.trae\mcp.json
{
  "mcp_servers": [{
    "name": "hermes-full",
    "type": "stdio",
    "command": "wsl.exe",
    "args": ["/home/yestin/hermes-mcp.sh"]
  }]
}
```

⚠️ 关键：wsl.exe默认使用系统Python，非Hermes venv。必须通过wrapper脚本显式指定venv路径，否则报 `ModuleNotFoundError: No module named 'model_tools'`。

## Workflow

### Phase 1: Discover

```bash
python3 ~/.hermes/skills/agent-skills/mcp-gateway/scripts/mcp_gateway.py --discover
```

扫描可用MCP servers，列出工具和能力。

### Phase 2: Connect

```bash
python3 ~/.hermes/skills/agent-skills/mcp-gateway/scripts/mcp_gateway.py --connect jira-server
```

连接到指定MCP server。

### Phase 3: Use

```bash
python3 ~/.hermes/skills/agent-skills/mcp-gateway/scripts/mcp_gateway.py --call jira.get_issue --params '{"key": "PROJ-123"}'
```

调用MCP工具。

### Phase 4: Manage

```bash
# List active connections
python3 ~/.hermes/skills/agent-skills/mcp-gateway/scripts/mcp_gateway.py --list

# Disconnect
python3 ~/.hermes/skills/agent-skills/mcp-gateway/scripts/mcp_gateway.py --disconnect jira-server
```

## 内置MCP Server模板

| Server | 工具 | 用途 |
|--------|------|------|
| jira | get_issue, create_issue, search | 项目管理 |
| slack | send_message, read_channel | 团队沟通 |
| github | create_pr, get_issue, search_code | 代码协作 |
| postgres | query, list_tables | 数据查询 |
| filesystem | read_file, write_file, list_dir | 文件操作 |

## Integration

- **autonomous-pr**: GitHub MCP for PR operations
- **project-context**: Filesystem MCP for safe file access
- **ops-monitor**: Database MCP for metrics queries

## 参考资料

- `references/trae-ide-integration.md` — Trae IDE集成详细配置和WSL桥接
- `references/trae-cn-config-troubleshooting.md` — Trae CN MCP配置故障排查（settings.json不生效、wsl.exe模块找不到等已知问题）

## Pitfalls

- MCP server需独立运行和管理
- 认证凭据需安全存储
- 工具能力因server实现而异
- 网络延迟影响响应时间

## Feedback Engine Patches
*自动生成于 2026-07-16 02:02:04*

## Tool Recommendations (from trajectory feedback)

### patch
Trajectory analysis shows **patch** strongly correlates with high session scores.
- Use `patch` for targeted find-and-replace edits instead of sed/awk.
- Supports fuzzy matching with 9 strategies for robust edits.
- Auto-runs syntax checks after modification.
- Preferred for surgical code changes over full file rewrites.

### Guardrails
- Ensure `old_string` is unique in the file unless `replace_all=True`.
- Include enough surrounding context to guarantee uniqueness.
- Use `mode='patch'` for V4A multi-file patches.

### Efficiency Tips
- Combine multiple edits into a single V4A patch when possible.
- Use `replace_all=True` for bulk replacements of the same pattern.
- Preview changes with `--dry-run` mode before applying.

---
## Feedback Engine Patches
*自动生成于 2026-07-17 02:02:37*

## Tool Recommendations (from trajectory feedback)

### read_file
Trajectory analysis shows **read_file** strongly correlates with high session scores.
- Preferred over cat/head/tail in terminal.
- Use this for reading text files with line numbers and pagination.
- Supports offset and limit for large file navigation.

---
## Feedback Engine Patches
*自动生成于 2026-07-17 02:02:37*

## Tool Recommendations (from trajectory feedback)

### patch
Trajectory analysis shows **patch** strongly correlates with high session scores.
- Use `patch` for targeted find-and-replace edits instead of sed/awk.
- Supports fuzzy matching with 9 strategies for robust edits.
- Auto-runs syntax checks after modification.
- Preferred for surgical code changes over full file rewrites.

### Guardrails
- Ensure `old_string` is unique in the file unless `replace_all=True`.
- Include enough surrounding context to guarantee uniqueness.
- Use `mode='patch'` for V4A multi-file patches.

### Efficiency Tips
- Combine multiple edits into a single V4A patch when possible.
- Use `replace_all=True` for bulk replacements of the same pattern.
- Preview changes with `--dry-run` mode before applying.

---
## Feedback Engine Patches
*自动生成于 2026-07-21 08:58:12*

## Tool Recommendations (from trajectory feedback)

### search_files
Trajectory analysis shows **search_files** strongly correlates with high session scores.
- Use instead of grep/rg/find in terminal.
- Content search: regex inside files (faster than shell grep).
- File search: glob patterns with results sorted by modification time.
- Supports output modes: `content`, `files_only`, `count`.

### Guardrails
- Regex patterns: ensure proper escaping for special characters.
- File globs: use simple patterns like `*.py`, `*config*`.
- For large directory trees, narrow with `path` parameter.

### Efficiency Tips
- Combine content search with `output_mode='files_only'` for fast file discovery.
- Use `context=N` for surrounding lines around matches.
- Limit results with `limit` parameter to avoid overwhelming output.

---
## Feedback Engine Patches
*自动生成于 2026-07-21 08:58:12*

## Tool Recommendations (from trajectory feedback)

### write_file
Trajectory analysis shows **write_file** strongly correlates with high session scores.
- Use `write_file` to create new files or overwrite existing ones.
- Preferred over terminal heredoc for structured file creation.
- Automatically creates parent directories.

### Guardrails
- Always use absolute paths to avoid ambiguity.
- Creates parent directories — verify the intended path before writing.
- Overwrites entire file content — if you need targeted edits, use `patch` instead.

### Efficiency Tips
- Batch content creation: write whole files at once instead of appending line-by-line.
- For large files, consider splitting into multiple smaller files.
- Use `patch` for incremental updates to avoid full rewrites.

---
## Feedback Engine Patches
*自动生成于 2026-07-22 12:19:48*

## Tool Recommendations (from trajectory feedback)

### search_files
Trajectory analysis shows **search_files** strongly correlates with high session scores.
- Use instead of grep/rg/find in terminal.
- Content search: regex inside files (faster than shell grep).
- File search: glob patterns with results sorted by modification time.
- Supports output modes: `content`, `files_only`, `count`.

### Guardrails
- Regex patterns: ensure proper escaping for special characters.
- File globs: use simple patterns like `*.py`, `*config*`.
- For large directory trees, narrow with `path` parameter.

### Efficiency Tips
- Combine content search with `output_mode='files_only'` for fast file discovery.
- Use `context=N` for surrounding lines around matches.
- Limit results with `limit` parameter to avoid overwhelming output.

---
## Feedback Engine Patches
*自动生成于 2026-07-22 12:19:48*

## Tool Recommendations (from trajectory feedback)

### patch
Trajectory analysis shows **patch** strongly correlates with high session scores.
- Use `patch` for targeted find-and-replace edits instead of sed/awk.
- Supports fuzzy matching with 9 strategies for robust edits.
- Auto-runs syntax checks after modification.
- Preferred for surgical code changes over full file rewrites.

### Guardrails
- Ensure `old_string` is unique in the file unless `replace_all=True`.
- Include enough surrounding context to guarantee uniqueness.
- Use `mode='patch'` for V4A multi-file patches.

### Efficiency Tips
- Combine multiple edits into a single V4A patch when possible.
- Use `replace_all=True` for bulk replacements of the same pattern.
- Preview changes with `--dry-run` mode before applying.

---
## Feedback Engine Patches
*自动生成于 2026-07-22 12:19:49*

## Tool Recommendations (from trajectory feedback)

### read_file
Trajectory analysis shows **read_file** strongly correlates with high session scores.
- Preferred over cat/head/tail in terminal.
- Use this for reading text files with line numbers and pagination.
- Supports offset and limit for large file navigation.
