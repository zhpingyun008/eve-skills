#!/usr/bin/env python3
"""Hermes-full MCP server — exposes ALL Hermes tools for IDE integration.

Uses low-level MCP SDK to avoid FastMCP type-inference issues with **kwargs.

Usage:
  python3 hermes-full-mcp-server.py

Config via env vars:
  HERMES_MCP_TOOLS    — comma-separated allowlist (default: all)
  HERMES_MCP_EXCLUDE  — comma-separated denylist (default: clarify)

IDE config (.trae/mcp.json or .vscode/mcp.json):
  {
    "mcp_servers": [{
      "name": "hermes-full",
      "type": "stdio",
      "command": "python3",
      "args": ["/path/to/hermes-full-mcp-server.py"],
      "env": {"HERMES_HOME": "/home/yestin/.hermes"}
    }]
  }
"""

from __future__ import annotations
import json, logging, os, sys, asyncio
from typing import Any

logger = logging.getLogger(__name__)
NEVER_EXPOSE = {"clarify"}


def run_server() -> int:
    verbose = "-v" in sys.argv or "--verbose" in sys.argv
    logging.basicConfig(
        level=logging.INFO if verbose else logging.WARNING,
        stream=sys.stderr,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )
    os.environ.setdefault("HERMES_QUIET", "1")
    os.environ.setdefault("HERMES_REDACT_SECRETS", "true")

    from model_tools import get_tool_definitions, handle_function_call
    from mcp.server.lowlevel import Server
    import mcp.server.stdio
    from mcp.types import (
        CallToolResult, ListToolsResult, TextContent, Tool,
    )

    all_defs = {}
    for td in (get_tool_definitions(quiet_mode=True) or []):
        if isinstance(td, dict) and td.get("type") == "function":
            fn = td["function"]
            all_defs[fn["name"]] = fn

    allowlist = os.environ.get("HERMES_MCP_TOOLS", "").strip()
    denylist_env = os.environ.get("HERMES_MCP_EXCLUDE", "").strip()
    denylist = set(NEVER_EXPOSE)
    if denylist_env:
        denylist |= {n.strip() for n in denylist_env.split(",") if n.strip()}
    selected = (
        {n.strip() for n in allowlist.split(",") if n.strip()}
        if allowlist else set(all_defs.keys())
    )
    tool_names = sorted(selected - denylist)

    mcp_tools = []
    for name in tool_names:
        spec = all_defs.get(name)
        if not spec:
            continue
        mcp_tools.append(Tool(
            name=name,
            description=spec.get("description", f"Hermes {name} tool"),
            inputSchema=spec.get("parameters", {"type": "object", "properties": {}}),
        ))

    logger.info("Hermes-full MCP: %d tools registered", len(mcp_tools))
    server = Server("hermes-full")

    @server.list_tools()
    async def list_tools() -> ListToolsResult:
        return ListToolsResult(tools=mcp_tools)

    @server.call_tool()
    async def call_tool(name: str, arguments: dict | None) -> CallToolResult:
        try:
            result = handle_function_call(name, arguments or {})
            return CallToolResult(
                content=[TextContent(type="text", text=str(result or ""))]
            )
        except Exception as exc:
            logger.exception("tool %s failed", name)
            return CallToolResult(
                isError=True,
                content=[TextContent(type="text", text=f"Error: {exc}")],
            )

    async def main():
        async with mcp.server.stdio.stdio_server() as (r, w):
            await server.run(r, w, server.create_initialization_options())

    asyncio.run(main())
    return 0


if __name__ == "__main__":
    sys.exit(run_server())
