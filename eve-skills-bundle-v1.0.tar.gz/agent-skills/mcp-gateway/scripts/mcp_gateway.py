#!/usr/bin/env python3
"""mcp-gateway — MCP (Model Context Protocol) gateway"""

import sys, json, os
from pathlib import Path
from datetime import datetime

MCP_CONFIG_DIR = Path.home() / ".hermes" / "mcp"
MCP_SERVERS = {
    "jira": {
        "description": "Jira project management",
        "tools": ["get_issue", "create_issue", "search_issues", "update_status"],
        "config_needed": ["JIRA_URL", "JIRA_EMAIL", "JIRA_API_TOKEN"],
    },
    "slack": {
        "description": "Slack communication",
        "tools": ["send_message", "read_channel", "list_channels", "add_reaction"],
        "config_needed": ["SLACK_BOT_TOKEN"],
    },
    "github": {
        "description": "GitHub code collaboration",
        "tools": ["create_pr", "get_issue", "search_code", "list_repos", "create_issue"],
        "config_needed": ["GITHUB_TOKEN"],
    },
    "postgres": {
        "description": "PostgreSQL database access",
        "tools": ["query", "list_tables", "describe_table", "explain_query"],
        "config_needed": ["PG_HOST", "PG_PORT", "PG_USER", "PG_PASSWORD", "PG_DATABASE"],
    },
    "filesystem": {
        "description": "Secure filesystem access",
        "tools": ["read_file", "write_file", "list_directory", "search_files"],
        "config_needed": [],
    },
}

def discover_servers() -> Dict:
    """Discover available MCP servers"""
    available = []
    for name, info in MCP_SERVERS.items():
        server_config = MCP_CONFIG_DIR / f"{name}.json"
        available.append({
            "name": name,
            "description": info["description"],
            "tools": info["tools"],
            "configured": server_config.exists(),
            "config_keys": info["config_needed"],
        })
    
    return {
        "total": len(available),
        "configured": sum(1 for s in available if s["configured"]),
        "servers": available,
    }

def connect_server(name: str) -> Dict:
    """Connect to an MCP server"""
    if name not in MCP_SERVERS:
        return {"error": f"Unknown server: {name}", "available": list(MCP_SERVERS.keys())}
    
    server_config = MCP_CONFIG_DIR / f"{name}.json"
    info = MCP_SERVERS[name]
    
    if not server_config.exists():
        # Generate template config
        MCP_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        template = {k: f"<your_{k.lower()}>" for k in info["config_needed"]}
        server_config.write_text(json.dumps(template, indent=2))
        
        return {
            "status": "needs_config",
            "server": name,
            "config_file": str(server_config),
            "required": info["config_needed"],
            "message": f"Config template created at {server_config}. Fill in your credentials.",
        }
    
    return {
        "status": "connected",
        "server": name,
        "tools_available": info["tools"],
        "description": info["description"],
    }

def list_connections() -> Dict:
    """List all active MCP connections"""
    connections = []
    if MCP_CONFIG_DIR.exists():
        for config_file in MCP_CONFIG_DIR.glob("*.json"):
            name = config_file.stem
            if name in MCP_SERVERS:
                connections.append({
                    "name": name,
                    "tools": MCP_SERVERS[name]["tools"],
                    "config_file": str(config_file),
                })
    
    return {"active": len(connections), "connections": connections}

def simulate_call(server: str, tool: str, params: Dict = None) -> Dict:
    """Simulate an MCP tool call"""
    if server not in MCP_SERVERS:
        return {"error": f"Unknown server: {server}"}
    
    if tool not in MCP_SERVERS[server]["tools"]:
        return {"error": f"Tool '{tool}' not available on '{server}'", "available": MCP_SERVERS[server]["tools"]}
    
    return {
        "server": server,
        "tool": tool,
        "params": params or {},
        "status": "simulated",
        "note": "This is a simulation. Real MCP calls require running MCP server process.",
    }

def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return
    
    cmd = sys.argv[1]
    
    if cmd == "--check":
        discovered = discover_servers()
        print(json.dumps({"status": "ok", "skill": "mcp-gateway", "servers_supported": len(MCP_SERVERS), **discovered}, indent=2))
    
    elif cmd == "--discover":
        result = discover_servers()
        print(json.dumps(result, indent=2))
    
    elif cmd == "--connect":
        name = sys.argv[2] if len(sys.argv) > 2 else None
        if not name:
            print("Usage: --connect <server-name>")
            print(f"Available: {list(MCP_SERVERS.keys())}")
            return
        result = connect_server(name)
        print(json.dumps(result, indent=2))
    
    elif cmd == "--list":
        result = list_connections()
        print(json.dumps(result, indent=2))
    
    elif cmd == "--call":
        server = sys.argv[2] if len(sys.argv) > 2 else None
        tool = sys.argv[3] if len(sys.argv) > 3 else None
        params_str = sys.argv[5] if len(sys.argv) > 5 and sys.argv[4] == "--params" else "{}"
        try:
            params = json.loads(params_str)
        except:
            params = {}
        result = simulate_call(server, tool, params)
        print(json.dumps(result, indent=2))
    
    else:
        print(f"Unknown: {cmd}")

if __name__ == "__main__":
    main()
