---
name: codebase-learner
description: First-time codebase learning — on entering a new repo, auto-read README → analyze structure → run tests → build knowledge graph. Subsequent tasks leverage this knowledge. Inspired by Devin "learn this codebase".
category: agent-skills
triggers:
  - "learn codebase"
  - "学习代码库"
  - "new repo"
  - "codebase learner"
  - "understand project"
  - "分析项目"
---

# codebase-learner — 代码库学习系统


## Overview

codebase-learner — 代码库学习系统 skill - auto-validated.
对标: Devin "learn this codebase" | Claude Code project understanding
评级: ★★★★☆ (P1)

## 作用

首次进入陌生代码库时自动学习：

1. 读取README/PROJECT.md
2. 分析目录结构
3. 识别技术栈和框架
4. 运行测试了解项目状态
5. 生成知识图谱(模块→依赖→入口)
6. 存储到.coderamp/供后续使用

## Workflow

1. **Read project docs** — parse README, CONTRIBUTING, ARCHITECTURE, and any PROJECT.md
2. **Map directory structure** — identify entry points, src layout, tests, configs, scripts
3. **Detect tech stack** — infer language, framework, build system, package manager
4. **Run existing tests** — establish baseline health; note failing/skipped tests
5. **Build knowledge graph** — module → dependency → entry-point relationships
6. **Persist to .coderamp/** — store structured knowledge for subsequent tasks

```bash
python3 ~/.hermes/skills/agent-skills/codebase-learner/scripts/codebase_learner.py --learn
python3 ~/.hermes/skills/agent-skills/codebase-learner/scripts/codebase_learner.py --knowledge
```

## Pitfalls

- **Stale knowledge**: The knowledge graph becomes outdated as code evolves; re-learn periodically or on major refactors
- **Large monorepos**: Full repo analysis can be slow and memory-heavy; scope to relevant subtrees when possible
- **Test failures**: If baseline tests are broken, the learner may misattribute health — treat as informational, not blocking
- **Inferred tech stack**: Detection heuristics can be wrong (e.g., a `.js` file in a Python project); always cross-verify with build files
- **Knowledge collisions**: Multiple agents in the same repo may overwrite .coderamp/; use locking or agent-scoped namespaces
