# Local Model Inference Reference

## Ollama Setup

### Installation

**Linux / WSL:**
```bash
curl -fsSL https://ollama.com/install.sh | sh
```

**macOS:**
Download the `.dmg` from https://ollama.com/download

**Windows (native):**
Download the `.exe` installer from https://ollama.com/download

### Service Management

```bash
# Start in foreground
ollama serve

# Start in background
ollama serve &

# Check status
curl -s http://localhost:11434/ | jq
# Expected: "Ollama is running"

# List installed models
ollama list

# List available models via API
curl http://localhost:11434/api/tags | jq '.models[].name'
```

### Model Management

```bash
# Pull a model
ollama pull <model_name>

# Remove a model
ollama rm <model_name>

# Show model details (size, quantization, parameters)
ollama show <model_name>

# Customize with Modelfile
ollama create my-model -f Modelfile
```

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `OLLAMA_HOST` | `127.0.0.1:11434` | Bind address for the API server |
| `OLLAMA_MODELS` | `~/.ollama/models` | Model storage directory |
| `OLLAMA_KEEP_ALIVE` | `5m` | Duration to keep models loaded in memory |
| `OLLAMA_NUM_PARALLEL` | `1` | Max number of parallel requests |

## Model Comparison

### Quantitative Benchmarks

| Model | Size | MMLU | HumanEval | MT-Bench | Context |
|-------|------|------|-----------|----------|---------|
| llama3.2:3b | 2.0 GB | 63.4 | 62.8 | 8.2 | 128K |
| llama3.1:8b | 4.7 GB | 68.4 | 67.3 | 8.4 | 128K |
| qwen2.5:7b | 4.7 GB | 73.6 | 70.1 | 8.6 | 128K |
| qwen2.5:14b | 8.5 GB | 78.9 | 76.2 | 8.8 | 128K |
| deepseek-r1:8b | 4.9 GB | 71.2 | 72.5 | 8.5 | 128K |
| deepseek-coder-v2:16b | 8.9 GB | 76.3 | 81.0 | 8.7 | 128K |
| mistral-nemo:12b | 7.1 GB | 68.1 | 65.5 | 8.3 | 128K |
| phi3:14b | 7.9 GB | 75.5 | 69.8 | 8.5 | 128K |
| gemma2:9b | 5.4 GB | 72.2 | 66.4 | 8.6 | 8K |

*Note: Scores are approximate and sourced from public benchmarks (Oct 2024 - Apr 2025). MMLU/HumanEval use 0-shot. MT-Bench uses GPT-4 as judge.*

### Task-Specific Recommendations

#### Code Generation
- **Best overall**: deepseek-coder-v2:16b (8.9 GB)
- **Lightweight**: qwen2.5-coder:7b (4.7 GB)
- **Budget**: codellama:7b (3.8 GB)

#### General Chat / Assistant
- **Best overall**: qwen2.5:14b (8.5 GB)
- **Balanced**: llama3.1:8b (4.7 GB)
- **Lightweight**: llama3.2:3b (2.0 GB)

#### Reasoning / Math / Logic
- **Best**: deepseek-r1:8b (4.9 GB) — chain-of-thought
- **Alternative**: qwen2.5:14b with CoT prompting

#### Chinese Language
- **Best**: qwen2.5:7b or 14b
- **Alternative**: yi:9b (5.5 GB)

#### Privacy-Sensitive (small footprint, fully local)
- **Tiny (sub-2GB)**: llama3.2:1b (700 MB), phi3:mini (1.2 GB)
- **Small (2-3GB)**: llama3.2:3b (2.0 GB), qwen2.5:3b (1.9 GB)

### Quantization Guide

| Quant | Size vs FP16 | Quality Loss | Use Case |
|-------|-------------|--------------|----------|
| Q8_0 | ~50% | Near zero | Max quality, enough RAM |
| Q6_K | ~42% | Negligible | High quality, good balance |
| Q5_K_M | ~38% | Very small | Recommended default |
| Q4_K_M | ~30% | Small | Best size/quality tradeoff |
| Q3_K_M | ~23% | Noticeable | RAM-constrained |
| Q2_K | ~17% | Significant | Emergency/embedded only |

## Privacy Considerations

### Data Flow Analysis

```
User Prompt → Local RAM → Model Weights (RAM/VRAM) → Local CPU/GPU → Response
                  ↑                                       ↓
            (no network hop)                     (no telemetry upload)
```

**Key guarantees when running fully locally:**
1. No network calls during inference
2. No logging to external services
3. No prompt or response data leaves the machine
4. Full control over model storage and lifecycle

### Best Practices

1. **Air-gapped operation**: Download models once, then disable network
   ```bash
   # Pre-download all needed models
   ollama pull llama3.2:3b qwen2.5:7b
   
   # Disconnect and verify offline mode
   ollama run llama3.2:3b "Are you running locally?"
   ```

2. **Model integrity verification**:
   ```bash
   # Ollama includes SHA256 hashes in its manifest
   # For llama.cpp, verify manually:
   sha256sum model.gguf  # Compare with HuggingFace listing
   ```

3. **RAM/VRAM isolation** (Docker):
   ```bash
   docker run --memory="8g" --cpus="4" \
     -v /path/to/models:/models \
     ollama/ollama:latest
   ```

4. **Disk encryption**: Store model files on an encrypted volume (LUKS, FileVault, BitLocker)

5. **Inference log cleanup**:
   ```bash
   # Ollama logs
   journalctl --user -u ollama --vacuum-time=1d
   
   # llama.cpp: logs go to stdout/stderr — redirect as needed
   ```

### Threat Model

| Threat | Mitigation |
|--------|-----------|
| Model poisoning (backdoored weights) | Verify SHA256, only pull from official sources |
| Side-channel attacks (power/timing) | Use constant-time inference (specialized builds) |
| Memory scraping by other processes | Run in isolated cgroup/VM |
| Disk forensics on decommissioned drives | Encrypt model storage at rest |
| Prompt injection via model metadata | Review Modelfiles before `ollama create` |

### Compliance

- **GDPR**: Local inference keeps personal data within EU jurisdiction
- **HIPAA**: No PHI transmitted to third-party APIs
- **SOC 2**: Full audit trail via local logging
- **FedRAMP**: Air-gapped deployment possible

## Troubleshooting

### Common Issues

| Symptom | Cause | Fix |
|---------|-------|-----|
| `ollama serve` binds to localhost but unreachable | WSL2 networking | Use `OLLAMA_HOST=0.0.0.0:11434` or access via `$(hostname).local` |
| Model loads but inference is slow (>5 tok/s) | CPU-only, large model | Use smaller model or Q4_K_M quant; enable GPU if available |
| `CUDA out of memory` | Model exceeds VRAM | Lower quant or split across CPU (`OLLAMA_NUM_GPU=0`) |
| `Invalid model file` after download | Corrupt download | `ollama rm <model> && ollama pull <model>` |
| llama.cpp `Segmentation fault` | Incompatible build | Rebuild with `make clean && make -j` |
| API returns empty response | Context overflow | Reduce prompt length or use model with larger context |
