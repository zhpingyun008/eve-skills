---
name: local-model
description: Local LLM model integration via Ollama or llama.cpp — download, serve, query local models for privacy-sensitive tasks; model comparison and recommendation; fallback to local when API unavailable.
category: agent-skills
triggers:
  - "local model"
  - "ollama"
  - "llama.cpp"
  - "offline model"
  - "private inference"
  - "run locally"
  - "本地模型"
  - "本地推理"
  - "model evaluation"
  - "model assessment"
  - "vision model"
  - "multimodal"
  - "edge model"
  - "模型评估"
  - "多模态模型"
  - "边缘部署"
---

# local-model — Local LLM Inference


## Overview

Brief description of this skill's purpose and capabilities.
评级: ★★★★☆ (P1)

## 作用

在本地运行大语言模型，提供隐私安全的推理能力。当用户需要离线推理、隐私保护、或 API 不可用时的降级方案。

## 支持的引擎

| 引擎 | 优点 | 缺点 | 适用场景 |
|------|------|------|----------|
| **Ollama** | 一键安装，自动管理模型，REST API | 仅支持 GGUF，定制化有限 | 快速上手，日常使用 |
| **llama.cpp** | 极致性能，量化灵活，多后端 | 需要手动编译，CLI 上手陡峭 | 性能调优，嵌入式部署 |

## 步骤

### 1. Ollama 快速启动

```bash
# 安装 (Linux/WSL)
curl -fsSL https://ollama.com/install.sh | sh

# 启动服务 (后台)
ollama serve &

# 拉取模型
ollama pull llama3.2:3b       # 轻量 (2GB)
ollama pull qwen2.5:7b        # 中文推荐 (4.7GB)
ollama pull deepseek-r1:8b    # 推理增强 (4.9GB)

# 测试推理
ollama run llama3.2:3b "Hello, what is 2+2?"

# API 调用 (http://localhost:11434)
curl http://localhost:11434/api/generate -d '{
  "model": "llama3.2:3b",
  "prompt": "Why is the sky blue?",
  "stream": false
}'
```

### 2. llama.cpp 编译与运行

```bash
# 克隆并编译
git clone https://github.com/ggerganov/llama.cpp.git
cd llama.cpp && make -j$(nproc)

# 下载模型 (HuggingFace)
# 推荐: https://huggingface.co/bartowski (GGUF 量化模型)
wget https://huggingface.co/bartowski/Llama-3.2-3B-Instruct-GGUF/resolve/main/Llama-3.2-3B-Instruct-Q4_K_M.gguf

# 交互式推理
./llama-cli -m Llama-3.2-3B-Instruct-Q4_K_M.gguf -p "Hello!" -n 256

# 服务模式 (OpenAI 兼容 API, 端口 8080)
./llama-server -m model.gguf --port 8080
```

### 3. Hermes Agent 集成

配置 local-model 作为 fallback provider:

```bash
# 检查 Ollama 是否在线
curl -s http://localhost:11434/api/tags | jq '.models[].name'

# 使用 local model 执行任务 (Ollama)
hermes config set provider local_provider --endpoint http://localhost:11434/v1 --model llama3.2:3b

# 健康检查
python3 ~/.hermes/skills/agent-skills/local-model/scripts/check.py
```

### 4. 模型推荐

| 任务类型 | 推荐模型 | 大小(Q4) | 说明 |
|----------|---------|---------|------|
| 代码生成 | deepseek-coder-v2:16b | 8.9GB | 代码能力强 |
| 中文对话 | qwen2.5:7b | 4.7GB | 中文最强 |
| 通用问答 | llama3.2:3b | 2.0GB | 轻量快速 |
| 长上下文 | mistral-nemo:12b | 7.1GB | 128k context |
| 推理/数学 | deepseek-r1:8b | 4.9GB | 思维链推理 |
| **多模态/视觉** | **MiniCPM-V 4.6** | **~0.8GB** | **1.3B, 边缘部署, 超越Gemma4-E2B, 官方免费API** |

> **MiniCPM-V 4.6 (openbmb/MiniCPM-V-4_6)**: 2026-05-11发布, 1.3B参数(LM 0.9B+SigLIP-400M视觉编码器)。专为手机/边缘端设计, intra-ViT早期压缩减少50%+视觉计算。Ollama/GGUF生态暂未支持(社区预计2-4周)。官方提供免费公共API。详见`references/reference.md`。

### 5. 模型-环境兼容性评估方法论

评估一个模型是否能在本机运行的标准化流程：

```bash
# Step 1: 硬件基线检查
uname -a                          # 系统架构 (x86_64/aarch64)
grep -o 'avx2\|avx\|sse4_2' /proc/cpuinfo | sort -u  # CPU指令集
nvidia-smi 2>/dev/null || echo "NO GPU"               # GPU
free -h | head -2                  # RAM总量与可用量
df -h / | tail -1                  # 磁盘可用空间
nproc                              # CPU核心数

# Step 2: 检查网络可达性
curl -s --max-time 5 -o /dev/null -w "%{http_code}" https://ollama.com

# Step 3: 检查模型在Ollama生态的状态
curl -s https://ollama.com/library/<model>/tags | grep -oP 'q[0-9]_[A-Z0-9_]+'  # 量化版本列表
```

**决策矩阵:**

| 硬件条件 | 可行模型规模(GGUF Q4) | 推理速度(CPU估) |
|----------|----------------------|----------------|
| 无GPU, >16GB RAM | 7B-13B | 2-6 tok/s |
| 无GPU, 8-16GB RAM | 3B-7B | 5-15 tok/s |
| 无GPU, 4-8GB RAM | 1B-3B | 10-30 tok/s |
| 有GPU(8GB VRAM) | 7B-13B | 20-60 tok/s |
| 有GPU(24GB+ VRAM) | 13B-34B | 40-100+ tok/s |

**多模态模型特殊考量:**
- 视觉编码器需额外RAM: SigLIP-400M ≈ 200-400MB (Q4)
- CPU上视觉推理极慢: 单图处理5-30秒
- 新模型(发布<1月)通常无GGUF/Ollama支持, 需等1-4周

成本-收益判据:
```
if 无GPU and 模型>7B:
    建议跳过 → CPU推理太慢, 工作流不可用
if 有免费API可用:
    优先用API → 零安装, 性能更好
if 月API成本 < ¥50:
    云端 > 本地 → 综合成本(电费+RAM+时间+质量损失)更高
```

### 6. 降级策略

当 API provider 不可用时自动切换到本地模型:

```python
# Pseudocode for fallback
try:
    response = call_api_provider(prompt)
except APIUnavailableError:
    print("API unavailable, falling back to local model")
    response = call_ollama("llama3.2:3b", prompt)
```

**零安装替代方案** (优先于本地部署):

| 模型 | 免费额度 | 说明 |
|------|---------|------|
| MiniCPM-V 4.6 | ✅ 免费公共API | 官方提供, 多模态(图片+文本) |
| Groq API | ✅ 免费层 | Llama/Mixtral 模型, 极速推理 |
| DeepSeek | ¥1/M tokens | 超低成本, 无需本地硬件 |

> 决策原则: 免费API > 低价云API > 本地部署。本地模型仅在完全离线或隐私绝对必要场景下考虑。

## 隐私注意事项

1. **完全离线**: Ollama/llama.cpp 下载模型后可完全断网运行
2. **数据不外传**: 所有推理在本地完成，无遥测，无日志上传
3. **审计可控**: 模型文件可哈希校验，推理日志本地存储
4. **模型来源**: 仅从 HuggingFace/Ollama 官方拉取，验证 SHA256
5. **资源隔离**: 建议使用 Docker/cgroups 限制 CPU/内存使用

## 验证

```bash
# 运行健康检查脚本
python3 ~/.hermes/skills/agent-skills/local-model/scripts/check.py

# 预期输出: OK
```

## 常见问题

| 问题 | 解决方案 |
|------|---------|
| `ollama: command not found` | 重新运行安装脚本或检查 PATH |
| `CUDA error: out of memory` | 使用更小的模型或量化级别 (Q2/Q3) |
| `connection refused :11434` | `ollama serve` 未启动 |
| 下载速度慢 | 设置 `OLLAMA_MODELS` 到高速磁盘，使用代理 |

## Workflow

1. **Assess environment** — check CPU/GPU/RAM/disk/network baseline; determine feasible model size via decision matrix
2. **Select engine** — choose Ollama (quick start) or llama.cpp (performance tuning) based on needs
3. **Check ecosystem readiness** — verify model exists in Ollama library, has GGUF format, or needs community conversion
4. **Install & configure** — install engine, pull/serve model, verify health with check script
5. **Integrate with Hermes** — set local model as provider or fallback endpoint
6. **Model selection** — match model to task type (code → deepseek-coder, Chinese → qwen, vision → MiniCPM-V, etc.)
7. **Fallback activation** — auto-detect API unavailability and route to local model
8. **Monitor resources** — track GPU/CPU memory, adjust quantization if OOM

## Pitfalls

- **VRAM exhaustion**: Running a 16B+ model on limited GPU causes OOM; always check model size vs available VRAM
- **First-run latency**: Initial model load can take 30-60 seconds; warm up the server before real use
- **Quantization quality loss**: Aggressive quantization (Q2, Q3) degrades output quality significantly for code/reasoning tasks
- **Port conflicts**: Ollama defaults to 11434, llama.cpp to 8080; check for conflicts if both are running
- **Disk space**: GGUF model files are large (2-9GB each); ensure sufficient disk before pulling multiple models
- **Fallback mismatch**: Local models are less capable than frontier APIs; complex reasoning tasks may degrade in fallback mode
- **Network availability (先检查后安装)**: Ollama官方网络多数情况下可达(curl ollama.com返回200), 但下载4GB+模型文件仍可能因网络波动失败。建议: `curl -s --max-time 5 -o /dev/null -w "%{http_code}" https://ollama.com` 先验证。大文件下载使用`ollama pull`的重试机制, 或提前下载GGUF文件离线导入。
- **Ecosystem readiness delay (新模型生态延迟)**: 新发布的模型(发布<1个月)通常没有GGUF/Ollama支持。MiniCPM-V 4.6(2026-05-11发布)至今17天仍无Ollama版本。预计社区GGUF需要2-4周。决策前先检查Ollama模型库或HF GGUF社区(bartowski等)。
- **Multimodal CPU penalty (多模态CPU代价)**: 视觉编码器在CPU上极慢。SigLIP-400M处理单张图片需5-30秒(CPU), 而文本推理仅需毫秒级。多模态模型在CPU上做Agent视觉任务基本不可用。
- **Cost comparison trap**: 本地模型看似免费但电费+RAM占用+质量损失的综合成本可能超过DeepSeek Flash的¥1/M token定价
