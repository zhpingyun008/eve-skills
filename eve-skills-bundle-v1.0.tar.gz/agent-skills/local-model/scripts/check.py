#!/usr/bin/env python3
"""local-model — skill structure validator (shared delegate)"""
import sys
from pathlib import Path

_check = Path(__file__).resolve().parent
_root = _check.parent
while not (_root / "_shared").exists():
    _root = _root.parent
sys.path.insert(0, str(_root / "_shared"))
from skill_validator import run

if __name__ == "__main__":
    run(_check.parent, "local-model")
