---
name: hook-engine
description: Pre/Post command hook system — trigger automated actions before/after tool calls, file operations, git events. Inspired by Claude Code hooks and Git hooks. PMP milestone management integration.
category: agent-skills
triggers:
  - "hook"
  - "钩子"
  - "pre-commit"
  - "自动触发"
  - "事件监听"
  - "lifecycle"
---

# hook-engine — 生命周期钩子引擎


## Overview

hook-engine — 生命周期钩子引擎 skill - auto-validated.
对标: Claude Code hooks (preToolUse/postToolUse) | Git hooks | PMP里程碑管理

## ⚠️ 重要发现 (2026-05-05): Hermes原生Shell Hooks已就绪

**Hermes Agent自带原生Shell Hooks系统**，通过 `~/.hermes/config.yaml` 的 `hooks:` 块注册，
运行在CLI+Gateway双通道，支持JSON stdin/stdout双向通信。

**hook-engine (本skill) 与原生Shell Hooks是两套互补系统，不是竞争关系。**

| 场景 | 用哪个 | 原因 |
|------|--------|------|
| 阻断危险terminal命令 | **原生 Shell Hooks** | pre_tool_call 支持 block 决策 |
| LLM上下文注入 (时间/环境) | **原生 Shell Hooks** | pre_llm_call 支持 context 注入 |
| git commit前自动lint+test | **hook-engine** | 原生不关注git生命周期 |
| 编辑后自动格式化 | **hook-engine** | 使用`$FILE`变量, 轻量 |
| 运行时错误诊断收集 | **两者都可** | 原生 on_error / hook-engine on-error |
| Agent会话开始/结束 | **原生 Shell Hooks** | on_session_start/end 事件 |
| 子Agent完成记录 | **原生 Shell Hooks** | subagent_stop 事件 |

**原生Shell Hooks JSON协议详情 → 看 `references/reference.md`**

## 作用 (本skill — 手动生命周期管理层)

专注于git/构建/编辑等**非agent运行时**的生命周期钩子：

- **pre-commit**: 提交前自动运行lint+test
- **post-edit**: 编辑后自动格式化和检查
- **pre-deploy**: 部署前运行全量测试+安全扫描
- **post-build**: 构建后检查产物大小/完整性
- **on-error**: 错误时自动收集诊断信息

## Trigger Conditions

- Commander says: hook / 钩子 / pre-commit / 自动触发 / native hooks
- Lifecycle event detected (commit/edit/build/deploy)
- Hook configuration change
- Agent运行时事件 → **优先用原生Shell Hooks** (见reference.md)

## Workflow

### Phase 1: Define Hooks

```bash
python3 ~/.hermes/skills/agent-skills/hook-engine/scripts/hook_engine.py --define pre-commit "pytest && ruff check ."
```

支持的钩子点：
| Hook点 | 触发时机 | 默认动作 |
|--------|---------|---------|
| pre-commit | git commit前 | lint + test |
| post-commit | git commit后 | 更新changelog |
| pre-edit | 文件编辑前 | 创建备份 |
| post-edit | 文件编辑后 | 格式化 + lint |
| pre-build | 构建前 | 依赖检查 |
| post-build | 构建后 | 产物大小检查 |
| pre-deploy | 部署前 | 全量测试+安全扫描 |
| post-deploy | 部署后 | 健康检查+通知 |
| on-error | 错误时 | 收集诊断+日志 |
| on-start | 会话启动 | 加载项目上下文 |
| on-exit | 会话结束 | 保存状态+压缩记忆 |

### Phase 2: List Hooks

```bash
python3 ~/.hermes/skills/agent-skills/hook-engine/scripts/hook_engine.py --list
```

### Phase 3: Test Hook

```bash
python3 ~/.hermes/skills/agent-skills/hook-engine/scripts/hook_engine.py --test pre-commit
```

干运行，不实际执行。

### Phase 4: Enable/Disable

```bash
python3 ~/.hermes/skills/agent-skills/hook-engine/scripts/hook_engine.py --disable pre-commit
python3 ~/.hermes/skills/agent-skills/hook-engine/scripts/hook_engine.py --enable pre-commit
```

## Hook配置存储

`~/.hermes/hooks.yaml`:
```yaml
hooks:
  pre-commit:
    enabled: true
    commands:
      - ruff check .
      - pytest -x
    on_failure: block  # block | warn | continue
  post-edit:
    enabled: true
    commands:
      - ruff format $FILE
    on_failure: warn
```

## Integration

- **project-context**: on-start hook自动加载PROJECT.md (→ 用原生Shell Hooks pre_llm_call更合适)
- **code-review**: pre-commit hook触发审查 (hook-engine适用)
- **test-engine**: pre-commit/pre-deploy触发测试 (hook-engine适用)
- **cicd-builder**: pre-deploy触发CI检查 (hook-engine适用)
- **self-healer**: on-error hook收集诊断 (两者均可, 原生on_error事件更自动)
- **terminal-log**: post_tool_call记录终端操作 (→ 只能用原生Shell Hooks)
- **git-guardrails**: pre_tool_call阻断危险git命令 (→ 只能用原生Shell Hooks)

## 原生Shell Hooks 快速模板

```yaml
# 添加到 ~/.hermes/config.yaml
hooks:
  post_tool_call:
    - matcher: "terminal"
      command: "bash ~/.hermes/agent-hooks/terminal-log.hook.sh"
      timeout: 5
  pre_llm_call:
    - matcher: ".*"
      command: "bash ~/.hermes/agent-hooks/cron-context.sh"
      timeout: 5
```

脚本规范: ~/.hermes/agent-hooks/ 目录, shebang脚本, JSON stdin/stdout协议.
详情: 见 `references/reference.md` 的「Native Hermes Shell Hooks」章节。

## Pitfalls

- Hook失败不应阻塞关键操作（可配置为warn模式）
- Hook脚本超时需设上限（默认30s）
- 避免Hook中调用自身导致循环
- ⚠️ **不要混淆两套系统**: hook-engine 配置在 `~/.hermes/hooks.yaml`, 原生Shell Hooks 配置在 `~/.hermes/config.yaml` 的 `hooks:` 块。两者文件格式不同、事件模型不同、不可互换。
- ⚠️ **不要在hook-engine里做原生能做的事**: 阻断terminal命令、注入LLM上下文等agent运行时事件 → 原生Shell Hooks更直接、更可靠。

## Verification

```bash
python3 ~/.hermes/skills/agent-skills/hook-engine/scripts/hook_engine.py --check
```
