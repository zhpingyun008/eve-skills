# Hook Engine Reference

## Available Hook Points
pre-commit/post-commit/pre-edit/post-edit/pre-build/post-build/pre-deploy/post-deploy/on-error/on-start/on-exit

## Failure Policies
- block: Stop execution
- warn: Continue with warning
- continue: Ignore failure

## Example (hook-engine standalone)
```yaml
hooks:
  pre-commit:
    enabled: true
    commands: [pytest, ruff]
    on_failure: block
```

---

## 🚨 Native Hermes Shell Hooks (2026-05-05)

**发现**: Hermes Agent 自带原生 Shell Hooks 系统 (`hooks:` 块 in `~/.hermes/config.yaml`),
与 hook-engine skill 的 `~/.hermes/hooks.yaml` 是**两套独立系统**。原生系统更强大。

### 核心差异

| 方面 | hook-engine (skill) | Shell Hooks (原生) |
|------|-------------------|-------------------|
| 事件模型 | 手动生命周期 | Hermes 数据面事件 |
| 触发方式 | 调用 `--trigger` | 自动被 agent 事件触发 |
| 事件范围 | commit/edit/build/deploy | tool_call/llm_call/session lifecycle |
| 配置位置 | `~/.hermes/hooks.yaml` | `~/.hermes/config.yaml` |
| 是否可阻断 | ❌ 仅记录 | ✅ pre_tool_call 可阻断 |
| 是否可注入 | ❌ | ✅ pre_llm_call 可注入上下文 |
| 跨进程隔离 | ✅ | ✅ |

### 原生 Shell Hooks 支持的事件
- `pre_tool_call` / `post_tool_call`
- `pre_llm_call` / `post_llm_call`
- `subagent_start` / `subagent_stop`
- `on_session_start` / `on_session_end`
- `on_error`

### 原生 Shell Hooks JSON 协议

**stdin** (Hermes → script):
```json
{
  "hook_event_name": "pre_tool_call",
  "tool_name": "terminal",
  "tool_input": {"command": "rm -rf /"},
  "session_id": "sess_abc123",
  "cwd": "/home/user/project"
}
```

**stdout** (script → Hermes):
```json
// Block
{"decision": "block", "reason": "Forbidden: rm -rf"}
// Inject context
{"context": "Today is Friday, 2026-04-17"}
// No-op
{}
```

### 原生配置 schema
```yaml
# ~/.hermes/config.yaml
hooks:
  pre_tool_call:
    - matcher: "terminal"
      command: "bash ~/.hermes/agent-hooks/block-dangerous.sh"
      timeout: 10
  post_tool_call:
    - matcher: "terminal"
      command: "bash ~/.hermes/agent-hooks/terminal-log.hook.sh"
      timeout: 5
hooks_auto_accept: false
```

### 互操作性
- Shell Hooks + hook-engine 可以共存（不同配置路径）
- 建议：hook-engine 负责 git/构建生命周期，Shell Hooks 负责 agent 运行时
- 脚本本身可复用：hook-engine 的 `on-error` 逻辑可移植为 Shell Hooks 的 `pre_llm_call`