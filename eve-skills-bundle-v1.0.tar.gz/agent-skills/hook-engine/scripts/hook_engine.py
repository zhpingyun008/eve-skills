#!/usr/bin/env python3
"""hook-engine — Pre/Post lifecycle hook system"""

import sys, json, os, subprocess, yaml
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional

HOOKS_FILE = Path.home() / ".hermes" / "hooks.yaml"
DEFAULT_HOOKS = {
    "hooks": {
        "pre-commit": {"enabled": False, "commands": ["ruff check .", "pytest -x --tb=short"], "on_failure": "block"},
        "post-commit": {"enabled": False, "commands": [], "on_failure": "warn"},
        "pre-edit": {"enabled": False, "commands": [], "on_failure": "warn"},
        "post-edit": {"enabled": False, "commands": ["ruff format $FILE 2>/dev/null || true"], "on_failure": "warn"},
        "pre-build": {"enabled": False, "commands": ["pip check 2>/dev/null || true"], "on_failure": "warn"},
        "post-build": {"enabled": False, "commands": [], "on_failure": "warn"},
        "pre-deploy": {"enabled": False, "commands": ["pytest --cov", "bandit -r . -q"], "on_failure": "block"},
        "post-deploy": {"enabled": False, "commands": ["curl -sf http://localhost:8000/health || echo 'Health check failed'"], "on_failure": "warn"},
        "on-error": {"enabled": True, "commands": ["echo '[HOOK] Error detected at $(date)'"], "on_failure": "continue"},
        "on-start": {"enabled": False, "commands": ["python3 ~/.hermes/skills/agent-skills/project-context/scripts/project_context.py --load 2>/dev/null || true"], "on_failure": "continue"},
        "on-exit": {"enabled": False, "commands": [], "on_failure": "continue"},
    }
}

def load_hooks() -> Dict:
    """Load hooks configuration"""
    if not HOOKS_FILE.exists():
        HOOKS_FILE.parent.mkdir(parents=True, exist_ok=True)
        save_hooks(DEFAULT_HOOKS)
        return DEFAULT_HOOKS
    
    try:
        with open(HOOKS_FILE) as f:
            return yaml.safe_load(f) or DEFAULT_HOOKS
    except:
        return DEFAULT_HOOKS

def save_hooks(config: Dict):
    """Save hooks configuration"""
    with open(HOOKS_FILE, 'w') as f:
        yaml.dump(config, f, default_flow_style=False, allow_unicode=True)

def list_hooks() -> List[Dict]:
    """List all hooks and their status"""
    config = load_hooks()
    hooks = []
    for name, hook in config.get("hooks", {}).items():
        hooks.append({
            "name": name,
            "enabled": hook.get("enabled", False),
            "commands": hook.get("commands", []),
            "on_failure": hook.get("on_failure", "warn"),
        })
    return hooks

def define_hook(name: str, commands: List[str], on_failure: str = "block", enabled: bool = True):
    """Define or update a hook"""
    config = load_hooks()
    config["hooks"][name] = {
        "enabled": enabled,
        "commands": commands,
        "on_failure": on_failure,
    }
    save_hooks(config)

def toggle_hook(name: str, enabled: bool):
    """Enable or disable a hook"""
    config = load_hooks()
    if name in config.get("hooks", {}):
        config["hooks"][name]["enabled"] = enabled
        save_hooks(config)
        return True
    return False

def execute_hook(name: str, env: Dict = None) -> Dict:
    """Execute a hook and return results"""
    config = load_hooks()
    hook = config.get("hooks", {}).get(name)
    
    if not hook or not hook.get("enabled"):
        return {"hook": name, "executed": False, "reason": "not enabled or not found"}
    
    results = []
    all_passed = True
    
    for cmd in hook.get("commands", []):
        # Expand variables
        expanded = cmd
        if env:
            for k, v in env.items():
                expanded = expanded.replace(f"${k}", str(v))
        
        try:
            result = subprocess.run(
                expanded, shell=True, capture_output=True, text=True, timeout=30,
                cwd=os.getcwd()
            )
            passed = result.returncode == 0
            results.append({
                "command": cmd,
                "exit_code": result.returncode,
                "output": result.stdout[:500] + result.stderr[:500],
                "passed": passed,
            })
            if not passed:
                all_passed = False
                if hook.get("on_failure") == "block":
                    break
        except subprocess.TimeoutExpired:
            results.append({"command": cmd, "error": "timeout", "passed": False})
            all_passed = False
        except Exception as e:
            results.append({"command": cmd, "error": str(e), "passed": False})
            all_passed = False
    
    return {
        "hook": name,
        "executed": True,
        "all_passed": all_passed,
        "on_failure_policy": hook.get("on_failure"),
        "results": results,
    }

def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return
    
    cmd = sys.argv[1]
    
    if cmd == "--check":
        hooks = list_hooks()
        print(json.dumps({"status": "ok", "skill": "hook-engine", "hooks_count": len(hooks), "enabled": sum(1 for h in hooks if h["enabled"])}))
    
    elif cmd == "--init":
        save_hooks(DEFAULT_HOOKS)
        print(f"Initialized hooks config: {HOOKS_FILE}")
        print(f"Default hooks: {len(DEFAULT_HOOKS['hooks'])} defined, 1 enabled (on-error)")
    
    elif cmd == "--list":
        hooks = list_hooks()
        print(json.dumps(hooks, indent=2))
    
    elif cmd == "--define":
        name = sys.argv[2] if len(sys.argv) > 2 else None
        commands = sys.argv[3:] if len(sys.argv) > 3 else []
        if not name:
            print("Usage: --define <hook-name> <command1> [command2 ...]")
            return
        define_hook(name, commands)
        print(f"Hook '{name}' defined with {len(commands)} commands")
    
    elif cmd in ("--enable", "--disable"):
        name = sys.argv[2] if len(sys.argv) > 2 else None
        if not name:
            print(f"Usage: {cmd} <hook-name>")
            return
        enable = cmd == "--enable"
        if toggle_hook(name, enable):
            print(f"Hook '{name}' {'enabled' if enable else 'disabled'}")
        else:
            print(f"Hook '{name}' not found")
    
    elif cmd == "--test":
        name = sys.argv[2] if len(sys.argv) > 2 else None
        if not name:
            print("Usage: --test <hook-name>")
            return
        result = execute_hook(name, {"FILE": "test.py"})
        print(json.dumps(result, indent=2))
    
    elif cmd == "--trigger":
        name = sys.argv[2] if len(sys.argv) > 2 else None
        if not name:
            print("Usage: --trigger <hook-name>")
            return
        result = execute_hook(name)
        print(json.dumps(result, indent=2))
        sys.exit(0 if result.get("all_passed") else 1)
    
    else:
        print(f"Unknown: {cmd}")

if __name__ == "__main__":
    main()
