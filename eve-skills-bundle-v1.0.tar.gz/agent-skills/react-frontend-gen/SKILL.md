---
name: react-frontend-gen
description: 从已有后端API生成完整React+TypeScript+Vite+TailwindCSS前端SPA。覆盖：脚手架、API客户端TS类型定义、路由、7种典型页面（搜索/详情/表单/列表/详情/聊天/首页）、Auth头注入、TailwindCSS配置、构建验证。适合"后端已有，补前端"场景。
category: agent-skills
triggers:
  - "前端生成 / frontend generation / build frontend"
  - "已有后端补前端 / frontend from existing API"
  - "React SPA from API / 从API生成React"
  - "Vite + React + TS + Tailwind / Vite脚手架"
  - "前端页面开发 / SPA pages"
  - "frontend from backend / 后端补前端"
  - "generate frontend / 创建前端 / build UI"
  - "前端界面 / web UI / SPA / single page app"
  - "React + TypeScript / React TS项目"
---

# react-frontend-gen — 从后端API生成React前端SPA

## Overview

从一个**已有后端API**（FastAPI/Express/Go等）生成完整的React前端单页应用。覆盖：项目脚手架、TypeScript API客户端、7种典型页面、Auth集成、TailwindCSS、构建验证。

**前提条件**：后端API已就绪且有9+个REST端点（search/booking/chat/orders），API文档或代码可查阅。

**不适用场景**：
- 全栈从零开始 → 使用 `fullstack-builder`
- 后端基础设施加固 → 使用 `backend-infra-hardening`
- 仅需API客户端代码 → 使用 `api-client-gen`

## 执行流程

### Step 0: 环境检查 + npm 国内镜像（中国大陆环境）

```bash
# 确保Node.js可用
node --version  # 需要 >= 18
npm --version

# 使用 npmmirror 提速（中国大陆必配）
npm config set registry https://registry.npmmirror.com
npm ping  # 预期: ~200ms

# 确认后端API可访问（健康检查）
curl -s http://localhost:8000/api/health
```

### Step 1: 脚手架（两种模式）

#### 模式A: shadcn/ui (推荐 — 专业设计系统)
```bash
cd ~/projects/{project-name}

# 1. 创建Vite+React+TS项目
npm create vite@latest frontend -- --template react-ts

# 2. 安装基础依赖
cd frontend
npm install
npm install axios react-router-dom

# 3. 初始化 shadcn/ui（交互式, 选默认配置即可）
npx shadcn@latest init -d

# 4. 批量安装常用组件
npx shadcn@latest add button card input label table badge dialog
npx shadcn@latest add form select separator tabs toast
npx shadcn@latest add avatar dropdown-menu sheet skeleton
```

#### 模式B: 纯 TailwindCSS（轻量项目）
```bash
cd ~/projects/{project-name}

# 1. 创建Vite+React+TS项目
npm create vite@latest frontend -- --template react-ts

# 2. 安装依赖
cd frontend
npm install
npm install axios react-router-dom tailwindcss @tailwindcss/vite
```

### Step 2: 基础配置

#### 2a. vite.config.ts — 添加Tailwind + API代理

```typescript
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: {
    proxy: { '/api': 'http://localhost:8000' }
  }
})
```

#### 2b. src/index.css — Tailwind入口

```css
@import "tailwindcss";
```

#### 2c. 删除模板样板文件

```bash
rm src/App.css  # 如果有
```

### Step 3: TypeScript API Client

创建 `src/api/client.ts`，结构如下：

```typescript
import axios from 'axios';

// ── TypeScript 类型定义 ──
// 从后端Pydantic/SQLAlchemy模型读取字段，生成TS interfaces

export interface FlightTicket {
  id: string;
  airline: string;
  flight_no: string;
  departure_airport: string;
  arrival_airport: string;
  departure_time: string;   // ISO datetime
  arrival_time: string;
  price: number;
  currency: string;
  seats_available: number;
  cabin_class: string;
}

export interface SearchFlightsParams {
  origin?: string;
  destination?: string;
  date?: string;
  passengers?: number;
  cabin_class?: string;
}

// ... 更多类型: PassengerInfo, Order, ChatMessage, HealthResponse 等

// ── API 客户端 ──
const client = axios.create({
  baseURL: 'http://localhost:8000/api',
  timeout: 30000,
  headers: { 'X-API-Key': 'dev-haihang-api-key-2026' }
});

// 错误拦截器
client.interceptors.response.use(
  r => r,
  error => {
    console.error(`API Error: ${error.response?.status}`, error.response?.data);
    return Promise.reject(error);
  }
);

// ── API 函数 ──
export async function searchFlights(params: SearchFlightsParams): Promise<FlightTicket[]> {
  const res = await client.get('/search/flights', { params });
  return res.data;
}

export async function getFlight(id: string): Promise<FlightTicket> {
  const res = await client.get(`/search/flights/${id}`);
  return res.data;
}

export async function createBooking(data: { ticket_id: string; passengers: any[] }) {
  const res = await client.post('/booking/create', data);
  return res.data;
}

// ... 9个端点全覆盖

export { client };
```

**关键原则**：类型定义必须对齐后端返回的实际JSON结构，包括字段名（camelCase/snake_case）、嵌套层级、可选性。

### Step 4: 路由 + Layout

#### 4a. 7类典型页面路由

```typescript
// src/App.tsx
import { Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';

// 延迟加载提升性能
const Home = lazy(() => import('./pages/Home'));
const SearchFlights = lazy(() => import('./pages/SearchFlights'));
const FlightDetail = lazy(() => import('./pages/FlightDetail'));
const BookingConfirm = lazy(() => import('./pages/BookingConfirm'));
const Orders = lazy(() => import('./pages/Orders'));
const OrderDetail = lazy(() => import('./pages/OrderDetail'));
const Chat = lazy(() => import('./pages/Chat'));

function App() {
  return (
    <Layout>
      <Suspense fallback={<div className="p-8 text-center">加载中...</div>}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/flights" element={<SearchFlights />} />
          <Route path="/flights/:id" element={<FlightDetail />} />
          <Route path="/booking" element={<BookingConfirm />} />
          <Route path="/orders" element={<Orders />} />
          <Route path="/orders/:id" element={<OrderDetail />} />
          <Route path="/chat" element={<Chat />} />
        </Routes>
      </Suspense>
    </Layout>
  );
}
```

#### 4b. Layout组件

```tsx
// src/components/Layout.tsx
import { Link, useLocation } from 'react-router-dom';

const NAV_ITEMS = [
  { path: '/flights', label: '搜索航班', icon: '🔍' },
  { path: '/orders', label: '我的订单', icon: '📋' },
  { path: '/chat', label: 'AI助手', icon: '🤖' },
];

export default function Layout({ children }: { children: React.ReactNode }) {
  const location = useLocation();
  return (
    <div className="min-h-screen bg-gray-50">
      <nav className="bg-gradient-to-r from-blue-600 to-blue-700 text-white shadow-md">
        <div className="max-w-4xl mx-auto px-4 py-3 flex items-center justify-between">
          <Link to="/" className="font-bold text-lg">✈️ 海航AI购票助手</Link>
          <div className="flex gap-4">
            {NAV_ITEMS.map(item => (
              <Link key={item.path} to={item.path}
                className={`px-3 py-1 rounded-full text-sm transition-colors ${
                  location.pathname.startsWith(item.path)
                    ? 'bg-white/20' : 'hover:bg-white/10'
                }`}>
                {item.icon} {item.label}
              </Link>
            ))}
          </div>
        </div>
      </nav>
      <main className="max-w-4xl mx-auto px-4 py-6">{children}</main>
      <footer className="text-center text-gray-400 text-xs py-4 border-t">
        海航AI购票助手 v1.0
      </footer>
    </div>
  );
}
```

### Step 5: 7类典型页面模板

每类页面有标准数据流模式和状态覆盖（loading/error/empty/success）：

#### 5a. 首页 (Home) — shadcn 版示例

```tsx
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

// 使用 shadcn Card 组件替代纯 Tailwind div
<Card className="hover:shadow-lg transition-shadow">
  <CardHeader>
    <CardTitle>搜索航班</CardTitle>
  </CardHeader>
  <CardContent>
    <Button>开始搜索</Button>
  </CardContent>
</Card>
```

#### 5b. 搜索页 (SearchFlights) — shadcn 版
- Form: 出发/到达城市下拉(自动互换按钮) + 日期 + 舱位 + 乘客数
- Submit → searchFlights() → 结果表格
- 状态: loading spinner / empty结果 / 错误提示 / 数据表格

```tsx
// 关键模式：表单提交 → API调用 → 状态管理
const [form, setForm] = useState({ origin: '', destination: '', date: '', passengers: 1, cabinClass: '' });
const [results, setResults] = useState<FlightTicket[]>([]);
const [loading, setLoading] = useState(false);
const [error, setError] = useState<string | null>(null);

const handleSearch = async () => {
  setLoading(true);
  setError(null);
  try {
    const data = await searchFlights(form);
    setResults(data);
  } catch (e) {
    setError('搜索失败，请重试');
  } finally {
    setLoading(false);
  }
};
```

#### 5c. 详情页 (FlightDetail)
- useParams → getFlight(id)
- 航班路线展示(起降城市+时间+价格)
- "立即预订"按钮 → navigate(/booking?flightId=xxx)

#### 5d. 预订表单 (BookingConfirm)
- useSearchParams获取flightId
- 旅客信息表单: firstName/lastName/idType/idNumber/phone
- 表单校验(身份证正则/手机号正则)
- Submit → createBooking() → 确认页

```tsx
// 三态路由：创建预订 / 显示已有订单 / 无参数引导
const [searchParams] = useSearchParams();
const flightId = searchParams.get('flightId');
const { orderId } = useParams();

if (orderId) { /* 获取并显示已有订单 */ }
else if (flightId) { /* 预订表单流程 */ }
else { /* 引导: 请先选择航班 */ }
```

#### 5e. 订单列表 (Orders)
- getUserOrders('user-001') → 卡片列表
- 状态徽章: pending=黄/confirmed=绿/cancelled=灰
- 点击→ navigate(/orders/:id)

#### 5f. 订单详情 (OrderDetail)
- useParams → getOrder(id)
- 航班信息 + 旅客列表 + 价格明细
- 取消按钮 → 确认弹窗 → cancelOrder(id)

#### 5g. AI聊天 (Chat)
- 消息气泡: 用户=右对齐蓝色 / AI=左对齐灰色
- sendChatMessage() → intent匹配回复
- 历史记录: getChatHistory()

### Step 6a: JWT Auth Integration (Post-Generation)

After the basic frontend is generated, add JWT authentication with login/register pages, AuthContext, and route guards.

**Required backend endpoints** (must exist first):
```
POST /api/auth/register  → {user_id, token, username}
POST /api/auth/login     → {user_id, token, username}
GET  /api/auth/me        → {id, username, phone, ...}  (Bearer token)
```

#### 6a.1 Create AuthContext

```tsx
// src/contexts/AuthContext.tsx
import { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from 'react';
import { setAuthToken, clearAuthToken } from '../api/client';
import apiClient from '../api/client';

const TOKEN_KEY = 'app_auth_token';

export interface User { id: string; username: string; phone: string; email?: string; }

interface AuthContextValue {
  user: User | null;
  token: string | null;
  loading: boolean;
  isAuthenticated: boolean;
  login: (phone: string, password: string) => Promise<void>;
  register: (username: string, phone: string, password: string) => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(
    () => { try { return localStorage.getItem(TOKEN_KEY); } catch { return null; } }
  );
  const [loading, setLoading] = useState(true);

  // On mount: verify stored token
  useEffect(() => {
    (async () => {
      const stored = localStorage.getItem(TOKEN_KEY);
      if (stored) {
        setAuthToken(stored);
        try {
          const { data } = await apiClient.get('/api/auth/me');
          setUser({ id: data.id, username: data.username, phone: data.phone });
          setToken(stored);
        } catch {
          localStorage.removeItem(TOKEN_KEY);
          clearAuthToken();
          setToken(null);
        }
      }
      setLoading(false);
    })();
  }, []);

  const login = useCallback(async (phone: string, password: string) => {
    const { data } = await apiClient.post('/api/auth/login', { phone, password });
    localStorage.setItem(TOKEN_KEY, data.token);
    setAuthToken(data.token);
    setToken(data.token);
    setUser({ id: data.user_id, username: data.username, phone });
  }, []);

  const register = useCallback(async (username: string, phone: string, password: string) => {
    const { data } = await apiClient.post('/api/auth/register', { username, phone, password });
    localStorage.setItem(TOKEN_KEY, data.token);
    setAuthToken(data.token);
    setToken(data.token);
    setUser({ id: data.user_id, username: data.username, phone });
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem(TOKEN_KEY);
    clearAuthToken();
    setToken(null);
    setUser(null);
  }, []);

  return (
    <AuthContext.Provider value={{ user, token, loading, isAuthenticated: !!user && !!token, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within an AuthProvider');
  return ctx;
}
```

#### 6a.2 Update API Client with Token Support

Add to `src/api/client.ts`:

```typescript
/** Update the Authorization header when auth token changes */
export function setAuthToken(token: string) {
  apiClient.defaults.headers.common['Authorization'] = `Bearer ${token}`;
}

/** Remove the Authorization header on logout */
export function clearAuthToken() {
  delete apiClient.defaults.headers.common['Authorization'];
}
```

Keep the existing `X-API-Key` header as a fallback for development.

#### 6a.3 Create Login and Register Pages

**LoginPage.tsx** — Phone + password form, calls `auth.login()`, navigates to home:
```tsx
export default function LoginPage() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      await login(phone, password);
      navigate('/');
    } catch (err: any) {
      setError(err?.response?.data?.detail || '登录失败');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mx-auto max-w-md px-4 py-16">
      <h1 className="text-2xl font-bold text-center mb-8">登录</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium mb-1">手机号</label>
          <input type="tel" value={phone} onChange={e => setPhone(e.target.value)}
            placeholder="13800138000" className="w-full rounded-lg border p-2.5 text-sm" required />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">密码</label>
          <input type="password" value={password} onChange={e => setPassword(e.target.value)}
            placeholder="输入密码" className="w-full rounded-lg border p-2.5 text-sm" required />
        </div>
        {error && <div className="text-red-500 text-sm">{error}</div>}
        <button type="submit" disabled={loading}
          className="w-full rounded-lg bg-blue-600 py-2.5 text-white font-semibold hover:bg-blue-700 disabled:opacity-50">
          {loading ? '登录中...' : '登录'}
        </button>
        <p className="text-center text-sm text-gray-500">
          还没有账号？<Link to="/register" className="text-blue-600">立即注册</Link>
        </p>
      </form>
    </div>
  );
}
```

**RegisterPage.tsx** — Username + phone + password + confirm, calls `auth.register()`, navigates to home.

#### 6a.4 Create ProtectedRoute (Route Guard)

```tsx
// src/components/ProtectedRoute.tsx
import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

export default function ProtectedRoute() {
  const { isAuthenticated, loading } = useAuth();

  if (loading) {
    return <div className="flex min-h-[70vh] items-center justify-center">
      <div className="h-8 w-8 animate-spin rounded-full border-4 border-blue-600 border-t-transparent" />
    </div>;
  }

  if (!isAuthenticated) return <Navigate to="/login" replace />;
  return <Outlet />;
}
```

#### 6a.5 Update App.tsx with Auth Routes

```tsx
import { AuthProvider } from './contexts/AuthContext';
import ProtectedRoute from './components/ProtectedRoute';

function App() {
  return (
    <AuthProvider>
      <Routes>
        {/* Public routes */}
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        
        {/* Protected routes */}
        <Route element={<ProtectedRoute />}>
          <Route element={<Layout />}>
            <Route path="/" element={<Home />} />
            <Route path="/flights" element={<SearchFlights />} />
            <Route path="/flights/:id" element={<FlightDetail />} />
            <Route path="/booking" element={<BookingConfirm />} />
            <Route path="/booking/:orderId" element={<BookingConfirm />} />
            <Route path="/orders" element={<Orders />} />
            <Route path="/orders/:id" element={<OrderDetail />} />
            <Route path="/chat" element={<Chat />} />
          </Route>
        </Route>
      </Routes>
    </AuthProvider>
  );
}
```

#### 6a.6 Replace Hardcoded USER_ID

In pages that use `const USER_ID = 'user-001'` (Chat.tsx, Orders.tsx), replace with:
```tsx
const { user } = useAuth();
// Then use: user?.id || 'fallback-id'
```

#### 6a.7 Verify

```bash
cd frontend && npx tsc -b --noEmit && npm run build
# Expected: 0 errors, build successful
```

### Step 6b: 页面间数据传递
使用 `useNavigate` + `location.state`：
```tsx
const nav = useNavigate();
nav('/booking', { state: { flight: selectedFlight } });

// 接收：
const loc = useLocation();
const flight = loc.state?.flight;
if (!flight) { /* 空状态引导 */ }
```

#### 6b. 全状态覆盖
每个数据组件必须覆盖4态：
```tsx
{loading ? <Spinner /> : 
 error ? <ErrorBanner msg={error} onRetry={retry} /> :
 data.length === 0 ? <EmptyState /> :
 <DataList items={data} />}
```

#### 6c. Auth头注入
API客户端必须包含认证token（X-API-Key或Bearer token）：
```tsx
const client = axios.create({
  baseURL: 'http://localhost:8000/api',
  headers: { 'X-API-Key': 'dev-haihang-api-key-2026' }
});
```

### Step 7: 构建验证

```bash
cd frontend

# TypeScript检查
npx tsc --noEmit
# 预期: 0 errors

# Vite生产构建
npx vite build
# 预期: ✓ N modules transformed in Xms
# 确认构建产物存在
ls dist/
```

### 管理后台闭环检查表 (Admin Panel Completeness)

当生成的是管理后台（非面向C端的产品页），必须通过以下闭环检查。任何缺失环节都导致"功能太单一"的用户反馈：

#### 核心闭环链

```mermaid
flowchart LR
    A[列表] --> B[详情/点击进入]
    B --> C[创建/添加]
    B --> D[编辑/修改]
    B --> E[删除]
    C --> A
    D --> A
    E --> A
```

| 环节 | 检查项 | 必须 |
|------|--------|------|
| **列表** | 展示所有资源、支持加载态/空态/错误态 | ✅ |
| **详情** | 点击列表项进入详情页，展示完整信息 | ✅ |
| **创建** | 表单+提交，成功后返回列表并刷新 | ✅ |
| **编辑** | 详情页内可修改名称/描述等字段 | ✅ |
| **删除** | 确认弹窗+调API删除+返回列表 | ✅ |
| **操作验证** | 创建后能立即测试（如Chatbot对话、KB查询） | ✅ |

#### 管理后台典型页面清单

| 资源类型 | 列表页 | 详情页 | 创建 | 编辑 | 删除 | 操作/测试 |
|----------|--------|--------|------|------|------|-----------|
| Chatbot | 名称/描述/状态 | 欢迎语+对话测试窗口 | ✅ | ✅ | ✅ | 直接聊天 |
| 知识库KB | 名称/文档数 | 文档列表+RAG查询+上传 | ✅ | ✅ | ✅ | 提问测试 |
| 订单 | 客户/金额/状态 | 订单详情+操作 | — | ✅ | — | 状态筛选 |
| 用户/设置 | 列表 | 角色/权限 | ✅ | ✅ | ✅ | — |

#### 功能单一自检问题

构建完成后自查：
1. 「我创建了一个资源，然后能做什么？」→ 必须在同页面就能操作/测试
2. 「我能修改刚才创建的吗？」→ 详情页必须有编辑功能
3. 「我不想要了怎么删？」→ 必须有删除+确认弹窗
4. 「这个页面比上个页面多了什么？」→ 每个页面必须有独特价值

### Vite 8 兼容性注意事项

Vite 8 使用 Rust 版 `oxc` 解析器替代传统的 `esbuild/swc`，有以下不兼容点：

#### 1. tsconfig 项目引用

```json
// ❌ Vite 8 oxc 不支持
{
  "references": [
    { "path": "./tsconfig.app.json" },
    { "path": "./tsconfig.node.json" }
  ]
}

// ✅ 合并为单文件
{
  "compilerOptions": {
    "target": "es2023",
    "lib": ["ES2023", "DOM"],
    "module": "esnext",
    "moduleResolution": "bundler",
    "jsx": "react-jsx",
    "noEmit": true,
    "strict": false,
    "noUnusedLocals": false,    // oxc 对 unused locals 敏感
    "noUnusedParameters": false
  },
  "include": ["src"]
}
```

**错误信号**: `[TSCONFIG_ERROR] Failed to load tsconfig for 'src/main.tsx': Tsconfig not found`

**修复**: 删除 `tsconfig.app.json` 和 `tsconfig.node.json`，合并到单 `tsconfig.json`。

#### 2. verbatimModuleSyntax

```json
// ❌ oxc 在 Vite 8 下不支持
"verbatimModuleSyntax": true

// ✅ 设为 false
"verbatimModuleSyntax": false
```

#### 3. rolldown 打包器

Vite 8 使用 `rolldown`（Rust 版 rollup）替代 `rollup`。常见差异：
- 导出检查更严格：`export interface` 必须确保所有引用都正确
- 构建时报错 `[MISSING_EXPORT]` 而非警告
- 修复：确保 `client.ts` 中实际导出了所有被 `import` 的类型和函数

## shadcn/ui 组件速查表

使用 shadcn 模式时，用 shadcn 组件替代手写 Tailwind 样式，产出更专业一致的设计。

| shadcn 组件 | 替代什么 | 典型用法 |
|-------------|---------|----------|
| `Button` | 手写`<button className="...">` | `<Button>提交</Button>` |
| `Card` | 手写`<div className="rounded-lg shadow ...">` | 卡片布局、面板容器 |
| `Input` | 手写`<input className="...">` | 表单输入框 |
| `Label` | 手写`<label className="...">` | 表单标签 |
| `Badge` | 手写状态徽章 | 订单状态(待处理/已完成) |
| `Table` | 手写`<table className="...">` | 数据表格、搜索结果 |
| `Dialog` | 手写confirm弹窗 | 删除确认、详情弹窗 |
| `Tabs` | 手写tab切换 | 多视图切换 |
| `Select` | 手写`<select>` | 下拉选择 |
| `Form` | 手写表单验证 | 带校验的复杂表单 |
| `Toast` | 手写通知 | 操作成功/失败提示 |
| `Skeleton` | 手写loading | 骨架屏加载态 |
| `Avatar` | 用户头像 | 用户菜单 |
| `Separator` | 分割线 | 内容分组 |
| `DropdownMenu` | 下拉菜单 | 用户操作菜单 |

```bash
# 批量安装
npx shadcn@latest add button card input label table badge dialog tabs
npx shadcn@latest add form select separator toast skeleton avatar dropdown-menu
```

## 常见问题

### 文件位置错误
CI/CD文件(.github/workflows/)和配置文件(pyproject.toml/.gitignore)可能被subagent写到用户home目录而非项目目录。固定检查：
```bash
# 验证位置正确
ls ~/projects/{project}/.github/workflows/ci.yml 2>/dev/null || echo "❌ Wrong location"
ls ~/projects/{project}/Makefile 2>/dev/null || echo "❌ Wrong location"
```

### Auth头导致测试403
API Key中间件添加后，测试client必须包含认证头：
```python
# conftest.py
@pytest.fixture(autouse=True)
def auth_client(client):
    client.headers.update({"X-API-Key": "dev-haihang-api-key-2026"})
    yield client
```

### TypeScript类型不匹配
后端Pydantic模型字段名(snake_case)与前端TS(camelCase)不一致时导致运行时undefined：
- 方案A: 在`api/client.ts`中定义transform函数做字段映射
- 方案B: 后端Pydantic配置`alias_generator=to_camel` + `populate_by_name=True`
- 方案C: 前端直接使用snake_case字段名（推荐，因为JSON默认snake_case）

### 路由404
确保App.tsx中的Route path与导航链接匹配，特别是带参路由：
```tsx
<Route path="/flights/:id" element={<FlightDetail />} />
// 导航到: /flights/T202605110000 ✅
// 导航到: /flights?id=T202605110000 ❌ (需使用searchParams)
```

### 预订表单双路径
`/booking`（创建新预订）和`/booking/:orderId`（查看已有订单）可能路由冲突。解决方案：在App.tsx中注册两个独立route：
```tsx
<Route path="/booking" element={<BookingConfirm />} />
<Route path="/booking/:orderId" element={<BookingConfirm />} />
```
组件内部通过`useSearchParams`和`useParams`区分。

## 验证清单

```bash
# ✅ 编译检查
cd frontend && npx tsc --noEmit && npx vite build

# ✅ 文件完整
ls frontend/src/api/client.ts
ls frontend/src/App.tsx
ls frontend/src/components/Layout.tsx
ls frontend/src/pages/{Home,SearchFlights,FlightDetail,BookingConfirm,Orders,OrderDetail,Chat}.tsx

# ✅ 后端联调（测试用）
python3 -c "from backend.main import app; print('✅ Backend OK')"
pytest tests/ -q | tail -1
```
