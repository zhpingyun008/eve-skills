# 中国大陆前端设计工具选型速查

> 结论：**shadcn/ui + TailwindCSS** 是唯一适合 AI Agent 自动化集成的方案。
> 即时设计/MasterGo 虽有中文站，但**均无 MCP 协议**，仅提供浏览器插件SDK。

---

## 可访问性测试 (2026-06-21)

| 平台 | URL | 可访问 | 类型 |
|------|-----|:------:|------|
| 即时设计 | js.design | ✅ 200 OK | React SPA |
| MasterGo | mastergo.com | ✅ 200 OK | React SPA |
| shadcn/ui 中文站 | shadcn.com.cn | ✅ 200 OK | 组件库文档 |
| npmmirror | registry.npmmirror.com | ✅ 208ms | npm镜像 |
| Google Stitch | stitch.withgoogle.com | ❌ GFW | — |

### CoDesign (腾讯) — 设计评审平台，不适合AI主动集成
- **可用**: codesign.qq.com ✅ 200 OK
- **功能**: 设计稿预览/标注/评论，非设计创建工具
- **Webhook**: ✅ 支持设计稿变更/评论事件推送（被动通知）
- **腾讯轻联 HiFlow**: ✅ 可打通 CoDesign → 飞书/企微（iPaaS）
- **缺陷**: ❌ 无公开 REST API
- **缺陷**: ❌ 无 MCP 协议
- **缺陷**: ❌ 无法程序化创建/编辑设计
- **定位**: 设计评审阶段使用，需设计师人工操作
- **结论**: AI Agent 可监听 CoDesign Webhook 接收通知，但无法主动操控。**仅适合有人工设计师参与的流程**。

## 各方案评价

### shadcn/ui + TailwindCSS (推荐 — 8.5/10)
- **白名单**: 无网络依赖，安装后离线可用
- **AI友好**: 代码即是设计，AI直接生成组件代码
- **npm**: 通过 npmmirror 安装，ping 208ms
- **验证**: `npm ping` ✅ | `npx shadcn@latest init -d` ✅
- **集成**: 已注入 react-frontend-gen 技能

### 即时设计 js.design / MasterGo (暂不推荐 — 6/10)
- **可用**: 网站可访问，功能强大，对标 Figma
- **缺陷**: ❌ 无 MCP Server 协议
- **缺陷**: ❌ 无公开 REST API（插件 SDK 需浏览器环境）
- **缺陷**: ❌ API 藏在 SPA 页面后，无法 curl
- **缺陷**: ❌ 插件开发需人工注册账号+手动操作
- **结论**: 对 AI Agent 来说，集成成本比 shadcn 高 10 倍。**不建议投入**。

### Ant Design (备选 — 7.5/10)
- 企业级后台管理系统适用
- npm 可装，npmmirror 可加速
- 风格固定，缺乏 shadcn 的"复制代码"灵活性

## 分层策略

```
场景A: 品牌落地页/官网 → shadcn/ui + TailwindCSS
场景B: 后台管理/数据面板 → Ant Design Pro
场景C: 营销图 → HTML+Playwright (现有)
场景D: 产品原型 → Stitch (VPN时激活，已就绪)
```

## 关键命令

```bash
# npm 国内镜像
npm config set registry https://registry.npmmirror.com

# shadcn 初始化
npx shadcn@latest init -d
npx shadcn@latest add button card input table badge dialog

# Stitch (需 VPN)
export STITCH_API_KEY='***'
stitch-mcp proxy
```
