#!/usr/bin/env python3
"""Health check for agent-skills/task-auto-healer"""
from pathlib import Path; import sys
md = Path(__file__).parent.parent / "SKILL.md"
if md.exists() and md.read_text().startswith("---"):
    print(f"OK: {md.parent.name} - verified"); sys.exit(0)
print(f"ERROR: {md.parent.name}"); sys.exit(1)
