---
name: task-auto-healer
description: Autonomous task failure diagnosis, repair, and retry engine for multi-agent task execution pipelines. Scans shared task queue for failed tasks, classifies failure via pattern matching (8 types including timeout, syntax, db-lock, dependency, resource, connection, permission, unknown), applies type-specific repair strategy, resets to pending for retry. Includes Dashboard backend plus frontend panels.
category: agent-skills
triggers:
  - 任务自愈
  - task auto-heal
  - 失败诊断
  - failed task repair
  - agent task healing
  - 自动修复任务
  - auto-heal tasks
  - task failure recovery
  - 任务失败自动修复
---

# Task Auto-Healer

Autonomous task failure diagnosis, repair, and retry engine for multi-agent task execution pipelines.

## Overview

When a multi-agent task execution pipeline (e.g., CMMI5 Agent Bridge with PM scheduler) identifies tasks in "failed" status, the auto-healer automatically:

1. **Scans** all failed tasks from shared state (SQLite)
2. **Diagnoses** the failure type via regex pattern matching on error messages
3. **Repairs** with a type-specific strategy
4. **Resets** the task to "pending" for re-execution
5. **Logs** every event for visibility

All operations are zero-confirmation, fully autonomous.

## Architecture

```
agent_bridge.py (shared state)
       |
auto_healer.py --- diagnose (classify error)
       |               |
       |         repair strategy
       |               |
       |         update_task_status("pending")
       |               |
       |         log event to auto_healer.log
       |
       +-- Cron integration (PM scheduler runs after every cycle)
       +-- Dashboard integration (auto_healer.py backend + HTMX panel)
```

## Failure Diagnosis (8 Types)

| Type | Patterns | Severity | Repair Strategy |
|---|---|---|---|
| TIMEOUT | `TimeoutExpired`, `timed out` | medium | increase_timeout (600s to 900s, retry) |
| SYNTAX_ERROR | `SyntaxError`, `ImportError`, `ModuleNotFoundError` | high | auto-install missing module (pip install) or auto-reset to pending |
| DB_LOCK | `database is locked`, `OperationalError` | low | clean WAL files, retry |
| DEPENDENCY | `No module`, `not found` | medium | auto pip install |
| RESOURCE | `OutOfMemory`, `No space left` | high | clean pip cache plus old logs |
| CONNECTION | `Connection refused`, `ConnectionError` | medium | wait 30s, retry |
| PERMISSION | `Permission denied` | medium | chmod fix |
| UNKNOWN | anything else | high | auto-reset and retry (logged to healer log) |

## Workflow

### 1. Scan + Diagnose + Repair

```bash
python3 ~/scripts/auto_healer.py
python3 ~/scripts/auto_healer.py --dry-run
python3 ~/scripts/auto_healer.py --task TEST-001
python3 ~/scripts/auto_healer.py --status
```

**SYNTAX_ERROR now fully autonomous**: When a task fails with `ModuleNotFoundError`, the auto-healer extracts the module name and runs `pip install <module>` automatically. If that fails or the error is a different syntax issue, it resets the task to pending for re-execution. No human intervention needed.

**UNKNOWN now auto-retries**: Previously escalated to human, now resets to pending with a log entry. The heuristic log records the raw error for later analysis.

### 2. Dashboard API

```
/api/auto-healer    full stats (events, types, recent)
/api/all            summary for HTMX polling
```

Response format:
```json
{
  "total_events": 15,
  "by_type": {"TIMEOUT": 8, "DB_LOCK": 4, "SYNTAX_ERROR": 3},
  "recent": ["[2026-05-21 00:35:00] [TIMEOUT] DEV task_001 | success"],
  "healthy": true
}
```

### 3. Cron Integration

The auto-healer runs as a post-step after the PM scheduler cron. The complete cron prompt chains: scheduler → auto-healer → feishu milestone push:

```
[AUTO-EXEC+HEAL] Execute CMMI5 PM scheduler with auto-exec. Then run: python3 ~/scripts/auto_healer.py. Then run: python3 ~/scripts/feishu-pusher.py --milestone. Report only if milestone message was generated (non-SILENT).
```

This way the same 5-minute cycle:
1. Schedules pending tasks (PM scheduler auto-exec)
2. Heals any failed tasks (auto_healer.py)
3. Pushes milestone completions to Feishu group (feishu-pusher.py --milestone)

The `--milestone` flag only generates output when an agent completes all its tasks (non-SILENT), avoiding spam.

## Files

| File | Purpose |
|---|---|
| `~/scripts/auto_healer.py` | Main engine: scan then diagnose then repair then log |
| `~/.hermes/logs/auto_healer.log` | Append-only event log |
| `~/projects/hermes-dashboard/backend/auto_healer.py` | Dashboard data provider |
| `~/projects/hermes-dashboard/frontend/routes.py` | API endpoint at `/api/auto-healer` |

## Pitfalls

- **Log format regex**: The log uses padded type fields like `[TIMEOUT        ]` (15 char width). Dashboard regex must use `r'\[(\w+)\s*\]'` NOT `r'\[(\w+)\]'` to handle padding spaces.
- **No failed tasks = nothing to heal**: The dry-run mode is useful for verifying the scanner works without side effects.
- **UNKNOWN type now auto-retries**: Previously escalated, now resets to pending. Check `auto_healer.log` for raw error context.
- **DB_LOCK repair deletes WAL**: Use with caution if other concurrent writers exist.
- **Cron prompt update required**: Adding auto-healer to a cron prompt only works if the cron template is explicit about running the script.

## Dashboard Integration Steps

To add auto-healer panel to an existing Hermes Dashboard:

1. Create `backend/auto_healer.py` with `get_healer_stats()` and `get_healer_summary()`
2. Add import plus API route in `routes.py`
3. Add `/api/auto-healer` endpoint
4. Add `auto_healer` to `/api/all` response
5. Add frontend HTML card plus JS update logic
6. Add CSS stanzas for `.auto-healer-stat`, `.healer-stat-value`, `.auto-healer-log`
7. Restart Dashboard

## Verification

```bash
# Test the engine
python3 ~/scripts/auto_healer.py --dry-run
# Expected: "no failed tasks" or shows diagnosed failures

# Test Dashboard API
curl -s http://127.0.0.1:8050/api/auto-healer | python3 -m json.tool

# Test in /api/all
curl -s http://127.0.0.1:8050/api/all | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('auto_healer',{}))"
```
