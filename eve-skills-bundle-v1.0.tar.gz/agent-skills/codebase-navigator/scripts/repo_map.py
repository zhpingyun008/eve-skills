#!/usr/bin/env python3
"""
Repo-Map: Lightweight code repository semantic mapper
Builds a dependency graph and symbol index for a codebase.
Inspired by Aider's map-repo.
"""
import sys
import re
import json
from pathlib import Path
from collections import defaultdict


def extract_imports(filepath: str) -> list:
    """Extract Python import statements"""
    try:
        content = Path(filepath).read_text()
    except Exception:
        return []
    
    imports = []
    for line in content.split('\n'):
        # Match: import X, from X import Y
        m = re.match(r'^(?:from\s+(\S+)\s+)?import\s+(.+)', line.strip())
        if m:
            module = m.group(1) or m.group(2).split(',')[0].strip().split()[0]
            imports.append(module)
    
    return imports


def extract_functions(filepath: str) -> list:
    """Extract function/class definitions"""
    try:
        content = Path(filepath).read_text()
    except Exception:
        return []
    
    symbols = []
    for i, line in enumerate(content.split('\n'), 1):
        m = re.match(r'^(?:async\s+)?(?:def|class)\s+(\w+)', line.strip())
        if m:
            symbols.append({"name": m.group(1), "line": i, "type": "class" if "class" in line else "function"})
    
    return symbols


def build_dependency_graph(root_dir: str, glob_pattern: str = "*.py") -> dict:
    """Build dependency graph for a codebase"""
    root = Path(root_dir)
    if not root.is_dir():
        return {"error": f"Not a directory: {root_dir}"}
    
    files_map = {}
    import_map = defaultdict(list)
    symbols_map = {}
    
    for f in root.rglob(glob_pattern):
        if '.venv' in str(f) or 'node_modules' in str(f) or '__pycache__' in str(f):
            continue
        
        rel_path = str(f.relative_to(root))
        files_map[rel_path] = {
            "size": f.stat().st_size,
            "lines": len(f.read_text().split('\n')) if f.exists() else 0,
        }
        
        imports = extract_imports(str(f))
        symbols = extract_functions(str(f))
        
        if imports:
            import_map[rel_path] = imports
        if symbols:
            symbols_map[rel_path] = symbols
    
    # Build reverse dependency map
    dependents = defaultdict(list)
    for file_path, imports in import_map.items():
        for imp in imports:
            # Try to match import to a file
            for known_file in files_map:
                base = known_file.replace('.py', '').replace('/', '.')
                if imp == base or imp.startswith(base):
                    dependents[known_file].append(file_path)
    
    return {
        "root": str(root),
        "total_files": len(files_map),
        "files": files_map,
        "imports": dict(import_map),
        "dependents": dict(dependents),
        "symbols": symbols_map,
        "most_depended_on": sorted(dependents.items(), key=lambda x: len(x[1]), reverse=True)[:10],
    }


def print_map(graph: dict):
    """Pretty-print the repo map"""
    if "error" in graph:
        print(f"ERROR: {graph['error']}")
        return
    
    print(f"\n╔══════════════════════════════════════════════════╗")
    print(f"║  Repository Map: {graph['root'][:30]:<30} ║")
    print(f"╠══════════════════════════════════════════════════╣")
    print(f"║  Total files: {graph['total_files']:<36} ║")
    print(f"║  Files with imports: {len(graph['imports']):<29} ║")
    print(f"║  Files with symbols: {len(graph['symbols']):<28} ║")
    print(f"╠══════════════════════════════════════════════════╣")
    print(f"║  Most Depended-On Files:                        ║")
    
    for file_path, deps in graph.get("most_depended_on", [])[:8]:
        print(f"║  {len(deps):>3} deps ← {file_path[:35]:<35} ║")
    
    print(f"╚══════════════════════════════════════════════════╝")


def main():
    if len(sys.argv) < 2:
        print("Usage: repo_map.py <directory> [glob_pattern] [--json]")
        print("Examples:")
        print("  repo_map.py ~/project")
        print("  repo_map.py ~/project '*.py' --json")
        sys.exit(1)
    
    root_dir = sys.argv[1]
    glob_pat = "*.py"
    json_out = False
    
    for arg in sys.argv[2:]:
        if arg == '--json':
            json_out = True
        elif not arg.startswith('--'):
            glob_pat = arg
    
    graph = build_dependency_graph(root_dir, glob_pat)
    
    if json_out:
        print(json.dumps(graph, indent=2, default=str))
    else:
        print_map(graph)


if __name__ == "__main__":
    main()
