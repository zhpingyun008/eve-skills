#!/usr/bin/env python3
"""semantic-search — Embedding-based code semantic search"""

import sys, json, os, re, ast, math
from pathlib import Path
from datetime import datetime
from collections import defaultdict
from typing import Dict, List, Tuple

INDEX_DIR = Path.home() / ".hermes" / "code_index"

def chunk_code(filepath: str) -> List[Dict]:
    """Chunk a source file into searchable blocks"""
    try:
        content = Path(filepath).read_text()
    except:
        return []
    
    chunks = []
    
    # Try AST-based chunking for Python
    if filepath.endswith(".py"):
        try:
            tree = ast.parse(content)
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.ClassDef)):
                    start = node.lineno
                    end = node.end_lineno if hasattr(node, 'end_lineno') else start + 5
                    chunk_lines = content.split('\n')[start-1:end]
                    chunks.append({
                        "type": type(node).__name__.replace("Def", ""),
                        "name": node.name,
                        "file": filepath,
                        "line_start": start,
                        "line_end": end,
                        "code": '\n'.join(chunk_lines),
                        "docstring": ast.get_docstring(node) or "",
                    })
        except SyntaxError:
            pass
    
    # Fallback: line-based chunking
    if not chunks:
        lines = content.split('\n')
        for i in range(0, len(lines), 20):
            chunk_lines = lines[i:i+20]
            chunks.append({
                "type": "block",
                "name": f"{filepath}:{i+1}",
                "file": filepath,
                "line_start": i + 1,
                "line_end": min(i + 20, len(lines)),
                "code": '\n'.join(chunk_lines),
                "docstring": "",
            })
    
    return chunks

def simple_vectorize(text: str) -> List[float]:
    """Simple TF-IDF-like vectorization (no external deps)"""
    # Tokenize
    tokens = re.findall(r'[a-zA-Z_][a-zA-Z0-9_]*', text.lower())
    
    # Keyword weights for code-specific terms
    code_keywords = {
        "auth": 3.0, "login": 2.5, "token": 2.5, "password": 3.0,
        "database": 2.0, "query": 2.0, "sql": 2.0, "connect": 1.5,
        "api": 2.0, "endpoint": 2.0, "route": 2.0, "handler": 2.0,
        "config": 1.5, "setting": 1.5, "environment": 1.5,
        "test": 1.5, "mock": 1.5, "fixture": 1.5,
        "error": 1.5, "exception": 1.5, "catch": 1.5,
        "cache": 2.0, "redis": 2.5, "memcache": 2.5,
        "queue": 2.0, "kafka": 2.5, "rabbitmq": 2.5,
        "deploy": 1.5, "docker": 2.0, "kubernetes": 2.5,
    }
    
    vector = defaultdict(float)
    for token in tokens:
        weight = code_keywords.get(token, 1.0)
        vector[token] += weight
    
    # Normalize
    norm = math.sqrt(sum(v*v for v in vector.values()))
    if norm > 0:
        return [{k: v/norm} for k, v in sorted(vector.items())]
    return []

def cosine_similarity(vec1: Dict[str, float], vec2: Dict[str, float]) -> float:
    """Calculate cosine similarity between two sparse vectors"""
    all_keys = set(vec1.keys()) | set(vec2.keys())
    dot = sum(vec1.get(k, 0) * vec2.get(k, 0) for k in all_keys)
    norm1 = math.sqrt(sum(v*v for v in vec1.values()))
    norm2 = math.sqrt(sum(v*v for v in vec2.values()))
    if norm1 == 0 or norm2 == 0:
        return 0
    return dot / (norm1 * norm2)

def semantic_search(query: str, source_dir: str = ".", top_k: int = 10) -> List[Dict]:
    """Search code semantically"""
    query_vec = {}
    for d in simple_vectorize(query):
        query_vec.update(d)
    
    results = []
    source_path = Path(source_dir)
    
    # Collect all code files
    code_files = []
    for ext in ["*.py", "*.js", "*.ts", "*.go", "*.rs", "*.java"]:
        code_files.extend(source_path.rglob(ext))
    
    # Limit to 200 files for performance
    code_files = code_files[:200]
    
    for filepath in code_files:
        if "test" in str(filepath).lower() and "test" not in query.lower():
            continue  # Skip test files unless searching for tests
        
        chunks = chunk_code(str(filepath))
        for chunk in chunks:
            # Combine docstring + code for better matching
            search_text = (chunk["docstring"] + " " + chunk["code"])[:500]
            chunk_vec = {}
            for d in simple_vectorize(search_text):
                chunk_vec.update(d)
            
            sim = cosine_similarity(query_vec, chunk_vec)
            if sim > 0.05:  # Minimum relevance threshold
                results.append({
                    "file": chunk["file"],
                    "line": chunk["line_start"],
                    "name": chunk["name"],
                    "type": chunk["type"],
                    "score": round(sim, 4),
                    "preview": chunk["code"][:200],
                })
    
    # Sort by relevance
    results.sort(key=lambda x: -x["score"])
    
    return results[:top_k]

def hybrid_search(query: str, source_dir: str = ".", top_k: int = 10) -> List[Dict]:
    """Hybrid: semantic + keyword search"""
    semantic_results = semantic_search(query, source_dir, top_k * 2)
    
    # Keyword grep as supplement
    keywords = re.findall(r'[a-zA-Z_][a-zA-Z0-9_]{2,}', query.lower())
    grep_results = []
    for kw in keywords[:3]:
        try:
            import subprocess
            r = subprocess.run(
                ["grep", "-rn", "--include=*.py", "--include=*.js", "--include=*.ts", kw, source_dir],
                capture_output=True, text=True, timeout=10
            )
            for line in r.stdout.strip().split('\n')[:10]:
                parts = line.split(':', 2)
                if len(parts) >= 3:
                    grep_results.append({
                        "file": parts[0],
                        "line": int(parts[1]) if parts[1].isdigit() else 0,
                        "name": kw,
                        "type": "grep",
                        "score": 0.3,
                        "preview": parts[2][:200],
                    })
        except:
            pass
    
    # Merge and deduplicate
    seen = set()
    merged = []
    for r in semantic_results + grep_results:
        key = f"{r['file']}:{r['line']}"
        if key not in seen:
            seen.add(key)
            merged.append(r)
    
    merged.sort(key=lambda x: -x["score"])
    return merged[:top_k]

def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return
    
    cmd = sys.argv[1]
    
    if cmd == "--check":
        # Check if sentence-transformers is available for better embeddings
        has_transformers = False
        try:
            import sentence_transformers
            has_transformers = True
        except:
            pass
        print(json.dumps({
            "status": "ok", "skill": "semantic-search",
            "embedding_mode": "sentence-transformers" if has_transformers else "tf-idf (fallback)",
            "capabilities": ["search", "hybrid", "index"]
        }))
    
    elif cmd == "--search":
        query = sys.argv[2] if len(sys.argv) > 2 else input("Search query: ")
        source = sys.argv[3] if len(sys.argv) > 3 else "."
        results = semantic_search(query, source)
        print(json.dumps({"query": query, "results_count": len(results), "results": results}, indent=2))
    
    elif cmd == "--hybrid":
        query = sys.argv[2] if len(sys.argv) > 2 else input("Search query: ")
        source = sys.argv[3] if len(sys.argv) > 3 else "."
        results = hybrid_search(query, source)
        print(json.dumps({"query": query, "results_count": len(results), "results": results}, indent=2))
    
    elif cmd == "--index":
        source = sys.argv[2] if len(sys.argv) > 2 else "."
        INDEX_DIR.mkdir(parents=True, exist_ok=True)
        
        files = list(Path(source).rglob("*.py")) + list(Path(source).rglob("*.js"))
        chunk_count = 0
        for f in files[:500]:
            chunks = chunk_code(str(f))
            chunk_count += len(chunks)
        
        index_info = {
            "indexed_at": datetime.now().isoformat(),
            "files": len(files[:500]),
            "chunks": chunk_count,
            "directory": source,
        }
        (INDEX_DIR / "index_info.json").write_text(json.dumps(index_info, indent=2))
        print(json.dumps(index_info, indent=2))
    
    else:
        print(f"Unknown: {cmd}")

if __name__ == "__main__":
    main()
