# Repo-Map Reference

## Dependency Types
- **direct_import**: `import X` or `from X import Y`
- **transitive**: A imports B, B imports C → A transitively depends on C
- **circular**: A imports B, B imports A (anti-pattern)

## Symbol Types
- **function**: `def name(...)`
- **async_function**: `async def name(...)`
- **class**: `class Name(...)`
- **method**: Function inside a class

## Usage
1. Build map: `repo_map.py <dir>`
2. Find most-depended-on files (refactoring risk assessment)
3. Trace import chains for impact analysis
4. Identify orphan files (no dependents, no imports)

## Metrics
- Most-depended-on files → High refactoring risk
- Circular dependencies → Architecture smell
- Deep import chains (>5 levels) → Coupling issue
