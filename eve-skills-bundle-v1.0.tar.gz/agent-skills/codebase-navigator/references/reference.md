# Symbol Index — Reference

## ctags 配置参考

### 默认 tags 文件格式

```
symbol_name<TAB>file_path<TAB>ex_command;"<TAB>kind:type<TAB>...
```

示例:
```
authenticate	auth.py	/^def authenticate(/;"	kind:function	line:42
User	models.py	/^class User(/;"	kind:class	line:15
```

### 常用 ctags 选项

| 选项 | 说明 |
|------|------|
| `-R` | 递归索引 |
| `-f .tags` | 指定输出文件 |
| `--languages=...` | 限制语言 |
| `--kinds-all=...` | 符号种类过滤 |
| `--fields=+n` | 包含行号 |
| `--exclude=node_modules` | 排除目录 |

### 语言支持清单

ctags 原生支持以下语言（部分列表）:

- Python (.py)
- JavaScript (.js, .mjs, .cjs)
- TypeScript (.ts, .tsx)
- Go (.go)
- Rust (.rs)
- Java (.java)
- C (.c, .h)
- C++ (.cpp, .cc, .cxx, .hpp)
- Ruby (.rb)
- PHP (.php)
- Shell (.sh, .bash)
- Makefile
- YAML (.yaml, .yml)
- JSON (.json)
- Markdown (.md)
- Lua (.lua)
- Perl (.pl, .pm)

完整列表: `ctags --list-languages`

### grep fallback 策略

当 ctags 不可用时，使用以下 ripgrep/grep 模式:

**查找Python函数定义:**
```bash
rg "^def\s+func_name\b" -n
rg "^async def\s+func_name\b" -n
```

**查找Python类定义:**
```bash
rg "^class\s+ClassName\b" -n
```

**查找变量赋值:**
```bash
rg "^\s*var_name\s*=" -n
```

**查找引用（所有出现位置）:**
```bash
rg "\bsymbol_name\b" -n
```

### .gitignore 建议

```
.tags
*.ctags
tags
```

### 性能指标

| 代码库规模 | ctags 索引时间 | rg 搜索时间 |
|-----------|--------------|------------|
| ~1K 文件 | <1s | <0.1s |
| ~10K 文件 | 2-5s | <0.5s |
| ~100K 文件 | 20-60s | 1-3s |

### 集成示例

```bash
# 快速跳转定义（返回文件:行号）
ctags -R -f .tags . && grep "^auth_user\b" .tags

# 查找所有调用auth_user的位置
rg "auth_user\(" --glob '!*.pyc' -n

# 搜索包含"parse"的符号
rg "parse" .tags --no-filename | cut -f1 | sort -u
```
