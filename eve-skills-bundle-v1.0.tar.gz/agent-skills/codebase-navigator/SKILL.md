---
author: hermes
description: 代码库导航三合一 — 语义搜索(自然语言描述搜代码)+仓库地图(文件依赖图+架构热点图)+符号索引(ctags/ripgrep快速符号定位)。对标Claude Code semantic search + Aider map-repo + ctags IDE导航。
name: codebase-navigator
version: '1.0'
category: agent-skills
triggers:
  - 代码库搜索
  - codebase navigation
  - semantic search
  - 语义搜索
  - symbol index
  - 符号索引
---

# codebase-navigator — 代码库导航三合一

对标: Claude Code semantic search + Aider map-repo + ctags IDE navigation + Cursor codebase indexing
评级: ★★★★★ (P0核心技能 — 三位一体)

## 概述

集三种代码导航能力于一体：

1. **Semantic Search** (语义搜索) — 用自然语言描述意图搜索代码，突破关键词限制
2. **Repo Map** (仓库地图) — 构建文件依赖图和架构热点图，厘清模块关系
3. **Symbol Index** (符号索引) — ctags/ripgrep 快速符号搜索，支持跳转定义和查找引用

## 1. 语义搜索 (Semantic Search)

突破关键词grep限制，用自然语言描述意图搜索代码：

- "找到认证逻辑" → 返回auth/login相关代码
- "哪里处理了支付回调" → 返回payment webhook handler
- "数据库连接池配置在哪" → 返回DB pool config

### 原理

```
代码文件 → 分块(chunk) → Embedding向量 → 向量索引
查询文本 → Embedding → 相似度计算 → 排序返回
```

### Phase 1: Index

```bash
python3 ~/.hermes/skills/agent-skills/codebase-navigator/scripts/semantic_search.py --index src/
```

- 扫描代码文件
- 按函数/类/块分割
- 生成embedding向量 (使用sentence-transformers或API)
- 存储向量索引 (.hermes/code_index/)

### Phase 2: Search

```bash
python3 ~/.hermes/skills/agent-skills/codebase-navigator/scripts/semantic_search.py --search "authentication logic"
```

- 查询文本→embedding
- 余弦相似度匹配
- 返回Top-K相关代码块(含文件路径+行号+代码片段)

### Phase 3: Update

```bash
python3 ~/.hermes/skills/agent-skills/codebase-navigator/scripts/semantic_search.py --update
```

增量更新索引(只处理变更文件)。

### Phase 4: Hybrid Search

```bash
python3 ~/.hermes/skills/agent-skills/codebase-navigator/scripts/semantic_search.py --hybrid "JWT token validation"
```

关键词+语义混合搜索，取交集/并集排序。

### 技术方案

**本地方案 (离线)**:
- sentence-transformers (all-MiniLM-L6-v2)
- FAISS向量索引
- 适合≤10万行代码库

**API方案 (在线)**:
- OpenAI text-embedding-3-small
- 适合任意规模, 按token计费

**回退方案**: TF-IDF关键词匹配 (无embedding时, 仍优于纯grep)

## 2. 仓库地图 (Repo Map)

Before any multi-file code change, build a lightweight semantic map of the repository.

### Step 1: Scan Structure

```
search_files('.', 'content', 'package.json|setup.py|Cargo.toml|go.mod|pom.xml|requirements.txt')
→ Identify project type and root
search_files('.', 'files', '*.py') or '*.ts' or '*.go' or '*.rs'
→ Get all source files
```

### Step 2: Extract Imports & Exports

For each source file (prioritize recently modified + top-level):

- **Python**: `import X`, `from X import Y` / `def fn`, `class Cls`, `__all__`
- **TypeScript/JavaScript**: `import ... from '...'`, `require('...')` / `export function/class/const`
- **Go**: `import (...)` / `func FuncName`, capital-first-letter = exported
- **Rust**: `use ...` / `pub fn/struct/trait/mod`

### Step 3: Build Dependency Graph

```
file_a.py → [file_b.py, file_c.py]   # file_a depends on file_b and file_c
```

Identify:
- Leaf nodes (no dependents) — safest to edit
- Hub nodes (many dependents) — edit with caution
- Entry points (main.py, index.ts, cmd/) — system boundary

### Step 4: Output Map

```
【代码仓库语义地图】
项目类型: Python / FastAPI
源文件数: 23
入口点: src/main.py, src/cli.py

核心依赖图:
  src/main.py → src/routes/*, src/models/*, src/services/*
  src/services/auth.py → src/models/user.py, src/utils/hash.py

枢纽节点(高风险编辑): src/models/user.py (12 dependents)
叶节点(安全编辑): src/utils/hash.py, src/config.py

关键符号索引:
  src/services/auth.py: authenticate(), create_token(), revoke_token()
  src/models/user.py: class User, class UserRole
```

### Step 5: Use for Refactoring

1. Check repo-map for affected files
2. Trace dependency chain
3. Estimate blast radius
4. Include affected files in the edit plan

### Scope Limits

- Default: scan up to 50 source files
- Skip: node_modules, .venv, __pycache__, .git, dist, build, target
- Prioritize: recently modified files (git diff --name-only) + matching user's change description

## 3. 符号索引 (Symbol Index)

Using `ctags` (Universal Ctags) or fallback to `ripgrep` for text-level symbol search. Supports 40+ languages.

### Step 1: Check/Generate Index

```bash
if [ -f .tags ] && [ "$(find . -name '*.py' -newer .tags | wc -l)" -eq 0 ]; then
    echo "索引已是最新"
else
    ctags -R -f .tags --languages=Python,JavaScript,TypeScript,Go,Rust,Java,C,C++ .
fi
```

### Step 2: Find Definition

```bash
# 精确匹配符号定义
grep "^symbol_name\b" .tags | head -20

# 模糊匹配（ripgrep）
rg "^$SYMBOL\b" .tags -n
```

### Step 3: Find References

```bash
# 在源码中搜索符号引用（排除定义行）
rg "\b$SYMBOL\b" --type-add 'code:*.{py,js,ts,go,rs}' -t code -n
```

### Step 4: Symbol Search

```bash
# 交互式符号搜索
rg "^(\w*${QUERY}\w*)" .tags -n --no-filename | cut -f1 | sort -u
```

### Scripts

| 脚本 | 来源 | 用途 |
|------|------|------|
| `scripts/semantic_search.py` | semantic-search | 语义搜索主脚本 |
| `scripts/repo_map.py` | repo-map | 仓库地图构建脚本 |
| `scripts/check.py` | symbol-index | 环境检查脚本 |

### References

| 文件 | 来源 | 内容 |
|------|------|------|
| `references/reference.md` | semantic-search | 语义搜索配置参考 |
| `references/reference.md` | symbol-index | ctags配置参考与语言支持 |
| `references/repo_map_guide.md` | repo-map | 仓库地图使用指南 |

### 依赖

- `ctags` (Universal Ctags recommended)
- `ripgrep` (rg) 或 `grep` (fallback)
- Python: sentence-transformers / FAISS (semantic search)
- OpenAI API key (optional, for API-based embedding)

```bash
# Ubuntu/Debian
sudo apt install universal-ctags ripgrep
pip3 install sentence-transformers faiss-cpu numpy

# macOS
brew install universal-ctags ripgrep
```

### Pitfalls

- 首次索引需时间 (1000文件≈30s); 大型代码库ctags首次索引也需几秒到几十秒
- Embedding API费用(按token)
- 跨语言代码语义搜索精度有限
- Regex-based import extraction is NOT as precise as LSP — mark results as "best-effort"
- For very large repos (500+ files), scan only top-level and recently changed
- Dynamic imports (importlib, require() with variables) may be missed
- ctags 对动态语言（Python/JS）的定义识别不如LSP精确
- .tags 文件建议加入 .gitignore

## Verification

```bash
# Semantic search health check
python3 ~/.hermes/skills/agent-skills/codebase-navigator/scripts/semantic_search.py --check

# Repo map health check
python3 ~/.hermes/skills/agent-skills/codebase-navigator/scripts/repo_map.py --check 2>/dev/null || echo "repo_map.py may not support --check flag"

# Symbol index environment check
python3 ~/.hermes/skills/agent-skills/codebase-navigator/scripts/check.py
```

## Integration

- **codebase-learner**: 首次进入代码库时自动索引
- **bug-fixer**: bug定位时语义搜索相似代码
- **context-loader**: 结合仓库地图提供代码上下文
- **multi-file-refactor**: 跨文件重构前使用导航信息规划影响范围

---
## Feedback Engine Patches
*自动生成于 2026-07-14 02:02:41*

## Tool Recommendations (from trajectory feedback)

### search_files
Trajectory analysis shows **search_files** strongly correlates with high session scores.
- Use instead of grep/rg/find in terminal.
- Content search: regex inside files (faster than shell grep).
- File search: glob patterns with results sorted by modification time.
- Supports output modes: `content`, `files_only`, `count`.

### Guardrails
- Regex patterns: ensure proper escaping for special characters.
- File globs: use simple patterns like `*.py`, `*config*`.
- For large directory trees, narrow with `path` parameter.

### Efficiency Tips
- Combine content search with `output_mode='files_only'` for fast file discovery.
- Use `context=N` for surrounding lines around matches.
- Limit results with `limit` parameter to avoid overwhelming output.

---
## Feedback Engine Patches
*自动生成于 2026-07-21 08:58:12*

## Tool Recommendations (from trajectory feedback)

### search_files
Trajectory analysis shows **search_files** strongly correlates with high session scores.
- Use instead of grep/rg/find in terminal.
- Content search: regex inside files (faster than shell grep).
- File search: glob patterns with results sorted by modification time.
- Supports output modes: `content`, `files_only`, `count`.

### Guardrails
- Regex patterns: ensure proper escaping for special characters.
- File globs: use simple patterns like `*.py`, `*config*`.
- For large directory trees, narrow with `path` parameter.

### Efficiency Tips
- Combine content search with `output_mode='files_only'` for fast file discovery.
- Use `context=N` for surrounding lines around matches.
- Limit results with `limit` parameter to avoid overwhelming output.

---
## Feedback Engine Patches
*自动生成于 2026-07-22 12:19:48*

## Tool Recommendations (from trajectory feedback)

### search_files
Trajectory analysis shows **search_files** strongly correlates with high session scores.
- Use instead of grep/rg/find in terminal.
- Content search: regex inside files (faster than shell grep).
- File search: glob patterns with results sorted by modification time.
- Supports output modes: `content`, `files_only`, `count`.

### Guardrails
- Regex patterns: ensure proper escaping for special characters.
- File globs: use simple patterns like `*.py`, `*config*`.
- For large directory trees, narrow with `path` parameter.

### Efficiency Tips
- Combine content search with `output_mode='files_only'` for fast file discovery.
- Use `context=N` for surrounding lines around matches.
- Limit results with `limit` parameter to avoid overwhelming output.
